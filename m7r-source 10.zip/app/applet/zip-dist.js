import AdmZip from 'adm-zip';
import fs from 'fs';
import path from 'path';

const zip = new AdmZip();
const distPath = path.resolve('dist');
const outputPath = path.resolve('public/dist.zip');

if (fs.existsSync(distPath)) {
  zip.addLocalFolder(distPath);
  zip.writeZip(outputPath);
  console.log('Successfully created public/dist.zip');
} else {
  console.error('dist folder does not exist. Run npm run build first.');
}
