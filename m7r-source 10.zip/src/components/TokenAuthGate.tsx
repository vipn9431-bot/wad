import React, { useState, useEffect, useRef } from 'react';
import {
  Server,
  Users,
  RefreshCw,
  Search,
  Crown,
  ShieldCheck,
  PlusCircle,
  Home,
  Star,
  Terminal,
  MessageSquare,
  Globe,
  X,
  Menu,
  ArrowLeft,
  ChevronLeft,
  LayoutGrid,
  Ticket,
  Shield,
  Sparkles,
  Gavel,
  Mic,
  Link2,
  Lock,
  Clock
} from 'lucide-react';
import { sound } from '../utils/sound';
import { ConnectedGuildItem, DiscordOAuthUser, AccessRoleMode } from '../types';
import { HeroLandingSection } from './HeroLandingSection';

export const OFFICIAL_OWNER_ID = '1219299588402577532';
export const CLOUD_API_BASE = '';

export interface AuthenticatedDiscordUser {
  id: string;
  username: string;
  globalName?: string;
  tag?: string;
  avatar?: string;
  isLoggedIn?: boolean;
  isOwner?: boolean;
  isMasterOwner?: boolean;
}

export interface ConnectedBotData {
  id: string;
  username: string;
  discriminator?: string;
  tag: string;
  avatar: string;
  verified?: boolean;
  guildsCount: number;
  membersCount: number;
  channelsCount: number;
  ping?: number;
  pingMs?: number;
  mode?: 'live' | 'demo';
  accessMode?: AccessRoleMode;
  discordUser?: AuthenticatedDiscordUser;
  connectedAt?: string;
  inviteUrl?: string;
  permissionsBitfield?: string;
  guilds?: ConnectedGuildItem[];
  selectedGuild?: ConnectedGuildItem;
}

export const DEFAULT_CONNECTED_GUILDS: ConnectedGuildItem[] = [
  {
    id: '1492318940192831100',
    name: 'm7r',
    icon: '',
    memberCount: 146,
    channelsCount: 36,
    rolesCount: 18,
    ownerId: OFFICIAL_OWNER_ID,
    owner: true,
    hasManagePermission: true,
    botPresent: true,
    hasBot: true,
    features: ['COMMUNITY', 'AUTO_MODERATION']
  }
];

export const DEFAULT_M7R_BOT_DATA: ConnectedBotData = {
  id: '1564565916216336494',
  username: 'M7R',
  discriminator: '1624',
  tag: 'M7R#1624',
  avatar: 'https://cdn.discordapp.com/embed/avatars/0.png',
  verified: true,
  guildsCount: 1,
  membersCount: 146,
  channelsCount: 36,
  ping: 14,
  pingMs: 14,
  mode: 'live',
  connectedAt: new Date().toLocaleTimeString('ar-SA'),
  inviteUrl:
    'https://discord.com/oauth2/authorize?client_id=1564565916216336494&permissions=8&integration_type=0&scope=bot+applications.commands',
  permissionsBitfield: '8 (Administrator)',
  guilds: DEFAULT_CONNECTED_GUILDS,
  selectedGuild: DEFAULT_CONNECTED_GUILDS[0]
};

export function isOfficialBotOwnerUser(user: any): boolean {
  if (!user) return false;
  return String(user.id) === OFFICIAL_OWNER_ID || String(user.username || '').toLowerCase() === 'u5r9';
}

export function getStoredAuthToken(): string {
  try {
    return localStorage.getItem('m7r_auth_token') || '';
  } catch {
    return '';
  }
}

export function getAuthHeaders(): Record<string, string> {
  const token = getStoredAuthToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export function getSavedDiscordUser(): AuthenticatedDiscordUser | null {
  try {
    const raw = localStorage.getItem('m7r_discord_user');
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function getSavedAuthGuilds(): ConnectedGuildItem[] {
  try {
    const raw = localStorage.getItem('m7r_auth_guilds');
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveAuthSessionToStorage(
  token: string,
  user: AuthenticatedDiscordUser,
  guilds: ConnectedGuildItem[]
) {
  try {
    if (token) localStorage.setItem('m7r_auth_token', token);
    if (user) {
      localStorage.setItem('m7r_discord_user', JSON.stringify(user));
      localStorage.setItem('m7r_logged_in', 'true');
    }
    if (Array.isArray(guilds)) {
      localStorage.setItem('m7r_auth_guilds', JSON.stringify(guilds));
    }
  } catch {}
}

export function clearAuthSessionFromStorage() {
  try {
    localStorage.removeItem('m7r_auth_token');
    localStorage.removeItem('m7r_session_token');
    localStorage.removeItem('m7r_discord_user');
    localStorage.removeItem('m7r_logged_in_user');
    localStorage.removeItem('m7r_logged_in');
    localStorage.removeItem('m7r_auth_guilds');
    localStorage.removeItem('m7r_selected_guild');
    localStorage.removeItem('m7r_selected_guild_id');
  } catch {}
}

let cachedDiscordAuthPayload: {
  url: string;
  redirectUri: string;
  origin: string;
  fetchedAt: number;
} | null = null;

export function isAllowedOAuthMessageOrigin(origin: string): boolean {
  if (!origin) return false;
  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  return (
    origin === currentOrigin ||
    origin.endsWith('.run.app') ||
    origin.endsWith('.replit.app') ||
    origin.endsWith('.repl.co') ||
    origin.endsWith('.netlify.app') ||
    origin.includes('localhost') ||
    origin.includes('127.0.0.1')
  );
}

export async function prefetchOfficialDiscordOAuthUrl(clientId = ''): Promise<string | null> {
  if (typeof window === 'undefined') return null;
  try {
    const origin = window.location.origin;
    const redirectUri = `${origin}/auth/discord/callback`;
    const params = new URLSearchParams({
      origin,
      redirect_uri: redirectUri
    });
    if (clientId) {
      params.set('client_id', clientId);
    }
    const res = await fetch(`/api/auth/discord/url?${params.toString()}`, {
      credentials: 'include'
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data?.url && typeof data.url === 'string' && data.url.startsWith('https://discord.com/')) {
      cachedDiscordAuthPayload = {
        url: data.url,
        redirectUri: data.redirectUri || redirectUri,
        origin,
        fetchedAt: Date.now()
      };
      return data.url;
    }
    return null;
  } catch {
    return null;
  }
}

export function getOfficialDiscordOAuthUrl(clientId = '1564565916216336494'): string {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  if (
    cachedDiscordAuthPayload &&
    cachedDiscordAuthPayload.origin === origin &&
    Date.now() - cachedDiscordAuthPayload.fetchedAt < 5 * 60 * 1000
  ) {
    return cachedDiscordAuthPayload.url;
  }
  const redirectUri =
    origin.includes('ais-dev-') ||
    origin.includes('ais-pre-') ||
    origin.includes('bot-m7r.netlify.app') ||
    origin.includes('replit.app')
      ? `${origin}/auth/discord/callback`
      : 'https://ais-dev-3d6x76wht4gxuksotfbupe-804593892274.europe-west2.run.app/auth/discord/callback';
  const cid = clientId || '1564565916216336494';
  return `https://discord.com/oauth2/authorize?client_id=${encodeURIComponent(
    cid
  )}&redirect_uri=${encodeURIComponent(
    redirectUri
  )}&response_type=token&scope=identify%20guilds&prompt=consent`;
}

export function launchOfficialDiscordOAuthWindow(clientId = ''): {
  pollStartTs: number;
  popup: Window | null;
  popupBlocked: boolean;
} {
  const pollStartTs = Date.now();
  const origin = window.location.origin;
  const hasFreshCache =
    cachedDiscordAuthPayload &&
    cachedDiscordAuthPayload.origin === origin &&
    Date.now() - cachedDiscordAuthPayload.fetchedAt < 4 * 60 * 1000 &&
    cachedDiscordAuthPayload.url.startsWith('https://discord.com/');

  const popupFeatures = 'width=580,height=740,menubar=no,toolbar=no,status=no,resizable=yes,scrollbars=yes';

  if (hasFreshCache && cachedDiscordAuthPayload) {
    const providerUrl = cachedDiscordAuthPayload.url;
    // Open Discord's official OAuth2 authorization URL directly in popup (never a container route)
    const popup = window.open(providerUrl, 'oauth_popup', popupFeatures);
    // Refresh cache in background for future attempts with a fresh signed state
    prefetchOfficialDiscordOAuthUrl(clientId).catch(() => {});
    return { pollStartTs, popup, popupBlocked: !popup };
  }

  // Open blank popup synchronously during click gesture to bypass popup blockers, then load Discord's provider URL
  const popup = window.open('about:blank', 'oauth_popup', popupFeatures);
  if (popup) {
    try {
      popup.document.write(
        '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"/><title>Discord OAuth2 | M7R</title></head>' +
          '<body style="background:#05070a;color:#e2e8f0;font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;">' +
          '<div><h3 style="color:#5865F2;margin-bottom:8px;">⏳ جاري الاتصال بصفحة Discord الرسمية...</h3>' +
          '<p style="color:#94a3b8;font-size:13px;">سيتم تحويلك تلقائياً خلال لحظة للموافقة الآمنة.</p></div></body></html>'
      );
      popup.document.close();
    } catch {
      // ignore document write error
    }
  }

  prefetchOfficialDiscordOAuthUrl(clientId)
    .then((freshUrl) => {
      const targetUrl = freshUrl || getOfficialDiscordOAuthUrl(clientId || undefined);
      if (popup && !popup.closed) {
        popup.location.href = targetUrl;
      }
    })
    .catch(() => {
      const fallbackUrl = getOfficialDiscordOAuthUrl(clientId || undefined);
      if (popup && !popup.closed) {
        popup.location.href = fallbackUrl;
      }
    });

  return { pollStartTs, popup, popupBlocked: !popup };
}

export async function verifyDiscordHashTokenIfPresent(): Promise<{
  user: DiscordOAuthUser;
  guilds: ConnectedGuildItem[];
  token: string;
} | null> {
  try {
    const hash = window.location.hash;
    if (!hash || !hash.includes('access_token=')) return null;
    const params = new URLSearchParams(hash.replace(/^#/, ''));
    const accessToken = params.get('access_token');
    if (!accessToken) return null;
    const res = await fetch('/api/auth/discord/verify-token', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ accessToken })
    });
    if (res.ok) {
      const data = await res.json();
      if (data?.user && (data?.token || data?.sessionToken)) {
        const finalToken = data.token || data.sessionToken;
        const guilds = Array.isArray(data.guilds) ? data.guilds : [];
        saveAuthSessionToStorage(finalToken, data.user, guilds);
        try {
          sessionStorage.setItem('m7r_active_dashboard_unlocked', 'true');
        } catch {}
        window.history.replaceState({}, document.title, window.location.pathname);
        return {
          user: data.user,
          guilds,
          token: finalToken
        };
      }
    }
    window.history.replaceState({}, document.title, window.location.pathname);
    return null;
  } catch {
    return null;
  }
}

export async function fetchAndApplyLiveGuildDetails(
  guildId: string
): Promise<{
  guild?: Partial<ConnectedGuildItem>;
  channels: { id: string; name: string; type: 'text' | 'voice' | 'category'; guildId?: string }[];
  textChannels?: { id: string; name: string }[];
  voiceChannels?: { id: string; name: string }[];
  categories?: { id: string; name: string }[];
  roles: { id: string; name: string; color: string }[];
  memberCount?: number;
} | null> {
  try {
    const res = await fetch(`/api/guilds/${encodeURIComponent(guildId)}/details`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) return null;
    const data = await res.json();
    return {
      guild: data?.guild,
      channels: Array.isArray(data?.channels) ? data.channels : [],
      textChannels: Array.isArray(data?.textChannels) ? data.textChannels : undefined,
      voiceChannels: Array.isArray(data?.voiceChannels) ? data.voiceChannels : undefined,
      categories: Array.isArray(data?.categories) ? data.categories : undefined,
      roles: Array.isArray(data?.roles) ? data.roles : [],
      memberCount: data?.memberCount
    };
  } catch {
    return null;
  }
}

export async function downloadZipBundle() {
  window.location.href = '/api/export/replit-bundle';
}

export async function downloadStandaloneWebHtmlFile() {
  try {
    const res = await fetch('/api/export/web-html');
    if (res.ok) {
      const data = await res.json();
      if (data?.html) {
        const blob = new Blob([data.html], { type: 'text/html;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'index.html';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 3000);
        return;
      }
    }
  } catch {}
  window.location.href = '/api/download-web-file';
}

export type PortalFlowStep = 'landing' | 'discord_oauth' | 'select_server';

interface TokenAuthGateProps {
  lang: 'ar' | 'en';
  setLang?: (lang: 'ar' | 'en') => void;
  currentBot?: ConnectedBotData | null;
  initialStep?: PortalFlowStep | 'discord_login';
  onOAuthLoginSuccess?: (user: DiscordOAuthUser, guilds: ConnectedGuildItem[], token: string) => void;
  onAuthenticated?: (botData: ConnectedBotData, token: string, oauthUser?: DiscordOAuthUser) => void;
  onConnected?: (botData: ConnectedBotData) => void;
  onEnterDemoMode?: () => void;
  onClose?: () => void;
  isModal?: boolean;
}

const DiscordLogoSvg: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z" />
  </svg>
);

export const TokenAuthGate: React.FC<TokenAuthGateProps> = ({
  lang,
  setLang,
  currentBot = null,
  initialStep = 'landing',
  onOAuthLoginSuccess,
  onAuthenticated,
  onConnected
}) => {
  const isAr = lang === 'ar';

  const normalizeStep = (s?: string): PortalFlowStep => {
    if (s === 'discord_login' || s === 'discord_oauth' || s === 'select_server') return 'select_server';
    return 'landing';
  };

  const [oauthUser, setOauthUser] = useState<DiscordOAuthUser | null>(() => {
    try {
      const token = getStoredAuthToken();
      const saved = localStorage.getItem('m7r_discord_user') || localStorage.getItem('m7r_logged_in_user');
      if (token && saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.id && parsed.username) return parsed;
      }
    } catch {}
    return null;
  });

  const [step, setStep] = useState<PortalFlowStep>(() => {
    const normalized = normalizeStep(initialStep);
    if (normalized === 'select_server') {
      const token = getStoredAuthToken();
      const saved = getSavedDiscordUser();
      if (token && saved?.id) return 'select_server';
    }
    return 'landing';
  });
  const [landingMenuOpen, setLandingMenuOpen] = useState(false);
  const [oauthLoading, setOauthLoading] = useState(false);
  const [refreshingServers, setRefreshingServers] = useState(false);
  const [selectingGuildId, setSelectingGuildId] = useState<string | null>(null);
  const [invitingGuildId, setInvitingGuildId] = useState<string | null>(null);
  const [statusToast, setStatusToast] = useState<string | null>(null);

  const [showSwitchAccountInputs, setShowSwitchAccountInputs] = useState(false);
  const [customUserIdInput, setCustomUserIdInput] = useState('');
  const [customUsernameInput, setCustomUsernameInput] = useState('');

  useEffect(() => {
    const normalized = normalizeStep(initialStep);
    if (normalized === 'select_server' && oauthUser?.id && getStoredAuthToken()) {
      setStep('select_server');
    } else if (normalized === 'landing') {
      setStep('landing');
    }
  }, [initialStep, oauthUser?.id]);

  const [botClientId, setBotClientId] = useState<string>(
    currentBot?.id || DEFAULT_M7R_BOT_DATA.id || '1564565916216336494'
  );
  const [dynamicInviteUrl, setDynamicInviteUrl] = useState<string>(
    currentBot?.inviteUrl ||
      DEFAULT_M7R_BOT_DATA.inviteUrl ||
      'https://discord.com/oauth2/authorize?client_id=1564565916216336494&permissions=8&integration_type=0&scope=bot+applications.commands'
  );
  const [botPingMs, setBotPingMs] = useState<number>(currentBot?.ping || 14);

  const [guildsList, setGuildsList] = useState<ConnectedGuildItem[]>(() => {
    if (!getStoredAuthToken() || !getSavedDiscordUser()?.id) return [];
    if (currentBot?.guilds && currentBot.guilds.length > 0) return currentBot.guilds;
    return getSavedAuthGuilds();
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [serverFilter, setServerFilter] = useState<'all' | 'yours' | 'invitable'>('all');

  // Rule 2: After OAuth2 login, show ONLY user's Manage Server list in `select_server` Hub to verify bot presence
  const completeRedirectToDashboardWithManageGuilds = (
    userObj: DiscordOAuthUser,
    manageServerGuilds: ConnectedGuildItem[],
    tokenStr?: string
  ) => {
    const finalToken = tokenStr || getStoredAuthToken();
    const finalGuilds = Array.isArray(manageServerGuilds) ? manageServerGuilds : [];

    if (finalToken && userObj) {
      saveAuthSessionToStorage(finalToken, userObj, finalGuilds);
    }
    setOauthUser(userObj);
    setGuildsList(finalGuilds);
    setStep('select_server');

    if (onOAuthLoginSuccess) {
      onOAuthLoginSuccess(userObj, finalGuilds, finalToken || '');
    }
  };

  const fetchLiveServers = async (playAudio = false): Promise<ConnectedGuildItem[]> => {
    setRefreshingServers(true);
    if (playAudio) sound.playClick();
    try {
      const hasToken = Boolean(getStoredAuthToken());
      const [meRes, botInfoRes, guildsRes] = await Promise.all([
        fetch('/api/auth/me', { headers: getAuthHeaders(), credentials: 'include' }).catch(() => null),
        fetch('/api/bot-info').catch(() => null),
        hasToken
          ? fetch('/api/guilds', { headers: getAuthHeaders(), credentials: 'include' }).catch(() => null)
          : Promise.resolve(null as any)
      ]);

      let mergedGuilds: ConnectedGuildItem[] = [];
      const seenIds = new Set<string>();
      let isOAuthAuthenticated = false;

      // Priority 1: Authenticated user's OAuth2 `Manage Server` (0x20 / 0x8 / Owner) guilds ONLY
      if (meRes && meRes.ok) {
        const meData = await meRes.json();
        if ((meData.authenticated || meData.isLoggedIn) && meData.user?.id) {
          isOAuthAuthenticated = true;
          setOauthUser(meData.user);
          try {
            localStorage.setItem('m7r_logged_in', 'true');
            localStorage.setItem('m7r_logged_in_user', JSON.stringify(meData.user));
            localStorage.setItem('m7r_discord_user', JSON.stringify(meData.user));
            if (meData.token) {
              localStorage.setItem('m7r_auth_token', meData.token);
            }
          } catch {}
        }
        if (Array.isArray(meData.guilds)) {
          for (const mg of meData.guilds) {
            if (mg && mg.id && !seenIds.has(String(mg.id))) {
              seenIds.add(String(mg.id));
              mergedGuilds.push({
                ...mg,
                hasManagePermission: true,
                botPresent: mg.botPresent !== false && mg.hasBot !== false,
                hasBot: mg.hasBot !== false && mg.botPresent !== false
              });
            }
          }
        }
      }

      // Priority 2: Authenticated /api/guilds fallback (strictly requires authenticated session)
      if (isOAuthAuthenticated && mergedGuilds.length === 0 && guildsRes && guildsRes.ok) {
        const gData = await guildsRes.json();
        if (gData?.authenticated && Array.isArray(gData.guilds)) {
          for (const g of gData.guilds) {
            if (g && g.id && !seenIds.has(String(g.id))) {
              seenIds.add(String(g.id));
              mergedGuilds.push({
                ...g,
                hasManagePermission: true,
                botPresent: g.botPresent !== false && g.hasBot !== false,
                hasBot: g.hasBot !== false && g.botPresent !== false
              });
            }
          }
        }
      }

      // Priority 3: Update live bot metadata & mark botPresent=true ONLY on guilds the user actually manages
      if (botInfoRes && botInfoRes.ok) {
        const bInfo = await botInfoRes.json();
        const resolvedClientId = bInfo.clientId || bInfo.applicationId || bInfo.id || '1564565916216336494';
        setBotClientId(resolvedClientId);
        setDynamicInviteUrl(
          bInfo.inviteUrl ||
            `https://discord.com/oauth2/authorize?client_id=${resolvedClientId}&permissions=8&integration_type=0&scope=bot+applications.commands`
        );
        if (typeof bInfo.ping === 'number' && bInfo.ping > 0) setBotPingMs(bInfo.ping);
        if (isOAuthAuthenticated && Array.isArray(bInfo.guilds) && bInfo.guilds.length > 0) {
          for (const bg of bInfo.guilds) {
            if (bg && bg.id) {
              const existingIdx = mergedGuilds.findIndex((x) => String(x.id) === String(bg.id));
              if (existingIdx >= 0) {
                mergedGuilds[existingIdx] = {
                  ...mergedGuilds[existingIdx],
                  ...bg,
                  hasManagePermission: true,
                  botPresent: true,
                  hasBot: true
                };
              }
            }
          }
        }
      }

      // Sort: servers where bot is already present first, then servers available to invite bot
      mergedGuilds.sort((a, b) => {
        const aPresent = a.hasBot !== false && a.botPresent !== false ? 1 : 0;
        const bPresent = b.hasBot !== false && b.botPresent !== false ? 1 : 0;
        return bPresent - aPresent;
      });

      if (isOAuthAuthenticated) {
        setGuildsList(mergedGuilds);
        try {
          localStorage.setItem('m7r_auth_guilds', JSON.stringify(mergedGuilds));
        } catch {}
        if (normalizeStep(initialStep) === 'select_server') {
          setStep('select_server');
        }
      } else {
        setGuildsList([]);
      }

      if (playAudio) {
        sound.playSuccess();
        setStatusToast(
          isAr
            ? `✅ تم فحص سيرفرات حسابك في Discord (${mergedGuilds.length} سيرفر تملك فيه صلاحية الإدارة)`
            : `✅ Refreshed your Discord admin servers (${mergedGuilds.length})`
        );
        setTimeout(() => setStatusToast(null), 4000);
      }
      return mergedGuilds;
    } catch {
      return guildsList;
    } finally {
      setRefreshingServers(false);
    }
  };

  const oauthPollTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    fetchLiveServers(false);
    prefetchOfficialDiscordOAuthUrl(botClientId).catch(() => {});
    return () => {
      if (oauthPollTimerRef.current) {
        clearInterval(oauthPollTimerRef.current);
        oauthPollTimerRef.current = null;
      }
    };
  }, []);

  // Listen for postMessage AND cross-tab localStorage updates from the Discord OAuth2 Popup (`/auth/discord/callback`)
  useEffect(() => {
    const handleOAuthMessage = (event: MessageEvent) => {
      if (!isAllowedOAuthMessageOrigin(event.origin)) {
        return;
      }
      const data = event.data;
      if (!data) return;

      if (data.type === 'OAUTH_AUTH_ERROR') {
        if (oauthPollTimerRef.current) {
          clearInterval(oauthPollTimerRef.current);
          oauthPollTimerRef.current = null;
        }
        sound.playError();
        setOauthLoading(false);
        setStatusToast(
          isAr
            ? `❌ تعذر إتمام تسجيل الدخول عبر Discord: ${String(data.error || 'خطأ في المصادقة')}`
            : `❌ Discord OAuth2 login failed: ${String(data.error || 'Authentication error')}`
        );
        setTimeout(() => setStatusToast(null), 8000);
        return;
      }

      if (data.type !== 'DISCORD_AUTH_SUCCESS' && data.type !== 'OAUTH_AUTH_SUCCESS') {
        return;
      }

      if (oauthPollTimerRef.current) {
        clearInterval(oauthPollTimerRef.current);
        oauthPollTimerRef.current = null;
      }

      sound.playSuccess();
      setOauthLoading(false);

      if (data.user) {
        setOauthUser(data.user);
      }
      const receivedGuilds: ConnectedGuildItem[] = Array.isArray(data.guilds) ? data.guilds : [];
      if (receivedGuilds.length > 0) {
        setGuildsList(receivedGuilds);
      }
      if (data.token && data.user) {
        saveAuthSessionToStorage(data.token, data.user, receivedGuilds);
      }

      if (data.user) {
        completeRedirectToDashboardWithManageGuilds(data.user, receivedGuilds, data.token);
      }
    };

    const handleStorageSync = (event: StorageEvent) => {
      if (event.key === 'm7r_discord_user' || event.key === 'm7r_auth_token') {
        try {
          const rawUser = localStorage.getItem('m7r_discord_user');
          const rawGuilds = localStorage.getItem('m7r_auth_guilds');
          const rawToken = localStorage.getItem('m7r_auth_token');
          if (rawUser) {
            const parsedUser = JSON.parse(rawUser);
            const parsedGuilds = rawGuilds ? JSON.parse(rawGuilds) : [];
            if (parsedUser && parsedUser.id) {
              if (oauthPollTimerRef.current) {
                clearInterval(oauthPollTimerRef.current);
                oauthPollTimerRef.current = null;
              }
              setOauthLoading(false);
              setOauthUser(parsedUser);
              if (Array.isArray(parsedGuilds) && parsedGuilds.length > 0) {
                setGuildsList(parsedGuilds);
              }
              sound.playSuccess();
              completeRedirectToDashboardWithManageGuilds(
                parsedUser,
                Array.isArray(parsedGuilds) ? parsedGuilds : [],
                rawToken || undefined
              );
            }
          }
        } catch {}
      }
    };

    window.addEventListener('message', handleOAuthMessage);
    window.addEventListener('storage', handleStorageSync);
    return () => {
      window.removeEventListener('message', handleOAuthMessage);
      window.removeEventListener('storage', handleStorageSync);
    };
  }, [isAr, botClientId]);

  // Launch REAL Official Discord OAuth2 Popup directly to Discord's authorization URL
  const handleTriggerRealDiscordOAuth = () => {
    sound.playClick();
    if (oauthPollTimerRef.current) {
      clearInterval(oauthPollTimerRef.current);
      oauthPollTimerRef.current = null;
    }
    setOauthLoading(true);
    const { pollStartTs, popupBlocked } = launchOfficialDiscordOAuthWindow(botClientId);

    if (popupBlocked) {
      setOauthLoading(false);
      sound.playError();
      setStatusToast(
        isAr
          ? '⚠️ المتصفح حظر النافذة المنبثقة! يرجى السماح بالنوافذ المنبثقة (Allow Popups) لإتمام تسجيل الدخول عبر Discord.'
          : '⚠️ Popup was blocked by your browser. Please allow popups for this site to connect Discord.'
      );
      setTimeout(() => setStatusToast(null), 7000);
      return;
    }

    let attempts = 0;
    const pollTimer = setInterval(async () => {
      attempts += 1;
      if (attempts > 60) {
        clearInterval(pollTimer);
        if (oauthPollTimerRef.current === pollTimer) {
          oauthPollTimerRef.current = null;
        }
        setOauthLoading(false);
        return;
      }
      try {
        const res = await fetch(`/api/me?poll_since=${pollStartTs}`, {
          headers: getAuthHeaders(),
          credentials: 'include'
        });
        if (res.ok) {
          const meData = await res.json();
          if (meData?.isLoggedIn && meData?.user?.id) {
            clearInterval(pollTimer);
            if (oauthPollTimerRef.current === pollTimer) {
              oauthPollTimerRef.current = null;
            }
            setOauthLoading(false);
            setOauthUser(meData.user);
            const userGuilds: ConnectedGuildItem[] = Array.isArray(meData.guilds) ? meData.guilds : [];
            if (userGuilds.length > 0) {
              setGuildsList(userGuilds);
            }
            if (meData.token) {
              saveAuthSessionToStorage(meData.token, meData.user, userGuilds);
            }
            sound.playSuccess();
            completeRedirectToDashboardWithManageGuilds(meData.user, userGuilds, meData.token);
          }
        }
      } catch {
        // continue polling
      }
    }, 1500);
    oauthPollTimerRef.current = pollTimer;
  };

  // Clicking "Authorize" on Screen 2 also launches Official Discord OAuth2 directly
  const handleDiscordOAuthAuthorize = async () => {
    handleTriggerRealDiscordOAuth();
  };

  // Open Dynamic Bot Invite Link Pre-targeted to that specific Server (Rule 2)
  const handleOpenBotInvite = (targetGuild?: ConnectedGuildItem) => {
    sound.playClick();
    const cid = botClientId || '1564565916216336494';
    const inviteLink = targetGuild?.id
      ? `https://discord.com/oauth2/authorize?client_id=${encodeURIComponent(
          cid
        )}&permissions=8&integration_type=0&scope=bot+applications.commands&guild_id=${encodeURIComponent(
          targetGuild.id
        )}&disable_guild_select=true`
      : dynamicInviteUrl ||
        `https://discord.com/oauth2/authorize?client_id=${cid}&permissions=8&integration_type=0&scope=bot+applications.commands`;

    window.open(inviteLink, '_blank', 'noopener,noreferrer');

    if (targetGuild?.id) {
      setInvitingGuildId(targetGuild.id);
      setStatusToast(
        isAr
          ? `⏳ جاري انتظار إضافة البوت إلى سيرفر "${targetGuild.name}" في ديسكورد... سيتفعّل زر الدخول فور انضمامه!`
          : `⏳ Waiting for bot to join "${targetGuild.name}"... Entry button will unlock once joined!`
      );

      let pollCount = 0;
      const joinTimer = setInterval(async () => {
        pollCount += 1;
        if (pollCount > 45) {
          clearInterval(joinTimer);
          setInvitingGuildId(null);
          return;
        }
        const updatedList = await fetchLiveServers(false);
        const matchedNowPresent = updatedList.find(
          (item) => String(item.id) === String(targetGuild.id) && item.hasBot !== false && item.botPresent !== false
        );
        if (matchedNowPresent) {
          clearInterval(joinTimer);
          setInvitingGuildId(null);
          sound.playShieldActivate();
          setStatusToast(
            isAr
              ? `🎉 تم التأكد من انضمام البوت إلى "${matchedNowPresent.name}"! تم تفعيل الدخول للوحة التحكم.`
              : `🎉 Bot joined "${matchedNowPresent.name}"! Dashboard access unlocked.`
          );
          handleSelectServer(matchedNowPresent);
        }
      }, 2000);
    }
  };

  // Enter isolated Server Dashboard ONLY if bot is present in that guild (Rules 2 & 3)
  const handleSelectServer = async (guild: ConnectedGuildItem) => {
    if (!oauthUser?.id || !getStoredAuthToken()) {
      handleTriggerRealDiscordOAuth();
      return;
    }

    const isPresent = guild.hasBot !== false && guild.botPresent !== false;
    if (!isPresent) {
      handleOpenBotInvite(guild);
      return;
    }

    setSelectingGuildId(guild.id);
    sound.playClick();

    try {
      const res = await fetch('/api/bot/select-guild', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ guildId: guild.id })
      });
      const data = await res.json();

      if (!res.ok || data?.botMissing || data?.success === false) {
        setStatusToast(
          data?.error ||
            (isAr
              ? `⚠️ البوت غير موجود داخل سيرفر "${guild.name}" بعد. أضف البوت أولاً ثم اضغط تحديث.`
              : `⚠️ Bot is not present in "${guild.name}" yet. Invite the bot first.`)
        );
        setTimeout(() => setStatusToast(null), 5000);
        setSelectingGuildId(null);
        return;
      }

      try {
        localStorage.setItem('m7r_selected_guild', JSON.stringify(guild));
        localStorage.setItem('m7r_selected_guild_id', guild.id);
        sessionStorage.setItem('m7r_active_dashboard_unlocked', 'true');
      } catch {}

      sound.playSuccess();

      const updatedBot: ConnectedBotData = {
        ...(data.botInfo || currentBot || DEFAULT_M7R_BOT_DATA),
        id: botClientId,
        inviteUrl: dynamicInviteUrl,
        guilds: guildsList,
        guildsCount: guildsList.length,
        selectedGuild: guild,
        membersCount: guild.memberCount || data.botInfo?.membersCount || 0,
        channelsCount: guild.channelsCount || data.botInfo?.channelsCount || 0,
        accessMode: isOfficialBotOwnerUser(oauthUser) ? 'bot_owner' : 'server_admin',
        discordUser: (oauthUser as any) || undefined,
        mode: 'live'
      };

      if (onAuthenticated) {
        onAuthenticated(updatedBot, getStoredAuthToken() || 'LIVE_SERVER_SESSION_CONFIGURED', oauthUser || undefined);
      }
      if (onConnected) {
        onConnected(updatedBot);
      }
    } catch {
      setStatusToast(
        isAr
          ? '⚠️ تعذر التحقق من اتصال البوت بالسيرفر. حاول مجدداً.'
          : '⚠️ Failed to verify bot membership in this server.'
      );
      setTimeout(() => setStatusToast(null), 4000);
    } finally {
      setSelectingGuildId(null);
    }
  };

  // STRICTLY Authenticated Manage Server Guilds ONLY (zero fallback guild leaks!)
  const connectedServers = guildsList.filter((g) => g.hasBot !== false && g.botPresent !== false);
  const invitableAdminServers = guildsList.filter((g) => g.hasBot === false || g.botPresent === false);

  const allDisplayServers = [...connectedServers, ...invitableAdminServers];

  const totalCount = allDisplayServers.length;
  const yoursCount = connectedServers.length;
  const invitableCount = invitableAdminServers.length;

  const filteredGuilds = allDisplayServers.filter((g) => {
    const matchesSearch =
      !searchQuery.trim() ||
      g.name.toLowerCase().includes(searchQuery.trim().toLowerCase()) ||
      g.id.includes(searchQuery.trim());
    if (!matchesSearch) return false;

    const isPresent = g.hasBot !== false && g.botPresent !== false;
    if (serverFilter === 'yours') return isPresent;
    if (serverFilter === 'invitable') return !isPresent;
    return true;
  });

  // ============================================================================
  // SCREEN 2: OFFICIAL DISCORD OAUTH2 AUTHORIZATION SCREEN (Matches IMG_3237 100%)
  // ============================================================================
  if (step === 'discord_oauth') {
    const activeUsername = customUsernameInput.trim() || oauthUser?.username || 'u5r9';
    const hostDisplay =
      typeof window !== 'undefined' ? window.location.origin : 'https://m7r.online';

    return (
      <div
        dir="ltr"
        className="min-h-screen w-full bg-[#2b2d31] text-[#dbdee1] flex flex-col justify-between select-none font-sans"
      >
        <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 max-w-lg mx-auto w-full">
          {/* Top "Signed in as u5r9 Not you?" */}
          <div className="mb-4 text-center text-sm text-[#949ba4]">
            <span>Signed in as </span>
            <strong className="text-[#dbdee1] font-semibold">{activeUsername}</strong>{' '}
            <button
              type="button"
              onClick={() => setShowSwitchAccountInputs(!showSwitchAccountInputs)}
              className="text-[#00a8fc] hover:underline font-medium ml-1 cursor-pointer"
            >
              Not you?
            </button>
          </div>

          {showSwitchAccountInputs && (
            <div className="w-full mb-4 p-3.5 rounded-xl bg-[#1e1f22] border border-white/10 grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left">
              <div>
                <label className="text-[11px] font-bold text-[#949ba4] block mb-1">
                  Discord Username:
                </label>
                <input
                  type="text"
                  value={customUsernameInput}
                  onChange={(e) => setCustomUsernameInput(e.target.value)}
                  placeholder="u5r9"
                  className="w-full bg-[#2b2d31] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#5865F2]"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-[#949ba4] block mb-1">
                  Discord User ID:
                </label>
                <input
                  type="text"
                  value={customUserIdInput}
                  onChange={(e) => setCustomUserIdInput(e.target.value)}
                  placeholder={OFFICIAL_OWNER_ID}
                  className="w-full bg-[#2b2d31] border border-white/10 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#5865F2]"
                />
              </div>
            </div>
          )}

          {/* Main Inner Rounded Discord Card */}
          <div className="w-full rounded-2xl bg-[#313338] border border-white/[0.07] shadow-2xl p-6 space-y-5">
            <h2 className="text-[15px] font-semibold text-white">
              This will allow the developer of M7R to:
            </h2>

            {/* Permissions Checklist */}
            <div className="space-y-4">
              <div className="flex items-center gap-3.5">
                <div className="w-6 h-6 rounded-full bg-[#b5bac1] text-[#2b2d31] flex items-center justify-center text-xs font-black shrink-0">
                  ✓
                </div>
                <span className="text-[15px] text-[#dbdee1] font-normal">
                  Access your username, avatar, and banner
                </span>
              </div>

              <div className="flex items-center gap-3.5">
                <div className="w-6 h-6 rounded-full bg-[#b5bac1] text-[#2b2d31] flex items-center justify-center text-xs font-black shrink-0">
                  ✓
                </div>
                <span className="text-[15px] text-[#dbdee1] font-normal">
                  Know what servers you&apos;re in
                </span>
              </div>

              <div className="flex items-center gap-3.5">
                <div className="w-6 h-6 rounded-full bg-[#b5bac1] text-[#2b2d31] flex items-center justify-center text-xs font-black shrink-0">
                  ✓
                </div>
                <span className="text-[15px] text-[#dbdee1] font-normal">
                  Join servers for you
                </span>
              </div>

              <div className="flex items-center gap-3.5">
                <div className="w-6 h-6 rounded-full bg-[#80848e] text-[#2b2d31] flex items-center justify-center text-xs font-black shrink-0">
                  ✕
                </div>
                <span className="text-[15px] text-[#949ba4] font-normal">
                  Have an existential crisis
                </span>
              </div>
            </div>

            <div className="border-t border-white/10 pt-5 space-y-4 text-[13px] text-[#949ba4] leading-relaxed">
              <div className="flex items-start gap-3">
                <Link2 className="w-5 h-5 text-[#949ba4] shrink-0 mt-0.5" />
                <div>
                  Once you authorize, you will be redirected{' '}
                  <strong className="text-[#dbdee1] font-semibold">outside of Discord</strong> to:{' '}
                  <strong className="text-[#dbdee1] font-semibold break-all">{hostDisplay}</strong>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Lock className="w-5 h-5 text-[#949ba4] shrink-0 mt-0.5" />
                <div>
                  The developer of M7R&apos;s{' '}
                  <span className="text-[#00a8fc]">privacy policy</span> and{' '}
                  <span className="text-[#00a8fc]">terms of service</span> apply to this
                  application. Discord&apos;s <span className="text-[#00a8fc]">Privacy Policy</span>{' '}
                  applies to data it receives.
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-[#949ba4] shrink-0" />
                <div>Active since Dec 14, 2025</div>
              </div>

              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-[#949ba4] shrink-0 mt-0.5" />
                <div>
                  This application <strong className="text-[#dbdee1] font-semibold">cannot</strong>{' '}
                  read your messages or send messages as you.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Stacked Cancel & Authorize Bar (Exact match to IMG_3237) */}
        <div className="w-full bg-[#232428] border-t border-white/[0.06] p-4">
          <div className="max-w-lg mx-auto space-y-3">
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setOauthLoading(false);
                setStep('landing');
              }}
              className="w-full py-3.5 rounded-xl bg-[#383a40] hover:bg-[#4e5058] text-white text-[15px] font-semibold transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleDiscordOAuthAuthorize}
              disabled={oauthLoading}
              className="w-full py-3.5 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white text-[15px] font-semibold transition-colors flex items-center justify-center cursor-pointer shadow-lg"
            >
              {oauthLoading ? (
                <div className="flex items-center gap-1.5 py-1">
                  <span className="w-2 h-2 rounded-full bg-white/90 animate-bounce" />
                  <span
                    className="w-2 h-2 rounded-full bg-white/90 animate-bounce"
                    style={{ animationDelay: '150ms' }}
                  />
                  <span
                    className="w-2 h-2 rounded-full bg-white/90 animate-bounce"
                    style={{ animationDelay: '300ms' }}
                  />
                </div>
              ) : (
                <span>Authorize</span>
              )}
            </button>

            <button
              type="button"
              onClick={handleTriggerRealDiscordOAuth}
              className="w-full py-2.5 rounded-xl bg-[#1e1f22] hover:bg-[#2b2d31] border border-white/10 text-[#00a8fc] text-xs font-semibold transition-colors cursor-pointer"
            >
              🔗 فتح صفحة ديسكورد الرسمية مباشرة (Open Discord.com OAuth2)
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================================
  // SCREEN 3: AUTHENTICATED USER'S MANAGE-SERVER HUB (Rule 2 Verification Gate)
  // ============================================================================
  if (step === 'select_server' && oauthUser?.id && getStoredAuthToken()) {
    return (
      <div
        dir={isAr ? 'rtl' : 'ltr'}
        className="min-h-screen w-full bg-[#060913] text-white px-4 py-6 sm:py-10 select-none"
      >
        <div className="max-w-xl mx-auto space-y-6">
          {/* Top Navigation Bar */}
          <div className="rounded-2xl bg-[#0b101e]/95 border border-slate-800/90 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-xl">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setStep('landing');
                }}
                className="px-3.5 py-2 rounded-xl bg-[#111827] hover:bg-slate-800 border border-slate-700/80 text-xs font-bold text-slate-200 flex items-center gap-1.5 cursor-pointer"
              >
                <Home className="w-4 h-4 text-[#38bdf8]" />
                <span>{isAr ? 'المزايا' : 'Features'}</span>
              </button>

              {oauthUser && (
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#060913] border border-white/10">
                  <img
                    src={oauthUser.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}
                    alt={oauthUser.username}
                    className="w-6 h-6 rounded-full object-cover border border-[#38bdf8]/40"
                  />
                  <span className="text-xs font-bold text-white font-mono">{oauthUser.username}</span>
                  <button
                    type="button"
                    onClick={async () => {
                      sound.playClick();
                      clearAuthSessionFromStorage();
                      try {
                        await fetch('/auth/logout', { credentials: 'include' });
                      } catch {}
                      setOauthUser(null);
                      setGuildsList([]);
                      setStep('landing');
                      setStatusToast(isAr ? 'تم تسجيل الخروج بنجاح' : 'Logged out successfully');
                      setTimeout(() => setStatusToast(null), 3000);
                    }}
                    className="text-[11px] font-bold text-rose-400 hover:underline cursor-pointer mr-1"
                  >
                    {isAr ? 'خروج' : 'Logout'}
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2.5" dir="ltr">
              <span className="text-lg font-black tracking-wide text-white font-mono">M7R</span>
              <div className="w-10 h-10 rounded-full bg-[#131c33] border border-[#38bdf8]/40 flex items-center justify-center font-black text-xs text-[#38bdf8] font-mono shadow-inner">
                M7R
              </div>
            </div>
          </div>

          {statusToast && (
            <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs font-bold text-center">
              {statusToast}
            </div>
          )}

          {/* Main Hub Title + 4-Squares Icon (Matches IMG_3238) */}
          <div className="flex items-start justify-between gap-4 pt-2">
            <div className="flex-1 text-right">
              <h1 className="text-2xl sm:text-3xl font-black text-white">
                {isAr ? 'مركز قيادة السيرفرات والبوتات' : 'Server & Bot Command Hub'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-1.5 leading-relaxed">
                {isAr
                  ? 'اختر سيرفرك للدخول مباشرة إلى لوحة التحكم أو أضف البوت إلى سيرفر جديد تمتلك فيه رتبة الإدارة'
                  : 'Select your server to directly enter the control dashboard or add the bot to a new server'}
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-[#111827] border border-slate-700/80 flex items-center justify-center text-blue-400 shrink-0 shadow-lg">
              <LayoutGrid className="w-6 h-6" />
            </div>
          </div>

          {/* Search Input Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 right-4 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isAr ? 'بحث في السيرفرات...' : 'Search servers...'}
              className="w-full rounded-2xl bg-[#0b101d] border border-slate-800/90 focus:border-blue-500/60 pr-11 pl-4 py-3.5 text-sm text-white placeholder-slate-500 focus:outline-none transition-all"
            />
          </div>

          {/* Filter Pills Row (الكل | سيرفراتك | متاحة للإضافة) */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setServerFilter('all');
              }}
              className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
                serverFilter === 'all'
                  ? 'bg-[#131d31] text-white border-2 border-white/90 shadow-lg'
                  : 'bg-[#0b101d] text-slate-300 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {isAr ? `الكل (${totalCount})` : `All (${totalCount})`}
            </button>

            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setServerFilter('yours');
              }}
              className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
                serverFilter === 'yours'
                  ? 'bg-[#131d31] text-white border-2 border-white/90 shadow-lg'
                  : 'bg-[#0b101d] text-slate-300 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {isAr ? `سيرفراتك (${yoursCount})` : `Your Servers (${yoursCount})`}
            </button>

            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setServerFilter('invitable');
              }}
              className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
                serverFilter === 'invitable'
                  ? 'bg-[#131d31] text-white border-2 border-white/90 shadow-lg'
                  : 'bg-[#0b101d] text-slate-300 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {isAr ? `متاحة للإضافة (${invitableCount})` : `Available (${invitableCount})`}
            </button>
          </div>

          {/* Refresh Server List Pill Button + Add Bot Button */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => fetchLiveServers(true)}
              disabled={refreshingServers}
              className="px-4 py-2.5 rounded-2xl bg-[#0b101d] hover:bg-[#131d31] border border-slate-800 text-slate-200 text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer transition-all"
            >
              <RefreshCw className={`w-4 h-4 ${refreshingServers ? 'animate-spin text-blue-400' : ''}`} />
              <span>{isAr ? 'تحديث قائمة السيرفرات' : 'Refresh Servers List'}</span>
            </button>

            <button
              type="button"
              onClick={() => handleOpenBotInvite()}
              className="px-4 py-2.5 rounded-2xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{isAr ? 'إضافة البوت لسيرفر جديد' : 'Add Bot to Server'}</span>
            </button>
          </div>

          {/* Section Title: سيرفراتك */}
          <div className="pt-2 border-b border-slate-800/80 pb-3 space-y-1">
            <h2 className="text-xl font-black text-white">
              {isAr ? 'سيرفراتك' : 'Your Servers'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              {isAr
                ? 'اضغط على أي سيرفر متصل للدخول إلى لوحة التحكم، أو اضغط على سيرفر متاح لإدخال البوت إليه فوراً'
                : 'Click on any connected server to enter its dashboard, or click an available server to invite the bot'}
            </p>
          </div>

          {/* Server Cards List (Strict Bot Presence Check & Explicit Actions) */}
          <div className="space-y-4 pb-12">
            {filteredGuilds.length === 0 ? (
              <div className="p-8 rounded-3xl bg-[#0b101d] border border-slate-800 text-center space-y-4">
                <Server className="w-10 h-10 text-slate-500 mx-auto" />
                <div className="space-y-1">
                  <h3 className="text-base font-black text-white">
                    {isAr ? 'لا توجد سيرفرات مطابقة في حسابك حالياً' : 'No matching Manage Server guilds found'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {isAr
                      ? 'تأكد من أنك تملك صلاحية Administrator أو Manage Server في السيرفر المطلوب ثم اضغط على تحديث.'
                      : 'Ensure you have Administrator or Manage Server permission, then click Refresh.'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => fetchLiveServers(true)}
                  className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-black cursor-pointer"
                >
                  {isAr ? '🔄 إعادة فحص السيرفرات' : '🔄 Refresh Servers'}
                </button>
              </div>
            ) : (
              filteredGuilds.map((g) => {
                const isPresent = g.hasBot !== false && g.botPresent !== false;
                const isSelecting = selectingGuildId === g.id;
                const isInviting = invitingGuildId === g.id;

                return (
                  <div
                    key={g.id}
                    className={`p-5 rounded-3xl bg-[#0b101d] border transition-all shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                      isPresent
                        ? 'border-emerald-500/35 hover:border-emerald-400/70'
                        : 'border-slate-800/90 hover:border-blue-500/45'
                    }`}
                  >
                    <div className="flex items-center gap-4 min-w-0 flex-1">
                      <div className="relative shrink-0">
                        {g.icon ? (
                          <img
                            src={g.icon}
                            alt={g.name}
                            className="w-16 h-16 rounded-2xl object-cover border border-slate-700"
                          />
                        ) : (
                          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#1e293b] to-[#0f172a] border border-slate-700 flex items-center justify-center text-lg font-black text-white font-mono">
                            {g.name.slice(0, 3).toUpperCase()}
                          </div>
                        )}
                        <span
                          className={`w-3.5 h-3.5 rounded-full absolute -bottom-1 -left-1 ring-4 ring-[#0b101d] ${
                            isPresent ? 'bg-emerald-400' : 'bg-amber-400'
                          }`}
                        />
                      </div>

                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-black text-white truncate">{g.name}</h3>
                          {(isSelecting || isInviting) && (
                            <RefreshCw className="w-4 h-4 text-blue-400 animate-spin shrink-0" />
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2 text-[11px]">
                          {isPresent ? (
                            <>
                              <span className="px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 font-black">
                                {isAr ? '● البوت متصل بالسيرفر' : '● Bot Connected'}
                              </span>
                              <span className="px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300 font-mono tabular-nums">
                                {g.memberCount || 0} {isAr ? 'عضو' : 'members'}
                              </span>
                            </>
                          ) : (
                            <>
                              <span className="px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/40 text-amber-300 font-black">
                                {isAr ? 'البوت غير موجود داخل هذا السيرفر' : 'Bot Not Installed'}
                              </span>
                              <span className="px-2.5 py-1 rounded-lg bg-purple-500/15 border border-purple-500/40 text-purple-300 font-bold">
                                {isAr ? '🛡️ لديك صلاحية الإدارة' : '🛡️ Manage Server'}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0">
                      {isPresent ? (
                        <button
                          type="button"
                          disabled={isSelecting}
                          onClick={() => handleSelectServer(g)}
                          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-l from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#05070c] text-xs font-black flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all disabled:opacity-60"
                        >
                          <LayoutGrid className="w-4 h-4" />
                          <span>{isSelecting ? (isAr ? 'جاري الدخول...' : 'Entering...') : isAr ? 'دخول لوحة التحكم والأوامر' : 'Open Dashboard & Commands'}</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleOpenBotInvite(g)}
                          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all"
                        >
                          <PlusCircle className="w-4 h-4" />
                          <span>
                            {isInviting
                              ? isAr
                                ? '⏳ جاري انتظار إضافة البوت...'
                                : '⏳ Waiting for Bot...'
                              : isAr
                              ? 'إضافة البوت إلى هذا السيرفر'
                              : 'Add Bot to This Server'}
                          </span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    );
  }

  const isGuestLoggedIn = Boolean(oauthUser?.id && getStoredAuthToken());

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="min-h-screen w-full bg-[#05070c] text-white select-none relative overflow-x-hidden m7r-ambient-canvas"
    >
      {/* SLIDE-OUT MOBILE NAVIGATION DRAWER */}
      {landingMenuOpen && (
        <div className="fixed inset-0 z-[150] flex justify-end bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="flex-1 cursor-pointer" onClick={() => setLandingMenuOpen(false)} />

          <div
            dir="rtl"
            className="w-[320px] sm:w-[360px] h-screen bg-[#05070c] border-s border-[#00f0ff]/20 p-5 flex flex-col justify-between overflow-y-auto shadow-2xl"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/10">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-[#0b101b] border border-[#38bdf8]/40 flex items-center justify-center font-mono font-black text-xs text-[#38bdf8]">
                    M7R
                  </div>
                  <div>
                    <div className="text-sm font-black text-white font-mono">M7R</div>
                    <div className="text-[11px] text-[#10b981]">● استجابة فورية فائقة السرعة</div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setLandingMenuOpen(false)}
                  className="w-10 h-10 rounded-xl bg-[#0b101b] hover:bg-slate-800 border border-white/10 flex items-center justify-center text-slate-400 hover:text-white cursor-pointer shrink-0"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-2 pt-1">
                {(isGuestLoggedIn
                  ? [
                      {
                        label: `سيرفراتي (${totalCount})`,
                        icon: Server,
                        action: () => {
                          setLandingMenuOpen(false);
                          setStep('select_server');
                        }
                      },
                      {
                        label: 'مزايا بوت M7R',
                        icon: Sparkles,
                        action: () => {
                          setLandingMenuOpen(false);
                          document.getElementById('m7r-modules-showcase')?.scrollIntoView({ behavior: 'smooth' });
                        }
                      }
                    ]
                  : [
                      {
                        label: 'مزايا وإمكانيات M7R',
                        icon: Sparkles,
                        action: () => {
                          setLandingMenuOpen(false);
                          document.getElementById('m7r-modules-showcase')?.scrollIntoView({ behavior: 'smooth' });
                        }
                      },
                      {
                        label: 'مقارنة M7R',
                        icon: ShieldCheck,
                        action: () => {
                          setLandingMenuOpen(false);
                          document.getElementById('m7r-comparison-section')?.scrollIntoView({ behavior: 'smooth' });
                        }
                      },
                      {
                        label: 'تسجيل الدخول عبر Discord',
                        icon: ShieldCheck,
                        action: () => {
                          setLandingMenuOpen(false);
                          handleTriggerRealDiscordOAuth();
                        }
                      }
                    ]
                ).map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        sound.playClick();
                        item.action();
                      }}
                      className="w-full py-2.5 px-3.5 rounded-xl bg-[#0b101b]/90 hover:bg-[#121a2d] border border-white/[0.06] hover:border-[#38bdf8]/35 flex items-center justify-between text-slate-100 font-bold text-sm transition-all cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-[#05070c] border border-[#38bdf8]/25 flex items-center justify-center text-[#38bdf8] shrink-0">
                          <Icon className="w-4 h-4" />
                        </div>
                        <span>{item.label}</span>
                      </div>
                      <ArrowLeft className="w-4 h-4 text-slate-400" />
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 space-y-2.5">
              {!isGuestLoggedIn && (
                <button
                  type="button"
                  onClick={() => {
                    setLandingMenuOpen(false);
                    handleTriggerRealDiscordOAuth();
                  }}
                  className="w-full py-3 px-4 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white font-black text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <DiscordLogoSvg className="w-4 h-4" />
                  <span>تسجيل الدخول عبر Discord</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  if (setLang) setLang(isAr ? 'en' : 'ar');
                  setLandingMenuOpen(false);
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-[#0b101b] hover:bg-[#131d33] border border-white/10 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Globe className="w-4 h-4 text-[#38bdf8]" />
                <span>{isAr ? 'English' : 'العربية'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FLOATING GLASS NAVBAR (الهيدر الذكي العائم - بدون أي أزرار تحكم أو أوامر للزائر) */}
      <header className="sticky top-0 z-50 border-b border-[#38bdf8]/15 bg-[#05070c]/85 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
          {/* Brand & Live Status */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0b101b] border border-[#38bdf8]/40 flex items-center justify-center font-mono font-black text-xs text-[#38bdf8] shadow-[0_0_20px_rgba(56,189,248,0.2)]">
              M7R
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-black tracking-tight text-white font-mono">M7R</span>
                <span className="px-2 py-0.5 rounded-md bg-[#10b981]/15 border border-[#10b981]/35 text-[#10b981] text-[10px] font-bold">
                  ● نظام سحابي متكامل
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                البوت العربي المتكامل لإدارة وحماية وتفاعل سيرفرك
              </p>
            </div>
          </div>

          {/* Center Quick Links (Guest-safe: Overview, Features, Comparison ONLY) */}
          <div className="hidden lg:flex items-center gap-1 p-1 rounded-xl bg-[#0b101b] border border-[#38bdf8]/20">
            <button
              type="button"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="px-3 py-1.5 rounded-lg bg-gradient-to-l from-[#38bdf8] to-[#818cf8] text-[#05070c] text-xs font-black cursor-pointer"
            >
              الرئيسية
            </button>
            <button
              type="button"
              onClick={() =>
                document.getElementById('m7r-modules-showcase')?.scrollIntoView({ behavior: 'smooth' })
              }
              className="px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/5 text-xs font-bold cursor-pointer transition-colors"
            >
              المزايا والإمكانيات
            </button>
            <button
              type="button"
              onClick={() =>
                document.getElementById('m7r-comparison-section')?.scrollIntoView({ behavior: 'smooth' })
              }
              className="px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/5 text-xs font-bold cursor-pointer transition-colors"
            >
              مقارنة M7R
            </button>
          </div>

          {/* Left Actions in RTL: Language Toggle + Discord OAuth2 Login ONLY for Guests */}
          <div className="flex items-center gap-2">
            {setLang && (
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setLang(isAr ? 'en' : 'ar');
                }}
                className="hidden sm:flex px-2.5 py-2 rounded-xl bg-[#0b101b] hover:bg-[#141e33] border border-white/10 text-slate-200 text-xs font-bold items-center gap-1.5 cursor-pointer"
                title="تغيير اللغة"
              >
                <Globe className="w-3.5 h-3.5 text-[#38bdf8]" />
                <span>{isAr ? 'EN' : 'عربي'}</span>
              </button>
            )}

            {isGuestLoggedIn && oauthUser ? (
              <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-[#0b101b] border border-emerald-500/35">
                <img
                  src={oauthUser.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}
                  alt={oauthUser.username}
                  className="w-7 h-7 rounded-lg object-cover border border-emerald-400/50"
                />
                <div className="text-right hidden sm:block">
                  <div className="text-xs font-black text-white leading-tight flex items-center gap-1">
                    <span>{oauthUser.globalName || oauthUser.username}</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  </div>
                  <div className="text-[10px] text-emerald-400 font-bold">
                    {totalCount} سيرفر متاح
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setStep('select_server');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 text-[10px] font-black cursor-pointer"
                >
                  سيرفراتي ({totalCount})
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleTriggerRealDiscordOAuth}
                className="px-4 py-2 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs font-black flex items-center gap-2 cursor-pointer transition-all shadow-md"
              >
                <DiscordLogoSvg className="w-4 h-4" />
                <span>تسجيل الدخول عبر Discord</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setLandingMenuOpen(true);
              }}
              className="lg:hidden w-10 h-10 rounded-xl bg-[#0b101b] border border-white/15 flex items-center justify-center text-slate-200 cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* MAIN GUEST LANDING VIEW: Login + M7R Feature Cards ONLY */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        <HeroLandingSection
          lang={lang}
          ping={botPingMs || 14}
          isStandaloneLanding={true}
          isAuthenticated={false}
          selectedGuild={null}
          onOpenLoginPrompt={handleTriggerRealDiscordOAuth}
        />
      </main>
    </div>
  );
};
