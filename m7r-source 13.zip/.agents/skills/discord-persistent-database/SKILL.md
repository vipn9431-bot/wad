---
name: discord-persistent-database
description: Fast, crash-safe data persistence for guild configurations, ticket states, staff ratings, giveaways, and XP levels.
---
- Maintain an in-memory `Map` cache backed by atomic disk/DB persistence so guild settings (like rating channel ID, log channel ID, and staff star scores) survive restarts.
- Provide clean helper methods (`getGuildConfig`, `updateGuildConfig`, `addStaffRating`, `getStaffStats`) with safe default fallbacks.
