---
name: discord-bot-expert
description: Build Discord bot features including Slash Commands, rich Embeds, moderation/anti-raid protection, ticket workflows, welcome cards, and audit logging in discord.js v14.
---
- Design structured Arabic/bilingual `EmbedBuilder` cards with persistent `ButtonBuilder` custom IDs.
- Build private ticket channels with `PermissionOverwrites` and clean close transcripts.
- Enforce role hierarchy checks before moderation actions and log all server events safely.
