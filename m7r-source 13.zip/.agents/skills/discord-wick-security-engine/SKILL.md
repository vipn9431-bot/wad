---
name: discord-wick-security-engine
description: Enterprise Anti-Nuke, Anti-Raid, AutoMod, and real-time Audit Log threat detection inspired by Wick Bot.
---
- Monitor `GuildAuditLogEntryCreate` to detect rapid channel deletions, role deletions, mass bans, or unauthorized webhook creation within sliding 10-second windows.
- Automatically strip dangerous permissions (`Administrator`, `BanMembers`, `ManageChannels`, `ManageRoles`) from offending accounts not on the owner whitelist (`Quarantine`).
- Implement Anti-Raid join-rate limiters, account-age gates, and instant channel lockdown/unlockdown commands.
