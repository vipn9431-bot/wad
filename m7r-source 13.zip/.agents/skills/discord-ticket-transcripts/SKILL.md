---
name: discord-ticket-transcripts
description: Advanced support ticket lifecycle management including category routing, staff claiming, transcript generation, and 1-to-5 star staff evaluation.
---
- Support multi-category ticket panels (`SelectMenu`), private permission overwrites, and a `Claim` button that locks ownership to the responding moderator and updates the channel topic.
- Before closing a ticket, generate a formatted conversation transcript sent to the logs channel, and trigger the 5-star interactive rating bar (`⭐` to `⭐⭐⭐⭐⭐`).
- Route completed ratings to the designated rating channel with a direct mention to the staff member (`<@staffId>`), star visual, ticket metadata, and cumulative staff rating average.
