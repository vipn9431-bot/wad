---
name: discord-bot-architect
description: Architect, build, and optimize production-grade Discord bots using Node.js, discord.js v14, Express, Slash Commands, interactive UI components, Gateway Intents, and modular architecture.
---
- Organize bot code modularly (`commands/`, `events/`, `handlers/`).
- Request only required `GatewayIntentBits` and verify member/bot permissions before executing actions.
- Always use `interaction.deferReply()` for async operations and guard against `InteractionAlreadyReplied`.
- Attach global `unhandledRejection` / `uncaughtException` handlers and expose Express `/health` on `process.env.PORT` without hardcoding tokens.
