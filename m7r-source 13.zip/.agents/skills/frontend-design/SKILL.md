---
name: frontend-design
description: Create distinctive, production-grade frontend interfaces with high design quality, bold typography, and cohesive dark command-center aesthetics.
---
- Avoid generic layouts and overused fonts; use modern geometric Arabic fonts (`Cairo`, `Readex Pro`) paired with `JetBrains Mono` for telemetry and stats.
- Commit to deep obsidian surfaces (`#07090e`, `#0d111a`), 1px translucent borders (`rgba(255,255,255,0.08)`), glassmorphism (`backdrop-filter: blur(16px)`), and crisp emerald/cyan accents.
- Prioritize smooth staggered entrances and subtle hover states (`translateY(-2px)`).
