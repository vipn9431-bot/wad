---
name: composition-patterns
description: React composition patterns for building flexible, reusable UI components without prop drilling.
---
- Structure dashboard views using reusable Bento cards, status badges, and modular modal/drawer components.
- Separate data-fetching/API logic from presentational UI components.
