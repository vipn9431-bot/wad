---
name: discord-components-v2-ui
description: Advanced Discord interactive UI engineering using StringSelectMenu, RoleSelectMenu, ChannelSelectMenu, UserSelectMenu, Modals, and stateful button pagination.
---
- Use native `ChannelSelectMenuBuilder` and `RoleSelectMenuBuilder` for instant server configuration inside Discord without typing IDs manually.
- Guard all component interactions by verifying `interaction.user.id` against the command initiator or required staff permissions.
- Encode lightweight state directly inside `customId` strings (e.g., `rate_ticket_5_<staffId>_<ticketId>`) so buttons remain 100% functional across bot restarts.
