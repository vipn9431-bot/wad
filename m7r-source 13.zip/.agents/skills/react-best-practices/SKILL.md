---
name: react-best-practices
description: Modern React and TypeScript performance optimization guidelines for component structure, disciplined hooks, and clean state management.
---
- Keep components focused and modular; avoid unnecessary `useEffect` chains and excessive re-renders.
- Use strict TypeScript interfaces for API payloads, bot stats, and server settings.
- Handle loading, empty, and error states gracefully in every dashboard widget.
