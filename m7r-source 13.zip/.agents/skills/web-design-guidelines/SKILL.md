---
name: web-design-guidelines
description: Review and enforce web interface guidelines covering responsive layout, spacing, visual hierarchy, and RTL/LTR accessibility.
---
- Ensure 100% responsive layouts across mobile and desktop viewports with proper Arabic RTL alignment (`dir="rtl"`).
- Maintain clear visual hierarchy, generous padding inside cards, and high contrast for all interactive buttons and toggles.
