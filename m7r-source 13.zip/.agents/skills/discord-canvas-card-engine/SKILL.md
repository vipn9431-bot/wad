---
name: discord-canvas-card-engine
description: Dynamic image and card generation for Discord Welcome banners, XP Level rank cards, and Staff Rating summaries.
---
- Design high-contrast dark glassmorphic visual cards (or fallback SVG/high-res Embed banners) displaying circular user avatars, progress bars, level badges, and star ratings.
- Ensure fast rendering and attach generated buffers cleanly via Discord `AttachmentBuilder`.
