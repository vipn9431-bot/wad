---
name: discord-web-health-tester
description: Real-time system health check API and diagnostic widget for monitoring bot uptime, API ping, and OAuth2 connectivity.
---
- Create a dedicated `/api/system-health` JSON endpoint that reports bot gateway status, WebSocket ping, memory usage, and OAuth2 readiness.
- Build a clean diagnostic status card in the admin dashboard showing green/red indicators for Bot Connection, Database Sync, and Discord API authorization.
