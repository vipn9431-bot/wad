---
name: automated-code-diagnostic-engine
description: Advanced error trapping, OAuth2 flow diagnostics, and backend health validation for Discord bots and web dashboards.
---
- Implement robust try/catch blocks around all OAuth2 token exchange endpoints (`/auth/discord/callback`), logging detailed error context (like invalid grant, mismatched redirect URI, or expired codes) instead of crashing the server.
- Provide clear console telemetry for missing environment variables (`DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `DISCORD_REDIRECT_URI`) upon server boot.
