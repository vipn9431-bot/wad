---
name: discord-high-scale-performance
description: Memory optimization, cache sweepers, rate-limit protection, and zero-downtime WebSocket resilience for Discord bots.
---
- Configure `Options.sweepers` on the Discord Client to periodically clean old message caches and keep RAM usage low on cloud hosting.
- Wrap all REST mutations in rate-limit-aware `try/catch` blocks and ensure all slash commands acknowledge within 2500ms using `deferReply()`.
