---
name: discord-api-tools
description: Integrate Discord REST API v10 operations, message actions, webhooks, and context-aware AI chat responders.
---
- Ignore bot messages (`message.author.bot`) in AI chat listeners to prevent reply loops.
- Fetch recent channel history for context, trigger `sendTyping()`, and split replies over 2000 characters.
- Wrap REST/message actions in `try/catch` blocks handling Discord API rate limits and missing permissions.
