---
name: frontend-design
description: Create distinctive, production-grade frontend interfaces with high design quality. Use this skill when building web components, pages, dashboards, or styling any web UI.
---

# Frontend Design Rules (M7R OS Standard)

1. **Aesthetic & Theme:** Bespoke dark command-center aesthetic using deep obsidian surfaces (`#07090e` background, `#0d111a` cards) with 1px translucent borders (`rgba(255, 255, 255, 0.08)`) and emerald (`#10b981`) / cyan (`#06b6d4`) accents.
2. **Typography & RTL:** Full Arabic RTL layout (`dir="rtl"`) with `Cairo` and `Readex Pro` fonts, paired with `JetBrains Mono` for telemetry and numbers.
3. **Layout & Depth:** Modular bento grids, glassmorphism (`backdrop-filter: blur(16px)`), ambient radial glows, and full mobile/desktop responsiveness.
4. **Motion:** Smooth staggered entrance animations and crisp hover states (`translateY(-2px)`).
