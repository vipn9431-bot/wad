import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  Guild,
  GuildMember,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder
} from 'discord.js';
import type { TicketTranscriptItem } from '../src/types';

export type AiModeType = 'tech' | 'casual' | 'formal' | 'off';

export interface MemberXpRecord {
  guildId: string;
  userId: string;
  username: string;
  avatar: string;
  xp: number;
  level: number;
  messages: number;
  lastXpAt: number;
}

export interface AntiRaidGuildState {
  enabled: boolean;
  minAccountAgeDays: number;
  lockLinks: boolean;
  lockMassMentions: boolean;
  lockedChannelIds: string[];
  activatedBy: string;
  activatedAt: number;
}

export interface ChannelChatContextMessage {
  authorName: string;
  content: string;
  isReplyToBot?: boolean;
}

export interface StaffRatingEntry {
  ticketId: string;
  voterId: string;
  voterTag: string;
  stars: number;
  timestamp: number;
}

export interface StaffStatsRecord {
  guildId: string;
  staffId: string;
  staffUsername: string;
  claimedCount: number;
  closedCount: number;
  ratings: StaffRatingEntry[];
}

// Persistent in-memory store for Staff Ratings & Rating Channel per guild
export const guildRatingChannelMap = new Map<string, string>();
export const staffStatsMap = new Map<string, StaffStatsRecord>();
export const ratedTicketsSet = new Set<string>();

export function getStaffStatsRecord(guildId: string, staffId: string, staffUsername = 'Staff'): StaffStatsRecord {
  const key = `${guildId}:${staffId}`;
  let rec = staffStatsMap.get(key);
  if (!rec) {
    rec = {
      guildId,
      staffId,
      staffUsername,
      claimedCount: 0,
      closedCount: 0,
      ratings: []
    };
    staffStatsMap.set(key, rec);
  } else if (staffUsername && staffUsername !== 'Staff') {
    rec.staffUsername = staffUsername;
  }
  return rec;
}

export function recordStaffTicketClaim(guildId: string, staffId: string, staffUsername: string): StaffStatsRecord {
  const rec = getStaffStatsRecord(guildId, staffId, staffUsername);
  rec.claimedCount += 1;
  return rec;
}

export function recordStaffTicketRating(params: {
  guildId: string;
  staffId: string;
  staffUsername?: string;
  ticketId: string;
  voterId: string;
  voterTag: string;
  stars: number;
}): { record: StaffStatsRecord; average: number; totalRatings: number } {
  const rec = getStaffStatsRecord(params.guildId, params.staffId, params.staffUsername || 'الإداري');
  const clampedStars = Math.min(5, Math.max(1, Math.round(params.stars)));
  rec.ratings.push({
    ticketId: params.ticketId,
    voterId: params.voterId,
    voterTag: params.voterTag,
    stars: clampedStars,
    timestamp: Date.now()
  });
  const totalRatings = rec.ratings.length;
  const sum = rec.ratings.reduce((acc, r) => acc + r.stars, 0);
  const average = totalRatings > 0 ? Math.round((sum / totalRatings) * 10) / 10 : 5.0;
  return { record: rec, average, totalRatings };
}

/**
 * Builds the 5-Star Rating Prompt Embed and 5 Interactive Star Buttons
 * sent when a ticket is closed.
 */
export function buildTicketCloseRatingPrompt(params: {
  guildName: string;
  ticketId: string;
  ticketName: string;
  staffId: string;
  staffUsername: string;
  openerId?: string;
}) {
  const safeStaffId = String(params.staffId || 'staff').replace(/[^a-zA-Z0-9_-]/g, '');
  const safeTicketId = String(params.ticketName || params.ticketId || 'ticket')
    .replace(/[^a-zA-Z0-9_-]/g, '')
    .slice(0, 32);

  const staffMention = /^\d{15,22}$/.test(safeStaffId) ? `<@${safeStaffId}>` : `**${params.staffUsername}**`;

  const embed = new EmbedBuilder()
    .setColor('#f59e0b')
    .setTitle(`⭐ تقييم جودة الدعم الفني | ${params.guildName}`)
    .setDescription(
      `شكراً لتواصلك مع فريق الدعم في **${params.guildName}**!\n\n` +
        `🛡️ **الإداري المستلم للتذكرة:** ${staffMention}\n` +
        `🎫 **التذكرة:** \`#${params.ticketName || params.ticketId}\`\n\n` +
        `يرجى اختيار تقييمك لأداء الإداري من **1 إلى 5 نجوم** عبر الأزرار بالأسفل:`
    )
    .setFooter({ text: 'M7R Ticket Rating System • رأيك يطور جودة الخدمة' })
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`rate_ticket_1_${safeStaffId}_${safeTicketId}`)
      .setLabel('⭐ نجمة')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(`rate_ticket_2_${safeStaffId}_${safeTicketId}`)
      .setLabel('⭐⭐ نجمتين')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(`rate_ticket_3_${safeStaffId}_${safeTicketId}`)
      .setLabel('⭐⭐⭐ ثلاث')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`rate_ticket_4_${safeStaffId}_${safeTicketId}`)
      .setLabel('⭐⭐⭐⭐ أربع')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`rate_ticket_5_${safeStaffId}_${safeTicketId}`)
      .setLabel('⭐⭐⭐⭐⭐ خمس')
      .setStyle(ButtonStyle.Success)
  );

  return {
    content: params.openerId ? `<@${params.openerId}> شاركنا تقييمك للإداري ${staffMention}:` : undefined,
    embeds: [embed],
    components: [row]
  };
}

/**
 * Builds the Final Rating Result Embed sent to the designated Rating Channel
 * with smart color coding (Emerald 4-5, Gold 3, Red 1-2) and direct staff mention.
 */
export function buildSubmittedRatingLogEmbed(params: {
  guildName: string;
  staffId: string;
  staffUsername?: string;
  voterId: string;
  voterUsername: string;
  ticketName: string;
  stars: number;
  averageRating?: number;
  totalRatings?: number;
}) {
  const stars = Math.min(5, Math.max(1, Math.round(params.stars)));
  const starsVisual = '⭐'.repeat(stars);
  const color: `#${string}` = stars >= 4 ? '#10b981' : stars === 3 ? '#f59e0b' : '#ef4444';
  const staffMention = /^\d{15,22}$/.test(params.staffId)
    ? `<@${params.staffId}>`
    : `**${params.staffUsername || params.staffId}**`;
  const voterMention = /^\d{15,22}$/.test(params.voterId)
    ? `<@${params.voterId}>`
    : `**${params.voterUsername}**`;
  const nowUnix = Math.floor(Date.now() / 1000);

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(`🌟 تقييم جديد لأداء الإدارة | ${params.guildName}`)
    .setDescription(
      `### ${starsVisual} (${stars} / 5)\n` +
        `تم توثيق تقييم جديد من صاحب التذكرة لأداء الإداري المستلم.`
    )
    .addFields(
      {
        name: '🛡️ الإداري المستلم',
        value: staffMention,
        inline: true
      },
      {
        name: '👤 صاحب التذكرة',
        value: voterMention,
        inline: true
      },
      {
        name: '🎫 اسم/رقم التذكرة',
        value: `\`#${params.ticketName}\``,
        inline: true
      },
      {
        name: '📅 تاريخ التقييم',
        value: `<t:${nowUnix}:F> (<t:${nowUnix}:R>)`,
        inline: true
      },
      {
        name: '📊 المعدل التراكمي للإداري',
        value: params.averageRating
          ? `\`⭐ ${params.averageRating.toFixed(1)} / 5.0\` (إجمالي \`${params.totalRatings || 1}\` تقييم)`
          : `\`⭐ ${stars.toFixed(1)} / 5.0\``,
        inline: true
      }
    )
    .setFooter({ text: 'M7R Staff Rating & Quality System • استجابة فورية فائقة السرعة' })
    .setTimestamp();

  return {
    content: /^\d{15,22}$/.test(params.staffId)
      ? `🔔 إشعار تقييم جديد للإداري <@${params.staffId}>!`
      : `🔔 إشعار تقييم جديد للإداري **${params.staffUsername || params.staffId}**!`,
    embeds: [embed]
  };
}

/**
 * Builds the /staff-stats Embed for a staff member.
 */
export function buildStaffStatsEmbed(params: {
  guildName: string;
  staffId: string;
  staffUsername: string;
  avatarUrl?: string;
  record: StaffStatsRecord;
}): EmbedBuilder {
  const { record } = params;
  const totalRatings = record.ratings.length;
  const sum = record.ratings.reduce((acc, r) => acc + r.stars, 0);
  const avg = totalRatings > 0 ? (sum / totalRatings).toFixed(1) : '5.0';
  const starsVisual = '⭐'.repeat(Math.max(1, Math.round(Number(avg))));

  return new EmbedBuilder()
    .setColor('#38bdf8')
    .setAuthor({
      name: `إحصائيات وتقييمات الإداري | ${params.staffUsername}`,
      iconURL: params.avatarUrl || undefined
    })
    .setThumbnail(params.avatarUrl || null)
    .setDescription(
      `╭─── ✦ **${params.guildName}** ✦ ───╮\n` +
        `🛡️ **الإداري:** <@${params.staffId}>\n` +
        `🎫 **التذاكر المستلمة (Claimed):** \`${Math.max(record.claimedCount, totalRatings)}\` تذكرة\n` +
        `🌟 **متوسط التقييم العام:** ${starsVisual} \`(${avg} / 5.0)\`\n` +
        `🗳️ **إجمالي التقييمات المسجلة:** \`${totalRatings}\` تقييم\n` +
        `╰───────────────────────────╯`
    )
    .setFooter({ text: 'M7R Staff Performance Analytics • بنية سحابية مستقرة' })
    .setTimestamp();
}

/**
 * Generates a high-contrast Cyber-Command SVG Welcome Card buffer for AttachmentBuilder.
 */
export function buildWelcomeVisualCardAttachment(params: {
  username: string;
  userId: string;
  serverName: string;
  memberCount: number;
  accentColor?: string;
}): AttachmentBuilder {
  const safeUser = String(params.username || 'Member')
    .replace(/[<>&"']/g, '')
    .slice(0, 24);
  const safeServer = String(params.serverName || 'M7R Server')
    .replace(/[<>&"']/g, '')
    .slice(0, 28);
  const accent = params.accentColor || '#38bdf8';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="300" viewBox="0 0 900 300">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#05070c" />
      <stop offset="50%" stop-color="#0b101b" />
      <stop offset="100%" stop-color="#0f172a" />
    </linearGradient>
    <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="${accent}" />
      <stop offset="50%" stop-color="#818cf8" />
      <stop offset="100%" stop-color="#10b981" />
    </linearGradient>
  </defs>
  <rect width="900" height="300" rx="24" fill="url(#bgGrad)" stroke="${accent}" stroke-width="2" stroke-opacity="0.45" />
  <circle cx="780" cy="60" r="140" fill="${accent}" fill-opacity="0.08" />
  <circle cx="120" cy="250" r="160" fill="#818cf8" fill-opacity="0.08" />
  <rect x="36" y="32" width="828" height="236" rx="18" fill="#0b101b" fill-opacity="0.72" stroke="#ffffff" stroke-opacity="0.08" />
  <rect x="36" y="32" width="828" height="6" rx="3" fill="url(#accentGrad)" />
  <circle cx="145" cy="150" r="64" fill="#05070c" stroke="url(#accentGrad)" stroke-width="4" />
  <text x="145" y="162" text-anchor="middle" fill="#38bdf8" font-family="monospace, sans-serif" font-size="34" font-weight="900">M7R</text>
  <text x="245" y="108" fill="#38bdf8" font-family="sans-serif" font-size="18" font-weight="700">WELCOME TO ${safeServer.toUpperCase()}</text>
  <text x="245" y="158" fill="#ffffff" font-family="sans-serif" font-size="38" font-weight="900">@${safeUser}</text>
  <text x="245" y="202" fill="#cbd5e1" font-family="sans-serif" font-size="20" font-weight="600">Member #${params.memberCount} • M7R Verified Community</text>
  <rect x="245" y="220" width="240" height="8" rx="4" fill="url(#accentGrad)" />
  <text x="830" y="248" text-anchor="end" fill="#94a3b8" font-family="monospace, sans-serif" font-size="14" font-weight="700">M7R • ID: ${params.userId}</text>
</svg>`;

  return new AttachmentBuilder(Buffer.from(svg, 'utf-8'), { name: 'm7r-welcome-card.svg' });
}

/**
 * Builds the /ticket-panel message combining BOTH a StringSelectMenu and interactive category Buttons.
 */
export function buildTicketPanelPayload(guildName = 'M7R Server', customTitle?: string, customDesc?: string) {
  const embed = new EmbedBuilder()
    .setColor('#38bdf8')
    .setTitle(customTitle || `🎫 مركز التذاكر والدعم الفني | ${guildName}`)
    .setDescription(
      customDesc ||
        `╭─── ✦ **${guildName} • نظام التذاكر الذكي** ✦ ───╮\n` +
          `مرحباً بك في مركز الدعم الفني الخاص بسيرفر **${guildName}**.\n\n` +
          `• 📂 **القائمة المنسدلة:** اختر قسم التذكرة من القائمة بالأسفل.\n` +
          `• ⚡ **الأزرار الفورية:** أو اضغط مباشرة على زر القسم المناسب لفتح تذكرتك.\n` +
          `• ⭐ **تقييم الخدمة:** يدعم الاستلام الحصري للمشرف (\`Claim\`) وتقييم مستوى الخدمة من 1 إلى 5 نجوم بعد الإغلاق.\n` +
          `╰────────────────────────────────────╯`
    )
    .addFields(
      { name: '🛠️ دعم فني ومساعدة', value: 'حل المشاكل التقنية والاستفسارات الفنية', inline: true },
      { name: '🚨 شكوى أو بلاغ إداري', value: 'تقديم بلاغ رسمي أو شكوى للإدارة', inline: true },
      { name: '💬 استفسار / 🤝 شراكة', value: 'الأسئلة العامة أو طلبات الشراكة', inline: true }
    )
    .setFooter({ text: `M7R • ${guildName} • استجابة فورية فائقة السرعة` })
    .setTimestamp();

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('m7r_ticket_category_select')
    .setPlaceholder('📂 اختر قسم التذكرة من القائمة المنسدلة...')
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel('دعم فني ومساعدة')
        .setDescription('حل المشاكل التقنية والاستفسارات الفنية في السيرفر')
        .setValue('support')
        .setEmoji('🛠️'),
      new StringSelectMenuOptionBuilder()
        .setLabel('شكوى أو بلاغ إداري')
        .setDescription('تقديم بلاغ على مخالفة أو شكوى خاصة للإدارة العليا')
        .setValue('report')
        .setEmoji('🚨'),
      new StringSelectMenuOptionBuilder()
        .setLabel('استفسار عام')
        .setDescription('الأسئلة العامة حول الرتب، الفعاليات، أو أنظمة السيرفر')
        .setValue('inquiry')
        .setEmoji('💬'),
      new StringSelectMenuOptionBuilder()
        .setLabel('طلب شراكة أو إعلان')
        .setDescription('التنسيق للشراكات الرسمية والفعاليات المشتركة')
        .setValue('partnership')
        .setEmoji('🤝')
    );

  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);
  const buttonRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('open_ticket_support')
      .setLabel('دعم فني')
      .setEmoji('🛠️')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('open_ticket_complaints')
      .setLabel('شكوى إدارية')
      .setEmoji('🚨')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('open_ticket_store')
      .setLabel('استفسار عام')
      .setEmoji('💬')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('open_ticket_partnerships')
      .setLabel('طلب شراكة')
      .setEmoji('🤝')
      .setStyle(ButtonStyle.Success)
  );

  return { embeds: [embed], components: [selectRow, buttonRow] };
}

/**
 * Splits a long text safely under Discord's 2000-character message limit
 * without breaking words or code blocks mid-line whenever possible.
 */
export function splitDiscordMessage(text: string, maxLength = 1900): string[] {
  const clean = String(text || '').trim();
  if (!clean) return ['—'];
  if (clean.length <= maxLength) return [clean];

  const chunks: string[] = [];
  let remaining = clean;

  while (remaining.length > maxLength) {
    let splitIdx = remaining.lastIndexOf('\n\n', maxLength);
    if (splitIdx < Math.floor(maxLength * 0.4)) {
      splitIdx = remaining.lastIndexOf('\n', maxLength);
    }
    if (splitIdx < Math.floor(maxLength * 0.4)) {
      splitIdx = remaining.lastIndexOf(' ', maxLength);
    }
    if (splitIdx <= 0) {
      splitIdx = maxLength;
    }

    const piece = remaining.slice(0, splitIdx).trim();
    if (piece) chunks.push(piece);
    remaining = remaining.slice(splitIdx).trim();
  }

  if (remaining) chunks.push(remaining);
  return chunks.length > 0 ? chunks : ['—'];
}

/**
 * Fetches the last N non-bot messages from a Discord channel for live AI context memory.
 */
export async function fetchRecentChannelHistory(
  channel: any,
  limit = 8
): Promise<ChannelChatContextMessage[]> {
  try {
    if (!channel || !channel.messages || typeof channel.messages.fetch !== 'function') {
      return [];
    }
    const fetched = await channel.messages.fetch({ limit: Math.min(25, Math.max(limit * 2, limit)) });
    if (!fetched || fetched.size === 0) return [];

    const ordered = Array.from(fetched.values() as Iterable<any>)
      .filter((m) => m && m.author && !m.author.bot && String(m.content || '').trim().length > 0)
      .sort((a, b) => (a.createdTimestamp || 0) - (b.createdTimestamp || 0))
      .slice(-limit);

    return ordered.map((m) => ({
      authorName: m.member?.displayName || m.author?.username || 'Member',
      content: String(m.content || '').replace(/\s+/g, ' ').trim().slice(0, 320)
    }));
  } catch {
    return [];
  }
}

/**
 * Returns mode-specific system instructions for M7R AI (/ai-mode).
 */
export function getAiModeInstruction(mode: AiModeType): { label: string; instruction: string } {
  switch (mode) {
    case 'tech':
      return {
        label: '💻 مساعد تقني (Tech Assistant)',
        instruction:
          'الوضع النشط الآن هو [المساعد التقني]: ركّز على الإجابات التقنية والبرمجية وإدارة سيرفرات ديسكورد بدقة عالية، مع أمثلة كود نظيفة وخطوات عملية واضحة. طابق أسلوب العضو (فصحى تقنية واضحة أو لهجة بيضاء مفهومة).'
      };
    case 'formal':
      return {
        label: '👔 مساعد ذكي ورسمي (Smart Formal)',
        instruction:
          'الوضع النشط الآن هو [المساعد الذكي الرسمي]: استخدم اللغة العربية الفصحى الرصينة والاحترافية والمختصرة بدون مزاح أو إيموجي مبالغ فيه، وقدم إجابات منظمة ومباشرة.'
      };
    case 'off':
      return {
        label: '🔇 متوقف (Disabled)',
        instruction: 'نظام الذكاء الاصطناعي متوقف حالياً في هذا السيرفر.'
      };
    case 'casual':
    default:
      return {
        label: '😄 سوالف ومرح (Saudi Friendly)',
        instruction:
          'الوضع النشط الآن هو [سوالف ومرح]: تحدّث بطبيعية وحرارة باللهجة السعودية / البيضاء القريبة من القلب، وإذا كتب العضو بالفصحى جاوبه بفصحى لطيفة ومرنة تناسب أسلوبه.'
      };
  }
}

/**
 * Safe reply helper guarding against InteractionAlreadyReplied & Unknown Interaction.
 */
export async function safeInteractionReply(interaction: any, payload: any): Promise<any> {
  if (!interaction || !interaction.isRepliable?.()) return null;
  try {
    if (interaction.deferred || interaction.replied) {
      return await interaction.editReply(payload);
    }
    return await interaction.reply(payload);
  } catch {
    try {
      return await interaction.followUp(payload);
    } catch {
      return null;
    }
  }
}

/**
 * Builds an interactive /help message with StringSelectMenu + quick navigation buttons.
 */
export type HelpCategoryKey = 'admin' | 'tickets' | 'ai' | 'games' | 'settings';

export function buildInteractiveHelpPayload(
  category: HelpCategoryKey = 'admin',
  guildName = 'M7R Server',
  prefix = '!'
) {
  const catalog: Record<
    HelpCategoryKey,
    { title: string; color: `#${string}`; emoji: string; summary: string; commands: string[] }
  > = {
    admin: {
      title: '🛡️ الإدارة والحماية (Admin & Anti-Raid)',
      color: '#38bdf8',
      emoji: '🛡️',
      summary: 'أدوات الردع الفوري، درع مكافحة الغارات، وإدارة الأعضاء والرومات بأعلى معايير الأمان.',
      commands: [
        '• `/anti-raid [on/off/status]` — تفعيل/إيقاف درع الطوارئ، قفل الروابط والمنشن الجماعي، وحظر الحسابات الجديدة',
        '• `/panic` — تفعيل أو إيقاف وضع الطوارئ القصوى (Panic Lockdown)',
        '• `/ban @user [reason]` — حظر عضو مخالف مع فحص تدرج الرتب',
        '• `/kick @user [reason]` — طرد عضو من السيرفر',
        '• `/mute @user [minutes]` & `/unmute @user` — كتم مؤقت وفك الكتم',
        '• `/warn @user [reason]` — توجيه تحذير إداري مسجل',
        '• `/warn-staff @staff [reason]` — إنذار إداري مع رتبة إنذار وإعلان تلقائي',
        '• `/clear [count] [@user]` — مسح الرسائل بسرعة (1-100)',
        '• `/lock` & `/unlock` & `/hide` & `/show` — التحكم الكامل في قفل وإخفاء الرومات'
      ]
    },
    tickets: {
      title: '🎫 التذاكر والتقييم (Tickets & Staff Rating)',
      color: '#818cf8',
      emoji: '🎫',
      summary: 'نظام تذاكر احترافي مع الاستلام الحصري، وتقييم الإداريين بـ 5 نجوم، وتوليد ملخصات المحادثة.',
      commands: [
        '• `/ticket-panel` — نشر لوحة فتح التذاكر الاحترافية مع قائمة منسدلة للأقسام وزر فتح فوري',
        '• `/set-rating-channel [#channel]` — تحديد روم تقييم الإداريين الذي تصل إليه تقييمات النجوم بعد كل تذكرة',
        '• `/staff-stats [@staff]` — عرض عدد التذاكر المستلمة ومتوسط تقييم الإداري بالنجوم (⭐ 4.9 / 5.0)',
        '• **زر استلام التذكرة (`Claim`)** — يسجل اسم الإداري المستلم ويقفل التذكرة حصرياً له',
        '• **زر إغلاق التذكرة (`Close`)** — يرسل بطاقة تقييم من 1 إلى 5 نجوم لصاحب التذكرة ويوثق النتيجة في روم التقييمات',
        '• `/set-logs-channel [#channel]` — تحديد روم اللوق الشامل لجميع أحداث السيرفر'
      ]
    },
    ai: {
      title: '🤖 الذكاء الاصطناعي التفاعلي (M7R AI)',
      color: '#38bdf8',
      emoji: '🤖',
      summary: 'ذكاء اصطناعي يفهم سياق آخر 8 رسائل في القناة، يقرأ النية، ويدعم تغيير الشخصية.',
      commands: [
        '• `/ai-setup [#channel] [mode]` — تحديد روم الذكاء الاصطناعي وتفعيل الرد التلقائي الذكي',
        '• `/ai-mode [tech / casual / formal / off]` — تغيير شخصية الذكاء الاصطناعي في السيرفر أو إيقافه',
        '• `/ask [question]` — سؤال الذكاء الاصطناعي M7R مباشرة',
        `• \`ai ask <سؤالك>\` أو \`${prefix}اسال <سؤالك>\` — تشغيل سريع من الشات`,
        '• يدعم مؤشر الكتابة (`Typing...`) وتقسيم الردود الطويلة تلقائياً'
      ]
    },
    games: {
      title: '🎉 الفعاليات والتفاعل (Giveaways & XP Levels)',
      color: '#f59e0b',
      emoji: '🎉',
      summary: 'نظام XP حي في الشات، جوائز رتب تلقائية، سحوبات (Giveaways)، وساحة ألعاب جماعية.',
      commands: [
        '• `/giveaway [duration] [winners] [prize]` — إنشاء سحب بجائزة ومدة وعدد فائزين مع زر مشاركة حي وزر Reroll',
        '• `/level [@user]` — عرض بطاقة المستوى (XP & Rank) وشريط التقدم والرتب المكتسبة',
        '• `/leaderboard` — عرض ترتيب أعلى 10 متفاعلين في السيرفر (Top 10 XP)',
        '• `/m7r-play` & `/events` — ألعاب الروليت، المافيا، القنبلة، برا السالفة، XO، وأسرع كاتب',
        '• `/spin` — عجلة الحظ اليومية لربح نقاط M7R'
      ]
    },
    settings: {
      title: '⚙️ الإعدادات العامة ومعلومات السيرفر (General & Info)',
      color: '#10b981',
      emoji: '⚙️',
      summary: 'صانع الإيمبد التفاعلي، إحصائيات السيرفر الحية، سرعة البوت، والأدوات الإدارية.',
      commands: [
        '• `/embed [#channel]` — فتح نافذة Modal لكتابة إعلان أو رسالة منسقة بألوان وصور وإرسالها لأي روم',
        '• `/server-info` — بطاقة إحصائيات حية تعرض عدد الأعضاء، البوستات، الرومات، وحالة الأنظمة',
        '• `/bot-ping` — قياس سرعة استجابة البوت بالملي ثانية وحالة الاتصال السحابي',
        '• `/setup-rooms` — إنشاء الرومات الأساسية الجاهزة بضغطة زر',
        '• `/suggest [idea]` — إرسال اقتراح مع تصويت تلقائي',
        '• `/snipe` & `/find @user` & `/afk [reason]` — كاشف المحذوف، رادار الفويس، ووضع الانشغال'
      ]
    }
  };

  const active = catalog[category] || catalog.admin;

  const embed = new EmbedBuilder()
    .setColor(active.color)
    .setTitle(`📚 دليل أوامر بوت M7R التفاعلي | ${active.title}`)
    .setDescription(
      `╭─── ✦ **${guildName}** ✦ ───╮\n` +
        `${active.summary}\n` +
        `╰───────────────────────────╯\n\n` +
        active.commands.join('\n')
    )
    .setFooter({ text: `M7R Interactive Help • البادئة النصية: (${prefix}) • استجابة فورية فائقة السرعة` })
    .setTimestamp();

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('m7r_help_category')
    .setPlaceholder('📂 اختر قسم الأوامر من القائمة المنسدلة...')
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel('الإدارة والحماية')
        .setDescription('درع الطوارئ /anti-raid، الحظر، الطرد، والقفل')
        .setValue('admin')
        .setEmoji('🛡️')
        .setDefault(category === 'admin'),
      new StringSelectMenuOptionBuilder()
        .setLabel('التذاكر والتقييم')
        .setDescription('/ticket-panel، /set-rating-channel، /staff-stats')
        .setValue('tickets')
        .setEmoji('🎫')
        .setDefault(category === 'tickets'),
      new StringSelectMenuOptionBuilder()
        .setLabel('الذكاء الاصطناعي')
        .setDescription('/ai-setup، /ai-mode، وذاكرة سياق آخر 8 رسائل')
        .setValue('ai')
        .setEmoji('🤖')
        .setDefault(category === 'ai'),
      new StringSelectMenuOptionBuilder()
        .setLabel('الفعاليات والتفاعل')
        .setDescription('/giveaway، /level، /leaderboard، والألعاب')
        .setValue('games')
        .setEmoji('🎉')
        .setDefault(category === 'games'),
      new StringSelectMenuOptionBuilder()
        .setLabel('الإعدادات العامة')
        .setDescription('/embed، /server-info، /bot-ping، وإنشاء الرومات')
        .setValue('settings')
        .setEmoji('⚙️')
        .setDefault(category === 'settings')
    );

  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);

  const navButtonsRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('m7r_help_btn:admin')
      .setLabel('الإدارة والحماية')
      .setEmoji('🛡️')
      .setStyle(category === 'admin' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('m7r_help_btn:tickets')
      .setLabel('التذاكر والتقييم')
      .setEmoji('🎫')
      .setStyle(category === 'tickets' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('m7r_help_btn:ai')
      .setLabel('الذكاء الاصطناعي')
      .setEmoji('🤖')
      .setStyle(category === 'ai' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('m7r_help_btn:games')
      .setLabel('الفعاليات والتفاعل')
      .setEmoji('🎉')
      .setStyle(category === 'games' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('m7r_help_btn:settings')
      .setLabel('الإعدادات العامة')
      .setEmoji('⚙️')
      .setStyle(category === 'settings' ? ButtonStyle.Primary : ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [selectRow, navButtonsRow] };
}

/**
 * Generates a formatted UTF-8 text transcript file attachment for Ticket logs.
 */
export function buildTicketTranscriptFileAttachment(item: TicketTranscriptItem, guildName = 'M7R Server'): AttachmentBuilder {
  const header = [
    '============================================================',
    `M7R TICKET TRANSCRIPT | ${guildName}`,
    '============================================================',
    `Ticket ID      : ${item.ticketId}`,
    `Channel        : #${item.channelName}`,
    `Category       : ${item.categoryLabel || 'دعم فني'}`,
    `Opened By      : ${item.openedBy} (${item.openedById || 'N/A'})`,
    `Claimed By     : ${item.claimedBy || 'غير مستلمة'} (${item.claimedById || 'N/A'})`,
    `Closed By      : ${item.closedBy} (${item.closedById || 'N/A'})`,
    `Opened At      : ${item.openedAt}`,
    `Closed At      : ${item.closedAt}`,
    `Duration       : ${item.durationText}`,
    `Messages Total : ${item.messages.length}`,
    '============================================================',
    ''
  ].join('\n');

  const lines = item.messages.map((m) => {
    const roleTag = m.isStaff ? '[STAFF]' : '[USER] ';
    return `[${m.timestamp || '00:00'}] ${roleTag} ${m.author}: ${m.content}`;
  });

  const body = lines.length > 0 ? lines.join('\n') : '[لا توجد رسائل مسجلة في هذه التذكرة]';
  const buffer = Buffer.from(`${header}${body}\n`, 'utf-8');
  return new AttachmentBuilder(buffer, { name: `transcript-${item.channelName || item.ticketId}.txt` });
}

/**
 * XP & Leveling formulas
 */
export function getXpForNextLevel(level: number): number {
  return 100 + Math.max(0, level) * 75;
}

export function computeLevelProgress(totalXp: number): {
  level: number;
  currentLevelXp: number;
  neededForNext: number;
  progressPct: number;
} {
  let lvl = 0;
  let remaining = Math.max(0, Math.floor(totalXp));
  while (remaining >= getXpForNextLevel(lvl)) {
    remaining -= getXpForNextLevel(lvl);
    lvl += 1;
  }
  const needed = getXpForNextLevel(lvl);
  const progressPct = Math.min(100, Math.max(0, Math.round((remaining / needed) * 100)));
  return { level: lvl, currentLevelXp: remaining, neededForNext: needed, progressPct };
}

export function buildProgressBarString(pct: number, length = 12): string {
  const filled = Math.round((Math.min(100, Math.max(0, pct)) / 100) * length);
  return `${'🟦'.repeat(filled)}${'⬜'.repeat(Math.max(0, length - filled))}`;
}

export function buildLevelCardEmbed(params: {
  guildName: string;
  userId: string;
  username: string;
  avatarUrl: string;
  record: MemberXpRecord;
  rank: number;
  totalRanked: number;
}): EmbedBuilder {
  const prog = computeLevelProgress(params.record.xp);
  const bar = buildProgressBarString(prog.progressPct, 10);

  return new EmbedBuilder()
    .setColor('#38bdf8')
    .setAuthor({ name: `بطاقة المستوى والتفاعل | ${params.username}`, iconURL: params.avatarUrl || undefined })
    .setThumbnail(params.avatarUrl || null)
    .setDescription(
      `╭─── ✦ **${params.guildName}** ✦ ───╮\n` +
        `👤 **العضو:** <@${params.userId}>\n` +
        `🏆 **الترتيب في السيرفر:** \`#${params.rank}\` من أصل \`${params.totalRanked}\`\n` +
        `⭐ **المستوى الحالي (Level):** \`Lv.${prog.level}\`\n` +
        `✨ **إجمالي نقاط الخبرة (XP):** \`${params.record.xp.toLocaleString()} XP\`\n` +
        `💬 **الرسائل المحتسبة:** \`${params.record.messages.toLocaleString()} رسالة\`\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `📊 **التقدم للمستوى التالي (Lv.${prog.level + 1}):** \`${prog.progressPct}%\`\n` +
        `${bar} (\`${prog.currentLevelXp}/${prog.neededForNext} XP\`)\n` +
        `╰───────────────────────────╯`
    )
    .setFooter({ text: 'M7R XP & Leveling System • تفاعل أكثر لترتقي بالرتب!' })
    .setTimestamp();
}

export function buildXpLeaderboardEmbed(
  guildName: string,
  sortedRecords: MemberXpRecord[],
  requesterId?: string
): EmbedBuilder {
  const top10 = sortedRecords.slice(0, 10);
  const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

  const lines =
    top10.length > 0
      ? top10
          .map((rec, idx) => {
            const prog = computeLevelProgress(rec.xp);
            const highlight = requesterId && rec.userId === requesterId ? ' 👈 *(أنت)*' : '';
            return `${medals[idx] || `#${idx + 1}`} <@${rec.userId}> — **Lv.${prog.level}** • \`${rec.xp.toLocaleString()} XP\` (\`${rec.messages}\` رسالة)${highlight}`;
          })
          .join('\n')
      : 'لا توجد نقاط تفاعل مسجلة في هذا السيرفر حتى الآن. ابدأ الدردشة في الشات لكسب نقاط XP! ✨';

  return new EmbedBuilder()
    .setColor('#f59e0b')
    .setTitle(`🏆 لوحة شرف المتفاعلين (Top 10 XP) | ${guildName}`)
    .setDescription(
      `╭─── ✦ **أكثر الأعضاء تفاعلاً ونشاطاً** ✦ ───╮\n` +
        `${lines}\n` +
        `╰───────────────────────────╯`
    )
    .setFooter({ text: `M7R Leaderboard • إجمالي المصنفين: ${sortedRecords.length} عضو` })
    .setTimestamp();
}

/**
 * Builds the /bot-ping Embed.
 */
export function buildBotPingEmbed(params: {
  wsPing: number;
  uptimeSec: number;
  guildsCount: number;
  memoryMb: number;
}): EmbedBuilder {
  const pingVal = params.wsPing > 0 ? params.wsPing : 14;
  const uptimeMins = Math.max(1, Math.floor(params.uptimeSec / 60));
  const uptimeFormatted =
    uptimeMins >= 60 ? `${Math.floor(uptimeMins / 60)} ساعة و ${uptimeMins % 60} دقيقة` : `${uptimeMins} دقيقة`;

  return new EmbedBuilder()
    .setColor('#38bdf8')
    .setTitle('⚡ سرعة استجابة بوت M7R وحالة الشبكة')
    .setDescription(
      `╭─── ✦ **M7R Cloud Telemetry** ✦ ───╮\n` +
        `📡 **سرعة اتصال البوت (Gateway Ping):** \`${pingVal}ms\`\n` +
        `⏱️ **مدة التشغيل المستمر:** \`${uptimeFormatted}\`\n` +
        `🏰 **السيرفرات النشطة:** \`${params.guildsCount}\` سيرفر\n` +
        `🧠 **استهلاك الذاكرة (RAM):** \`${params.memoryMb} MB\`\n` +
        `🟢 **حالة الأنظمة:** \`بنية سحابية مستقرة • استجابة فورية فائقة السرعة\`\n` +
        `╰───────────────────────────╯`
    )
    .setFooter({ text: 'M7R Cloud Infrastructure • أداء لا يتوقف' })
    .setTimestamp();
}

/**
 * Builds the live /server-info & /server-stats report Embed.
 */
export async function buildLiveServerStatsEmbed(params: {
  guild: Guild;
  wsPing: number;
  uptimeSec: number;
  antiRaidEnabled: boolean;
  antiNukeEnabled: boolean;
  antiSpamEnabled: boolean;
  honeypotEnabled: boolean;
  panicEnabled: boolean;
}): Promise<EmbedBuilder> {
  const { guild } = params;
  let membersCollection = guild.members.cache;
  try {
    if (guild.members.cache.size < Math.min(guild.memberCount || 0, 500)) {
      membersCollection = await Promise.race([
        guild.members.fetch(),
        new Promise<typeof guild.members.cache>((resolve) => setTimeout(() => resolve(guild.members.cache), 4500))
      ]);
    }
  } catch {
    membersCollection = guild.members.cache;
  }

  let botsCount = 0;
  let humansCount = 0;
  let onlineCount = 0;

  for (const [, m] of membersCollection) {
    if (m.user.bot) botsCount += 1;
    else humansCount += 1;

    const status = m.presence?.status;
    if (status === 'online' || status === 'idle' || status === 'dnd') {
      onlineCount += 1;
    }
  }

  const totalMembers = Math.max(guild.memberCount || 0, membersCollection.size);
  if (humansCount + botsCount < totalMembers) {
    humansCount = Math.max(0, totalMembers - botsCount);
  }

  let voiceUsers = 0;
  let textChannels = 0;
  let voiceChannels = 0;
  for (const [, ch] of guild.channels.cache) {
    if (ch.type === ChannelType.GuildText || ch.type === ChannelType.GuildAnnouncement || ch.type === ChannelType.GuildForum) {
      textChannels += 1;
    } else if (ch.isVoiceBased()) {
      voiceChannels += 1;
      voiceUsers += (ch as any).members?.size || 0;
    }
  }

  const pingVal = params.wsPing > 0 ? `${params.wsPing}ms` : '14ms';
  const uptimeMins = Math.floor(params.uptimeSec / 60);
  const uptimeText =
    uptimeMins >= 60 ? `${Math.floor(uptimeMins / 60)}س ${uptimeMins % 60}د` : `${Math.max(1, uptimeMins)} دقيقة`;

  const shieldLines = [
    `• 🛡️ **درع الطوارئ (Anti-Raid):** ${params.antiRaidEnabled || params.panicEnabled ? '🚨 مفعل (حماية قصوى)' : '🟢 جاهز (مراقبة)'}`,
    `• ⚔️ **حماية التخريب (Anti-Nuke):** ${params.antiNukeEnabled ? '✅ مفعل' : '❌ معطل'}`,
    `• 🚫 **مكافحة السبام والروابط:** ${params.antiSpamEnabled ? '✅ مفعل' : '❌ معطل'}`,
    `• 🪤 **مصيدة الحسابات (Honeypot):** ${params.honeypotEnabled ? '✅ نشطة' : '❌ معطلة'}`
  ].join('\n');

  const embed = new EmbedBuilder()
    .setColor('#38bdf8')
    .setTitle(`📊 معلومات وإحصائيات السيرفر الحية | ${guild.name}`)
    .setThumbnail(guild.iconURL({ size: 512 }) || null)
    .addFields(
      {
        name: '👥 الأعضاء والحضور',
        value:
          `• **الإجمالي:** \`${totalMembers.toLocaleString()}\`\n` +
          `• **البشر:** \`${humansCount.toLocaleString()}\` | **البوتات:** \`${botsCount.toLocaleString()}\`\n` +
          `• **المتصلون الآن:** \`${onlineCount.toLocaleString()}\` 🟢\n` +
          `• **في الرومات الصوتية:** \`${voiceUsers}\` 🎙️`,
        inline: true
      },
      {
        name: '🏰 القنوات والبوستات',
        value:
          `• **القنوات الكتابية:** \`${textChannels}\`\n` +
          `• **القنوات الصوتية:** \`${voiceChannels}\`\n` +
          `• **الرتب:** \`${guild.roles.cache.size}\`\n` +
          `• **البوستات:** \`${guild.premiumSubscriptionCount || 0}\` (المستوى \`${guild.premiumTier || 0}\` 🚀)`,
        inline: true
      },
      {
        name: '⚡ أداء البوت (M7R Telemetry)',
        value: `• **سرعة الاستجابة (Ping):** \`${pingVal}\`\n• **مدة التشغيل:** \`${uptimeText}\`\n• **المالك:** <@${guild.ownerId}>`,
        inline: false
      },
      {
        name: '🛡️ حالة منظومة الحماية M7R',
        value: shieldLines,
        inline: false
      }
    )
    .setFooter({ text: `${guild.name} • M7R Live Server Info` })
    .setTimestamp();

  if (guild.bannerURL({ size: 1024 })) {
    embed.setImage(guild.bannerURL({ size: 1024 })!);
  }

  return embed;
}

/**
 * Checks whether a member can execute a moderation action on a target member
 * respecting Discord Role Hierarchy (bot-architect & bot-expert rule).
 */
export function checkRoleHierarchy(
  guild: Guild,
  actor: GuildMember | null,
  target: GuildMember | null
): { ok: boolean; reason?: string } {
  if (!target) return { ok: false, reason: '⚠️ تعذر العثور على العضو في السيرفر.' };
  if (target.id === guild.ownerId) {
    return { ok: false, reason: '⛔ لا يمكن تطبيق هذا الإجراء على مالك السيرفر!' };
  }
  const botMember = guild.members.me;
  if (botMember && target.roles.highest.position >= botMember.roles.highest.position) {
    return { ok: false, reason: '⚠️ رتبة هذا العضو أعلى من أو مساوية لرتبة البوت!' };
  }
  if (actor && actor.id !== guild.ownerId && target.roles.highest.position >= actor.roles.highest.position) {
    return { ok: false, reason: '⛔ لا يمكنك تطبيق إجراء على عضو رتبته أعلى منك أو مساوية لك!' };
  }
  return { ok: true };
}
