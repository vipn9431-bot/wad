// Auto-synced live snapshot from botClient.guilds.cache for static Netlify fallback
export const LIVE_BOT_GUILDS_LIST = [
  {
    "id": "1486763846151438456",
    "name": "M7R Empire ⚜️",
    "icon": "https://cdn.discordapp.com/icons/1486763846151438456/bcd0ce5bcbf335a201189354919525c2.webp",
    "memberCount": 144,
    "channelsCount": 36,
    "rolesCount": 73,
    "ownerId": "1219299588402577532",
    "hasBot": true,
    "botPresent": true,
    "canManage": true
  },
  {
    "id": "1493178407188693112",
    "name": "m7r",
    "icon": "https://cdn.discordapp.com/icons/1493178407188693112/f61be6472a2e8801cab912a46a0165f9.webp",
    "memberCount": 72,
    "channelsCount": 23,
    "rolesCount": 37,
    "ownerId": "1219299588402577532",
    "hasBot": true,
    "botPresent": true,
    "canManage": true
  },
  {
    "id": "1525374225425367171",
    "name": "𝐀𝐩𝐞𝐱 ⚜️ / صيد الضبان 🦎",
    "icon": "https://cdn.discordapp.com/icons/1525374225425367171/f62646a01b911a76d02c672d1c97985e.webp",
    "memberCount": 309,
    "channelsCount": 49,
    "rolesCount": 30,
    "ownerId": "1184069933374652466",
    "hasBot": true,
    "botPresent": true,
    "canManage": true
  },
  {
    "id": "1564569257755410523",
    "name": "𝓜7𝓡's server",
    "icon": "",
    "memberCount": 7,
    "channelsCount": 8,
    "rolesCount": 5,
    "ownerId": "1219299588402577532",
    "hasBot": true,
    "botPresent": true,
    "canManage": true
  }
];

export const LIVE_BOT_GUILD_DETAILS_MAP: Record<string, any> = {
  "1486763846151438456": {
    "success": true,
    "live": true,
    "guild": {
      "id": "1486763846151438456",
      "name": "M7R Empire ⚜️",
      "icon": "https://cdn.discordapp.com/icons/1486763846151438456/bcd0ce5bcbf335a201189354919525c2.webp",
      "memberCount": 144,
      "channelsCount": 21,
      "rolesCount": 72,
      "ownerId": "1219299588402577532",
      "hasBot": true,
      "botPresent": true,
      "canManage": true
    },
    "textChannels": [
      {
        "id": "1489504448018645103",
        "name": "✈️welcome-ترحيب",
        "type": "text",
        "parentId": "1489504431501480016",
        "position": 0
      },
      {
        "id": "1489504454586663139",
        "name": "💬𝕔𝕙𝕥-شات",
        "type": "text",
        "parentId": "1489504432361181295",
        "position": 0
      },
      {
        "id": "1554125110418345984",
        "name": "تقديم-f2",
        "type": "text",
        "parentId": null,
        "position": 0
      },
      {
        "id": "1555576626551586866",
        "name": "شات-•-administration🕵🏻",
        "type": "text",
        "parentId": "1555576352395235429",
        "position": 0
      },
      {
        "id": "1557772584781746288",
        "name": "log-server🔎",
        "type": "text",
        "parentId": "1489566465282801757",
        "position": 0
      },
      {
        "id": "1561752671017508984",
        "name": "انشاء-رومك",
        "type": "text",
        "parentId": "1489504434592419880",
        "position": 0
      },
      {
        "id": "1489504445418045562",
        "name": "قوانين-laws👨‍⚖️",
        "type": "text",
        "parentId": "1489504431501480016",
        "position": 1
      },
      {
        "id": "1489504455954141326",
        "name": "🎫ticket-التكت",
        "type": "text",
        "parentId": "1489504432361181295",
        "position": 1
      },
      {
        "id": "1489566222868545536",
        "name": "الرفض-❌-القبول-✅",
        "type": "text",
        "parentId": "1489566465282801757",
        "position": 1
      },
      {
        "id": "1555563049837138062",
        "name": "ممنوع-الإرسال🚫",
        "type": "text",
        "parentId": null,
        "position": 1
      },
      {
        "id": "1489588955245445230",
        "name": "ajr🕋",
        "type": "text",
        "parentId": "1489504432361181295",
        "position": 2
      },
      {
        "id": "1521928410405011562",
        "name": "التذاكر-التقديم-🎫",
        "type": "text",
        "parentId": "1489566465282801757",
        "position": 2
      },
      {
        "id": "1554249049446555751",
        "name": "الاعلانات-announcements📢",
        "type": "text",
        "parentId": "1489504431501480016",
        "position": 2
      },
      {
        "id": "1567566284600639519",
        "name": "ticket-284",
        "type": "text",
        "parentId": null,
        "position": 2
      },
      {
        "id": "1554250704519176253",
        "name": "طريقت-التسجيل-registration✍️",
        "type": "text",
        "parentId": "1489504432361181295",
        "position": 3
      },
      {
        "id": "1558651073596755968",
        "name": "ابـداعـكـم📸",
        "type": "text",
        "parentId": "1489504432361181295",
        "position": 4
      }
    ],
    "voiceChannels": [
      {
        "id": "1489504442456870982",
        "name": "[🏆]𝑽𝑶𝑰𝑪𝑬 ~ فـايـت 1",
        "type": "voice",
        "parentId": "1489504434592419880",
        "position": 0
      },
      {
        "id": "1555576931678953502",
        "name": "فويس  ٠ Administration🕵🏻",
        "type": "voice",
        "parentId": "1555576352395235429",
        "position": 0
      },
      {
        "id": "1489504446764285955",
        "name": "[🏆]𝑽𝑶𝑰𝑪𝑬 ~ فـايـت 2",
        "type": "voice",
        "parentId": "1489504434592419880",
        "position": 1
      },
      {
        "id": "1489504449163559042",
        "name": "[🏆]𝑽𝑶𝑰𝑪𝑬 ~ فـايـت3",
        "type": "voice",
        "parentId": "1489504434592419880",
        "position": 2
      },
      {
        "id": "1561942336265650308",
        "name": "أنشئ رومك",
        "type": "voice",
        "parentId": "1489504434592419880",
        "position": 3
      }
    ],
    "categoryChannels": [
      {
        "id": "1489504431501480016",
        "name": "قوانين",
        "type": "category",
        "position": 0
      },
      {
        "id": "1489504432361181295",
        "name": "عام",
        "type": "category",
        "position": 1
      },
      {
        "id": "1489504434592419880",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬",
        "type": "category",
        "position": 2
      },
      {
        "id": "1555576352395235429",
        "name": "الاداره ٠ Administration🕵🏼",
        "type": "category",
        "position": 3
      },
      {
        "id": "1489566465282801757",
        "name": "log",
        "type": "category",
        "position": 4
      },
      {
        "id": "1555574285844750348",
        "name": "التذاكر",
        "type": "category",
        "position": 5
      }
    ],
    "channels": [
      {
        "id": "1489504448018645103",
        "name": "✈️welcome-ترحيب",
        "type": "text"
      },
      {
        "id": "1489504454586663139",
        "name": "💬𝕔𝕙𝕥-شات",
        "type": "text"
      },
      {
        "id": "1554125110418345984",
        "name": "تقديم-f2",
        "type": "text"
      },
      {
        "id": "1555576626551586866",
        "name": "شات-•-administration🕵🏻",
        "type": "text"
      },
      {
        "id": "1557772584781746288",
        "name": "log-server🔎",
        "type": "text"
      },
      {
        "id": "1561752671017508984",
        "name": "انشاء-رومك",
        "type": "text"
      },
      {
        "id": "1489504445418045562",
        "name": "قوانين-laws👨‍⚖️",
        "type": "text"
      },
      {
        "id": "1489504455954141326",
        "name": "🎫ticket-التكت",
        "type": "text"
      },
      {
        "id": "1489566222868545536",
        "name": "الرفض-❌-القبول-✅",
        "type": "text"
      },
      {
        "id": "1555563049837138062",
        "name": "ممنوع-الإرسال🚫",
        "type": "text"
      },
      {
        "id": "1489588955245445230",
        "name": "ajr🕋",
        "type": "text"
      },
      {
        "id": "1521928410405011562",
        "name": "التذاكر-التقديم-🎫",
        "type": "text"
      },
      {
        "id": "1554249049446555751",
        "name": "الاعلانات-announcements📢",
        "type": "text"
      },
      {
        "id": "1567566284600639519",
        "name": "ticket-284",
        "type": "text"
      },
      {
        "id": "1554250704519176253",
        "name": "طريقت-التسجيل-registration✍️",
        "type": "text"
      },
      {
        "id": "1558651073596755968",
        "name": "ابـداعـكـم📸",
        "type": "text"
      },
      {
        "id": "1489504442456870982",
        "name": "[🏆]𝑽𝑶𝑰𝑪𝑬 ~ فـايـت 1",
        "type": "voice"
      },
      {
        "id": "1555576931678953502",
        "name": "فويس  ٠ Administration🕵🏻",
        "type": "voice"
      },
      {
        "id": "1489504446764285955",
        "name": "[🏆]𝑽𝑶𝑰𝑪𝑬 ~ فـايـت 2",
        "type": "voice"
      },
      {
        "id": "1489504449163559042",
        "name": "[🏆]𝑽𝑶𝑰𝑪𝑬 ~ فـايـت3",
        "type": "voice"
      },
      {
        "id": "1561942336265650308",
        "name": "أنشئ رومك",
        "type": "voice"
      },
      {
        "id": "1489504431501480016",
        "name": "قوانين",
        "type": "category"
      },
      {
        "id": "1489504432361181295",
        "name": "عام",
        "type": "category"
      },
      {
        "id": "1489504434592419880",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬",
        "type": "category"
      },
      {
        "id": "1555576352395235429",
        "name": "الاداره ٠ Administration🕵🏼",
        "type": "category"
      },
      {
        "id": "1489566465282801757",
        "name": "log",
        "type": "category"
      },
      {
        "id": "1555574285844750348",
        "name": "التذاكر",
        "type": "category"
      }
    ],
    "roles": [
      {
        "id": "1489504350362534051",
        "name": "𝑺𝒆𝒓𝒗𝒆𝒓 𝑶𝒘𝒏𝒆𝒓",
        "color": "#ff0000",
        "position": 72,
        "managed": false
      },
      {
        "id": "1486764085457457182",
        "name": "new",
        "color": "#000000",
        "position": 71,
        "managed": false
      },
      {
        "id": "1486764194589184155",
        "name": "ŕu",
        "color": "#000000",
        "position": 70,
        "managed": true
      },
      {
        "id": "1489500061107884153",
        "name": "Gold share",
        "color": "#000000",
        "position": 69,
        "managed": true
      },
      {
        "id": "1489500102610649151",
        "name": "Gold Bot",
        "color": "#000000",
        "position": 68,
        "managed": true
      },
      {
        "id": "1489501675768123448",
        "name": "Xenon",
        "color": "#000000",
        "position": 67,
        "managed": true
      },
      {
        "id": "1489504348261322916",
        "name": "M7r BOSS",
        "color": "#992d22",
        "position": 66,
        "managed": false
      },
      {
        "id": "1489504349423009936",
        "name": "w",
        "color": "#021f32",
        "position": 65,
        "managed": false
      },
      {
        "id": "1489504351763431504",
        "name": "★ |  𝐎𝐟𝐫𝐚𝐬 𝐨𝐟 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫",
        "color": "#ffca00",
        "position": 64,
        "managed": false
      },
      {
        "id": "1489504359476625518",
        "name": "| 𝐅𝐎𝐔𝐍𝐃𝐄𝐑 ★",
        "color": "#606060",
        "position": 63,
        "managed": false
      },
      {
        "id": "1489504360672264223",
        "name": "| 𝐒𝐞𝐫𝐯𝐞𝐫 𝐌𝐚𝐧𝐚𝐠𝐞𝐫",
        "color": "#055d00",
        "position": 62,
        "managed": false
      },
      {
        "id": "1489504362056388668",
        "name": "★  | 𝐂𝐎 𝐎𝐟𝐫𝐚𝐬 𝐨𝐟 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫",
        "color": "#000000",
        "position": 61,
        "managed": false
      },
      {
        "id": "1489504362857496676",
        "name": "★ | 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 𝐩𝐭𝐫𝐟𝐝",
        "color": "#ffffff",
        "position": 60,
        "managed": false
      },
      {
        "id": "1489504363792699532",
        "name": "★ | 𝐗𝐩𝐫𝐮𝐭 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫",
        "color": "#8a0000",
        "position": 59,
        "managed": false
      },
      {
        "id": "1489504364841406534",
        "name": "★ 𝐅𝐭 | 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 𝐣𝐨𝐚𝐬𝐝",
        "color": "#02005e",
        "position": 58,
        "managed": false
      },
      {
        "id": "1489504365915013192",
        "name": "| 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 𝐄𝐬𝐱𝐩𝐭𝐫 ★",
        "color": "#270070",
        "position": 57,
        "managed": false
      },
      {
        "id": "1489504367110389760",
        "name": "𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫",
        "color": "#7073d9",
        "position": 56,
        "managed": false
      },
      {
        "id": "1489504368184131609",
        "name": "| فـريــق اول",
        "color": "#260b0b",
        "position": 55,
        "managed": false
      },
      {
        "id": "1489504370067509248",
        "name": "々 | 𝑪𝒐 𝑶𝒘𝒏𝒆𝒓",
        "color": "#040404",
        "position": 54,
        "managed": false
      },
      {
        "id": "1489504371010965666",
        "name": "々 | 𝑴𝒂𝒋𝒐𝒓",
        "color": "#470700",
        "position": 53,
        "managed": false
      },
      {
        "id": "1489504371526991894",
        "name": "々 | 𝑭𝒐𝒖𝒏𝒅𝒆𝒓",
        "color": "#72ff00",
        "position": 52,
        "managed": false
      },
      {
        "id": "1489504372957249667",
        "name": "々 |  𝑪𝒐 𝑭𝒐𝒖𝒏𝒅𝒆𝒓",
        "color": "#d6ff00",
        "position": 51,
        "managed": false
      },
      {
        "id": "1489504374358147284",
        "name": "々 | 𝑪𝒐𝒎𝒎𝒂𝒏𝒅𝒆𝒓",
        "color": "#e74c3c",
        "position": 50,
        "managed": false
      },
      {
        "id": "1489504375259926588",
        "name": "々 | Advisor",
        "color": "#00ff86",
        "position": 49,
        "managed": false
      },
      {
        "id": "1489504376102981642",
        "name": "々 | Co Advisor",
        "color": "#992d22",
        "position": 48,
        "managed": false
      },
      {
        "id": "1489504377046827288",
        "name": "عضو قلتش xp",
        "color": "#2ecc71",
        "position": 47,
        "managed": false
      },
      {
        "id": "1489504378023972914",
        "name": "𝑪𝒐𝒏𝒔𝒐𝒍𝒆 🎮",
        "color": "#564681",
        "position": 46,
        "managed": false
      },
      {
        "id": "1489504379177533561",
        "name": "Xbox 🎮",
        "color": "#11806a",
        "position": 45,
        "managed": false
      },
      {
        "id": "1489504380469117089",
        "name": "𝐈𝐏𝐀𝐃 📱",
        "color": "#005d2f",
        "position": 44,
        "managed": false
      },
      {
        "id": "1489504381647716472",
        "name": "𝑷𝑪 🖥️",
        "color": "#ffffff",
        "position": 43,
        "managed": false
      },
      {
        "id": "1489504382721593344",
        "name": "| رئـيس رقـبـاء",
        "color": "#a84300",
        "position": 42,
        "managed": false
      },
      {
        "id": "1489504383577227264",
        "name": "| رقـيـب اول",
        "color": "#c27c0e",
        "position": 41,
        "managed": false
      },
      {
        "id": "1489504384550174730",
        "name": "| رقـيـب",
        "color": "#f1c40f",
        "position": 40,
        "managed": false
      },
      {
        "id": "1489504385586298971",
        "name": "|وكـيـل رقـيـب",
        "color": "#71368a",
        "position": 39,
        "managed": false
      },
      {
        "id": "1489504386693726248",
        "name": "| عـريـف",
        "color": "#e91e63",
        "position": 38,
        "managed": false
      },
      {
        "id": "1489504387494842458",
        "name": "| جـنـدي اول",
        "color": "#e67e22",
        "position": 37,
        "managed": false
      },
      {
        "id": "1489504388480241724",
        "name": "| جـنـدي",
        "color": "#206694",
        "position": 36,
        "managed": false
      },
      {
        "id": "1489504390149832814",
        "name": "𝐟𝐨𝐮𝐧𝐝𝐞𝐫",
        "color": "#ff0000",
        "position": 35,
        "managed": false
      },
      {
        "id": "1489504391378505748",
        "name": "| مـلازم",
        "color": "#1f8b4c",
        "position": 34,
        "managed": false
      },
      {
        "id": "1489504392510963882",
        "name": "| مـلازم اول",
        "color": "#11806a",
        "position": 33,
        "managed": false
      },
      {
        "id": "1489504393429520416",
        "name": "| نـقـيـب",
        "color": "#e91e63",
        "position": 32,
        "managed": false
      },
      {
        "id": "1489504394042146939",
        "name": "| رائـد",
        "color": "#9b59b6",
        "position": 31,
        "managed": false
      },
      {
        "id": "1489504395401101454",
        "name": "|مـقـدم",
        "color": "#3498db",
        "position": 30,
        "managed": false
      },
      {
        "id": "1489504396717854802",
        "name": "| عـقـيـد",
        "color": "#2ecc71",
        "position": 29,
        "managed": false
      },
      {
        "id": "1489504397875613779",
        "name": "| عـمـيـد",
        "color": "#1abc9c",
        "position": 28,
        "managed": false
      },
      {
        "id": "1489504398991167489",
        "name": "| لـواء",
        "color": "#ed1717",
        "position": 27,
        "managed": false
      },
      {
        "id": "1489504400488665169",
        "name": "| فـريـق",
        "color": "#e91e63",
        "position": 26,
        "managed": false
      },
      {
        "id": "1489504401797415042",
        "name": "| مـسـؤول التـقـديـم",
        "color": "#9b59b6",
        "position": 25,
        "managed": false
      },
      {
        "id": "1489504402892132432",
        "name": "| نـائـب مـســؤول الـتـقـديـم",
        "color": "#3498db",
        "position": 24,
        "managed": false
      },
      {
        "id": "1489504403596771391",
        "name": "𝐂𝐎 𝐁𝐎𝐒𝐒",
        "color": "#607d8b",
        "position": 23,
        "managed": false
      },
      {
        "id": "1489504411251249172",
        "name": "々 | ticket support",
        "color": "#e67e22",
        "position": 22,
        "managed": false
      },
      {
        "id": "1489504415969972244",
        "name": "اشعارات الاخبار",
        "color": "#ff0000",
        "position": 21,
        "managed": false
      },
      {
        "id": "1489504420596285461",
        "name": "تـحـذير اول..🚨!",
        "color": "#e74c3c",
        "position": 20,
        "managed": false
      },
      {
        "id": "1489504421745262602",
        "name": "تـحـذيـر ثاني..🚨!",
        "color": "#e74c3c",
        "position": 19,
        "managed": false
      },
      {
        "id": "1489504423196622980",
        "name": "تـحـذيـر ثالـث..🚨!",
        "color": "#e74c3c",
        "position": 18,
        "managed": false
      },
      {
        "id": "1489571917596983408",
        "name": "Security",
        "color": "#000000",
        "position": 17,
        "managed": true
      },
      {
        "id": "1493201310634213469",
        "name": "Boogie",
        "color": "#000000",
        "position": 16,
        "managed": true
      },
      {
        "id": "1493202964892881020",
        "name": "LunaBot 🌙",
        "color": "#000000",
        "position": 15,
        "managed": true
      },
      {
        "id": "1493280599434330305",
        "name": "غير متفعل",
        "color": "#ff0909",
        "position": 14,
        "managed": false
      },
      {
        "id": "1530423745351782424",
        "name": "KeyCrusher",
        "color": "#000000",
        "position": 13,
        "managed": true
      },
      {
        "id": "1549729643022782524",
        "name": "Botx4999",
        "color": "#000000",
        "position": 12,
        "managed": true
      },
      {
        "id": "1554132090826653739",
        "name": "Wicks",
        "color": "#000000",
        "position": 11,
        "managed": true
      },
      {
        "id": "1555220336503689316",
        "name": "ZMN",
        "color": "#000000",
        "position": 10,
        "managed": true
      },
      {
        "id": "1555533729038991392",
        "name": "عضو رسمي",
        "color": "#ffee04",
        "position": 9,
        "managed": false
      },
      {
        "id": "1555533787788615690",
        "name": "غير رسمي",
        "color": "#e91e63",
        "position": 8,
        "managed": false
      },
      {
        "id": "1556140544361627708",
        "name": "غير مقبول",
        "color": "#e91e63",
        "position": 7,
        "managed": false
      },
      {
        "id": "1558083295042998344",
        "name": "Prisoner",
        "color": "#992d22",
        "position": 6,
        "managed": false
      },
      {
        "id": "1558454639538470933",
        "name": "Server Booster",
        "color": "#f47fff",
        "position": 5,
        "managed": true
      },
      {
        "id": "1559947910072770581",
        "name": "Better eh",
        "color": "#ffea1d",
        "position": 4,
        "managed": false
      },
      {
        "id": "1559963416033230938",
        "name": "Blockspin",
        "color": "#000000",
        "position": 3,
        "managed": false
      },
      {
        "id": "1564993642324562051",
        "name": "كتم",
        "color": "#607d8b",
        "position": 2,
        "managed": false
      },
      {
        "id": "1565683468095070310",
        "name": "m7r",
        "color": "#000000",
        "position": 1,
        "managed": true
      }
    ]
  },
  "1493178407188693112": {
    "success": true,
    "live": true,
    "guild": {
      "id": "1493178407188693112",
      "name": "m7r",
      "icon": "https://cdn.discordapp.com/icons/1493178407188693112/f61be6472a2e8801cab912a46a0165f9.webp",
      "memberCount": 72,
      "channelsCount": 18,
      "rolesCount": 36,
      "ownerId": "1219299588402577532",
      "hasBot": true,
      "botPresent": true,
      "canManage": true
    },
    "textChannels": [
      {
        "id": "1494241924947771505",
        "name": "log-ticket",
        "type": "text",
        "parentId": "1494242017788690605",
        "position": 0
      },
      {
        "id": "1494245853068787742",
        "name": "𝐖𝐄𝐋𝐂𝐎𝐌𝐄👋",
        "type": "text",
        "parentId": "1494255103576899635",
        "position": 0
      },
      {
        "id": "1494258381853163631",
        "name": "cht💬",
        "type": "text",
        "parentId": "1493178407796740156",
        "position": 0
      },
      {
        "id": "1513917715021168650",
        "name": "ممنوع-الارسال🚫",
        "type": "text",
        "parentId": null,
        "position": 0
      },
      {
        "id": "1494245139525402764",
        "name": "ticket🎫",
        "type": "text",
        "parentId": "1493178407796740156",
        "position": 1
      },
      {
        "id": "1494247222701723738",
        "name": "𝐑𝐮𝐥𝐞𝐬📚",
        "type": "text",
        "parentId": "1494255103576899635",
        "position": 1
      },
      {
        "id": "1494250880470351992",
        "name": "تقديم-اعضاء",
        "type": "text",
        "parentId": null,
        "position": 1
      },
      {
        "id": "1495385168779935774",
        "name": "news-🗞️",
        "type": "text",
        "parentId": "1493178407796740156",
        "position": 2
      },
      {
        "id": "1494641554403627079",
        "name": "اقتراحات",
        "type": "text",
        "parentId": "1493178407796740156",
        "position": 3
      }
    ],
    "voiceChannels": [
      {
        "id": "1493178407796740159",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬 1",
        "type": "voice",
        "parentId": "1493178407796740157",
        "position": 0
      },
      {
        "id": "1496130667560435732",
        "name": "m7r",
        "type": "voice",
        "parentId": "1494242017788690605",
        "position": 0
      },
      {
        "id": "1494250569995653203",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬 2",
        "type": "voice",
        "parentId": "1493178407796740157",
        "position": 1
      },
      {
        "id": "1522561455046660256",
        "name": "فايتات",
        "type": "voice",
        "parentId": "1494242017788690605",
        "position": 1
      },
      {
        "id": "1494250708331921479",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬 3",
        "type": "voice",
        "parentId": "1493178407796740157",
        "position": 2
      },
      {
        "id": "1494250784156553306",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬 4",
        "type": "voice",
        "parentId": "1493178407796740157",
        "position": 3
      },
      {
        "id": "1498021612916576276",
        "name": "𝐖𝐚𝐫 𝐭𝐲𝐜𝐨𝐨𝐧 1",
        "type": "voice",
        "parentId": "1493178407796740157",
        "position": 4
      },
      {
        "id": "1498021868865851462",
        "name": "𝐖𝐚𝐫 𝐭𝐲𝐜𝐨𝐨𝐧 2",
        "type": "voice",
        "parentId": "1493178407796740157",
        "position": 5
      },
      {
        "id": "1498021920678088824",
        "name": "𝐖𝐚𝐫 𝐭𝐲𝐜𝐨𝐨𝐧 3",
        "type": "voice",
        "parentId": "1493178407796740157",
        "position": 6
      }
    ],
    "categoryChannels": [
      {
        "id": "1494255103576899635",
        "name": "قوانين",
        "type": "category",
        "position": 0
      },
      {
        "id": "1493178407796740156",
        "name": "عام",
        "type": "category",
        "position": 1
      },
      {
        "id": "1493178407796740157",
        "name": "Voice Channels",
        "type": "category",
        "position": 2
      },
      {
        "id": "1494242017788690605",
        "name": "log",
        "type": "category",
        "position": 3
      }
    ],
    "channels": [
      {
        "id": "1494241924947771505",
        "name": "log-ticket",
        "type": "text"
      },
      {
        "id": "1494245853068787742",
        "name": "𝐖𝐄𝐋𝐂𝐎𝐌𝐄👋",
        "type": "text"
      },
      {
        "id": "1494258381853163631",
        "name": "cht💬",
        "type": "text"
      },
      {
        "id": "1513917715021168650",
        "name": "ممنوع-الارسال🚫",
        "type": "text"
      },
      {
        "id": "1494245139525402764",
        "name": "ticket🎫",
        "type": "text"
      },
      {
        "id": "1494247222701723738",
        "name": "𝐑𝐮𝐥𝐞𝐬📚",
        "type": "text"
      },
      {
        "id": "1494250880470351992",
        "name": "تقديم-اعضاء",
        "type": "text"
      },
      {
        "id": "1495385168779935774",
        "name": "news-🗞️",
        "type": "text"
      },
      {
        "id": "1494641554403627079",
        "name": "اقتراحات",
        "type": "text"
      },
      {
        "id": "1493178407796740159",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬 1",
        "type": "voice"
      },
      {
        "id": "1496130667560435732",
        "name": "m7r",
        "type": "voice"
      },
      {
        "id": "1494250569995653203",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬 2",
        "type": "voice"
      },
      {
        "id": "1522561455046660256",
        "name": "فايتات",
        "type": "voice"
      },
      {
        "id": "1494250708331921479",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬 3",
        "type": "voice"
      },
      {
        "id": "1494250784156553306",
        "name": "『🔊』𝑽𝑶𝑰𝑪𝑬 4",
        "type": "voice"
      },
      {
        "id": "1498021612916576276",
        "name": "𝐖𝐚𝐫 𝐭𝐲𝐜𝐨𝐨𝐧 1",
        "type": "voice"
      },
      {
        "id": "1498021868865851462",
        "name": "𝐖𝐚𝐫 𝐭𝐲𝐜𝐨𝐨𝐧 2",
        "type": "voice"
      },
      {
        "id": "1498021920678088824",
        "name": "𝐖𝐚𝐫 𝐭𝐲𝐜𝐨𝐨𝐧 3",
        "type": "voice"
      },
      {
        "id": "1494255103576899635",
        "name": "قوانين",
        "type": "category"
      },
      {
        "id": "1493178407796740156",
        "name": "عام",
        "type": "category"
      },
      {
        "id": "1493178407796740157",
        "name": "Voice Channels",
        "type": "category"
      },
      {
        "id": "1494242017788690605",
        "name": "log",
        "type": "category"
      }
    ],
    "roles": [
      {
        "id": "1494241550169800768",
        "name": "FlixerX",
        "color": "#000000",
        "position": 36,
        "managed": true
      },
      {
        "id": "1493178551640264777",
        "name": "Xenon",
        "color": "#000000",
        "position": 35,
        "managed": true
      },
      {
        "id": "1494242413475004491",
        "name": "Boogie",
        "color": "#000000",
        "position": 34,
        "managed": true
      },
      {
        "id": "1494248242370842694",
        "name": "𝑺𝒆𝒓𝒗𝒆𝒓 𝑶𝒘𝒏𝒆𝒓",
        "color": "#ff0101",
        "position": 33,
        "managed": false
      },
      {
        "id": "1494248437120499773",
        "name": "جندي",
        "color": "#000000",
        "position": 32,
        "managed": false
      },
      {
        "id": "1494248486592450612",
        "name": "جندي اول",
        "color": "#000000",
        "position": 31,
        "managed": false
      },
      {
        "id": "1494248523258925127",
        "name": "عريف",
        "color": "#000000",
        "position": 30,
        "managed": false
      },
      {
        "id": "1494248943834497024",
        "name": "رقيب",
        "color": "#000000",
        "position": 29,
        "managed": false
      },
      {
        "id": "1494249142296510555",
        "name": "وكيل رقيب",
        "color": "#000000",
        "position": 28,
        "managed": false
      },
      {
        "id": "1494249199464747050",
        "name": "رقيب اول",
        "color": "#000000",
        "position": 27,
        "managed": false
      },
      {
        "id": "1494249305240768604",
        "name": "ملازم",
        "color": "#000000",
        "position": 26,
        "managed": false
      },
      {
        "id": "1494249351529107549",
        "name": "ملازم اول",
        "color": "#000000",
        "position": 25,
        "managed": false
      },
      {
        "id": "1494249396718796831",
        "name": "نقيب",
        "color": "#000000",
        "position": 24,
        "managed": false
      },
      {
        "id": "1494249429711061144",
        "name": "رائد",
        "color": "#000000",
        "position": 23,
        "managed": false
      },
      {
        "id": "1494249479711490048",
        "name": "مقدم",
        "color": "#000000",
        "position": 22,
        "managed": false
      },
      {
        "id": "1494249518433177650",
        "name": "عقيد",
        "color": "#000000",
        "position": 21,
        "managed": false
      },
      {
        "id": "1494249566864674856",
        "name": "عميد",
        "color": "#000000",
        "position": 20,
        "managed": false
      },
      {
        "id": "1494249621021790258",
        "name": "لواء",
        "color": "#000000",
        "position": 19,
        "managed": false
      },
      {
        "id": "1494249666987167825",
        "name": "فريق",
        "color": "#000000",
        "position": 18,
        "managed": false
      },
      {
        "id": "1494249959304990730",
        "name": "ticket support",
        "color": "#e74c3c",
        "position": 17,
        "managed": false
      },
      {
        "id": "1494254417677914144",
        "name": "غير مفعل",
        "color": "#f1c40f",
        "position": 16,
        "managed": false
      },
      {
        "id": "1494258198427729944",
        "name": "Fizbo",
        "color": "#000000",
        "position": 15,
        "managed": true
      },
      {
        "id": "1496130154198601903",
        "name": "LunaBot 🌙",
        "color": "#000000",
        "position": 14,
        "managed": true
      },
      {
        "id": "1496130779502346301",
        "name": "m7r",
        "color": "#000000",
        "position": 13,
        "managed": false
      },
      {
        "id": "1500469155076243479",
        "name": "Riezn BOT",
        "color": "#000000",
        "position": 12,
        "managed": true
      },
      {
        "id": "1512406478722437142",
        "name": "PlayStation™Network Unofficial",
        "color": "#000000",
        "position": 11,
        "managed": true
      },
      {
        "id": "1513913032403587084",
        "name": "PSN TROPHY BOT",
        "color": "#000000",
        "position": 10,
        "managed": true
      },
      {
        "id": "1513919257166090354",
        "name": "Sapphire",
        "color": "#000000",
        "position": 9,
        "managed": true
      },
      {
        "id": "1537088708488994938",
        "name": "VetroniqBot Quran",
        "color": "#000000",
        "position": 8,
        "managed": true
      },
      {
        "id": "1544698856644681790",
        "name": "ProBot ✨",
        "color": "#000000",
        "position": 7,
        "managed": true
      },
      {
        "id": "1545428206855655496",
        "name": "KeyCrusher",
        "color": "#000000",
        "position": 6,
        "managed": true
      },
      {
        "id": "1549033488898859050",
        "name": "ذِكـر",
        "color": "#000000",
        "position": 5,
        "managed": true
      },
      {
        "id": "1549050808375709727",
        "name": "々 | 𝑭𝒐𝒖𝒏𝒅𝒆𝒓",
        "color": "#2ecc71",
        "position": 4,
        "managed": false
      },
      {
        "id": "1555609870919663658",
        "name": "m7r",
        "color": "#000000",
        "position": 3,
        "managed": true
      },
      {
        "id": "1559598239702061161",
        "name": "Wicks",
        "color": "#000000",
        "position": 2,
        "managed": true
      },
      {
        "id": "1567523887107805287",
        "name": "m7r",
        "color": "#000000",
        "position": 1,
        "managed": true
      }
    ]
  },
  "1525374225425367171": {
    "success": true,
    "live": true,
    "guild": {
      "id": "1525374225425367171",
      "name": "𝐀𝐩𝐞𝐱 ⚜️ / صيد الضبان 🦎",
      "icon": "https://cdn.discordapp.com/icons/1525374225425367171/f62646a01b911a76d02c672d1c97985e.webp",
      "memberCount": 309,
      "channelsCount": 29,
      "rolesCount": 29,
      "ownerId": "1184069933374652466",
      "hasBot": true,
      "botPresent": true,
      "canManage": true
    },
    "textChannels": [
      {
        "id": "1525374660726751343",
        "name": "↯・〢⌠🕋⌡・اذكار",
        "type": "text",
        "parentId": "1525540523841028288",
        "position": 0
      },
      {
        "id": "1567479983260041286",
        "name": "↯・〢⌠💬⌡・شــات",
        "type": "text",
        "parentId": "1525374641814634618",
        "position": 0
      },
      {
        "id": "1525374646541615215",
        "name": "↯・〢⌠👋⌡・𝐖𝐄𝐋𝐂𝐎𝐌𝐄",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 0
      },
      {
        "id": "1561672973730058281",
        "name": "الرتب",
        "type": "text",
        "parentId": null,
        "position": 0
      },
      {
        "id": "1525540524935876742",
        "name": "↯・〢⌠🕋⌡لوحة・التحكم",
        "type": "text",
        "parentId": "1525540523841028288",
        "position": 1
      },
      {
        "id": "1554187961132908544",
        "name": "↯・〢⌠🦎⌡تقديم・صيد・الضبان",
        "type": "text",
        "parentId": "1525374641814634618",
        "position": 1
      },
      {
        "id": "1554188107426037972",
        "name": "↯・〢⌠❗⌡・𝐋𝐢𝐯𝐞",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 1
      },
      {
        "id": "1561672973730058284",
        "name": "moderator-only",
        "type": "text",
        "parentId": null,
        "position": 1
      },
      {
        "id": "1564671539654172733",
        "name": "مرجعات-التقديمات-والسيرفر",
        "type": "text",
        "parentId": null,
        "position": 2
      },
      {
        "id": "1554189346721243156",
        "name": "↯・〢⌠📰⌡・الاخبار",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 2
      },
      {
        "id": "1554189529005690910",
        "name": "↯・〢⌠⬅️⌡・تريدات",
        "type": "text",
        "parentId": "1525374641814634618",
        "position": 2
      },
      {
        "id": "1554191185667428555",
        "name": "↯・〢⌠📓⌡・القوانين",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 3
      },
      {
        "id": "1560985615720255600",
        "name": "↯・〢⌠🔐⌡خذ・مفتاحك",
        "type": "text",
        "parentId": "1525374641814634618",
        "position": 3
      },
      {
        "id": "1564678396825575564",
        "name": "ممنوع-الارسال🚫",
        "type": "text",
        "parentId": null,
        "position": 3
      },
      {
        "id": "1564675479615840388",
        "name": "↯・〢⌠🎫⌡・تيكت",
        "type": "text",
        "parentId": "1525374641814634618",
        "position": 4
      },
      {
        "id": "1554195755411963974",
        "name": "↯・〢⌠🚨⌡・التحذيرات",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 4
      },
      {
        "id": "1563998137876611102",
        "name": "↯・〢⌠🦎⌡السيرفر・الخاص・صيد・الضبان",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 5
      },
      {
        "id": "1567477494184157314",
        "name": "↯・〢⌠🦠⌡・سكربتات",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 6
      },
      {
        "id": "1564308034446958734",
        "name": "لايفات•صناع•المحتوى👨🏻‍💻",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 7
      },
      {
        "id": "1567604612024893594",
        "name": "m7r•ai🤖",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 8
      },
      {
        "id": "1567946198302597160",
        "name": "clips📸",
        "type": "text",
        "parentId": "1525374641093214229",
        "position": 9
      }
    ],
    "voiceChannels": [
      {
        "id": "1525540525992575036",
        "name": "↯・〢⌠🕋⌡القرأن・كريم",
        "type": "voice",
        "parentId": "1525540523841028288",
        "position": 0
      },
      {
        "id": "1567895015458340895",
        "name": "Waiting ⏳",
        "type": "voice",
        "parentId": "1567895524806365224",
        "position": 0
      },
      {
        "id": "1525374644465565696",
        "name": "↯・〢⌠🎙️⌡・𝐕𝐨𝐢𝐜𝐞",
        "type": "voice",
        "parentId": "1525374642682990634",
        "position": 0
      },
      {
        "id": "1525374645409157160",
        "name": "↯・〢⌠❗⌡𝐋𝐈𝐕𝐄・𝐕𝐨𝐢𝐜𝐞",
        "type": "voice",
        "parentId": "1525374642682990634",
        "position": 1
      },
      {
        "id": "1567895781388718100",
        "name": "Admin test⚜️",
        "type": "voice",
        "parentId": "1567895524806365224",
        "position": 1
      },
      {
        "id": "1567945327791841342",
        "name": "تقديم صانع المحتوى 👨🏻‍💻⚜️",
        "type": "voice",
        "parentId": "1567895524806365224",
        "position": 2
      },
      {
        "id": "1525374647594385498",
        "name": "↯・〢⌠🎙️⌡・سوالف",
        "type": "voice",
        "parentId": "1525374642682990634",
        "position": 2
      },
      {
        "id": "1525374652732539050",
        "name": "↯・〢⌠➕⌡انشاء・روم",
        "type": "voice",
        "parentId": "1525374642682990634",
        "position": 3
      }
    ],
    "categoryChannels": [
      {
        "id": "1525540523841028288",
        "name": "🕋 Ayat・آيات",
        "type": "category",
        "position": 0
      },
      {
        "id": "1525374641093214229",
        "name": "〡𝐍𝐄𝐖𝐒",
        "type": "category",
        "position": 1
      },
      {
        "id": "1525374641814634618",
        "name": "🌍〡𝐏𝐔𝐁𝐋𝐈𝐂",
        "type": "category",
        "position": 2
      },
      {
        "id": "1525374642682990634",
        "name": "🎤〡𝐕𝐎𝐈𝐂𝐄",
        "type": "category",
        "position": 3
      },
      {
        "id": "1564677799573459038",
        "name": "التذاكر",
        "type": "category",
        "position": 4
      },
      {
        "id": "1567895524806365224",
        "name": "Support🔒⚜️",
        "type": "category",
        "position": 5
      }
    ],
    "channels": [
      {
        "id": "1525374660726751343",
        "name": "↯・〢⌠🕋⌡・اذكار",
        "type": "text"
      },
      {
        "id": "1567479983260041286",
        "name": "↯・〢⌠💬⌡・شــات",
        "type": "text"
      },
      {
        "id": "1525374646541615215",
        "name": "↯・〢⌠👋⌡・𝐖𝐄𝐋𝐂𝐎𝐌𝐄",
        "type": "text"
      },
      {
        "id": "1561672973730058281",
        "name": "الرتب",
        "type": "text"
      },
      {
        "id": "1525540524935876742",
        "name": "↯・〢⌠🕋⌡لوحة・التحكم",
        "type": "text"
      },
      {
        "id": "1554187961132908544",
        "name": "↯・〢⌠🦎⌡تقديم・صيد・الضبان",
        "type": "text"
      },
      {
        "id": "1554188107426037972",
        "name": "↯・〢⌠❗⌡・𝐋𝐢𝐯𝐞",
        "type": "text"
      },
      {
        "id": "1561672973730058284",
        "name": "moderator-only",
        "type": "text"
      },
      {
        "id": "1564671539654172733",
        "name": "مرجعات-التقديمات-والسيرفر",
        "type": "text"
      },
      {
        "id": "1554189346721243156",
        "name": "↯・〢⌠📰⌡・الاخبار",
        "type": "text"
      },
      {
        "id": "1554189529005690910",
        "name": "↯・〢⌠⬅️⌡・تريدات",
        "type": "text"
      },
      {
        "id": "1554191185667428555",
        "name": "↯・〢⌠📓⌡・القوانين",
        "type": "text"
      },
      {
        "id": "1560985615720255600",
        "name": "↯・〢⌠🔐⌡خذ・مفتاحك",
        "type": "text"
      },
      {
        "id": "1564678396825575564",
        "name": "ممنوع-الارسال🚫",
        "type": "text"
      },
      {
        "id": "1564675479615840388",
        "name": "↯・〢⌠🎫⌡・تيكت",
        "type": "text"
      },
      {
        "id": "1554195755411963974",
        "name": "↯・〢⌠🚨⌡・التحذيرات",
        "type": "text"
      },
      {
        "id": "1563998137876611102",
        "name": "↯・〢⌠🦎⌡السيرفر・الخاص・صيد・الضبان",
        "type": "text"
      },
      {
        "id": "1567477494184157314",
        "name": "↯・〢⌠🦠⌡・سكربتات",
        "type": "text"
      },
      {
        "id": "1564308034446958734",
        "name": "لايفات•صناع•المحتوى👨🏻‍💻",
        "type": "text"
      },
      {
        "id": "1567604612024893594",
        "name": "m7r•ai🤖",
        "type": "text"
      },
      {
        "id": "1567946198302597160",
        "name": "clips📸",
        "type": "text"
      },
      {
        "id": "1525540525992575036",
        "name": "↯・〢⌠🕋⌡القرأن・كريم",
        "type": "voice"
      },
      {
        "id": "1567895015458340895",
        "name": "Waiting ⏳",
        "type": "voice"
      },
      {
        "id": "1525374644465565696",
        "name": "↯・〢⌠🎙️⌡・𝐕𝐨𝐢𝐜𝐞",
        "type": "voice"
      },
      {
        "id": "1525374645409157160",
        "name": "↯・〢⌠❗⌡𝐋𝐈𝐕𝐄・𝐕𝐨𝐢𝐜𝐞",
        "type": "voice"
      },
      {
        "id": "1567895781388718100",
        "name": "Admin test⚜️",
        "type": "voice"
      },
      {
        "id": "1567945327791841342",
        "name": "تقديم صانع المحتوى 👨🏻‍💻⚜️",
        "type": "voice"
      },
      {
        "id": "1525374647594385498",
        "name": "↯・〢⌠🎙️⌡・سوالف",
        "type": "voice"
      },
      {
        "id": "1525374652732539050",
        "name": "↯・〢⌠➕⌡انشاء・روم",
        "type": "voice"
      },
      {
        "id": "1525540523841028288",
        "name": "🕋 Ayat・آيات",
        "type": "category"
      },
      {
        "id": "1525374641093214229",
        "name": "〡𝐍𝐄𝐖𝐒",
        "type": "category"
      },
      {
        "id": "1525374641814634618",
        "name": "🌍〡𝐏𝐔𝐁𝐋𝐈𝐂",
        "type": "category"
      },
      {
        "id": "1525374642682990634",
        "name": "🎤〡𝐕𝐎𝐈𝐂𝐄",
        "type": "category"
      },
      {
        "id": "1564677799573459038",
        "name": "التذاكر",
        "type": "category"
      },
      {
        "id": "1567895524806365224",
        "name": "Support🔒⚜️",
        "type": "category"
      }
    ],
    "roles": [
      {
        "id": "1525374628128751718",
        "name": "𝐎𝐰𝐧𝐞𝐫",
        "color": "#e74c3c",
        "position": 29,
        "managed": false
      },
      {
        "id": "1564671109360652368",
        "name": "Co-Owner",
        "color": "#992d22",
        "position": 28,
        "managed": false
      },
      {
        "id": "1568141884818456737",
        "name": "⚜️الإدارة العليا⚜️",
        "color": "#3d0202",
        "position": 27,
        "managed": false
      },
      {
        "id": "1525374630066389052",
        "name": "𝐁𝐎𝐓",
        "color": "#71368a",
        "position": 26,
        "managed": false
      },
      {
        "id": "1525374626970992700",
        "name": "𝐀𝐃𝐌𝐈𝐍",
        "color": "#e67e22",
        "position": 25,
        "managed": false
      },
      {
        "id": "1564308377465524255",
        "name": "صانع محتوى👨🏻‍💻",
        "color": "#71368a",
        "position": 24,
        "managed": false
      },
      {
        "id": "1525374629005361322",
        "name": "𝐌𝐄𝐌𝐁𝐄𝐑",
        "color": "#1f8b4c",
        "position": 22,
        "managed": false
      },
      {
        "id": "1525375157055782916",
        "name": "Lara✨",
        "color": "#000000",
        "position": 21,
        "managed": true
      },
      {
        "id": "1525375391873630372",
        "name": "🕋 Ayat・آيات",
        "color": "#000000",
        "position": 20,
        "managed": true
      },
      {
        "id": "1525375487663149149",
        "name": "Valor",
        "color": "#000000",
        "position": 19,
        "managed": true
      },
      {
        "id": "1525375673584324700",
        "name": "ProBot ✨",
        "color": "#000000",
        "position": 18,
        "managed": true
      },
      {
        "id": "1527005045734772780",
        "name": "IM",
        "color": "#000000",
        "position": 17,
        "managed": true
      },
      {
        "id": "1535843650049802324",
        "name": "Wicks",
        "color": "#000000",
        "position": 16,
        "managed": true
      },
      {
        "id": "1536049094722723943",
        "name": "๖ۣۜDynasty Stock",
        "color": "#000000",
        "position": 15,
        "managed": true
      },
      {
        "id": "1539762936837439498",
        "name": ".",
        "color": "#000000",
        "position": 14,
        "managed": false
      },
      {
        "id": "1539763881180925982",
        "name": "Anti Nuke Bot",
        "color": "#000000",
        "position": 13,
        "managed": true
      },
      {
        "id": "1539765695653355663",
        "name": "NukeBot",
        "color": "#000000",
        "position": 12,
        "managed": true
      },
      {
        "id": "1553810197368279133",
        "name": "Xenon",
        "color": "#000000",
        "position": 11,
        "managed": true
      },
      {
        "id": "1554194188994744403",
        "name": "Kivo",
        "color": "#000000",
        "position": 10,
        "managed": true
      },
      {
        "id": "1560985407477256366",
        "name": "BotScripts",
        "color": "#000000",
        "position": 9,
        "managed": true
      },
      {
        "id": "1562050742280392724",
        "name": "M7R GAMES",
        "color": "#000000",
        "position": 8,
        "managed": true
      },
      {
        "id": "1564350999211151441",
        "name": "FiveCore",
        "color": "#000000",
        "position": 7,
        "managed": true
      },
      {
        "id": "1564379157176123435",
        "name": "Riezn BOT",
        "color": "#000000",
        "position": 6,
        "managed": true
      },
      {
        "id": "1564671380891500614",
        "name": "KeyCrusher",
        "color": "#000000",
        "position": 5,
        "managed": true
      },
      {
        "id": "1564674902647115808",
        "name": "𝐀𝐩𝐞𝐱",
        "color": "#000000",
        "position": 4,
        "managed": true
      },
      {
        "id": "1567187831724707906",
        "name": "كتم",
        "color": "#607d8b",
        "position": 3,
        "managed": false
      },
      {
        "id": "1567193633424408629",
        "name": "m7r",
        "color": "#000000",
        "position": 2,
        "managed": true
      },
      {
        "id": "1567896098276773898",
        "name": "⚠️تحت التدريب⚠️",
        "color": "#f1c40f",
        "position": 1,
        "managed": false
      }
    ]
  },
  "1564569257755410523": {
    "success": true,
    "live": true,
    "guild": {
      "id": "1564569257755410523",
      "name": "𝓜7𝓡's server",
      "icon": "",
      "memberCount": 7,
      "channelsCount": 6,
      "rolesCount": 4,
      "ownerId": "1219299588402577532",
      "hasBot": true,
      "botPresent": true,
      "canManage": true
    },
    "textChannels": [
      {
        "id": "1564569258673840179",
        "name": "general",
        "type": "text",
        "parentId": "1564569258673840178",
        "position": 0
      },
      {
        "id": "1564983743670919301",
        "name": "تذكرة-u5r9",
        "type": "text",
        "parentId": null,
        "position": 0
      },
      {
        "id": "1564569258673840180",
        "name": "clips-and-highlights",
        "type": "text",
        "parentId": "1564569258673840178",
        "position": 1
      },
      {
        "id": "1568253833556140042",
        "name": "ممنوع-الارسال🚫",
        "type": "text",
        "parentId": null,
        "position": 1
      }
    ],
    "voiceChannels": [
      {
        "id": "1564569258673840182",
        "name": "Lobby",
        "type": "voice",
        "parentId": "1564569258673840181",
        "position": 0
      },
      {
        "id": "1564569258673840183",
        "name": "Gaming",
        "type": "voice",
        "parentId": "1564569258673840181",
        "position": 1
      }
    ],
    "categoryChannels": [
      {
        "id": "1564569258673840178",
        "name": "Text Channels",
        "type": "category",
        "position": 0
      },
      {
        "id": "1564569258673840181",
        "name": "Voice Channels",
        "type": "category",
        "position": 1
      }
    ],
    "channels": [
      {
        "id": "1564569258673840179",
        "name": "general",
        "type": "text"
      },
      {
        "id": "1564983743670919301",
        "name": "تذكرة-u5r9",
        "type": "text"
      },
      {
        "id": "1564569258673840180",
        "name": "clips-and-highlights",
        "type": "text"
      },
      {
        "id": "1568253833556140042",
        "name": "ممنوع-الارسال🚫",
        "type": "text"
      },
      {
        "id": "1564569258673840182",
        "name": "Lobby",
        "type": "voice"
      },
      {
        "id": "1564569258673840183",
        "name": "Gaming",
        "type": "voice"
      },
      {
        "id": "1564569258673840178",
        "name": "Text Channels",
        "type": "category"
      },
      {
        "id": "1564569258673840181",
        "name": "Voice Channels",
        "type": "category"
      }
    ],
    "roles": [
      {
        "id": "1564646420936523867",
        "name": "new",
        "color": "#000000",
        "position": 4,
        "managed": false
      },
      {
        "id": "1564965342172815498",
        "name": "kia",
        "color": "#000000",
        "position": 3,
        "managed": true
      },
      {
        "id": "1565038247388778648",
        "name": "ne",
        "color": "#000000",
        "position": 2,
        "managed": false
      },
      {
        "id": "1567839239725645847",
        "name": "m7r",
        "color": "#000000",
        "position": 1,
        "managed": true
      }
    ]
  }
};
