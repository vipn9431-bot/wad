import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { LanguageProvider } from './contexts/LanguageContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { HashRouter } from './utils/hashRouter';
import './index.css';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

class RootErrorBoundary extends React.Component<{ children: React.ReactNode }, ErrorBoundaryState> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error?.message || 'Unexpected rendering error'
    };
  }

  componentDidCatch(error: Error) {
    console.error('[M7R RootErrorBoundary Caught]:', error);
  }

  handleResetAndReload = () => {
    try {
      localStorage.removeItem('m7r_selected_guild');
      localStorage.removeItem('m7r_discord_user');
    } catch {}
    this.setState({ hasError: false, errorMessage: '' });
    window.location.replace('/');
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          dir="rtl"
          className="min-h-screen bg-[#07090e] text-white flex items-center justify-center p-6 text-center"
        >
          <div className="max-w-md w-full rounded-3xl bg-[#0d111a] border border-slate-800 p-8 space-y-4 shadow-2xl">
            <h2 className="text-lg font-black text-white">استعادة جلسة لوحة تحكم M7R تلقائياً</h2>
            <p className="text-xs text-slate-400">
              تم رصد تعارض بسيط في ذاكرة المتصفح المؤقتة. اضغط بالأسفل لإعادة تنشيط الواجهة فوراً.
            </p>
            <button
              type="button"
              onClick={this.handleResetAndReload}
              className="w-full py-3 rounded-2xl bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs font-black cursor-pointer"
            >
              إعادة تحميل لوحة التحكم الآن
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <RootErrorBoundary>
    <ThemeProvider>
      <LanguageProvider>
        <HashRouter>
          <App />
        </HashRouter>
      </LanguageProvider>
    </ThemeProvider>
  </RootErrorBoundary>
);
