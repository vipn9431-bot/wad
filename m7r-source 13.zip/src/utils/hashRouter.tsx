import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

export interface RouteMeta {
  id: string;
  path: string;
  categoryAr: string;
  categoryEn: string;
  labelAr: string;
  labelEn: string;
}

export const DASHBOARD_ROUTES: Record<string, RouteMeta> = {
  overview: {
    id: 'overview',
    path: '#/overview',
    categoryAr: 'عام',
    categoryEn: 'General',
    labelAr: 'نظرة عامة',
    labelEn: 'Overview'
  },
  analytics: {
    id: 'analytics',
    path: '#/analytics',
    categoryAr: 'عام',
    categoryEn: 'General',
    labelAr: 'الإحصائيات والتحليلات',
    labelEn: 'Analytics & Insights'
  },
  audit_logs: {
    id: 'audit_logs',
    path: '#/audit_logs',
    categoryAr: 'عام',
    categoryEn: 'General',
    labelAr: 'سجلات السيرفر',
    labelEn: 'Server Audit Logs'
  },
  wizard: {
    id: 'wizard',
    path: '#/wizard',
    categoryAr: 'عام',
    categoryEn: 'General',
    labelAr: 'فحص جهوزية البوت',
    labelEn: 'Pre-Publish Diagnostics'
  },
  logsvisualizer: {
    id: 'logsvisualizer',
    path: '#/logsvisualizer',
    categoryAr: 'عام',
    categoryEn: 'General',
    labelAr: 'محلل السجلات',
    labelEn: 'Log Visualizer'
  },
  antinuke: {
    id: 'antinuke',
    path: '#/antinuke',
    categoryAr: 'الإشراف والحماية',
    categoryEn: 'Moderation & Protection',
    labelAr: 'الحماية والرادار',
    labelEn: 'Protection'
  },
  staff_warnings: {
    id: 'staff_warnings',
    path: '#/staff_warnings',
    categoryAr: 'الإشراف والحماية',
    categoryEn: 'Moderation & Protection',
    labelAr: 'الإشراف والرقابة',
    labelEn: 'Staff Warnings'
  },
  rules_builder: {
    id: 'rules_builder',
    path: '#/rules_builder',
    categoryAr: 'الإشراف والحماية',
    categoryEn: 'Moderation & Protection',
    labelAr: 'القوانين',
    labelEn: 'Server Rules'
  },
  ready_rooms: {
    id: 'ready_rooms',
    path: '#/ready_rooms',
    categoryAr: 'المجتمع والتفاعل',
    categoryEn: 'Community & Engagement',
    labelAr: 'الرومات الجاهزة ومنشئ السيرفر',
    labelEn: 'Ready Rooms & Builder'
  },
  server_builder: {
    id: 'server_builder',
    path: '#/server_builder',
    categoryAr: 'المجتمع والتفاعل',
    categoryEn: 'Community & Engagement',
    labelAr: 'منشئ السيرفر',
    labelEn: 'Server Builder'
  },
  tickets: {
    id: 'tickets',
    path: '#/tickets',
    categoryAr: 'المجتمع والتفاعل',
    categoryEn: 'Community & Engagement',
    labelAr: 'التذاكر',
    labelEn: 'Tickets System'
  },
  welcome: {
    id: 'welcome',
    path: '#/welcome',
    categoryAr: 'المجتمع والتفاعل',
    categoryEn: 'Community & Engagement',
    labelAr: 'الترحيب',
    labelEn: 'Welcome Studio'
  },
  staff_apps: {
    id: 'staff_apps',
    path: '#/staff_apps',
    categoryAr: 'المجتمع والتفاعل',
    categoryEn: 'Community & Engagement',
    labelAr: 'التقديمات',
    labelEn: 'Applications'
  },
  suggestions: {
    id: 'suggestions',
    path: '#/suggestions',
    categoryAr: 'المجتمع والتفاعل',
    categoryEn: 'Community & Engagement',
    labelAr: 'الاقتراحات والأفكار',
    labelEn: 'Suggestions Hub'
  },
  levels_ranks: {
    id: 'levels_ranks',
    path: '#/levels_ranks',
    categoryAr: 'المجتمع والتفاعل',
    categoryEn: 'Community & Engagement',
    labelAr: 'المستويات والرتب',
    labelEn: 'Levels & Ranks'
  },
  roles_stats: {
    id: 'roles_stats',
    path: '#/roles_stats',
    categoryAr: 'المجتمع والتفاعل',
    categoryEn: 'Community & Engagement',
    labelAr: 'الرتب التلقائية',
    labelEn: 'Auto & Interactive Roles'
  },
  games: {
    id: 'games',
    path: '#/games',
    categoryAr: 'المجتمع والتفاعل',
    categoryEn: 'Community & Engagement',
    labelAr: 'الألعاب',
    labelEn: 'Games Arena'
  },
  extras: {
    id: 'extras',
    path: '#/extras',
    categoryAr: 'التخصيص والأتمتة',
    categoryEn: 'Customization & Automation',
    labelAr: 'الردود التلقائية الذكية',
    labelEn: 'Smart Auto-Replies'
  },
  auto_line: {
    id: 'auto_line',
    path: '#/auto_line',
    categoryAr: 'التخصيص والأتمتة',
    categoryEn: 'Customization & Automation',
    labelAr: 'الخط التلقائي',
    labelEn: 'Auto-Line Divider'
  },
  embed_builder: {
    id: 'embed_builder',
    path: '#/embed_builder',
    categoryAr: 'التخصيص والأتمتة',
    categoryEn: 'Customization & Automation',
    labelAr: 'صانع الإيمبد',
    labelEn: 'Custom Embed Builder'
  },
  auto_emoji: {
    id: 'auto_emoji',
    path: '#/auto_emoji',
    categoryAr: 'التخصيص والأتمتة',
    categoryEn: 'Customization & Automation',
    labelAr: 'الإيموجي التلقائي',
    labelEn: 'Auto-Emoji Reactor'
  },
  tempvoice: {
    id: 'tempvoice',
    path: '#/tempvoice',
    categoryAr: 'التخصيص والأتمتة',
    categoryEn: 'Customization & Automation',
    labelAr: 'رومات صوتية مؤقتة',
    labelEn: 'TempVoice Channels'
  },
  azkar: {
    id: 'azkar',
    path: '#/azkar',
    categoryAr: 'التخصيص والأتمتة',
    categoryEn: 'Customization & Automation',
    labelAr: 'الأذكار والأدعية',
    labelEn: 'Azkar & Duas'
  },
  quran: {
    id: 'quran',
    path: '#/quran',
    categoryAr: 'التخصيص والأتمتة',
    categoryEn: 'Customization & Automation',
    labelAr: 'إذاعة القرآن الكريم',
    labelEn: 'Holy Quran Radio'
  },
  mass_dm: {
    id: 'mass_dm',
    path: '#/mass_dm',
    categoryAr: 'أدوات البوت والإدارة',
    categoryEn: 'Bot & Admin Tools',
    labelAr: 'الإرسال الجماعي',
    labelEn: 'Mass Role DM Broadcast'
  },
  commands: {
    id: 'commands',
    path: '#/commands',
    categoryAr: 'أدوات البوت والإدارة',
    categoryEn: 'Bot & Admin Tools',
    labelAr: 'إعدادات الأوامر',
    labelEn: 'Commands Settings'
  },
  backup: {
    id: 'backup',
    path: '#/backup',
    categoryAr: 'أدوات البوت والإدارة',
    categoryEn: 'Bot & Admin Tools',
    labelAr: 'النسخ الاحتياطي',
    labelEn: 'Snapshots & Backup'
  },
  basics: {
    id: 'basics',
    path: '#/basics',
    categoryAr: 'أدوات البوت والإدارة',
    categoryEn: 'Bot & Admin Tools',
    labelAr: 'إعدادات البوت والذكاء الاصطناعي',
    labelEn: 'Bot & AI Settings'
  },
  replit: {
    id: 'replit',
    path: '#/replit',
    categoryAr: 'أدوات البوت والإدارة',
    categoryEn: 'Bot & Admin Tools',
    labelAr: 'النشر على Replit',
    labelEn: 'Deploy to Replit'
  },
  prosuite: {
    id: 'prosuite',
    path: '#/prosuite',
    categoryAr: 'أدوات البوت والإدارة',
    categoryEn: 'Bot & Admin Tools',
    labelAr: 'الأدوات المتقدمة',
    labelEn: 'Advanced Suite'
  },
  aichat: {
    id: 'aichat',
    path: '#/aichat',
    categoryAr: 'أدوات البوت والإدارة',
    categoryEn: 'Bot & Admin Tools',
    labelAr: 'المساعد الذكي',
    labelEn: 'AI Assistant'
  },
  creator_hub: {
    id: 'creator_hub',
    path: '#/creator_hub',
    categoryAr: 'أدوات البوت والإدارة',
    categoryEn: 'Bot & Admin Tools',
    labelAr: 'مركز المنشئ',
    labelEn: 'Creator Hub'
  }
};

const ROUTE_STORAGE_KEY = 'm7r_last_route';

export function isOAuthHash(hash: string): boolean {
  return (
    hash.includes('access_token=') ||
    hash.includes('token_type=') ||
    hash.includes('error=')
  );
}

export function isValidRoute(routeId: string): boolean {
  return Object.prototype.hasOwnProperty.call(DASHBOARD_ROUTES, routeId);
}

export function parseRouteFromHash(hash: string): string | null {
  if (!hash || isOAuthHash(hash)) return null;
  const cleaned = hash.replace(/^#\/?/, '').split('?')[0].trim();
  if (!cleaned) return null;
  return isValidRoute(cleaned) ? cleaned : null;
}

export function getInitialRoute(): string {
  try {
    const fromHash = parseRouteFromHash(window.location.hash);
    if (fromHash) return fromHash;
    const saved = localStorage.getItem(ROUTE_STORAGE_KEY);
    if (saved && isValidRoute(saved)) return saved;
  } catch {
    // ignore storage failures
  }
  return 'overview';
}

export function getRouteMeta(routeId: string): RouteMeta {
  return DASHBOARD_ROUTES[routeId] || DASHBOARD_ROUTES.overview;
}

interface HashRouterContextValue {
  currentRoute: string;
  routeMeta: RouteMeta;
  navigate: (routeId: string, options?: { replace?: boolean; scrollTop?: boolean }) => void;
}

const HashRouterContext = createContext<HashRouterContextValue | null>(null);

export const HashRouter: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentRoute, setCurrentRoute] = useState<string>(() => getInitialRoute());

  const persistRoute = useCallback((routeId: string) => {
    try {
      localStorage.setItem(ROUTE_STORAGE_KEY, routeId);
    } catch {
      // ignore
    }
  }, []);

  const navigate = useCallback(
    (routeId: string, options?: { replace?: boolean; scrollTop?: boolean }) => {
      const targetId = isValidRoute(routeId) ? routeId : 'overview';
      const targetHash = `#/${targetId}`;
      persistRoute(targetId);
      setCurrentRoute(targetId);

      try {
        if (!isOAuthHash(window.location.hash) && window.location.hash !== targetHash) {
          const base = `${window.location.pathname || '/'}${window.location.search || ''}${targetHash}`;
          if (options?.replace) {
            window.history.replaceState({ route: targetId }, '', base);
          } else {
            window.history.pushState({ route: targetId }, '', base);
          }
        }
      } catch {
        if (!isOAuthHash(window.location.hash)) {
          window.location.hash = targetHash;
        }
      }

      if (options?.scrollTop !== false) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    },
    [persistRoute]
  );

  // Sync URL hash on initial load (only when not holding an OAuth fragment)
  useEffect(() => {
    const rawHash = window.location.hash;
    if (isOAuthHash(rawHash)) {
      return;
    }
    const parsed = parseRouteFromHash(rawHash);
    if (!parsed) {
      const initial = getInitialRoute();
      persistRoute(initial);
      try {
        const base = `${window.location.pathname || '/'}${window.location.search || ''}#/${initial}`;
        window.history.replaceState({ route: initial }, '', base);
      } catch {
        // ignore
      }
    } else {
      persistRoute(parsed);
    }
  }, [persistRoute]);

  // Listen to browser Back/Forward (popstate) and manual hash edits (hashchange)
  useEffect(() => {
    const syncFromLocation = () => {
      if (isOAuthHash(window.location.hash)) return;
      const parsed = parseRouteFromHash(window.location.hash);
      if (parsed) {
        setCurrentRoute(parsed);
        persistRoute(parsed);
      }
    };

    window.addEventListener('hashchange', syncFromLocation);
    window.addEventListener('popstate', syncFromLocation);
    return () => {
      window.removeEventListener('hashchange', syncFromLocation);
      window.removeEventListener('popstate', syncFromLocation);
    };
  }, [persistRoute]);

  const value = useMemo<HashRouterContextValue>(
    () => ({
      currentRoute,
      routeMeta: getRouteMeta(currentRoute),
      navigate
    }),
    [currentRoute, navigate]
  );

  return <HashRouterContext.Provider value={value}>{children}</HashRouterContext.Provider>;
};

export function useHashRouter(): HashRouterContextValue {
  const ctx = useContext(HashRouterContext);
  if (!ctx) {
    throw new Error('useHashRouter must be used within a <HashRouter>');
  }
  return ctx;
}

interface HashLinkProps extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
  to: string;
  onNavigate?: (routeId: string) => void;
}

export const HashLink: React.FC<HashLinkProps> = ({ to, onClick, onNavigate, children, ...rest }) => {
  const { navigate } = useHashRouter();
  const targetId = isValidRoute(to) ? to : 'overview';

  return (
    <a
      {...rest}
      href={`#/${targetId}`}
      onClick={(e) => {
        if (onClick) onClick(e);
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) {
          return;
        }
        e.preventDefault();
        navigate(targetId);
        if (onNavigate) onNavigate(targetId);
      }}
    >
      {children}
    </a>
  );
};
