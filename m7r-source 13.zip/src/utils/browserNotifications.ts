import { ThreatLog } from '../types';

export type BrowserPushPermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

const PUSH_ENABLED_KEY = 'm7r_antinuke_push_enabled';
const PUSH_PERMISSION_EVENT = 'm7r-push-state-changed';

let swRegistrationPromise: Promise<ServiceWorkerRegistration | null> | null = null;

export function getBrowserPushPermission(): BrowserPushPermissionState {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission as BrowserPushPermissionState;
}

export function isAntiNukePushEnabled(): boolean {
  const perm = getBrowserPushPermission();
  if (perm !== 'granted') return false;
  try {
    const raw = localStorage.getItem(PUSH_ENABLED_KEY);
    if (raw === 'false') return false;
    return true;
  } catch {
    return true;
  }
}

export function setAntiNukePushEnabled(enabled: boolean): void {
  try {
    localStorage.setItem(PUSH_ENABLED_KEY, enabled ? 'true' : 'false');
    window.dispatchEvent(new CustomEvent(PUSH_PERMISSION_EVENT));
  } catch {
    // ignore storage quota errors
  }
}

export function subscribePushStateChange(listener: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  window.addEventListener(PUSH_PERMISSION_EVENT, listener);
  return () => window.removeEventListener(PUSH_PERMISSION_EVENT, listener);
}

export function registerM7RNotificationServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
    return Promise.resolve(null);
  }
  if (!swRegistrationPromise) {
    swRegistrationPromise = navigator.serviceWorker
      .register('/sw.js', { scope: '/' })
      .then((reg) => reg)
      .catch(() => null);
  }
  return swRegistrationPromise;
}

export async function requestAntiNukePushPermission(): Promise<{
  permission: BrowserPushPermissionState;
  enabled: boolean;
}> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return { permission: 'unsupported', enabled: false };
  }

  let permission: NotificationPermission = Notification.permission;
  if (permission !== 'granted') {
    try {
      permission = await Notification.requestPermission();
    } catch {
      permission = Notification.permission;
    }
  }

  if (permission === 'granted') {
    setAntiNukePushEnabled(true);
    const swReg = await registerM7RNotificationServiceWorker();
    const title = '🛡️ تم تفعيل إشعارات درع M7R Anti-Nuke بنجاح';
    const options: NotificationOptions = {
      body: 'سيصلك إشعار متصفح فوري لحظة رصد أو صد أي تهديد أمني أو محاولة تخريب.',
      tag: 'm7r-push-welcome',
      icon: '/favicon.ico',
      requireInteraction: false
    };
    try {
      if (swReg && swReg.showNotification) {
        await swReg.showNotification(title, options);
      } else {
        new Notification(title, options);
      }
    } catch {
      try {
        new Notification(title, options);
      } catch {
        // ignore if OS blocks
      }
    }
    window.dispatchEvent(new CustomEvent(PUSH_PERMISSION_EVENT));
    return { permission: 'granted', enabled: true };
  }

  setAntiNukePushEnabled(false);
  window.dispatchEvent(new CustomEvent(PUSH_PERMISSION_EVENT));
  return { permission: permission as BrowserPushPermissionState, enabled: false };
}

export function isSecurityThreatForPush(threat: Partial<ThreatLog> | null | undefined): boolean {
  if (!threat || !threat.id) return false;
  if (String(threat.id).startsWith('th-login-')) return false;
  const actionLower = String(threat.action || '').toLowerCase();
  if (actionLower.includes('oauth2') && actionLower.includes('login')) return false;
  return true;
}

function getThreatNotificationTitle(threat: ThreatLog): string {
  switch (threat.type) {
    case 'anti-nuke':
      return `🛡️ إنذار Anti-Nuke: ${threat.action}`;
    case 'rogue-bot':
      return `🤖 رصد بوت دخيل: ${threat.action}`;
    case 'lockdown':
      return `🚨 تنبيه طوارئ السيرفر: ${threat.action}`;
    case 'anti-invite':
      return `🔗 حظر رابط مخالف: ${threat.action}`;
    case 'anti-spam':
    default:
      return `⚠️ تدخل درع الحماية: ${threat.action}`;
  }
}

export async function dispatchThreatBrowserNotification(
  threat: ThreatLog,
  onClickFocus?: () => void
): Promise<boolean> {
  if (!isSecurityThreatForPush(threat)) return false;
  if (!isAntiNukePushEnabled()) return false;

  const title = getThreatNotificationTitle(threat);
  const body = [
    threat.executor ? `المنفذ: ${threat.executor}` : '',
    threat.target ? `الهدف: ${threat.target}` : '',
    threat.details || ''
  ]
    .filter(Boolean)
    .join('\n')
    .slice(0, 240);

  const options: NotificationOptions = {
    body,
    tag: threat.id,
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    requireInteraction: threat.severity === 'critical' || threat.severity === 'high',
    data: { url: '/', threatId: threat.id }
  };

  try {
    const swReg = await registerM7RNotificationServiceWorker();
    if (swReg && typeof swReg.showNotification === 'function') {
      await swReg.showNotification(title, options);
      return true;
    }
  } catch {
    // fallback to window.Notification below
  }

  try {
    const notif = new Notification(title, options);
    notif.onclick = () => {
      try {
        window.focus();
      } catch {}
      onClickFocus?.();
      notif.close();
    };
    return true;
  } catch {
    return false;
  }
}
