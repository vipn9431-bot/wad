import React, { useState, useEffect, useRef } from 'react';
import { Navbar, DashboardSidebar } from './components/Navbar';
import { HashLink, useHashRouter } from './utils/hashRouter';
import { OverviewTab } from './components/OverviewTab';
import { BasicBotSettingsTab } from './components/BasicBotSettingsTab';
import { CommandsManagerTab } from './components/CommandsManagerTab';
import { WelcomeTab } from './components/WelcomeTab';
import { AntiNukeTab } from './components/AntiNukeTab';
import { TicketsTab } from './components/TicketsTab';
import { ReactionRolesStatsTab } from './components/ReactionRolesStatsTab';
import { ExtraSystemsTab } from './components/ExtraSystemsTab';
import { AdvancedSuiteTab } from './components/AdvancedSuiteTab';
import { ReplitHubTab } from './components/ReplitHubTab';
import { AzkarTab } from './components/AzkarTab';
import { AiChatbotTab } from './components/AiChatbotTab';
import { LogVisualizerTab } from './components/LogVisualizerTab';
import { DatabaseBackupTab } from './components/DatabaseBackupTab';
import { TempVoiceTab } from './components/TempVoiceTab';
import { GamesEventsTab } from './components/GamesEventsTab';
import { StaffApplicationsTab } from './components/StaffApplicationsTab';
import { SetupWizardCreatorHubTab } from './components/SetupWizardCreatorHubTab';
import { AuditLogsStaffWarningsTab } from './components/AuditLogsStaffWarningsTab';
import { HeroLandingSection } from './components/HeroLandingSection';
import { M7RAutomationAndToolsTab } from './components/M7RAutomationAndToolsTab';
import { FloatingWebAiAssistant } from './components/FloatingWebAiAssistant';
import { ReadyRoomsAndSuggestionsTab } from './components/ReadyRoomsAndSuggestionsTab';
import {
  TokenAuthGate,
  ConnectedBotData,
  getSavedDiscordUser,
  getSavedAuthGuilds,
  getStoredAuthToken,
  getAuthHeaders,
  saveAuthSessionToStorage,
  clearAuthSessionFromStorage,
  isOfficialBotOwnerUser,
  OFFICIAL_OWNER_ID,
  AuthenticatedDiscordUser,
  verifyDiscordHashTokenIfPresent,
  fetchAndApplyLiveGuildDetails,
  launchOfficialDiscordOAuthWindow,
  prefetchOfficialDiscordOAuthUrl,
  isAllowedOAuthMessageOrigin,
  downloadZipBundle,
  CLOUD_API_BASE
} from './components/TokenAuthGate';
import { invalidateChannelsCache, setGuildChannelsCache } from './components/ChannelSelector';
import { Save, RotateCcw, CheckCircle2, AlertCircle, ShieldCheck, Bell, Crown } from 'lucide-react';
import { useLanguage } from './contexts/LanguageContext';
import {
  AntiNukeConfig,
  AntiSpamConfig,
  AntiInviteConfig,
  Ticket,
  ReactionRolesConfig,
  LiveServerStatsConfig,
  AutoResponse,
  Voice247Config,
  ThreatLog,
  BotBasicSettings,
  TicketPanelConfig,
  DiscordCommandConfig,
  AzkarConfig,
  HoneypotTrapConfig,
  WelcomeConfig,
  ConnectedGuildItem,
  AccessRoleMode,
  GuildJoinNotification
} from './types';

import { sound } from './utils/sound';
import {
  dispatchThreatBrowserNotification,
  isSecurityThreatForPush,
  registerM7RNotificationServiceWorker
} from './utils/browserNotifications';

const SENSITIVE_COMMANDS_SET = new Set(['ban', 'unban', 'kick', 'antinuke', 'trap', 'clearwarnings']);

function hasValidAuthSession(): boolean {
  try {
    const token = getStoredAuthToken();
    const user = getSavedDiscordUser();
    return Boolean(token && user && user.id && user.username);
  } catch {
    return false;
  }
}

function getSavedSelectedGuild(): ConnectedGuildItem | null {
  try {
    if (!hasValidAuthSession()) return null;
    const raw = localStorage.getItem('m7r_selected_guild');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.id && parsed.name && parsed.hasBot !== false && parsed.botPresent !== false) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return null;
}

export default function App() {
  const isReturningFromOAuth = (() => {
    try {
      const params = new URLSearchParams(window.location.search);
      return (
        params.has('auth_token') ||
        params.has('session_token') ||
        params.get('discord_auth') === 'success' ||
        params.has('code') ||
        window.location.hash.includes('access_token=')
      );
    } catch {
      return false;
    }
  })();

  const [tokenGateInitialStep, setTokenGateInitialStep] = useState<'landing' | 'discord_oauth' | 'select_server'>(() => {
    if (isReturningFromOAuth || hasValidAuthSession()) {
      return 'select_server';
    }
    return 'landing';
  });
  const [showTokenGate, setShowTokenGate] = useState<boolean>(() => {
    try {
      if (isReturningFromOAuth) {
        // Rule 2: Always land on server verification hub right after OAuth login
        return true;
      }
      if (hasValidAuthSession() && getSavedSelectedGuild()) {
        return false;
      }
    } catch {}
    return true;
  });

  const [connectedBot, setConnectedBot] = useState<ConnectedBotData | null>(() => {
    const validAuth = hasValidAuthSession();
    const initialGuild = validAuth ? getSavedSelectedGuild() : null;
    const savedUser = validAuth ? getSavedDiscordUser() : null;
    const savedGuilds = validAuth ? getSavedAuthGuilds() : [];
    const ownerVerified = isOfficialBotOwnerUser(savedUser);
    return {
      username: 'M7R',
      tag: 'M7R#1624',
      id: '1564565916216336494',
      avatar: '',
      guildsCount: savedGuilds.length,
      membersCount: initialGuild?.memberCount || 0,
      channelsCount: initialGuild?.channelsCount || 0,
      ping: 17,
      mode: 'live',
      guilds: savedGuilds,
      selectedGuild: initialGuild || undefined,
      accessMode: ownerVerified ? 'bot_owner' : 'server_admin',
      discordUser: savedUser || undefined
    };
  });

  const { currentRoute: activeTab, navigate: setActiveTab } = useHashRouter();
  const [sidebarMenuOpen, setSidebarMenuOpen] = useState<boolean>(false);
  const { lang, setLang, toggleLang, isAr, dir, t } = useLanguage();
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [panicMode, setPanicMode] = useState(false);
  const [attacksThwarted, setAttacksThwarted] = useState(1280);

  // Access Mode ('server_admin' = Safe Server Control | 'bot_owner' = Strictly restricted to Official Bot Owner ID)
  const [accessMode, setAccessMode] = useState<AccessRoleMode>(() => {
    const savedUser = getSavedDiscordUser();
    return isOfficialBotOwnerUser(savedUser) ? 'bot_owner' : 'server_admin';
  });
  const [guildNotifications, setGuildNotifications] = useState<GuildJoinNotification[]>([]);
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState<number>(0);

  // Unsaved Changes & Save Toast State
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveBannerMessage, setSaveBannerMessage] = useState<string | null>(null);

  const isOfficialOwnerLoggedIn = isOfficialBotOwnerUser(connectedBot?.discordUser || getSavedDiscordUser());

  const activeGuildIdRef = useRef<string>(connectedBot?.selectedGuild?.id || '');
  useEffect(() => {
    activeGuildIdRef.current = connectedBot?.selectedGuild?.id || '';
  }, [connectedBot?.selectedGuild?.id]);

  const handleLogout = () => {
    const savedToken = getStoredAuthToken();
    clearAuthSessionFromStorage();
    invalidateChannelsCache();
    try {
      sessionStorage.removeItem('m7r_login_prompt_seen');
      sessionStorage.removeItem('m7r_active_dashboard_unlocked');
    } catch {}
    setConnectedBot({
      username: 'M7R',
      tag: 'M7R#1624',
      id: '1564565916216336494',
      avatar: '',
      guildsCount: 0,
      membersCount: 0,
      channelsCount: 0,
      ping: 17,
      mode: 'live',
      guilds: [],
      selectedGuild: undefined,
      accessMode: 'server_admin',
      discordUser: undefined
    });
    setAccessMode('server_admin');
    setTokenGateInitialStep('landing');
    setShowTokenGate(true);
    sound.playClick();
    fetch('/api/auth/discord/logout', {
      method: 'POST',
      credentials: 'include',
      headers: savedToken ? { Authorization: `Bearer ${savedToken}` } : {}
    }).catch(() => {});
  };

  const directOAuthPollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Direct Official Discord OAuth2 Popup Launcher -> routes to select_server verification hub
  const handleDirectDiscordOAuthLogin = () => {
    sound.playClick();
    if (directOAuthPollRef.current) {
      clearInterval(directOAuthPollRef.current);
      directOAuthPollRef.current = null;
    }
    const { pollStartTs, popupBlocked } = launchOfficialDiscordOAuthWindow(connectedBot?.id || '1564565916216336494');

    if (popupBlocked) {
      sound.playError();
      setSaveBannerMessage(
        '⚠️ المتصفح حظر النافذة المنبثقة! يرجى السماح بالنوافذ المنبثقة (Allow Popups) لإتمام تسجيل الدخول عبر Discord.'
      );
      setTimeout(() => setSaveBannerMessage(null), 7000);
      return;
    }

    let attempts = 0;
    const pollTimer = setInterval(async () => {
      attempts += 1;
      if (attempts > 60) {
        clearInterval(pollTimer);
        if (directOAuthPollRef.current === pollTimer) {
          directOAuthPollRef.current = null;
        }
        return;
      }
      try {
        const res = await fetch(`/api/me?poll_since=${pollStartTs}`, {
          headers: getAuthHeaders(),
          credentials: 'include'
        });
        if (res.ok) {
          const meData = await res.json();
          if (meData?.isLoggedIn && meData?.user?.id) {
            clearInterval(pollTimer);
            if (directOAuthPollRef.current === pollTimer) {
              directOAuthPollRef.current = null;
            }
            const verifiedOwner = isOfficialBotOwnerUser(meData.user);
            const oauthUser: AuthenticatedDiscordUser = {
              id: String(meData.user.id),
              username: String(meData.user.username),
              tag: String(meData.user.tag || meData.user.username),
              avatar: meData.user.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png',
              isLoggedIn: true,
              isOwner: verifiedOwner
            };
            const manageServerGuilds: ConnectedGuildItem[] = Array.isArray(meData.guilds)
              ? meData.guilds
              : [];
            const finalToken = String(meData.token || meData.sessionToken || getStoredAuthToken());
            saveAuthSessionToStorage(finalToken, oauthUser, manageServerGuilds);

            setConnectedBot((prev) => ({
              ...(prev || {
                username: 'M7R',
                tag: 'M7R#1624',
                id: '1564565916216336494',
                avatar: '',
                guildsCount: manageServerGuilds.length,
                membersCount: 0,
                channelsCount: 0,
                ping: 17,
                mode: 'live'
              }),
              guilds: manageServerGuilds,
              guildsCount: manageServerGuilds.length,
              selectedGuild: undefined,
              accessMode: verifiedOwner ? 'bot_owner' : 'server_admin',
              discordUser: oauthUser
            }));

            setAccessMode(verifiedOwner ? 'bot_owner' : 'server_admin');
            setTokenGateInitialStep('select_server');
            setShowTokenGate(true);
            sound.playShieldActivate();
            setSaveBannerMessage(
              `🎉 مرحباً ${oauthUser.username}! تم تسجيل الدخول عبر Discord OAuth2 وجلب سيرفراتك (${manageServerGuilds.length}). اختر السيرفر للتحكم أو أضف البوت!`
            );
            setTimeout(() => setSaveBannerMessage(null), 6000);
          }
        }
      } catch {
        // continue polling
      }
    }, 1500);
    directOAuthPollRef.current = pollTimer;
  };

  const handleMasterRefresh = async () => {
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/bot/refresh', {
        method: 'POST',
        credentials: 'include',
        headers: getAuthHeaders()
      });
      const data = await res.json();
      setSaveBannerMessage(data?.message || '🎉 تم تنفيذ أمر (تحديث)! تم تحديث ومزامنة جميع أنظمة وأوامر بوت M7R وجلب كل جديد.');
      setTimeout(() => setSaveBannerMessage(null), 6000);
      const qGuild = activeGuildIdRef.current ? `?guildId=${encodeURIComponent(activeGuildIdRef.current)}` : '';
      fetch(`/api/status${qGuild}`, {
        credentials: 'include',
        headers: getAuthHeaders()
      })
        .then((r) => r.json())
        .then((statusData) => {
          if (statusData?.botInfo && hasValidAuthSession()) {
            const liveGuilds: ConnectedGuildItem[] = Array.isArray(statusData.botInfo.guilds)
              ? statusData.botInfo.guilds
              : [];
            const liveMap = new Map(liveGuilds.map((g) => [String(g.id), g]));
            setConnectedBot((prev) => {
              const updatedGuilds =
                prev?.guilds && prev.guilds.length > 0
                  ? prev.guilds.map((ug) => {
                      const m = liveMap.get(String(ug.id));
                      return m ? { ...ug, ...m, hasBot: true, botPresent: true } : ug;
                    })
                  : [];
              return {
                ...statusData.botInfo,
                guilds: updatedGuilds,
                guildsCount: updatedGuilds.length,
                selectedGuild: prev?.selectedGuild
              };
            });
          }
          if (statusData?.discordCommands) setDiscordCommandsState(statusData.discordCommands);
        })
        .catch(() => {});
    } catch {
      setSaveBannerMessage('🔄 تم التحديث بنجاح!');
      setTimeout(() => setSaveBannerMessage(null), 4000);
    }
  };

  // Verify m7r_auth_token on mount and handle Official Discord OAuth2 Callback Return (?auth_token, ?session_token, or #access_token)
  useEffect(() => {
    verifyDiscordHashTokenIfPresent().then((hashAuth) => {
      if (hashAuth) {
        const verifiedOwner = hashAuth.user.isOwner;
        const userGuilds = Array.isArray(hashAuth.guilds) ? hashAuth.guilds : [];

        setConnectedBot((prev) => ({
          ...(prev || {
            username: 'M7R',
            tag: 'M7R#1624',
            id: '1564565916216336494',
            avatar: '',
            guildsCount: userGuilds.length,
            membersCount: 0,
            channelsCount: 0,
            ping: 17,
            mode: 'live'
          }),
          guilds: userGuilds,
          guildsCount: userGuilds.length,
          selectedGuild: undefined,
          accessMode: verifiedOwner ? 'bot_owner' : 'server_admin',
          discordUser: hashAuth.user
        }));

        setAccessMode(verifiedOwner ? 'bot_owner' : 'server_admin');
        setTokenGateInitialStep('select_server');
        setShowTokenGate(true);
        sound.playShieldActivate();
        setSaveBannerMessage(
          verifiedOwner
            ? `👑 مرحباً ${hashAuth.user.username}! تم التحقق من معرف المالك الرسمي (${OFFICIAL_OWNER_ID}). اختر السيرفر للدخول!`
            : `🎉 مرحباً ${hashAuth.user.username}! تم تسجيل الدخول عبر Discord OAuth2 بنجاح!`
        );
        setTimeout(() => setSaveBannerMessage(null), 6000);
        return;
      }

      const params = new URLSearchParams(window.location.search);
      const urlToken = (params.get('auth_token') || params.get('session_token') || '').trim();
      if (urlToken) {
        localStorage.setItem('m7r_auth_token', urlToken);
        localStorage.setItem('m7r_session_token', urlToken);
        localStorage.setItem('m7r_logged_in', 'true');
        try {
          const cleanHash =
            window.location.hash && !window.location.hash.includes('access_token=')
              ? window.location.hash
              : `#/${activeTab || 'overview'}`;
          window.history.replaceState({}, document.title, `/${cleanHash}`);
        } catch {}
      }

      const activeToken = urlToken || getStoredAuthToken();
      const savedUser = getSavedDiscordUser();

      if (!activeToken || (!savedUser && !urlToken)) {
        setAccessMode('server_admin');
        setShowTokenGate(true);
        setTokenGateInitialStep('landing');
        return;
      }

      if (savedUser) {
        const verifiedOwner = isOfficialBotOwnerUser(savedUser);
        setAccessMode(verifiedOwner ? 'bot_owner' : 'server_admin');
      }

      const headers = getAuthHeaders();
      fetch('/api/me', { headers, credentials: 'include' })
        .then((res) => {
          const ct = res.headers.get('content-type') || '';
          if (!res.ok || !ct.includes('application/json')) {
            return fetch(`${CLOUD_API_BASE}/api/me`, { headers, credentials: 'include' }).then((r) => r.json());
          }
          return res.json();
        })
        .then((data) => {
          if (data?.isLoggedIn && data?.user?.id && data?.user?.username) {
            const verifiedOwner = isOfficialBotOwnerUser(data.user);
            const oauthUser: AuthenticatedDiscordUser = {
              id: String(data.user.id),
              username: String(data.user.username),
              tag: String(data.user.tag || data.user.username),
              avatar: data.user.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png',
              isLoggedIn: true,
              isOwner: verifiedOwner
            };

            const userGuilds: ConnectedGuildItem[] = Array.isArray(data.guilds)
              ? data.guilds
              : getSavedAuthGuilds();

            const finalToken = String(data.token || data.sessionToken || activeToken);
            saveAuthSessionToStorage(finalToken, oauthUser, userGuilds);

            const savedSelected = getSavedSelectedGuild();
            const matched = savedSelected
              ? userGuilds.find((g) => g.id === savedSelected.id && g.hasBot !== false && g.botPresent !== false) || null
              : null;
            if (matched) {
              localStorage.setItem('m7r_selected_guild', JSON.stringify(matched));
              localStorage.setItem('m7r_selected_guild_id', matched.id);
            }

            setConnectedBot((prev) => ({
              ...(prev || {
                username: 'M7R',
                tag: 'M7R#1624',
                id: '1564565916216336494',
                avatar: '',
                guildsCount: userGuilds.length,
                membersCount: 0,
                channelsCount: 0,
                ping: 17,
                mode: 'live'
              }),
              guilds: userGuilds,
              guildsCount: userGuilds.length,
              selectedGuild: matched || undefined,
              membersCount: matched?.memberCount || 0,
              channelsCount: matched?.channelsCount || 0,
              accessMode: verifiedOwner ? 'bot_owner' : 'server_admin',
              discordUser: oauthUser
            }));

            setAccessMode(verifiedOwner ? 'bot_owner' : 'server_admin');

            if (urlToken || params.get('discord_auth') === 'success') {
              // Rule 2: After OAuth2 login, show user's Manage Server list for bot presence verification
              setTokenGateInitialStep('select_server');
              setShowTokenGate(true);
              sound.playShieldActivate();
              setSaveBannerMessage(
                `🎉 مرحباً ${oauthUser.username}! تم تسجيل الدخول عبر Discord OAuth2 وجلب سيرفراتك (${userGuilds.length}).`
              );
              setTimeout(() => setSaveBannerMessage(null), 6000);
            } else if (matched) {
              // Hydrate the restored verified server's isolated state
              handleSelectGuild(matched, { silent: true }).catch(() => {});
            } else {
              setTokenGateInitialStep('select_server');
              setShowTokenGate(true);
            }
          }
        })
        .catch(() => {})
        .finally(() => {
          if (params.has('auth_token') || params.has('discord_auth') || params.has('session_token')) {
            try {
              const cleanHash =
                window.location.hash && !window.location.hash.includes('access_token=')
                  ? window.location.hash
                  : `#/${activeTab || 'overview'}`;
              window.history.replaceState({}, document.title, `/${cleanHash}`);
            } catch {}
          }
        });
    });

    prefetchOfficialDiscordOAuthUrl().catch(() => {});

    const handleOAuthPopupMsg = (event: MessageEvent) => {
      if (!isAllowedOAuthMessageOrigin(event.origin)) {
        return;
      }

      if (event.data?.type === 'OAUTH_AUTH_ERROR') {
        if (directOAuthPollRef.current) {
          clearInterval(directOAuthPollRef.current);
          directOAuthPollRef.current = null;
        }
        sound.playError();
        setSaveBannerMessage(
          `❌ تعذر إتمام تسجيل الدخول عبر Discord: ${String(event.data?.error || 'خطأ في المصادقة')}`
        );
        setTimeout(() => setSaveBannerMessage(null), 8000);
        return;
      }

      if (
        (event.data?.type === 'DISCORD_AUTH_SUCCESS' || event.data?.type === 'OAUTH_AUTH_SUCCESS') &&
        event.data?.user?.id &&
        event.data?.user?.username
      ) {
        if (directOAuthPollRef.current) {
          clearInterval(directOAuthPollRef.current);
          directOAuthPollRef.current = null;
        }
        const incomingUser = event.data.user;
        const verifiedOwner = isOfficialBotOwnerUser(incomingUser);
        const oauthUser: AuthenticatedDiscordUser = {
          id: String(incomingUser.id),
          username: String(incomingUser.username),
          tag: String(incomingUser.tag || incomingUser.username),
          avatar: incomingUser.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png',
          isLoggedIn: true,
          isOwner: verifiedOwner
        };

        const incomingToken = String(event.data?.token || event.data?.sessionToken || getStoredAuthToken());
        const incomingGuilds: ConnectedGuildItem[] = Array.isArray(event.data?.guilds)
          ? event.data.guilds
          : [];
        saveAuthSessionToStorage(incomingToken, oauthUser, incomingGuilds);

        setConnectedBot((prev) =>
          prev
            ? {
                ...prev,
                guilds: incomingGuilds,
                guildsCount: incomingGuilds.length,
                selectedGuild: undefined,
                accessMode: verifiedOwner ? 'bot_owner' : 'server_admin',
                discordUser: oauthUser
              }
            : {
                username: 'M7R',
                tag: 'M7R#1624',
                id: '1564565916216336494',
                avatar: '',
                guildsCount: incomingGuilds.length,
                membersCount: 0,
                channelsCount: 0,
                ping: 17,
                mode: 'live',
                guilds: incomingGuilds,
                selectedGuild: undefined,
                accessMode: verifiedOwner ? 'bot_owner' : 'server_admin',
                discordUser: oauthUser
              }
        );
        setAccessMode(verifiedOwner ? 'bot_owner' : 'server_admin');
        setTokenGateInitialStep('select_server');
        setShowTokenGate(true);
        sound.playShieldActivate();
        setSaveBannerMessage(
          `🎉 مرحباً ${oauthUser.username}! تم تسجيل الدخول عبر Discord OAuth2 وجلب سيرفراتك (${incomingGuilds.length}).`
        );
        setTimeout(() => setSaveBannerMessage(null), 6000);
      }
    };

    window.addEventListener('message', handleOAuthPopupMsg);
    return () => {
      window.removeEventListener('message', handleOAuthPopupMsg);
      if (directOAuthPollRef.current) {
        clearInterval(directOAuthPollRef.current);
        directOAuthPollRef.current = null;
      }
    };
  }, []);

  // Poll every 8s for live bot status & new server joins while preserving user's authenticated Manage Server guilds
  useEffect(() => {
    let prevNotifTopId: string | null = null;

    const syncStatus = (isInitial = false) => {
      if (!hasValidAuthSession()) return;
      const gQuery = activeGuildIdRef.current
        ? `?guildId=${encodeURIComponent(activeGuildIdRef.current)}`
        : '';
      fetch(`/api/status${gQuery}`, {
        credentials: 'include',
        headers: getAuthHeaders()
      })
        .then((res) => {
          const ct = res.headers.get('content-type') || '';
          if (!res.ok || !ct.includes('application/json')) {
            throw new Error('Not JSON');
          }
          return res.json();
        })
        .then((data) => {
          if (data && data.botInfo) {
            const liveBotGuilds: ConnectedGuildItem[] = Array.isArray(data.botInfo.guilds)
              ? data.botInfo.guilds
              : [];
            const liveBotGuildMap = new Map<string, ConnectedGuildItem>();
            for (const bg of liveBotGuilds) {
              liveBotGuildMap.set(String(bg.id), bg);
            }

            setConnectedBot((prev) => {
              const prevGuilds = Array.isArray(prev?.guilds) ? prev!.guilds! : [];
              const effectiveGuilds: ConnectedGuildItem[] = prevGuilds.map((ug) => {
                const liveMatch = liveBotGuildMap.get(String(ug.id));
                if (liveMatch) {
                  return {
                    ...ug,
                    ...liveMatch,
                    hasManagePermission: true,
                    hasBot: true,
                    botPresent: true
                  };
                }
                return ug;
              });

              const activeG = prev?.selectedGuild
                ? effectiveGuilds.find((g) => g.id === prev.selectedGuild!.id) || prev.selectedGuild
                : undefined;

              return {
                ...data.botInfo,
                guilds: effectiveGuilds,
                guildsCount: effectiveGuilds.length,
                selectedGuild: activeG,
                membersCount: activeG?.memberCount || 0,
                channelsCount: activeG?.channelsCount || 0,
                discordUser: prev?.discordUser || getSavedDiscordUser() || undefined
              };
            });
          }
          if (isInitial && data?.welcomeConfig) {
            setWelcomeConfigState(data.welcomeConfig);
          }
          if (isInitial && data?.discordCommands) {
            setDiscordCommandsState(data.discordCommands);
          }
          if (Array.isArray(data?.guildJoinNotifications)) {
            const topId = data.guildJoinNotifications[0]?.id || null;
            if (!isInitial && topId && prevNotifTopId && topId !== prevNotifTopId) {
              const latest = data.guildJoinNotifications[0];
              sound.playShieldActivate();
              setSaveBannerMessage(
                `🎉 إشعار جديد: دخل البوت إلى سيرفر (${latest.guildName}) وتم تفعيل صلاحية التحكم في السيرفر تلقائياً!`
              );
              setTimeout(() => setSaveBannerMessage(null), 6000);
            }
            prevNotifTopId = topId;
            setGuildNotifications(data.guildJoinNotifications);
            setUnreadNotificationsCount(
              typeof data.unreadNotificationsCount === 'number'
                ? data.unreadNotificationsCount
                : data.guildJoinNotifications.filter((n: GuildJoinNotification) => !n.read).length
            );
          }
        })
        .catch(() => {});
    };

    syncStatus(true);
    const interval = setInterval(() => syncStatus(false), 8000);
    return () => clearInterval(interval);
  }, []);

  // Deduplicated Anti-Nuke Threat Feed Watcher (SSE Stream + Polling Backup -> Instant Browser Push Alerts)
  const seenThreatIdsRef = useRef<Set<string>>(new Set(['th-101', 'th-102']));
  const initialThreatsSeededRef = useRef<boolean>(false);

  const handleIncomingSecurityThreat = (threat: ThreatLog, totalThwartedFromServer?: number) => {
    if (!threat || !threat.id) return;
    if (seenThreatIdsRef.current.has(threat.id)) return;
    seenThreatIdsRef.current.add(threat.id);

    setThreatLogs((prev) => {
      if (prev.some((t) => t.id === threat.id)) return prev;
      return [threat, ...prev].slice(0, 30);
    });

    if (typeof totalThwartedFromServer === 'number') {
      setAttacksThwarted(totalThwartedFromServer);
    } else if (isSecurityThreatForPush(threat)) {
      setAttacksThwarted((prev) => prev + 1);
    }

    if (isSecurityThreatForPush(threat)) {
      if (threat.severity === 'critical' || threat.severity === 'high') {
        sound.playAlarm();
      } else {
        sound.playShieldActivate();
      }
      dispatchThreatBrowserNotification(threat, () => {
        setActiveTab('antinuke');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }).catch(() => {});

      setSaveBannerMessage(
        `🛡️ إنذار حماية فوري: ${threat.action}${threat.target ? ` (${threat.target})` : ''}`
      );
      setTimeout(() => setSaveBannerMessage(null), 6000);
    }
  };

  useEffect(() => {
    registerM7RNotificationServiceWorker().catch(() => {});

    const onSwMessage = (event: MessageEvent) => {
      if (event.data?.type === 'M7R_FOCUS_PROTECTION_TAB') {
        setActiveTab('antinuke');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', onSwMessage);
    }

    const syncThreats = async (isInitialSeed = false) => {
      try {
        const res = await fetch('/api/threats', {
          credentials: 'include',
          headers: getAuthHeaders()
        });
        if (!res.ok) return;
        const data = await res.json();
        const rawServerLogs: ThreatLog[] = Array.isArray(data?.logs) ? data.logs : [];
        const uniqueLogsMap = new Map<string, ThreatLog>();
        for (const l of rawServerLogs) {
          if (l?.id && !uniqueLogsMap.has(l.id)) {
            uniqueLogsMap.set(l.id, l);
          }
        }
        const serverLogs = Array.from(uniqueLogsMap.values());

        if (isInitialSeed || !initialThreatsSeededRef.current) {
          serverLogs.forEach((l) => {
            if (l?.id) seenThreatIdsRef.current.add(l.id);
          });
          initialThreatsSeededRef.current = true;
          if (serverLogs.length > 0) {
            setThreatLogs(serverLogs);
          }
          if (typeof data?.totalThwarted === 'number') {
            setAttacksThwarted(data.totalThwarted);
          }
          return;
        }

        const unseen = serverLogs.filter((l) => l?.id && !seenThreatIdsRef.current.has(l.id));
        if (unseen.length > 0) {
          unseen.slice().reverse().forEach((l) => {
            handleIncomingSecurityThreat(l, data?.totalThwarted);
          });
        }
      } catch {
        // ignore transient network errors
      }
    };

    syncThreats(true);

    let eventSource: EventSource | null = null;
    if (typeof EventSource !== 'undefined') {
      try {
        eventSource = new EventSource('/api/threats/stream');
        eventSource.addEventListener('threat', (evt: MessageEvent) => {
          try {
            const payload = JSON.parse(evt.data);
            if (payload?.threat) {
              handleIncomingSecurityThreat(payload.threat, payload.totalThwarted);
            }
          } catch {}
        });
      } catch {}
    }

    const pollTimer = setInterval(() => syncThreats(false), 4000);
    return () => {
      clearInterval(pollTimer);
      if (eventSource) eventSource.close();
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.removeEventListener('message', onSwMessage);
      }
    };
  }, []);

  // Basic Bot Settings
  const [basicSettings, setBasicSettingsState] = useState<BotBasicSettings>({
    botUsername: 'M7R',
    presenceStatus: 'dnd',
    activityType: 'PLAYING',
    activityText: 'M7R Security 🛡️',
    streamingUrl: 'https://twitch.tv/m7r',
    prefix: '!',
    logChannelName: 'log-server',
    commandsChannelName: 'cmd',
    keepAlive247: true,
    heartbeatIntervalSec: 25
  });

  // Welcome System Config (Full VIP Welcome Studio)
  const [welcomeConfig, setWelcomeConfigState] = useState<WelcomeConfig>({
    enabled: true,
    channelName: 'welcome',
    messageMode: 'embed_and_text',
    welcomeMessage: '✨ يا هلا ومليون غلا بك يا {user} في سيرفر {server} الرسمي! أنت العضو رقم #{count}',
    embedTitle: '✦ أهلاً بك في إمبراطورية {server} ✦',
    embedDescription:
      'نورت السيرفر يا {user}!\nيرجى الاطلاع على القوانين واختيار رتبك، ونتمنى لك أوقاتاً ممتعة معنا في عائلة M7R 🛡️',
    embedColor: '#8A2BE2',
    bannerUrl: '/assets/aistudio/IMG_3117_2cec6847.jpeg',
    showAvatarThumbnail: true,
    showMemberCount: true,
    showAccountAge: true,
    footerText: 'M7R PRO • نظام الترحيب الملكي والحماية المتكاملة',
    autoRoleEnabled: true,
    autoRoleName: 'Member',
    botAutoRoleName: 'Bots',
    sendDm: true,
    dmMessage: 'مرحباً بك يا {username} في سيرفر {server}! في حال احتجت أي مساعدة يمكنك فتح تذكرة دعم فني في أي وقت.',
    leaveEnabled: true,
    leaveChannelName: 'welcome',
    leaveMessage: 'غادرنا العضو {username}، نتمنى له التوفيق 👋',
    vipCardEnabled: true,
    vipCardTheme: 'purple_chrome',
    cardHeadline: '✦ WELCOME TO THE EMPIRE ✦',
    neonBorderColor: '#9D4EDD',
    rulesChannelName: 'القوانين',
    rolesChannelName: 'الرتب',
    ticketChannelName: 'التذاكر',
    sayWelcomeEnabled: true
  });

  // Ticket Panel Config
  const [ticketPanel, setTicketPanelState] = useState<TicketPanelConfig>({
    storeName: 'M7R Official Store',
    embedTitle: 'M7R | مركز التذاكر والدعم الفني والمبيعات 🛒',
    embedDescription:
      'أهلاً بكم في مركز التذاكر الرسمي. يرجى الضغط على الزر المناسب لطلبك أدناه ليتم فتح تذكرة خاصة بك مع فريق الإدارة المختص:',
    embedColor: '#8A2BE2',
    bannerUrl: '/assets/aistudio/IMG_3117_2cec6847.jpeg',
    welcomeMessage:
      'مرحباً بك في تذكرتك الخاصة! يرجى كتابة تفاصيل طلبك والانتظار حتى يقوم أحد المشرفين باستلام التذكرة.',
    targetChannelName: 'tickets',
    supportRoleName: 'Support',
    buttons: [
      {
        id: 'btn_store',
        label: 'شراء منتج',
        emoji: '🛒',
        style: 'Primary',
        categoryDescription: 'لشراء حسابات، نيترو، كروت شحن، أو رتب خاصة.',
        enabled: true
      },
      {
        id: 'btn_support',
        label: 'الدعم الفني',
        emoji: '🛠️',
        style: 'Secondary',
        categoryDescription: 'لحل المشكلات التقنية واستفسارات السيرفر.',
        enabled: true
      },
      {
        id: 'btn_complaints',
        label: 'الشكاوى والمقترحات',
        emoji: '💼',
        style: 'Secondary',
        categoryDescription: 'للتواصل مع الإدارة العليا وتقديم البلاغات.',
        enabled: true
      },
      {
        id: 'btn_partnerships',
        label: 'الشراكات والإعلانات',
        emoji: '🤝',
        style: 'Success',
        categoryDescription: 'لعقد صفقات التبادل الإعلاني والتعاون المشترك.',
        enabled: true
      }
    ]
  });

  // Full Essential Moderation, Voice, Channel, Role, Welcome, Ticket, Islamic & Security Commands
  const [discordCommands, setDiscordCommandsState] = useState<DiscordCommandConfig[]>([
    // 1. MODERATION & PUNISHMENTS
    {
      id: 'cmd-mute',
      name: 'mute',
      aliases: ['ميوت', 'كتم', 'اسكات', 'تايم', 'timeout'],
      description: 'كتم عضو مؤقتاً (Timeout) ومنعه من الكتابة والتحدث (مثال: !mute @user 15 سبب)',
      category: 'moderation',
      enabled: true,
      cooldownSec: 3,
      customReply: '🔇 **تم إعطاء ميوت (كتم مؤقت) للعضو بنجاح بواسطة إدارة M7R!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-unmute',
      name: 'unmute',
      aliases: ['فك-الميوت', 'فك-ميوت', 'فك-كتم', 'تكلم', 'فك', 'untimeout'],
      description: 'فك الميوت (الكتم المؤقت) عن عضو في السيرفر فوراً (مثال: !unmute @user)',
      category: 'moderation',
      enabled: true,
      cooldownSec: 3,
      customReply: '🔊 **تم فك الميوت عن العضو بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-ban',
      name: 'ban',
      aliases: ['باند', 'حظر', 'طير'],
      description: 'حظر عضو مخالف من السيرفر نهائياً مع توثيق السبب (مثال: !ban @user سبب)',
      category: 'moderation',
      enabled: true,
      cooldownSec: 5,
      customReply: '🔨 **تم حظر العضو المخالف (Ban) من السيرفر بواسطة M7R!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-unban',
      name: 'unban',
      aliases: ['فك-الباند', 'فك-حظر', 'عفو'],
      description: 'فك الحظر (Unban) عن عضو باستخدام الآيدي (مثال: !unban 10987654321)',
      category: 'moderation',
      enabled: true,
      cooldownSec: 5,
      customReply: '✅ **تم فك الحظر (Unban) عن العضو بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-kick',
      name: 'kick',
      aliases: ['طرد', 'كيك'],
      description: 'طرد عضو من السيرفر مع إمكانية كتابة السبب (مثال: !kick @user سبب)',
      category: 'moderation',
      enabled: true,
      cooldownSec: 5,
      customReply: '👢 **تم طرد العضو من السيرفر بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-warn',
      name: 'warn',
      aliases: ['تحذير', 'انذار'],
      description: 'توجيه تحذير إداري رسمي لعضو وحفظه في سجل التحذيرات (مثال: !warn @user السبب)',
      category: 'moderation',
      enabled: true,
      cooldownSec: 3,
      customReply: '⚠️ **تم توجيه تحذير رسمي للعضو وتوثيقه في سجل الرقابة!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-warnings',
      name: 'warnings',
      aliases: ['تحذيرات', 'انذارات', 'سجل-التحذيرات'],
      description: 'عرض قائمة وعدد التحذيرات المسجلة على عضو (مثال: !warnings @user)',
      category: 'moderation',
      enabled: true,
      cooldownSec: 3,
      customReply: '📋 **سجل التحذيرات الإدارية للعضو:**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-clearwarnings',
      name: 'clearwarnings',
      aliases: ['مسح-التحذيرات', 'ازالة-التحذيرات', 'تصفير-التحذيرات'],
      description: 'مسح وتصفير جميع التحذيرات المسجلة على عضو (مثال: !clearwarnings @user)',
      category: 'moderation',
      enabled: true,
      cooldownSec: 5,
      customReply: '🧹 **تم مسح جميع التحذيرات المسجلة على العضو بنجاح!**',
      allowedChannel: 'all'
    },

    // 2. CHANNELS & ROLES MANAGEMENT
    {
      id: 'cmd-clear',
      name: 'clear',
      aliases: ['مسح', 'تنظيف', 'purge'],
      description: 'مسح عدد محدد من الرسائل في الروم الحالي (مثال: !clear 50)',
      category: 'channels',
      enabled: true,
      cooldownSec: 3,
      customReply: '🧹 **تم تنظيف الشات ومسح الرسائل بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-lock',
      name: 'lock',
      aliases: ['قفل', 'تقفيل'],
      description: 'قفل الروم الحالي ومنع الأعضاء من إرسال الرسائل',
      category: 'channels',
      enabled: true,
      cooldownSec: 3,
      customReply: '🔒 **تم قفل الروم بنجاح بواسطة حماية M7R!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-unlock',
      name: 'unlock',
      aliases: ['فتح', 'فتح-الروم'],
      description: 'إعادة فتح الروم الحالي والسماح للأعضاء بالكتابة',
      category: 'channels',
      enabled: true,
      cooldownSec: 3,
      customReply: '🔓 **تم فتح الروم بنجاح بواسطة M7R!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-hide',
      name: 'hide',
      aliases: ['اخفاء', 'خفي'],
      description: 'إخفاء الروم الحالي عن جميع الأعضاء فوراً',
      category: 'channels',
      enabled: true,
      cooldownSec: 3,
      customReply: '👁️‍🗨️ **تم إخفاء الروم عن الأعضاء بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-show',
      name: 'show',
      aliases: ['اظهار', 'ظهر'],
      description: 'إظهار الروم الحالي للأعضاء من جديد',
      category: 'channels',
      enabled: true,
      cooldownSec: 3,
      customReply: '👁️ **تم إظهار الروم للجميع بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-slowmode',
      name: 'slowmode',
      aliases: ['بطء', 'تهدئة', 'سلو'],
      description: 'تحديد مهلة إرسال الرسائل في الروم بالثواني (مثال: !slowmode 5)',
      category: 'channels',
      enabled: true,
      cooldownSec: 3,
      customReply: '⏱️ **تم تحديث وضع التهدئة (Slowmode) للروم بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-role',
      name: 'role',
      aliases: ['رتبة', 'رول', 'اعطاء-رتبة'],
      description: 'إعطاء أو سحب رتبة من عضو (مثال: !role @user VIP)',
      category: 'channels',
      enabled: true,
      cooldownSec: 3,
      customReply: '🎖️ **تم تحديث رتب العضو بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-nick',
      name: 'nick',
      aliases: ['لقب', 'تغيير-لقب', 'اسم'],
      description: 'تغيير لقب عضو داخل السيرفر أو إعادته للاسم الأصلي (مثال: !nick @user البطل)',
      category: 'channels',
      enabled: true,
      cooldownSec: 3,
      customReply: '✏️ **تم تغيير لقب العضو في السيرفر بنجاح!**',
      allowedChannel: 'all'
    },

    // 3. VOICE MODERATION
    {
      id: 'cmd-vkick',
      name: 'vkick',
      aliases: ['طرد-صوتي', 'فصل', 'فصل-صوتي'],
      description: 'فصل عضو من الروم الصوتي فوراً (مثال: !vkick @user)',
      category: 'voice',
      enabled: true,
      cooldownSec: 3,
      customReply: '🔌 **تم فصل العضو من الروم الصوتي بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-vmute',
      name: 'vmute',
      aliases: ['ميوت-صوتي', 'كتم-صوتي'],
      description: 'كتم المايكروفون عن عضو متواجد في الروم الصوتي (مثال: !vmute @user)',
      category: 'voice',
      enabled: true,
      cooldownSec: 3,
      customReply: '🎙️ **تم كتم العضو صوتياً في الروم الصوتي!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-vunmute',
      name: 'vunmute',
      aliases: ['فك-ميوت-صوتي', 'فك-كتم-صوتي'],
      description: 'فك الكتم الصوتي عن عضو في الروم الصوتي (مثال: !vunmute @user)',
      category: 'voice',
      enabled: true,
      cooldownSec: 3,
      customReply: '🔊 **تم فك الكتم الصوتي عن العضو بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-move',
      name: 'move',
      aliases: ['سحب', 'نقل'],
      description: 'سحب عضو من روم صوتي آخر إلى الروم الصوتي الذي تتواجد فيه (مثال: !move @user)',
      category: 'voice',
      enabled: true,
      cooldownSec: 3,
      customReply: '🧲 **تم سحب العضو إلى رومك الصوتي بنجاح!**',
      allowedChannel: 'all'
    },

    // 4. WELCOME & GENERAL COMMANDS
    {
      id: 'cmd-welcome',
      name: 'welcome',
      aliases: ['ترحيب', 'تست-ترحيب'],
      description: 'إرسال بطاقة الترحيب المخصصة في الروم لتجربتها أو الترحيب بعضو (مثال: !welcome @user)',
      category: 'general',
      enabled: true,
      cooldownSec: 3,
      customReply: '👋 **تم إرسال بطاقة الترحيب الرسمية بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-setwelcome',
      name: 'setwelcome',
      aliases: ['تعيين-الترحيب', 'روم-الترحيب'],
      description: 'تعيين الروم الحالي كروم رسمي لاستقبال الأعضاء الجدد والترحيب بهم تلقائياً',
      category: 'general',
      enabled: true,
      cooldownSec: 5,
      customReply: '✅ **تم تعيين هذا الروم كروم رسمي للترحيب بالأعضاء الجدد!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-ping',
      name: 'ping',
      aliases: ['بنق', 'اتصال', 'بينج'],
      description: 'فحص سرعة اتصال البوت بالديسكورد (Latency)',
      category: 'general',
      enabled: true,
      cooldownSec: 3,
      customReply: '🏓 **M7R Security Pong!** سرعة الاستجابة ممتازة والنظام يعمل المستمر.',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-server',
      name: 'server',
      aliases: ['سيرفر', 'معلومات-السيرفر', 'احصائيات'],
      description: 'عرض إحصائيات ومعلومات السيرفر الحالية بالتفصيل',
      category: 'general',
      enabled: true,
      cooldownSec: 5,
      customReply: '📊 معلومات السيرفر الرسمية المحمية بواسطة M7R:',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-roles',
      name: 'roles',
      aliases: ['رتب', 'الرتب', 'قائمة-الرتب'],
      description: 'عرض قائمة جميع رتب السيرفر وعدد الأعضاء في كل رتبة',
      category: 'general',
      enabled: true,
      cooldownSec: 5,
      customReply: '🎖️ **قائمة رتب السيرفر الرسمية:**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-help',
      name: 'help',
      aliases: ['مساعدة', 'اوامر', 'commands'],
      description: 'عرض موسوعة جميع أوامر بوت M7R الأساسية والإدارية المفعلة مع رابط الدشبورد (https://bot-m7r.netlify.app/)',
      category: 'general',
      enabled: true,
      cooldownSec: 5,
      customReply: '📜 قائمة الأوامر الأساسية والإدارية المتاحة في بوت M7R (🌐 الدشبورد: https://bot-m7r.netlify.app/ ):',
      allowedChannel: 'all'
    },

    // 5. TICKETS COMMANDS
    {
      id: 'cmd-panel',
      name: 'panel',
      aliases: ['تكت', 'بانل', 'تذاكر'],
      description: 'إرسال لوحة التذاكر المخصصة في الروم الحالي فوراً',
      category: 'tickets',
      enabled: true,
      cooldownSec: 5,
      customReply: '🎫 **تم إرسال لوحة التذاكر بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-claim',
      name: 'claim',
      aliases: ['استلام', 'تولي'],
      description: 'استلام التذكرة المفتوحة حالياً باسم المشرف',
      category: 'tickets',
      enabled: true,
      cooldownSec: 3,
      customReply: '✅ **تم استلام التذكرة بواسطة المشرف بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-close',
      name: 'close',
      aliases: ['اغلاق', 'قفل-تكت'],
      description: 'إغلاق التذكرة الحالية وأرشفتها في روم اللوق',
      category: 'tickets',
      enabled: true,
      cooldownSec: 5,
      customReply: '🔒 **تم إغلاق التذكرة وأرشفتها بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-come',
      name: 'come',
      aliases: ['نداء', 'تعال', 'استدعاء'],
      description: 'إرسال نداء تنبيهي لعضو في الخاص للحضور إلى التذكرة أو الروم (مثال: !come @user)',
      category: 'tickets',
      enabled: true,
      cooldownSec: 5,
      customReply: '📲 **تم إرسال نداء عاجل للعضو في الخاص للحضور إلى الروم!**',
      allowedChannel: 'all'
    },

    // 6. UTILITY & PROFILE COMMANDS
    {
      id: 'cmd-tax',
      name: 'tax',
      aliases: ['ضريبة', 'ضريبه', 'حساب-ضريبة'],
      description: 'حساب ضريبة البروبوت (ProBot Tax 5%) بدقة للمتاجر والوسطاء (مثال: !tax 100000)',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '💰 **حاسبة ضريبة المتجر (M7R Tax Calculator):**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-say',
      name: 'say',
      aliases: ['قول', 'تحدث', 'ارسل'],
      description: 'جعل البوت يرسل رسالة في الروم (مثال: !say مرحباً بكم)',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '📢 **رسالة من إدارة M7R:**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-embed',
      name: 'embed',
      aliases: ['ايمبد', 'اعلان', 'رسالة-رسمية'],
      description: 'جعل البوت يرسل إعلاناً رسمياً منسقاً داخل بطاقة Embed باسم السيرفر (مثال: !embed إعلان هام)',
      category: 'utility',
      enabled: true,
      cooldownSec: 5,
      customReply: '📢 **تم إرسال الإعلان الرسمي بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-user',
      name: 'user',
      aliases: ['هوية', 'معلوماتي', 'بروفايل', 'يوزر', 'id'],
      description: 'عرض بطاقة معلومات العضو وتاريخ دخوله للسيرفر والديسكورد',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '🪪 **بطاقة الهوية الرقمية للعضو (M7R Profile):**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-avatar',
      name: 'avatar',
      aliases: ['افتار', 'صورة', 'افاتار'],
      description: 'عرض الصورة الرمزية للعضو بجودة عالية مع رابط التحميل',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '🖼️ **الصورة الرمزية للعضو:**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-banner',
      name: 'banner',
      aliases: ['بنر', 'بانر', 'خلفية'],
      description: 'عرض صورة البنر الشخصي للعضو أو السيرفر بجودة عالية',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '🎨 **بنر العضو الرسمي:**',
      allowedChannel: 'all'
    },

    // 7. ISLAMIC AZKAR & SECURITY COMMANDS
    {
      id: 'cmd-azkar',
      name: 'azkar',
      aliases: ['اذكار', 'ذكر', 'دعاء', 'قران'],
      description: 'عرض ذكر مبارك أو آية قرآنية مع فضلها وأزرار التسبيح التفاعلية',
      category: 'islamic',
      enabled: true,
      cooldownSec: 5,
      customReply: '🕌 **أذكار المسلم اليومية من M7R:**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-status',
      name: 'status',
      aliases: ['حالة', 'حمايه', 'حماية'],
      description: 'عرض تقرير حالة أنظمة الحماية والمصيدة والترحيب في السيرفر',
      category: 'security',
      enabled: true,
      cooldownSec: 5,
      customReply: '🛡️ جميع أنظمة الحماية ومصيدة M7R تعمل بكفاءة 100%.',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-trap',
      name: 'trap',
      aliases: ['مصيدة', 'فخ', 'honeypot'],
      description: 'فحص حالة روم مصيدة السبام والهاكرز في السيرفر',
      category: 'security',
      enabled: true,
      cooldownSec: 5,
      customReply: '🪤 **مصيدة الحماية M7R نشطة وترصد أي تحركات مشبوهة!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-antinuke',
      name: 'antinuke',
      aliases: ['انتي-نوك', 'حماية-شاملة', 'shield'],
      description: 'فحص إعدادات الحماية Anti-Nuke ضد التصفير وحذف الرومات والرتب',
      category: 'security',
      enabled: true,
      cooldownSec: 5,
      customReply: '🛡️ **نظام الحماية M7R Anti-Nuke في حالة تأهب قصوى!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-come',
      name: 'come',
      aliases: ['نداء', 'تعال'],
      description: 'نداء عضو في الروم الحالي وإرسال إيمبد نداء عاجل له في الخاص مع زر انتقال مباشر للروم',
      category: 'moderation',
      enabled: true,
      cooldownSec: 3,
      customReply: '🔔 **تم إرسال نداء عاجل للعضو في الروم وفي الخاص!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-clear',
      name: 'clear',
      aliases: ['مسح', 'تنظيف'],
      description: 'مسح عدد من الرسائل (1-100) بسرعة فائقة مع إمكانية فلترة رسائل عضو محدد',
      category: 'moderation',
      enabled: true,
      cooldownSec: 3,
      customReply: '🧹 **تم تنظيف الشات بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-lock',
      name: 'lock',
      aliases: ['قفل', 'فتح', 'unlock'],
      description: 'قفل أو فتح الروم الحالي أمام الأعضاء بضغطة زر مع إيمبد رسمي',
      category: 'moderation',
      enabled: true,
      cooldownSec: 3,
      customReply: '🔒 **تم تحديث حالة قفل الروم بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-hide',
      name: 'hide',
      aliases: ['اخفاء', 'اظهار', 'show'],
      description: 'إخفاء أو إظهار الروم الحالي عن الأعضاء (@everyone)',
      category: 'moderation',
      enabled: true,
      cooldownSec: 3,
      customReply: '🙈 **تم تحديث حالة ظهور الروم بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-move-all',
      name: 'move-all',
      aliases: ['سحب-الكل', 'سحب'],
      description: 'سحب جميع الأعضاء المتواجدين في الرومات الصوتية إلى رومك الصوتي الحالي بضغطة واحدة',
      category: 'moderation',
      enabled: true,
      cooldownSec: 5,
      customReply: '🔊 **تم سحب جميع الأعضاء إلى رومك الصوتي بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-role',
      name: 'role',
      aliases: ['رتبة', 'رتبه', 'رتبة-الكل', 'role-all'],
      description: 'إعطاء أو سحب رتبة من عضو أو توزيع رتبة جماعية لكل أعضاء السيرفر بأمان',
      category: 'moderation',
      enabled: true,
      cooldownSec: 5,
      customReply: '🎭 **تم تحديث الرتب بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-embed',
      name: 'embed',
      aliases: ['ايمبد', 'اعلان'],
      description: 'فتح نافذة تفاعلية (Modal) لإنشاء وإرسال إعلان رسمي فخم بثيم M7R البنفسجي',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '📢 **تم نشر الإيمبد الرسمي بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-poll',
      name: 'poll',
      aliases: ['تصويت', 'استفتاء'],
      description: 'إنشاء تصويت تفاعلي بأزرار وشريط نسب مئوية حي وحماية صوت واحد لكل عضو',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '📊 **تصويت تفاعلي رسمي لأعضاء السيرفر:**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-giveaway',
      name: 'giveaway',
      aliases: ['قيف-اواي', 'قرعة', 'سحب'],
      description: 'إطلاق سحب قيف أواي احترافي مع زر مشاركة حي وزر إعادة السحب (Reroll)',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '🎉 **تم إطلاق القيف أواي الرسمي!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-top-staff',
      name: 'top-staff',
      aliases: ['توب-الادارة', 'توب-المشرفين', 'نقاط-الادارة'],
      description: 'عرض لوحة شرف أفضل المشرفين حسب التذاكر المستلمة وتقييمات الأعضاء (5 نجوم ⭐)',
      category: 'general',
      enabled: true,
      cooldownSec: 3,
      customReply: '🏆 **لوحة شرف وتوب مشرفين M7R PRO:**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-server',
      name: 'server',
      aliases: ['سيرفر', 'معلومات-السيرفر'],
      description: 'عرض بطاقة معلومات السيرفر الشاملة (المالك، الأعضاء، البوستات، الرومات، وتاريخ التأسيس)',
      category: 'general',
      enabled: true,
      cooldownSec: 3,
      customReply: '🏰 **بطاقة معلومات السيرفر الرسمية:**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-user',
      name: 'user',
      aliases: ['هوية', 'يوزر', 'افتار', 'بنر', 'avatar', 'banner'],
      description: 'عرض بطاقة هوية العضو (نقاط M7R 💎، نقاط الإدارة 🏆، الرتب، والافتار والبنر بدقة عالية)',
      category: 'general',
      enabled: true,
      cooldownSec: 3,
      customReply: '🪪 **بطاقة هوية العضو الرسمية:**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-dashboard',
      name: 'dashboard',
      aliases: ['دشبورد', 'داشبورد', 'ويب', 'لوحة-الويب', 'موقع', 'رابط'],
      description: 'إرسال رابط وبطاقة دشبورد الويب الرسمية (https://bot-m7r.netlify.app/) للتحكم المباشر في السيرفر',
      category: 'general',
      enabled: true,
      cooldownSec: 3,
      customReply: '🌐 **دشبورد الويب الرسمي لبوت M7R PRO المستمر:**\n🔗 https://bot-m7r.netlify.app/',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-setup-rooms',
      name: 'setup-rooms',
      aliases: ['رومات-جاهزة', 'انشاء-رومات', 'بناء-السيرفر'],
      description: 'إنشاء الرومات الجاهزة بضغطة زر (ترحيب، شات عام، تكت، تقديم، اقتراحات، ألعاب، لوق، قرآن)',
      category: 'channels',
      enabled: true,
      cooldownSec: 5,
      customReply: '🏗️ **تم فتح لوحة الرومات الجاهزة ومصمم السيرفر الذكي!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-suggest',
      name: 'suggest',
      aliases: ['اقتراح', 'فكرة', 'اقترح'],
      description: 'إرسال اقتراح أو فكرة لتطوير السيرفر مع أزرار تصويت حية وشريط نسبة موافقة',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '💡 **تم نشر اقتراحك للتصويت في روم الاقتراحات بنجاح!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-snipe',
      name: 'snipe',
      aliases: ['سنايب', 'اخر-محذوف', 'محذوف'],
      description: 'كشف آخر رسالة تم حذفها أو تعديلها في الروم الحالي مع اسم صاحبها والتوقيت',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '🕵️‍♂️ **كاشف الرسائل المحذوفة والمعدلة (M7R Snipe):**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-find',
      name: 'find',
      aliases: ['وين', 'بحث-صوتي', 'اين'],
      description: 'البحث عن عضو وكشف الروم الصوتي المتواجد فيه حالياً مع حالة المايك وزر انتقال مباشر',
      category: 'voice',
      enabled: true,
      cooldownSec: 3,
      customReply: '🔍 **رادار البحث الصوتي (M7R Voice Finder):**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-afk',
      name: 'afk',
      aliases: ['مشغول', 'غائب', 'برب'],
      description: 'تفعيل وضع الانشغال الذكي ليرد البوت تلقائياً على أي شخص يمنشنك مع سبب غيابك ومنذ متى',
      category: 'utility',
      enabled: true,
      cooldownSec: 3,
      customReply: '💤 **تم تفعيل وضع الانشغال الذكي (M7R AFK)!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-panic',
      name: 'panic',
      aliases: ['طوارئ', 'قفل-السيرفر', 'حظر-تجول'],
      description: 'تفعيل أو إيقاف وضع الطوارئ القصوى وقفل رومات السيرفر لحمايته من الهجمات',
      category: 'security',
      enabled: true,
      cooldownSec: 5,
      customReply: '🚨 **تم تحديث حالة وضع الطوارئ (Panic Mode) بواسطة M7R Shield!**',
      allowedChannel: 'all'
    },
    {
      id: 'cmd-auto-line',
      name: 'auto-line',
      aliases: ['خط', 'فاصل'],
      description: 'إرسال الخط التلقائي الفخم لتنظيم الشات أو تفعيل الخط التلقائي للروم',
      category: 'utility',
      enabled: true,
      cooldownSec: 2,
      customReply: '✨ **خط M7R الملكي:**',
      allowedChannel: 'all'
    }
  ]);

  // Azkar System State
  const [azkarConfig, setAzkarConfigState] = useState<AzkarConfig>({
    enabled: true,
    channelName: 'اذكار',
    intervalMinutes: 30,
    embedColor: '#059669',
    showVirtue: true,
    items: [
      {
        id: 'az-1',
        category: 'quran',
        categoryLabel: 'آية قرآنية سكينة',
        arabicText: '﴿ الَّذِينَ آمَنُوا وَتَطْمَئِنُّ قُلُوبُهُم بِذِكْرِ اللَّهِ ۗ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾',
        virtue: 'سورة الرعد: آية 28 - طمأنينة القلوب وسكينة الأرواح.',
        enabled: true
      },
      {
        id: 'az-2',
        category: 'salawat',
        categoryLabel: 'الصلاة على النبي ﷺ',
        arabicText: 'اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا وَحَبِيبِنَا مُحَمَّدٍ وَعَلَى آلِهِ وَصَحْبِهِ أَجْمَعِينَ',
        virtue: 'قال رسول الله ﷺ: «مَنْ صَلَّى عَلَيَّ صَلاةً صَلَّى اللَّهُ عَلَيْهِ بِهَا عَشْرًا».',
        enabled: true
      },
      {
        id: 'az-3',
        category: 'istighfar',
        categoryLabel: 'سيد الاستغفار',
        arabicText:
          'اللَّهُمَّ أَنْتَ رَبِّي لا إِلَهَ إِلا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لا يَغْفِرُ الذُّنُوبَ إِلا أَنْتَ.',
        virtue: 'من قالها موقناً بها حين يمسي فمات من ليلته دخل الجنة، وكذلك إذا أصبح.',
        enabled: true
      },
      {
        id: 'az-4',
        category: 'general',
        categoryLabel: 'تسبيح وتحميد',
        arabicText: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
        virtue: 'كلمتان خفيفتان على اللسان، ثقيلتان في الميزان، حبيبتان إلى الرحمن.',
        enabled: true
      },
      {
        id: 'az-5',
        category: 'sabah',
        categoryLabel: 'أذكار الصباح والمساء',
        arabicText: 'بِسْمِ اللَّهِ الَّذِي لا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ',
        virtue: 'ثلاث مرات صباحاً ومساءً لم يضره شيء.',
        enabled: true
      },
      {
        id: 'az-6',
        category: 'general',
        categoryLabel: 'كنز من كنوز الجنة',
        arabicText: 'لا حَوْلَ وَلا قُوَّةَ إِلا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ',
        virtue: 'كنز من تحت العرش وبراءة من الحول والقوة إلا بالله.',
        enabled: true
      },
      {
        id: 'az-7',
        category: 'istighfar',
        categoryLabel: 'استغفار وتوبة',
        arabicText: 'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لا إِلَهَ إِلا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ',
        virtue: 'من قاله غُفرت ذنوبه وإن كان فر من الزحف.',
        enabled: true
      },
      {
        id: 'az-8',
        category: 'quran',
        categoryLabel: 'دعاء جامع',
        arabicText: '﴿ رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ ﴾',
        virtue: 'أكثر دعاء كان يدعو به النبي ﷺ.',
        enabled: true
      }
    ]
  });

  // Dedicated Honeypot Trap State
  const [honeypotTrap, setHoneypotTrapState] = useState<HoneypotTrapConfig>({
    enabled: true,
    channelName: '🚫-ممنوع-الدخول',
    punishment: 'ban',
    timeoutDurationMinutes: 10080,
    deleteMessage: true,
    alertLogChannel: 'log-server',
    customWarningMessage:
      '⚠️ تحذير أمني شديد: هذا الروم عبارة عن مصيدة آلية لكشف البوتات وحسابات السيلف بوت والمخربين. أي رسالة أو تفاعل هنا يؤدي للحظر الفوري من سيرفر M7R!',
    whitelistUserIds: ['498712345678901234'],
    whitelistRoleNames: ['Owner', 'Co-Owner', 'Lead Admin'],
    totalTrapped: 18
  });

  // Anti-Nuke Config
  const [antiNuke, setAntiNukeState] = useState<AntiNukeConfig>({
    enabled: true,
    massBanLimit: 3,
    exemptRoleId: '',
    punishmentAction: 'strip_roles',
    massBanWindowSeconds: 10,
    massBanAction: 'strip_roles',
    massKickLimit: 3,
    massChannelDeleteLimit: 2,
    massRoleDeleteLimit: 2,
    massMessageDeleteLimit: 5,
    liveMessageDeleteMonitor: true,
    antiDeleteChatNotice: true,
    quarantineNewBots: true,
    blockWebhookCreation: true,
    whitelistUserIds: ['498712345678901234', '912384756102938475'],
    adminRoleRateLimits: {
      enabled: true,
      defaultCommandsPerMinute: 12,
      notifyUserOnLimit: true,
      logChannelAlert: true,
      policies: [
        {
          id: 'rl-tier-deputy',
          roleId: '',
          roleName: 'Co-Owner',
          importanceTier: 'owner_deputy',
          commandsPerMinute: 45,
          actionOnExceed: 'block_warn',
          enabled: true
        },
        {
          id: 'rl-tier-head',
          roleId: '',
          roleName: 'Head Admin',
          importanceTier: 'head_admin',
          commandsPerMinute: 25,
          actionOnExceed: 'block_warn',
          enabled: true
        },
        {
          id: 'rl-tier-mod',
          roleId: '',
          roleName: 'Moderator',
          importanceTier: 'moderator',
          commandsPerMinute: 12,
          actionOnExceed: 'timeout_5m',
          enabled: true
        },
        {
          id: 'rl-tier-helper',
          roleId: '',
          roleName: 'Helper',
          importanceTier: 'helper',
          commandsPerMinute: 6,
          actionOnExceed: 'timeout_5m',
          enabled: true
        }
      ]
    }
  });

  // Anti-Spam Config
  const [antiSpam, setAntiSpamState] = useState<AntiSpamConfig>({
    enabled: true,
    maxMessages: 5,
    windowSeconds: 3,
    maxMentions: 3,
    blockRepetitiveMessages: true,
    blockEmojiFlood: true,
    punishment: 'timeout',
    timeoutDurationMinutes: 5,
    trapChannels: ['#general', '#chat', '#market', '#support']
  });

  // Anti-Invite Config
  const [antiInvite, setAntiInviteState] = useState<AntiInviteConfig>({
    enabled: true,
    blockDiscordInvites: true,
    blockSuspiciousLinks: true,
    whitelistDomains: ['discord.com', 'github.com', 'bot-m7r.netlify.app'],
    exemptRoles: ['Co-Owner', 'Security Chief', 'VIP Sponsor'],
    action: 'delete_warn'
  });

  const [autoResponses, setAutoResponsesState] = useState<AutoResponse[]>([
    {
      id: 'ar-1',
      trigger: 'سلام عليكم',
      matchType: 'contains',
      reply: 'وعليكم السلام ورحمة الله وبركاته! أهلاً بك في سيرفر M7R المحمي بنظام الحماية 🛡️',
      autoReaction: '❤️',
      enabled: true
    },
    {
      id: 'ar-2',
      trigger: 'متجر',
      matchType: 'contains',
      reply: '🛒 تفضل بزيارة روم التذاكر لطلب منتجات المتجر الحصرية: <#tickets>',
      autoReaction: '🛒',
      enabled: true
    }
  ]);

  const [voice247, setVoice247State] = useState<Voice247Config>({
    enabled: true,
    channelId: '110293847561029384',
    channelName: '🔊 المستمر | خلوة وتلاوات عطرة',
    audioMode: 'quran',
    selectedReciter: 'alafasy',
    autoReconnect: true,
    deafened: true,
    muted: false,
    scheduleEnabled: true
  });

  // Wrappers that trigger the Unsaved Changes bar automatically!
  const setBasicSettings = (val: BotBasicSettings) => {
    setBasicSettingsState(val);
    setHasUnsavedChanges(true);
  };

  const setWelcomeConfig = (val: WelcomeConfig) => {
    setWelcomeConfigState(val);
    setHasUnsavedChanges(true);
  };

  const setTicketPanel = (val: TicketPanelConfig) => {
    setTicketPanelState(val);
    setHasUnsavedChanges(true);
  };

  const setDiscordCommands = (val: DiscordCommandConfig[]) => {
    setDiscordCommandsState(val);
    setHasUnsavedChanges(true);
  };

  const setAntiNuke: React.Dispatch<React.SetStateAction<AntiNukeConfig>> = (val) => {
    setAntiNukeState(val);
    setHasUnsavedChanges(true);
  };

  const setAntiSpam: React.Dispatch<React.SetStateAction<AntiSpamConfig>> = (val) => {
    setAntiSpamState(val);
    setHasUnsavedChanges(true);
  };

  const setAntiInvite: React.Dispatch<React.SetStateAction<AntiInviteConfig>> = (val) => {
    setAntiInviteState(val);
    setHasUnsavedChanges(true);
  };

  const setAutoResponses: React.Dispatch<React.SetStateAction<AutoResponse[]>> = (val) => {
    setAutoResponsesState(val);
    setHasUnsavedChanges(true);
  };

  const setVoice247: React.Dispatch<React.SetStateAction<Voice247Config>> = (val) => {
    setVoice247State(val);
    setHasUnsavedChanges(true);
  };

  const setAzkarConfig = (val: AzkarConfig) => {
    setAzkarConfigState(val);
    setHasUnsavedChanges(true);
  };

  const setHoneypotTrap: React.Dispatch<React.SetStateAction<HoneypotTrapConfig>> = (val) => {
    setHoneypotTrapState(val);
    setHasUnsavedChanges(true);
  };

  // Hydrate full isolated per-guild settings payload returned from /api/guild/select or /api/settings
  const applyIsolatedGuildSettings = (s: any, guildTickets?: Ticket[]) => {
    if (s && typeof s === 'object') {
      if (s.basicSettings) setBasicSettingsState(s.basicSettings);
      if (s.welcomeConfig) setWelcomeConfigState(s.welcomeConfig);
      if (s.ticketPanelConfig) setTicketPanelState(s.ticketPanelConfig);
      if (Array.isArray(s.discordCommands)) setDiscordCommandsState(s.discordCommands);
      if (s.antiNuke) setAntiNukeState(s.antiNuke);
      if (s.antiSpam) setAntiSpamState(s.antiSpam);
      if (s.antiInvite) setAntiInviteState(s.antiInvite);
      if (s.voice247) setVoice247State(s.voice247);
      if (Array.isArray(s.autoResponses)) setAutoResponsesState(s.autoResponses);
      if (s.azkarConfig) setAzkarConfigState(s.azkarConfig);
      if (s.honeypotTrapConfig) setHoneypotTrapState(s.honeypotTrapConfig);
      if (s.reactionRolesConfig) setReactionRolesConfigState(s.reactionRolesConfig);
      if (s.liveServerStatsConfig) setLiveStatsConfigState(s.liveServerStatsConfig);
    }
    if (Array.isArray(guildTickets)) {
      setTickets(guildTickets);
    }
    setHasUnsavedChanges(false);
  };

  // Switch active controlled server & strictly isolate channels, roles, settings, tickets & commands per guild
  const handleSelectGuild = async (guild: ConnectedGuildItem, opts?: { silent?: boolean }) => {
    if (!guild || !guild.id) return;
    if (!hasValidAuthSession()) {
      setTokenGateInitialStep('landing');
      setShowTokenGate(true);
      return;
    }

    const isPresent = guild.hasBot !== false && guild.botPresent !== false;
    if (!isPresent) {
      const cid = connectedBot?.id || '1564565916216336494';
      const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${encodeURIComponent(
        cid
      )}&permissions=8&integration_type=0&scope=bot+applications.commands&guild_id=${encodeURIComponent(
        guild.id
      )}&disable_guild_select=true`;
      window.open(inviteUrl, '_blank', 'noopener,noreferrer');
      setTokenGateInitialStep('select_server');
      setShowTokenGate(true);
      return;
    }

    if (!opts?.silent) sound.playShieldActivate();
    invalidateChannelsCache();
    localStorage.setItem('m7r_logged_in', 'true');
    localStorage.setItem('m7r_selected_guild', JSON.stringify(guild));
    localStorage.setItem('m7r_selected_guild_id', guild.id);
    activeGuildIdRef.current = guild.id;

    try {
      const currentHash = window.location.hash || `#/${activeTab || 'overview'}`;
      const nextUrl = `${window.location.pathname || '/'}?guild_id=${encodeURIComponent(guild.id)}${currentHash}`;
      window.history.replaceState({}, document.title, nextUrl);
    } catch {
      // ignore
    }

    try {
      const [selectRes, liveDetails] = await Promise.all([
        fetch('/api/guild/select', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
          body: JSON.stringify({ guildId: guild.id })
        }).catch(() => null),
        fetchAndApplyLiveGuildDetails(guild.id)
      ]);

      if (selectRes && selectRes.status === 403) {
        setTokenGateInitialStep('select_server');
        setShowTokenGate(true);
        setSaveBannerMessage(
          lang === 'ar'
            ? `🔒 البوت غير متواجد في سيرفر (${guild.name}). أضف البوت أولاً للدخول إلى لوحة التحكم.`
            : `🔒 Bot is not in (${guild.name}). Please add the bot first.`
        );
        setTimeout(() => setSaveBannerMessage(null), 5000);
        return;
      }

      const selectData =
        selectRes && selectRes.ok && (selectRes.headers.get('content-type') || '').includes('application/json')
          ? await selectRes.json()
          : null;

      if (selectData?.botMissing) {
        setTokenGateInitialStep('select_server');
        setShowTokenGate(true);
        return;
      }

      const updatedGuild: ConnectedGuildItem = {
        ...guild,
        ...(liveDetails?.guild || {}),
        ...(selectData?.selectedGuild || {}),
        hasBot: true,
        botPresent: true
      };

      localStorage.setItem('m7r_selected_guild', JSON.stringify(updatedGuild));
      localStorage.setItem('m7r_selected_guild_id', updatedGuild.id);

      const resolvedChannels =
        (Array.isArray(selectData?.channels) && selectData.channels.length > 0 && selectData.channels) ||
        (Array.isArray(liveDetails?.channels) ? liveDetails.channels : []);

      setGuildChannelsCache(resolvedChannels, updatedGuild.id, updatedGuild.name);

      setGuildLiveChannels({
        textChannels:
          (Array.isArray(selectData?.textChannels) && selectData.textChannels) ||
          (Array.isArray(liveDetails?.textChannels) ? liveDetails.textChannels : []),
        voiceChannels:
          (Array.isArray(selectData?.voiceChannels) && selectData.voiceChannels) ||
          (Array.isArray(liveDetails?.voiceChannels) ? liveDetails.voiceChannels : []),
        categories: Array.isArray((liveDetails as any)?.categories) ? (liveDetails as any).categories : []
      });

      const resolvedRoles =
        (Array.isArray(selectData?.roles) && selectData.roles.length > 0 && selectData.roles) ||
        (Array.isArray(liveDetails?.roles) ? liveDetails.roles : []);
      setGuildLiveRoles(resolvedRoles);

      if (selectData?.settings || selectData?.tickets) {
        applyIsolatedGuildSettings(selectData.settings, selectData.tickets);
      }

      setConnectedBot((prev) => {
        const existingGuilds = prev?.guilds && prev.guilds.length > 0 ? prev.guilds : getSavedAuthGuilds();
        return {
          ...(selectData?.botInfo || prev || {
            username: 'M7R',
            tag: 'M7R#1624',
            id: '1564565916216336494',
            avatar: '',
            ping: 17,
            mode: 'live'
          }),
          guilds: existingGuilds,
          guildsCount: existingGuilds.length,
          selectedGuild: updatedGuild,
          membersCount: updatedGuild.memberCount || 0,
          channelsCount: updatedGuild.channelsCount || resolvedChannels.length || 0,
          accessMode,
          discordUser: prev?.discordUser || getSavedDiscordUser() || undefined
        };
      });

      setShowTokenGate(false);

      if (!opts?.silent) {
        setSaveBannerMessage(
          lang === 'ar'
            ? `✅ تم التبديل للتحكم المعزول في سيرفر: ${updatedGuild.name} (${updatedGuild.memberCount} عضو • ${updatedGuild.channelsCount || resolvedChannels.length} روم حي)`
            : `✅ Switched isolated server control to: ${updatedGuild.name} (${updatedGuild.memberCount} members • ${updatedGuild.channelsCount || resolvedChannels.length} live channels)`
        );
        setTimeout(() => setSaveBannerMessage(null), 4000);
      }
    } catch {
      // ignore
    }
  };

  // Threat Logs
  const [threatLogs, setThreatLogs] = useState<ThreatLog[]>([
    {
      id: 'th-101',
      type: 'anti-nuke',
      action: 'Mass Ban Blocked',
      target: '3 members targeted',
      executor: 'RogueAdmin#9921',
      timestamp: 'منذ دقيقتين',
      severity: 'critical',
      details: 'حاول المشرف طرد 3 أعضاء خلال ثانيتين. تم سحب جميع رتبه فوراً وعزله في سجن M7R.'
    },
    {
      id: 'th-102',
      type: 'anti-spam',
      action: 'Anti-Spam Trap Triggered',
      target: '#عام-chat',
      executor: 'SpammerBot#1104',
      timestamp: 'منذ 14 دقيقة',
      severity: 'high',
      details: 'أرسل 7 رسائل مكررة في غضون ثانيتين. تم إيقافه مؤقتاً (Timeout) لمدة 15 دقيقة ومسح رسائله.'
    }
  ]);

  // Tickets
  const [tickets, setTickets] = useState<Ticket[]>([
    {
      id: 'ticket-1092',
      channelName: 'ticket-1092',
      category: 'store',
      categoryLabel: '🛒 شراء منتج / M7R Store',
      user: {
        name: 'Rakan_Gamer',
        avatar: '',
        id: '8271635241098'
      },
      claimedBy: 'Sultan [Lead Support]',
      status: 'claimed',
      createdAt: 'اليوم، 03:15 ص',
      messages: [
        {
          id: 'm1',
          author: 'Rakan_Gamer',
          avatar: '',
          isStaff: false,
          content: 'السلام عليكم، أريد شراء باقة نيترو سنة ورتبة VIP للمتجر.',
          timestamp: '03:15 ص'
        },
        {
          id: 'm2',
          author: 'M7R Bot',
          avatar: '',
          isStaff: true,
          content: 'مرحباً بك! تذكرتك مفتوحة، يرجى انتظار أحد مسؤولي المتجر للرد عليك.',
          timestamp: '03:15 ص'
        }
      ]
    }
  ]);

  // Interactive Reaction Roles & Live Server Stats State
  const [guildLiveChannels, setGuildLiveChannels] = useState<{
    textChannels: { id: string; name: string }[];
    voiceChannels: { id: string; name: string }[];
    categories?: { id: string; name: string }[];
  }>({
    textChannels: [
      { id: 'roles', name: 'الرتب-التفاعلية' },
      { id: 'general', name: 'شات-عام' },
      { id: 'tickets', name: 'tickets' }
    ],
    voiceChannels: [{ id: 'vc1', name: '🔊・أنشئ رومك' }],
    categories: []
  });

  const [guildLiveRoles, setGuildLiveRoles] = useState<{ id: string; name: string; color: string }[]>([
    { id: 'r1', name: 'Roblox Player', color: '#E11D48' },
    { id: 'r2', name: 'GTA V RP', color: '#10B981' },
    { id: 'r3', name: 'PlayStation VIP', color: '#3B82F6' },
    { id: 'r4', name: 'Valorant Agent', color: '#FF4655' }
  ]);

  const initialReactionRoleItems = [
    {
      id: 'rr_roblox',
      label: 'Roblox',
      roleId: '',
      roleName: 'Roblox Player',
      roleColor: '#E11D48',
      emoji: '🧱',
      category: 'gaming' as const,
      buttonStyle: 'Danger' as const,
      colorHex: '#E11D48',
      description: 'رتبة لاعبي روبلوكس والفعاليات الخاصة بها'
    },
    {
      id: 'rr_gtav',
      label: 'GTA V / FiveM',
      roleId: '',
      roleName: 'GTA V RP',
      roleColor: '#10B981',
      emoji: '🚓',
      category: 'gaming' as const,
      buttonStyle: 'Success' as const,
      colorHex: '#10B981',
      description: 'رتبة لاعبي قراند رول بلاي والحياة الواقعية'
    },
    {
      id: 'rr_ps5',
      label: 'PlayStation',
      roleId: '',
      roleName: 'PlayStation VIP',
      roleColor: '#3B82F6',
      emoji: '🎮',
      category: 'gaming' as const,
      buttonStyle: 'Primary' as const,
      colorHex: '#3B82F6',
      description: 'رتبة مجتمع لاعبي بلايستيشن 4 و 5'
    },
    {
      id: 'rr_valorant',
      label: 'Valorant',
      roleId: '',
      roleName: 'Valorant Agent',
      roleColor: '#FF4655',
      emoji: '🎯',
      category: 'gaming' as const,
      buttonStyle: 'Secondary' as const,
      colorHex: '#FF4655',
      description: 'رتبة لاعبي فالورانت والبطولات التنافسية'
    },
    {
      id: 'rr_pings',
      label: 'إشعارات السيرفر والفعاليات',
      roleId: '',
      roleName: 'Server Pings 🔔',
      roleColor: '#8A2BE2',
      emoji: '🔔',
      category: 'pings' as const,
      buttonStyle: 'Primary' as const,
      colorHex: '#8A2BE2',
      description: 'احصل على تنبيه فوري عند بدء الفعاليات والمسابقات'
    }
  ];

  const [reactionRolesConfig, setReactionRolesConfigState] = useState<ReactionRolesConfig>({
    enabled: true,
    channelId: '',
    channelName: 'الرتب-التفاعلية',
    targetChannelName: 'الرتب-التفاعلية',
    panelTitle: '🎭 منظومة الرتب التفاعلية • M7R PRO ✨',
    panelDescription: 'اختر رتب الألعاب والإشعارات الخاصة بك بضغطة زر أو من القائمة المنسدلة أدناه ليتم منحك الرتبة فوراً!',
    embedColor: '#8A2BE2',
    bannerUrl: '/assets/aistudio/IMG_3117_2cec6847.jpeg',
    mode: 'both',
    displayMode: 'both',
    autoCreateMissingRoles: true,
    roles: initialReactionRoleItems,
    items: initialReactionRoleItems
  });

  const [liveStatsConfig, setLiveStatsConfigState] = useState<LiveServerStatsConfig>({
    enabled: true,
    categoryName: '📊 إحصائيات السيرفر • M7R',
    updateIntervalMinutes: 5,
    updateIntervalSec: 300,
    counters: [
      {
        id: 'stat_total',
        type: 'members',
        enabled: true,
        channelId: '',
        format: '👥・الأعضاء: {count}',
        formatTemplate: '👥・الأعضاء: {count}'
      },
      {
        id: 'stat_online',
        type: 'online',
        enabled: true,
        channelId: '',
        format: '🟢・المتصلين: {count}',
        formatTemplate: '🟢・المتصلين: {count}'
      },
      {
        id: 'stat_boosts',
        type: 'boosts',
        enabled: true,
        channelId: '',
        format: '💎・البوستات: {count}',
        formatTemplate: '💎・البوستات: {count}'
      },
      {
        id: 'stat_gamers',
        type: 'gamers',
        enabled: true,
        channelId: '',
        format: '🎮・اللاعبين: {count}',
        formatTemplate: '🎮・اللاعبين: {count}',
        roleName: 'Member'
      }
    ]
  });

  const [isSavingReactionRoles, setIsSavingReactionRoles] = useState(false);
  const [isDeployingReactionRoles, setIsDeployingReactionRoles] = useState(false);
  const [isSavingLiveStats, setIsSavingLiveStats] = useState(false);
  const [isDeployingLiveStats, setIsDeployingLiveStats] = useState(false);

  const setReactionRolesConfig: React.Dispatch<React.SetStateAction<ReactionRolesConfig>> = (val) => {
    setReactionRolesConfigState(val);
    setHasUnsavedChanges(true);
  };

  const setLiveStatsConfig: React.Dispatch<React.SetStateAction<LiveServerStatsConfig>> = (val) => {
    setLiveStatsConfigState(val);
    setHasUnsavedChanges(true);
  };

  useEffect(() => {
    const activeGId = connectedBot?.selectedGuild?.id || '';
    if (!activeGId || !hasValidAuthSession()) return;
    fetch(`/api/reaction-roles?guildId=${encodeURIComponent(activeGId)}`, {
      credentials: 'include',
      headers: getAuthHeaders()
    })
      .then((r) => r.json())
      .then((d) => {
        if (d?.config) setReactionRolesConfigState(d.config);
      })
      .catch(() => {});
    fetch(`/api/server-stats?guildId=${encodeURIComponent(activeGId)}`, {
      credentials: 'include',
      headers: getAuthHeaders()
    })
      .then((r) => r.json())
      .then((d) => {
        if (d?.config) setLiveStatsConfigState(d.config);
      })
      .catch(() => {});
  }, [connectedBot?.selectedGuild?.id]);

  const handleTogglePanicMode = () => {
    const next = !panicMode;
    setPanicMode(next);
    fetch('/api/panic-mode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled: next })
    }).catch(() => {});

    const newLog: ThreatLog = {
      id: `th-${Date.now()}`,
      type: 'lockdown',
      action: next ? 'Emergency Panic Mode Activated' : 'Panic Mode Deactivated',
      target: next ? 'ALL_CHANNELS_LOCKED' : 'CHANNELS_RESTORED',
      executor: 'M7R Security Officer',
      timestamp: 'الآن',
      severity: next ? 'critical' : 'low',
      details: next
        ? 'تم قفل جميع رومات السيرفر ومنع إرسال الرسائل وتجميد الرتب لصد هجوم شامل!'
        : 'تم إلغاء وضع الطوارئ وإعادة فتح السيرفر تدريجياً.'
    };
    setThreatLogs((prev) => [newLog, ...prev]);
  };

  const handleSimulateAttack = (type: 'nuke' | 'spam' | 'invite') => {
    setAttacksThwarted((prev) => prev + 1);
    let newLog: ThreatLog;
    if (type === 'nuke') {
      newLog = {
        id: `th-${Date.now()}`,
        type: 'anti-nuke',
        action: 'Mass Channel Delete Attack Intercepted',
        target: 'Attempted to delete #chat-1, #chat-2',
        executor: `Attacker_${Math.floor(1000 + Math.random() * 9000)}#0000`,
        timestamp: 'الآن',
        severity: 'critical',
        details: 'تم حظر المهاجم فوراً واسترجاع الصلاحيات بفضل نظام الحماية Anti-Nuke.'
      };
    } else if (type === 'spam') {
      newLog = {
        id: `th-${Date.now()}`,
        type: 'anti-spam',
        action: 'Spam Wave Neutralized',
        target: '#general',
        executor: `RaidBot_${Math.floor(100 + Math.random() * 900)}`,
        timestamp: 'الآن',
        severity: 'high',
        details: 'رصدت مصيدة السبام 12 رسالة في ثانية واحدة وتم تفعيل الكتم الفوري (Timeout).'
      };
    } else {
      newLog = {
        id: `th-${Date.now()}`,
        type: 'anti-invite',
        action: 'Invite Link Thwarted',
        target: '#chat',
        executor: `Promo_${Math.floor(100 + Math.random() * 900)}`,
        timestamp: 'الآن',
        severity: 'medium',
        details: 'تم مسح رابط دعوة سيرفر ديسكورد غير مرخص وتطبيق تحذير تلقائي.'
      };
    }
    handleIncomingSecurityThreat(newLog);
  };

  const handleTicketAction = (ticketId: string, action: string, staffName?: string, extra?: string) => {
    setTickets((prev) => {
      return prev
        .map((t) => {
          if (t.id !== ticketId) return t;
          const updated = { ...t };
          const timeNow = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

          if (action === 'claim') {
            updated.status = 'claimed';
            updated.claimedBy = staffName || 'المشرف المسؤول';
            updated.messages = [
              ...updated.messages,
              {
                id: `m-${Date.now()}`,
                author: 'M7R Bot [System]',
                avatar: '',
                isStaff: true,
                content: `✨ تم استلام التذكرة بنجاح! 🙋‍♂️\nمرحباً، قام الإداري ${updated.claimedBy} باستلام تذكرتك الآن. تم قفل الشات عن بقية الإدارة لمنع التداخل وضمان أفضل خدمة لك! 🌸`,
                timestamp: timeNow
              }
            ];
          } else if (action === 'unclaim') {
            updated.status = 'open';
            updated.claimedBy = null;
            updated.messages = [
              ...updated.messages,
              {
                id: `m-${Date.now()}`,
                author: 'M7R Bot [System]',
                avatar: '',
                isStaff: true,
                content: `🔓 تم فك استلام التذكرة بواسطة ${staffName || 'المشرف المسؤول'} وإعادة فتح الكتابة لجميع طاقم الإدارة.`,
                timestamp: timeNow
              }
            ];
          } else if (action === 'close') {
            updated.status = 'closed';
            updated.messages = [
              ...updated.messages,
              {
                id: `m-${Date.now()}`,
                author: 'M7R Bot [Smart Summary 💜]',
                avatar: '',
                isStaff: true,
                content: '🔒 تم إغلاق التذكرة وإرسال إيمبد ملخص التذكرة التفاعلي إلى روم السجل مع تقييم 5 نجوم ⭐ للمشرف.',
                timestamp: timeNow
              }
            ];
          } else if (action === 'save_file') {
            updated.messages = [
              ...updated.messages,
              {
                id: `m-${Date.now()}`,
                author: 'M7R Bot [Smart Summary 💜]',
                avatar: '',
                isStaff: true,
                content: `💜 تم إرسال إيمبد ملخص التذكرة التفاعلي (مع أزرار تصفح الرسائل بالكامل) إلى روم السجل (#${ticketPanel.transcriptChannelName || 'ticket-logs'})!`,
                timestamp: timeNow
              }
            ];
          } else if (action === 'remind') {
            updated.messages = [
              ...updated.messages,
              {
                id: `m-${Date.now()}`,
                author: 'M7R Bot [Reminder]',
                avatar: '',
                isStaff: true,
                content: `⏰ تنبيه من الإدارة: يرجى موافاتنا بالرد المطلوب لتفادي إغلاق التذكرة تلقائياً.`,
                timestamp: timeNow
              }
            ];
          } else if (action === 'transfer') {
            updated.messages = [
              ...updated.messages,
              {
                id: `m-${Date.now()}`,
                author: 'M7R Bot [System]',
                avatar: '',
                isStaff: true,
                content: `🔄 تم تحويل التذكرة إلى قسم (${extra || 'الإدارة العليا'}) لمتابعة الإجراءات.`,
                timestamp: timeNow
              }
            ];
          } else if (action === 'send_reply') {
            updated.messages = [
              ...updated.messages,
              {
                id: `m-${Date.now()}`,
                author: staffName || 'M7R Staff',
                avatar: '',
                isStaff: true,
                content: extra || 'شكراً لتواصلك مع M7R.',
                timestamp: timeNow
              }
            ];
          }
          return updated;
        })
        .filter((t) => action !== 'delete' || t.id !== ticketId);
    });
  };

  const handleCreateSimulatedTicket = (
    category: 'store' | 'support' | 'complaints' | 'partnerships',
    categoryLabel: string
  ) => {
    sound.playShieldActivate();
    const newNumber = Math.floor(1000 + Math.random() * 9000);
    const newTicket: Ticket = {
      id: `ticket-${newNumber}`,
      channelName: `ticket-${newNumber}`,
      category,
      categoryLabel,
      user: {
        name: `Member_${Math.floor(100 + Math.random() * 900)}`,
        avatar: '',
        id: `${Date.now()}`
      },
      claimedBy: null,
      status: 'open',
      createdAt: 'الآن',
      messages: [
        {
          id: `m-${Date.now()}`,
          author: 'M7R Bot',
          avatar: '',
          isStaff: true,
          content: ticketPanel.welcomeMessage,
          timestamp: 'الآن'
        }
      ]
    };
    setTickets((prev) => [newTicket, ...prev]);
  };

  const handleSaveReactionRoles = async () => {
    setIsSavingReactionRoles(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/reaction-roles/config', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          guildId: connectedBot?.selectedGuild?.id,
          config: reactionRolesConfig
        })
      });
      const data = await res.json();
      if (data?.config) setReactionRolesConfigState(data.config);
      setSaveBannerMessage(data?.message || '✅ تم حفظ إعدادات الرتب التفاعلية لهذا السيرفر بنجاح!');
      setTimeout(() => setSaveBannerMessage(null), 4000);
    } catch {} finally {
      setIsSavingReactionRoles(false);
    }
  };

  const handleDeployReactionRoles = async () => {
    setIsDeployingReactionRoles(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/reaction-roles/deploy', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          guildId: connectedBot?.selectedGuild?.id,
          channelId: reactionRolesConfig.channelId,
          channelName: reactionRolesConfig.channelName,
          config: reactionRolesConfig
        })
      });
      const data = await res.json();
      setSaveBannerMessage(data?.message || data?.error || '🎭 تم إرسال لوحة الرتب التفاعلية إلى السيرفر بنجاح!');
      setTimeout(() => setSaveBannerMessage(null), 5000);
    } catch {} finally {
      setIsDeployingReactionRoles(false);
    }
  };

  const handleSaveLiveStats = async () => {
    setIsSavingLiveStats(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/server-stats/config', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          guildId: connectedBot?.selectedGuild?.id,
          config: liveStatsConfig
        })
      });
      const data = await res.json();
      if (data?.config) setLiveStatsConfigState(data.config);
      setSaveBannerMessage(data?.message || '✅ تم حفظ قوالب رومات الإحصائيات الحية لهذا السيرفر بنجاح!');
      setTimeout(() => setSaveBannerMessage(null), 4000);
    } catch {} finally {
      setIsSavingLiveStats(false);
    }
  };

  const handleDeployLiveStats = async () => {
    setIsDeployingLiveStats(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/server-stats/deploy', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          guildId: connectedBot?.selectedGuild?.id,
          config: liveStatsConfig
        })
      });
      const data = await res.json();
      setSaveBannerMessage(data?.message || data?.error || '📊 تم إنشاء وتحديث رومات الإحصائيات الحية أعلى السيرفر!');
      setTimeout(() => setSaveBannerMessage(null), 5000);
    } catch {} finally {
      setIsDeployingLiveStats(false);
    }
  };

  const handleSaveSettings = async () => {
    setIsSaving(true);
    sound.playShieldActivate();
    try {
      const activeGId = connectedBot?.selectedGuild?.id;
      const res = await fetch('/api/settings', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          guildId: activeGId,
          basicSettings,
          welcome: welcomeConfig,
          ticketPanel,
          commands: discordCommands,
          antiNuke,
          antiSpam,
          antiInvite,
          voice247,
          autoResp: autoResponses,
          azkar: azkarConfig,
          trap: honeypotTrap,
          reactionRoles: reactionRolesConfig,
          liveServerStats: liveStatsConfig
        })
      });
      const data = await res.json();
      if (data?.botInfo) {
        setConnectedBot((prev) => ({
          ...data.botInfo,
          guilds: prev?.guilds || data.botInfo.guilds || [],
          selectedGuild: prev?.selectedGuild || data.botInfo.selectedGuild,
          discordUser: prev?.discordUser || getSavedDiscordUser() || undefined
        }));
      }
      setHasUnsavedChanges(false);
      setSaveBannerMessage(
        lang === 'ar'
          ? `✅ تم حفظ جميع التعديلات لعزل سيرفر (${connectedBot?.selectedGuild?.name || activeGId || 'الحالي'}) وتطبيقها مباشرة في ديسكورد!`
          : '✅ All changes saved and synced directly to your Discord Bot for this server!'
      );
      setTimeout(() => setSaveBannerMessage(null), 4000);
    } catch {
      setHasUnsavedChanges(false);
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleAccessMode = async (mode: AccessRoleMode) => {
    setAccessMode(mode);
    try {
      const res = await fetch('/api/auth/access-mode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode })
      });
      const data = await res.json();
      if (data?.message) {
        setSaveBannerMessage(data.message);
        setTimeout(() => setSaveBannerMessage(null), 4500);
      }
    } catch {
      // ignore
    }
  };

  const handleMarkNotificationsRead = async () => {
    setUnreadNotificationsCount(0);
    setGuildNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    try {
      await fetch('/api/notifications/guilds/read', { method: 'POST' });
    } catch {
      // ignore
    }
  };

  const handleSimulateServerJoin = async () => {
    try {
      const res = await fetch('/api/notifications/guilds/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const data = await res.json();
      if (Array.isArray(data?.notifications)) {
        setGuildNotifications(data.notifications);
        setUnreadNotificationsCount(data.unreadCount ?? 1);
      }
      if (data?.accessMode) {
        setAccessMode(data.accessMode);
      }
      if (data?.message) {
        setSaveBannerMessage(data.message);
        setTimeout(() => setSaveBannerMessage(null), 5000);
      }
    } catch {
      // ignore
    }
  };

  // Unlock all 35+ commands and features for all users without restrictions
  const visibleCommands = discordCommands;

  const syncCommandsToBackendImmediately = (nextCommands: DiscordCommandConfig[]) => {
    setDiscordCommandsState(nextCommands);
    try {
      localStorage.setItem('m7r_custom_commands', JSON.stringify(nextCommands));
    } catch {}
    fetch('/api/settings', {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify({
        guildId: connectedBot?.selectedGuild?.id || 'default',
        commands: nextCommands
      })
    }).catch(() => {});
  };

  const handleUpdateVisibleCommands = (updatedSubset: DiscordCommandConfig[]) => {
    setDiscordCommands(updatedSubset);
    syncCommandsToBackendImmediately(updatedSubset);
  };

  // Add one or more custom aliases to any command in src/App.tsx
  const handleAddCommandAlias = (commandId: string, rawAliasInput: string) => {
    const newAliases = rawAliasInput
      .split(/[,\s،]+/)
      .map((s) => s.trim().replace(/^[!/]+/, ''))
      .filter(Boolean);
    if (newAliases.length === 0) return;

    sound.playSuccess();
    const updated = discordCommands.map((cmd) => {
      if (cmd.id !== commandId && cmd.name !== commandId) return cmd;
      const merged = Array.from(new Set([...cmd.aliases, ...newAliases]));
      return { ...cmd, aliases: merged };
    });
    syncCommandsToBackendImmediately(updated);
    setSaveBannerMessage(
      lang === 'ar'
        ? `✅ تم إضافة الاختصار (${newAliases.join(' ، ')}) للأمر وتفعيله فوراً في السيرفر!`
        : `✅ Alias (${newAliases.join(', ')}) added and synced to Discord!`
    );
    setTimeout(() => setSaveBannerMessage(null), 4000);
  };

  // Remove a specific alias from a command in src/App.tsx
  const handleRemoveCommandAlias = (commandId: string, aliasToRemove: string) => {
    sound.playClick();
    const updated = discordCommands.map((cmd) => {
      if (cmd.id !== commandId && cmd.name !== commandId) return cmd;
      return {
        ...cmd,
        aliases: cmd.aliases.filter((a) => a !== aliasToRemove)
      };
    });
    syncCommandsToBackendImmediately(updated);
  };

  if (showTokenGate || !hasValidAuthSession() || !connectedBot?.selectedGuild?.id) {
    const canShowAssistant = hasValidAuthSession();
    return (
      <>
        <TokenAuthGate
          lang={lang}
          setLang={setLang}
          initialStep={hasValidAuthSession() ? tokenGateInitialStep : 'landing'}
          currentBot={connectedBot}
          onOAuthLoginSuccess={(user, guilds, token) => {
            const verifiedOwner = isOfficialBotOwnerUser(user);
            if (token && user) {
              saveAuthSessionToStorage(token, user as AuthenticatedDiscordUser, guilds);
            }
            setConnectedBot((prev) => ({
              ...(prev || {
                username: 'M7R',
                tag: 'M7R#1624',
                id: '1564565916216336494',
                avatar: '',
                membersCount: 0,
                channelsCount: 0,
                ping: 17,
                mode: 'live'
              }),
              guilds,
              guildsCount: guilds.length,
              selectedGuild: undefined,
              accessMode: verifiedOwner ? 'bot_owner' : 'server_admin',
              discordUser: user as AuthenticatedDiscordUser
            }));
            setAccessMode(verifiedOwner ? 'bot_owner' : 'server_admin');
            setTokenGateInitialStep('select_server');
            setShowTokenGate(true);
          }}
          onAuthenticated={(info, _token, oauthUser) => {
            if (!info?.selectedGuild?.id) return;
            const resolvedOwner = isOfficialBotOwnerUser(oauthUser || info.discordUser);
            setConnectedBot(info);
            setAccessMode(resolvedOwner ? 'bot_owner' : 'server_admin');
            invalidateChannelsCache();
            localStorage.setItem('m7r_selected_guild', JSON.stringify(info.selectedGuild));
            localStorage.setItem('m7r_selected_guild_id', info.selectedGuild.id);
            activeGuildIdRef.current = info.selectedGuild.id;
            setShowTokenGate(false);
            handleSelectGuild(info.selectedGuild, { silent: true }).catch(() => {});
          }}
          onConnected={(info) => {
            if (!info?.selectedGuild?.id) return;
            setConnectedBot(info);
            const resolvedOwner = isOfficialBotOwnerUser(info.discordUser || getSavedDiscordUser());
            setAccessMode(resolvedOwner ? 'bot_owner' : 'server_admin');
            setBasicSettingsState((prev) => ({
              ...prev,
              botUsername: info.username || 'M7R'
            }));
            invalidateChannelsCache();
            localStorage.setItem('m7r_selected_guild', JSON.stringify(info.selectedGuild));
            localStorage.setItem('m7r_selected_guild_id', info.selectedGuild.id);
            activeGuildIdRef.current = info.selectedGuild.id;
            setShowTokenGate(false);
            handleSelectGuild(info.selectedGuild, { silent: true }).catch(() => {});
          }}
        />
        {canShowAssistant && (
          <FloatingWebAiAssistant
            lang={lang}
            onNavigateTab={(tabId: string) => {
              if (!connectedBot?.selectedGuild?.id) return;
              setShowTokenGate(false);
              setActiveTab(tabId);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#05070c] text-slate-100 flex flex-col selection:bg-[#00f0ff]/25 selection:text-[#00f0ff] m7r-ambient-canvas">
      {/* Top Workspace Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        panicMode={panicMode}
        onTogglePanicMode={handleTogglePanicMode}
        lang={lang}
        setLang={setLang}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        botInfo={connectedBot}
        onOpenTokenGate={handleDirectDiscordOAuthLogin}
        onSelectGuild={handleSelectGuild}
        accessMode={accessMode}
        onToggleAccessMode={handleToggleAccessMode}
        notifications={guildNotifications}
        unreadCount={unreadNotificationsCount}
        onMarkNotificationsRead={handleMarkNotificationsRead}
        onSimulateServerJoin={handleSimulateServerJoin}
        onLogout={handleLogout}
        onTriggerRefresh={handleMasterRefresh}
        externalMenuOpen={sidebarMenuOpen}
        onExternalMenuOpenChange={setSidebarMenuOpen}
      />

      {/* SaaS Workspace Canvas: Persistent Sidebar + Main Viewport */}
      <div className="flex flex-1 min-h-0">
        <DashboardSidebar
          lang={lang}
          botInfo={connectedBot}
          mobileOpen={sidebarMenuOpen}
          onCloseMobile={() => setSidebarMenuOpen(false)}
          onNavigateComplete={(tabId) => setActiveTab(tabId)}
        />

        <div className="flex-1 min-w-0 flex flex-col">
          {/* Flat Hairline Active Server Context & Guild Switcher Strip */}
          <div className="border-b border-[#00f0ff]/15 bg-[#0b101b]/80 backdrop-blur-xl px-4 sm:px-6 lg:px-8 py-3">
            <div className="max-w-6xl mx-auto space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div className="flex items-start sm:items-center gap-2.5 min-w-0">
                  {accessMode === 'server_admin' ? (
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5 sm:mt-0" />
                  ) : (
                    <Crown className="w-4 h-4 text-amber-400 shrink-0 mt-0.5 sm:mt-0" />
                  )}
                  <div className="min-w-0 text-xs">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-slate-200">
                      <span className="font-semibold text-white">
                        {accessMode === 'server_admin'
                          ? lang === 'ar'
                            ? `صلاحية التحكم في السيرفر (${connectedBot?.selectedGuild?.name || 'السيرفر الحالي'})`
                            : `Server Control Mode (${connectedBot?.selectedGuild?.name || 'Current Server'})`
                          : lang === 'ar'
                          ? 'وضع مالك البوت الكامل'
                          : 'Full Bot Owner Mode'}
                      </span>
                      {isOfficialOwnerLoggedIn && (
                        <>
                          <span aria-hidden="true" className="text-slate-600">·</span>
                          <span className="font-mono tabular-nums text-[11px] text-slate-400">
                            {connectedBot?.discordUser?.username} ({OFFICIAL_OWNER_ID})
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setTokenGateInitialStep('select_server');
                      setShowTokenGate(true);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-[#05070c] hover:bg-[#101829] border border-[#00f0ff]/30 text-[#00f0ff] text-xs font-bold cursor-pointer transition-colors whitespace-nowrap shrink-0"
                  >
                    {lang === 'ar' ? '🔄 تبديل السيرفر / قائمة السيرفرات' : '🔄 Switch Server / Servers Hub'}
                  </button>

                  {isOfficialOwnerLoggedIn && (
                    <>
                      <button
                        type="button"
                        onClick={handleSimulateServerJoin}
                        className="px-3 py-1.5 rounded-lg bg-[#0d121d] hover:bg-slate-800 border border-slate-800 text-emerald-300 text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors whitespace-nowrap shrink-0"
                      >
                        <Bell className="w-3.5 h-3.5 shrink-0" />
                        <span>{lang === 'ar' ? 'اختبار إشعار سيرفر' : 'Test Join Alert'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          handleToggleAccessMode(
                            accessMode === 'server_admin' ? 'bot_owner' : 'server_admin'
                          )
                        }
                        className="px-3 py-1.5 rounded-lg bg-[#0d121d] hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-medium cursor-pointer transition-colors whitespace-nowrap shrink-0"
                      >
                        {accessMode === 'server_admin'
                          ? lang === 'ar'
                            ? 'التبديل لوضع المالك'
                            : 'Switch to Owner'
                          : lang === 'ar'
                          ? 'معاينة وضع الإدارة'
                          : 'Preview Server Mode'}
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Manage Server Guilds Selector Row (Strictly Authenticated User Guilds Only) */}
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] font-medium text-slate-400 me-1.5">
                  {lang === 'ar' ? 'سيرفراتك:' : 'Guilds:'}
                </span>
                {(connectedBot?.guilds || []).map((g) => {
                  const isSelected = connectedBot?.selectedGuild?.id === g.id;
                  const isPresent = g.hasBot !== false && g.botPresent !== false;
                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        if (isPresent) {
                          handleSelectGuild(g);
                        } else {
                          const cid = connectedBot?.id || '1564565916216336494';
                          const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${encodeURIComponent(
                            cid
                          )}&permissions=8&integration_type=0&scope=bot+applications.commands&guild_id=${encodeURIComponent(
                            g.id
                          )}&disable_guild_select=true`;
                          window.open(inviteUrl, '_blank', 'noopener,noreferrer');
                        }
                      }}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                        isSelected && isPresent
                          ? 'bg-indigo-600 text-white border border-indigo-500'
                          : isPresent
                          ? 'bg-[#0d121d] hover:bg-slate-800 text-slate-300 border border-slate-800'
                          : 'bg-slate-900/70 hover:bg-slate-800 text-sky-300 border border-slate-800'
                      }`}
                    >
                      {g.icon ? (
                        <img
                          src={g.icon}
                          alt={g.name}
                          className="w-4 h-4 rounded-full object-cover shrink-0"
                        />
                      ) : (
                        <span className="w-4 h-4 rounded-full bg-slate-800 text-[10px] flex items-center justify-center font-semibold shrink-0">
                          {g.name.slice(0, 1)}
                        </span>
                      )}
                      <span className="truncate max-w-[140px]">{g.name}</span>
                      {isPresent ? (
                        <span className="text-[11px] font-mono tabular-nums opacity-80">
                          {g.memberCount || 0}
                        </span>
                      ) : (
                        <span className="text-[11px] font-medium text-sky-300">
                          {lang === 'ar' ? '+ إضافة البوت' : '+ Invite Bot'}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Save & Status Toast Banner */}
          {saveBannerMessage && (
            <div className="max-w-6xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-4">
              <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-700/60 text-emerald-200 text-xs font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{saveBannerMessage}</span>
              </div>
            </div>
          )}

          {/* Main Routed Content Area with Smooth Keyed Compositor Transition */}
          <main className="flex-1 w-full max-w-6xl mx-auto p-4 sm:p-6 lg:p-8 pb-24">
            <div key={activeTab} className="m7r-route-enter space-y-8">
              {activeTab === 'overview' && (
                <div className="space-y-10">
                  <HeroLandingSection
                    lang={lang}
                    isAuthenticated={true}
                    selectedGuild={connectedBot?.selectedGuild || null}
                    onOpenServerSelectorHub={() => {
                      setTokenGateInitialStep('select_server');
                      setShowTokenGate(true);
                    }}
                    onOpenDashboardTab={(tabId: string) => {
                      setActiveTab(tabId);
                    }}
                    onOpenSidebarMenu={() => setSidebarMenuOpen(true)}
                    ping={connectedBot?.ping || 14}
                  />
                  <OverviewTab
                    lang={lang}
                    panicMode={panicMode}
                    onSimulateAttack={handleSimulateAttack}
                    threatLogs={threatLogs}
                    attacksThwarted={attacksThwarted}
                    botInfo={connectedBot}
                    onNavigateTab={setActiveTab}
                  />
                </div>
              )}

              {activeTab === 'analytics' && (
                <div className="space-y-8">
                  <OverviewTab
                    lang={lang}
                    panicMode={panicMode}
                    onSimulateAttack={handleSimulateAttack}
                    threatLogs={threatLogs}
                    attacksThwarted={attacksThwarted}
                    botInfo={connectedBot}
                    onNavigateTab={setActiveTab}
                  />
                  <LogVisualizerTab
                    lang={lang}
                    threatLogs={threatLogs}
                    attacksThwarted={attacksThwarted}
                  />
                </div>
              )}

              {activeTab === 'aichat' && <AiChatbotTab lang={lang} />}

              {activeTab === 'basics' && (
                <div className="space-y-8">
                  <BasicBotSettingsTab
                    lang={lang}
                    settings={basicSettings}
                    onChangeSettings={setBasicSettings}
                    botInfo={connectedBot}
                    onSelectGuild={handleSelectGuild}
                  />
                  <AiChatbotTab lang={lang} />
                </div>
              )}

              {activeTab === 'commands' && (
                <CommandsManagerTab
                  lang={lang}
                  prefix={basicSettings.prefix}
                  commands={visibleCommands}
                  onChangeCommands={handleUpdateVisibleCommands}
                  onAddAlias={handleAddCommandAlias}
                  onRemoveAlias={handleRemoveCommandAlias}
                  onSave={handleSaveSettings}
                />
              )}

              {activeTab === 'welcome' && (
                <WelcomeTab
                  lang={lang}
                  welcomeConfig={welcomeConfig}
                  onChangeWelcomeConfig={setWelcomeConfig}
                  onSave={handleSaveSettings}
                  serverName={connectedBot?.selectedGuild?.name || 'M7R Server'}
                  guildId={connectedBot?.selectedGuild?.id}
                />
              )}

              {activeTab === 'tickets' && (
                <TicketsTab
                  lang={lang}
                  tickets={tickets}
                  onTicketAction={handleTicketAction}
                  onCreateSimulatedTicket={handleCreateSimulatedTicket}
                  panelConfig={ticketPanel}
                  onChangePanelConfig={setTicketPanel}
                  guildId={connectedBot?.selectedGuild?.id}
                />
              )}

              {activeTab === 'antinuke' && (
                <AntiNukeTab
                  lang={lang}
                  antiNuke={antiNuke}
                  setAntiNuke={setAntiNuke}
                  antiSpam={antiSpam}
                  setAntiSpam={setAntiSpam}
                  antiInvite={antiInvite}
                  setAntiInvite={setAntiInvite}
                  honeypotTrap={honeypotTrap}
                  setHoneypotTrap={setHoneypotTrap}
                  onSaveSettings={handleSaveSettings}
                  guildRoles={guildLiveRoles}
                  onTestThreatSimulated={(log) => handleIncomingSecurityThreat(log)}
                />
              )}

              {activeTab === 'azkar' && (
                <AzkarTab
                  lang={lang}
                  azkarConfig={azkarConfig}
                  onChangeAzkarConfig={setAzkarConfig}
                  onSave={handleSaveSettings}
                />
              )}

              {activeTab === 'roles_stats' && (
                <ReactionRolesStatsTab
                  lang={lang}
                  reactionRolesConfig={reactionRolesConfig}
                  setReactionRolesConfig={setReactionRolesConfig}
                  onSaveReactionRoles={handleSaveReactionRoles}
                  onDeployReactionRoles={handleDeployReactionRoles}
                  isSavingReactionRoles={isSavingReactionRoles}
                  isDeployingReactionRoles={isDeployingReactionRoles}
                  liveStatsConfig={liveStatsConfig}
                  setLiveStatsConfig={setLiveStatsConfig}
                  onSaveLiveStats={handleSaveLiveStats}
                  onDeployLiveStats={handleDeployLiveStats}
                  isSavingLiveStats={isSavingLiveStats}
                  isDeployingLiveStats={isDeployingLiveStats}
                  guildChannels={guildLiveChannels}
                  guildRoles={guildLiveRoles}
                  memberCount={connectedBot?.selectedGuild?.memberCount || connectedBot?.membersCount || 1450}
                />
              )}

              {(activeTab === 'extras' || activeTab === 'quran') && (
                <ExtraSystemsTab
                  lang={lang}
                  autoResponses={autoResponses}
                  setAutoResponses={setAutoResponses}
                  voice247={voice247}
                  setVoice247={setVoice247}
                  onSave={handleSaveSettings}
                  quranOnly={activeTab === 'quran'}
                />
              )}

              {activeTab === 'tempvoice' && <TempVoiceTab lang={lang} />}

              {activeTab === 'games' && <GamesEventsTab lang={lang} />}

              {(activeTab === 'wizard' || activeTab === 'creator_hub') && (
                <SetupWizardCreatorHubTab
                  lang={lang}
                  initialSection={activeTab === 'creator_hub' ? 'creator_hub' : 'wizard'}
                  guildId={connectedBot?.selectedGuild?.id || 'default'}
                  serverName={connectedBot?.selectedGuild?.name || 'M7R Server'}
                  isOwner={isOfficialOwnerLoggedIn}
                />
              )}

              {activeTab === 'staff_apps' && (
                <StaffApplicationsTab
                  lang={lang}
                  guildRoles={guildLiveRoles}
                  serverName={connectedBot?.selectedGuild?.name || 'M7R Server'}
                  guildId={connectedBot?.selectedGuild?.id || 'default'}
                />
              )}

              {(activeTab === 'audit_logs' || activeTab === 'staff_warnings') && (
                <AuditLogsStaffWarningsTab
                  lang={lang}
                  initialSection={activeTab === 'staff_warnings' ? 'staff_warnings' : 'audit_logs'}
                  guildId={connectedBot?.selectedGuild?.id || 'default'}
                  serverName={connectedBot?.selectedGuild?.name || 'M7R Server'}
                />
              )}

              {activeTab === 'logsvisualizer' && (
                <LogVisualizerTab
                  lang={lang}
                  threatLogs={threatLogs}
                  attacksThwarted={attacksThwarted}
                />
              )}

              {activeTab === 'backup' && (
                <DatabaseBackupTab
                  lang={lang}
                  currentConfig={{
                    basicSettings,
                    welcome: welcomeConfig,
                    ticketPanel,
                    commands: discordCommands,
                    antiNuke,
                    antiSpam,
                    antiInvite,
                    voice247,
                    autoResp: autoResponses,
                    azkar: azkarConfig,
                    trap: honeypotTrap,
                    reactionRoles: reactionRolesConfig,
                    liveStats: liveStatsConfig
                  }}
                  onRestoreBackup={async (restored) => {
                    if (restored.basicSettings) setBasicSettingsState(restored.basicSettings);
                    if (restored.welcome) setWelcomeConfigState(restored.welcome);
                    if (restored.ticketPanel) setTicketPanelState(restored.ticketPanel);
                    if (Array.isArray(restored.commands)) setDiscordCommandsState(restored.commands);
                    if (restored.antiNuke) setAntiNukeState(restored.antiNuke);
                    if (restored.antiSpam) setAntiSpamState(restored.antiSpam);
                    if (restored.antiInvite) setAntiInviteState(restored.antiInvite);
                    if (restored.voice247) setVoice247State(restored.voice247);
                    if (Array.isArray(restored.autoResp)) setAutoResponsesState(restored.autoResp);
                    if (restored.azkar) setAzkarConfigState(restored.azkar);
                    if (restored.trap) setHoneypotTrapState(restored.trap);
                    if (restored.reactionRoles) setReactionRolesConfigState(restored.reactionRoles);
                    if (restored.liveStats) setLiveStatsConfigState(restored.liveStats);

                    try {
                      await fetch('/api/settings', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(restored)
                      });
                    } catch {
                      // ignore
                    }
                  }}
                />
              )}

              {activeTab === 'prosuite' && <AdvancedSuiteTab lang={lang} />}

              {activeTab === 'replit' && <ReplitHubTab lang={lang} />}

              {(activeTab === 'ready_rooms' ||
                activeTab === 'suggestions' ||
                activeTab === 'server_builder') && (
                <ReadyRoomsAndSuggestionsTab
                  lang={lang}
                  view={activeTab === 'suggestions' ? 'suggestions' : 'ready_rooms'}
                  guildId={connectedBot?.selectedGuild?.id || 'default'}
                  serverName={connectedBot?.selectedGuild?.name || 'M7R Server'}
                  onNavigateToStaffApps={() => {
                    setActiveTab('staff_apps');
                  }}
                />
              )}

              {(activeTab === 'rules_builder' ||
                activeTab === 'levels_ranks' ||
                activeTab === 'auto_line' ||
                activeTab === 'embed_builder' ||
                activeTab === 'auto_emoji' ||
                activeTab === 'mass_dm') && (
                <M7RAutomationAndToolsTab
                  lang={lang}
                  view={activeTab}
                  guildRoles={guildLiveRoles}
                  serverName={connectedBot?.selectedGuild?.name || 'M7R Server'}
                />
              )}
            </div>
          </main>

          {/* Clean Footer without synthetic telemetry */}
          <footer className="border-t border-slate-800/80 bg-[#080b12] py-5 px-4 sm:px-6 lg:px-8 text-xs text-slate-400">
            <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-white">M7R</span>
                <span aria-hidden="true">·</span>
                <span>
                  {lang === 'ar'
                    ? 'إدارة وحماية سيرفرات ديسكورد'
                    : 'Discord Server Protection & Management'}
                </span>
              </div>

              <div className="flex items-center gap-4">
                <HashLink
                  to="replit"
                  onNavigate={() => sound.playClick()}
                  className="hover:text-white transition-colors"
                >
                  {lang === 'ar' ? 'تشغيل على Replit' : 'Deploy on Replit'}
                </HashLink>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <HashLink
                  to="wizard"
                  onNavigate={() => sound.playClick()}
                  className="hover:text-white transition-colors"
                >
                  {lang === 'ar' ? 'فحص الجهوزية' : 'Diagnostics'}
                </HashLink>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <HashLink
                  to="antinuke"
                  onNavigate={() => sound.playClick()}
                  className="hover:text-white transition-colors"
                >
                  {lang === 'ar' ? 'إعدادات الحماية' : 'Protection'}
                </HashLink>
              </div>
            </div>
          </footer>
        </div>
      </div>

      {/* Floating Unsaved Changes Action Bar */}
      {hasUnsavedChanges && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 w-[94%] max-w-3xl rounded-xl bg-[#0d121d]/95 backdrop-blur-md border border-slate-700 p-3.5 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-xs font-medium text-white">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
            <span>
              {lang === 'ar'
                ? 'لديك تعديلات غير محفوظة — احفظ التغييرات لمزامنتها مع البوت في ديسكورد.'
                : 'You have unsaved changes — save to sync with your Discord bot.'}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setHasUnsavedChanges(false);
              }}
              className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'تراجع' : 'Reset'}</span>
            </button>

            <button
              type="button"
              onClick={handleSaveSettings}
              disabled={isSaving}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors whitespace-nowrap"
            >
              <Save className="w-4 h-4" />
              <span>
                {isSaving
                  ? lang === 'ar'
                    ? 'جاري الحفظ...'
                    : 'Saving...'
                  : lang === 'ar'
                  ? 'حفظ التغييرات'
                  : 'Save Changes'}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Floating Web-Exclusive AI Assistant Widget */}
      <FloatingWebAiAssistant
        lang={lang}
        onNavigateTab={(tabId: string) => {
          setActiveTab(tabId);
        }}
      />
    </div>
  );
}
