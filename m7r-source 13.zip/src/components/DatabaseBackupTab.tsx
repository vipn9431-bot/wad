import React, { useState, useRef } from 'react';
import {
  Database,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  FileJson,
  RefreshCw,
  HardDrive,
  ShieldCheck,
  Sparkles,
  Copy,
  Check
} from 'lucide-react';
import { sound } from '../utils/sound';

interface DatabaseBackupTabProps {
  lang: 'ar' | 'en';
  currentConfig: Record<string, any>;
  onRestoreBackup: (backupData: Record<string, any>) => Promise<void>;
}

export const DatabaseBackupTab: React.FC<DatabaseBackupTabProps> = ({
  lang,
  currentConfig,
  onRestoreBackup
}) => {
  const isAr = lang === 'ar';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [restoring, setRestoring] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);
  const [previewJson, setPreviewJson] = useState<string | null>(null);

  const generateBackupPayload = () => {
    return {
      version: '2.7.0',
      exportedAt: new Date().toISOString(),
      botOwner: 'u5r9',
      dashboardUrl: 'https://bot-m7r.netlify.app/',
      data: currentConfig
    };
  };

  const handleExportJson = () => {
    sound.playShieldActivate();
    const payload = generateBackupPayload();
    const jsonString = JSON.stringify(payload, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    const dateStamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `m7r-bot-backup-${dateStamp}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setStatusMsg({
      type: 'success',
      text: isAr
        ? '✅ تم تصدير وتحميل نسخة احتياطية كاملة للإعدادات بصيغة JSON بنجاح!'
        : '✅ Full bot configuration exported as JSON file successfully!'
    });
    setTimeout(() => setStatusMsg(null), 5000);
  };

  const handleCopyJson = () => {
    sound.playClick();
    const payload = generateBackupPayload();
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 3000);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    sound.playClick();
    setRestoring(true);
    setStatusMsg(null);

    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const configToRestore = parsed.data || parsed;

      if (typeof configToRestore !== 'object' || configToRestore === null) {
        throw new Error('Invalid JSON structure');
      }

      setPreviewJson(JSON.stringify(parsed, null, 2).slice(0, 600) + '\n...');
      await onRestoreBackup(configToRestore);
      sound.playShieldActivate();

      setStatusMsg({
        type: 'success',
        text: isAr
          ? `🎉 تمت استعادة النسخة الاحتياطية من الملف (${file.name}) وتطبيق جميع الإعدادات على البوت فوراً!`
          : `🎉 Successfully restored configuration from (${file.name}) and synced with the bot!`
      });
    } catch {
      setStatusMsg({
        type: 'error',
        text: isAr
          ? '❌ الملف المرفوع غير صالح! يرجى التأكد من رفع ملف نسخة احتياطية بصيغة JSON صحيح.'
          : '❌ Invalid backup file! Please upload a valid M7R JSON configuration file.'
      });
    } finally {
      setRestoring(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="rounded-3xl border border-indigo-500/30 bg-gradient-to-r from-[#111526] via-[#0d101b] to-[#131124] p-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-black text-white">
                  {isAr ? 'النسخ الاحتياطي واستعادة الإعدادات (Database Backup)' : 'Database Backup & Restore'}
                </h2>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'قم بتصدير إعدادات البوت كملف JSON للاحتفاظ بها، أو ارفع نسخة احتياطية سابقة لاستعادة كل الأنظمة بضغطة زر.'
                    : 'Export your current bot configuration as a JSON file or upload a previous backup to restore settings.'}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportJson}
              className="px-5 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black flex items-center gap-2 shadow-lg shadow-indigo-950/60 cursor-pointer transition-all"
            >
              <Download className="w-4 h-4" />
              <span>{isAr ? 'تصدير الإعدادات (Export JSON)' : 'Export Backup (JSON)'}</span>
            </button>
          </div>
        </div>
      </div>

      {statusMsg && (
        <div
          className={`p-4 rounded-2xl border text-xs font-bold flex items-center gap-2.5 shadow-lg ${
            statusMsg.type === 'success'
              ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-200'
              : 'bg-rose-950/70 border-rose-500/50 text-rose-200'
          }`}
        >
          {statusMsg.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
          )}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Main Grid: Export Card & Import/Restore Card */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card 1: Export Configuration */}
        <div className="rounded-3xl border border-slate-800 bg-[#0d1017] p-6 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">
                    {isAr ? 'تصدير نسخة احتياطية كاملة (Export JSON)' : 'Export Current Configuration'}
                  </h3>
                  <span className="text-[11px] text-slate-400">
                    {isAr ? 'حفظ جميع إعدادات السيرفر والأوامر في ملف خارجي' : 'Save all bot settings & rules into a portable JSON file'}
                  </span>
                </div>
              </div>
              <span className="text-xs font-mono text-emerald-400">JSON v2.7</span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-2 text-xs text-slate-300">
              <div className="font-bold text-white flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>{isAr ? 'ما الذي يتم حفظه داخل النسخة الاحتياطية؟' : 'What is included in the backup?'}</span>
              </div>
              <ul className="space-y-1 text-[11px] text-slate-400 list-disc list-inside">
                <li>{isAr ? 'إعدادات البوت الأساسية، البادئة (Prefix)، وحالة البوت' : 'Basic Bot Settings, Prefix & Presence Status'}</li>
                <li>{isAr ? 'إعدادات المصيدة (Kick / Ban / Timeout) ودرع الحماية' : 'Honeypot Trap (Kick / Ban / Timeout) & Anti-Nuke Shield'}</li>
                <li>{isAr ? 'جميع أوامر الديسكورد والردود التلقائية المخصصة' : 'All Custom Commands & Auto-Responses'}</li>
                <li>{isAr ? 'بانل التذاكر، الترحيب، الرتب التفاعلية، وإذاعة القرآن المستمر' : 'Tickets Panel, Welcome Studio, Reaction Roles & Quran المستمر'}</li>
              </ul>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 pt-2">
            <button
              type="button"
              onClick={handleExportJson}
              className="flex-1 py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 cursor-pointer transition-all"
            >
              <FileJson className="w-4 h-4" />
              <span>{isAr ? 'تحميل ملف النسخة الاحتياطية (.json)' : 'Download Backup File (.json)'}</span>
            </button>

            <button
              type="button"
              onClick={handleCopyJson}
              className="py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all"
            >
              {copiedJson ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-400" />}
              <span>{copiedJson ? (isAr ? 'تم النسخ!' : 'Copied!') : (isAr ? 'نسخ الكود' : 'Copy JSON')}</span>
            </button>
          </div>
        </div>

        {/* Card 2: Upload & Restore Backup */}
        <div className="rounded-3xl border border-slate-800 bg-[#0d1017] p-6 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                  <Upload className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">
                    {isAr ? 'رفع واستعادة نسخة سابقة (Restore Backup)' : 'Upload & Restore Backup'}
                  </h3>
                  <span className="text-[11px] text-slate-400">
                    {isAr ? 'ارفع ملف JSON محفوظ مسبقاً لاسترجاع إعداداتك فوراً' : 'Upload a previously exported JSON file to restore settings'}
                  </span>
                </div>
              </div>
              <HardDrive className="w-4 h-4 text-slate-500" />
            </div>

            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-700 hover:border-indigo-500/60 rounded-2xl p-6 text-center bg-slate-900/40 hover:bg-slate-900/80 transition-all cursor-pointer space-y-2"
            >
              <Upload className="w-8 h-8 text-indigo-400 mx-auto" />
              <div className="text-xs font-bold text-white">
                {isAr ? 'اضغط هنا لاختيار ملف النسخة الاحتياطية (.json)' : 'Click to select a JSON backup file'}
              </div>
              <p className="text-[11px] text-slate-400">
                {isAr
                  ? 'سيتم فحص الملف ومزامنة الإعدادات تلقائياً مع البوت في ديسكورد'
                  : 'Settings will be validated and synced live to your Discord bot'}
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>

            {previewJson && (
              <div className="p-3 rounded-xl bg-black/60 border border-slate-800 text-[10px] font-mono text-emerald-300 max-h-28 overflow-y-auto">
                {previewJson}
              </div>
            )}
          </div>

          <button
            type="button"
            disabled={restoring}
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-3 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-indigo-950/50 cursor-pointer transition-all disabled:opacity-50"
          >
            {restoring ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>
              {restoring
                ? isAr
                  ? 'جاري استعادة الإعدادات...'
                  : 'Restoring Backup...'
                : isAr
                ? 'رفع ملف النسخة الاحتياطية واستعادتها الآن 📂'
                : 'Upload & Restore JSON Backup 📂'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
