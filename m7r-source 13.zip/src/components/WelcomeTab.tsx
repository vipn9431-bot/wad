import React, { useState } from 'react';
import {
  UserPlus,
  Sparkles,
  Palette,
  Image as ImageIcon,
  ShieldCheck,
  Mail,
  UserMinus,
  SendHorizonal,
  CheckCircle2,
  Save,
  Eye,
  Zap,
  Hand,
  Link2
} from 'lucide-react';
import { WelcomeConfig } from '../types';
import { ChannelSelector } from './ChannelSelector';
import { getAuthHeaders } from './TokenAuthGate';
import { sound } from '../utils/sound';

interface WelcomeTabProps {
  lang: 'ar' | 'en';
  welcomeConfig: WelcomeConfig;
  onChangeWelcomeConfig: (updated: WelcomeConfig) => void;
  onSave: () => void;
  serverName?: string;
  guildId?: string;
}

const BANNER_PRESETS = [
  {
    label: '⚜️ بنر M7R البنفسجي الرسمي (Purple Winged Chrome)',
    url: '/assets/aistudio/IMG_3117_2cec6847.jpeg'
  },
  {
    label: '🔮 تدرج الكروم البنفسجي الملكي (Cosmic Purple)',
    url: '/api/welcome/card-preview?username=M7R_Member&server=M7R%20Empire&count=1285&theme=purple_chrome'
  },
  {
    label: 'بدون صورة إضافية',
    url: ''
  }
];

export const WelcomeTab: React.FC<WelcomeTabProps> = ({
  lang,
  welcomeConfig,
  onChangeWelcomeConfig,
  onSave,
  serverName = 'M7R Server',
  guildId
}) => {
  const isAr = lang === 'ar';
  const activeGuildId = (guildId || (typeof window !== 'undefined' ? localStorage.getItem('m7r_selected_guild_id') : '') || '').trim();
  const [testingWelcome, setTestingWelcome] = useState(false);
  const [quickSettingUp, setQuickSettingUp] = useState(false);
  const [testFeedback, setTestFeedback] = useState<string | null>(null);
  const [previewWelcomeCount, setPreviewWelcomeCount] = useState(4);

  const updateField = <K extends keyof WelcomeConfig>(key: K, value: WelcomeConfig[K]) => {
    onChangeWelcomeConfig({
      ...welcomeConfig,
      [key]: value
    });
  };

  const insertVariable = (
    field: 'welcomeMessage' | 'embedDescription' | 'dmMessage' | 'leaveMessage',
    variable: string
  ) => {
    sound.playClick();
    updateField(field, `${welcomeConfig[field] || ''} ${variable}`.trim());
  };

  const handleTestWelcomeInDiscord = async () => {
    setTestingWelcome(true);
    setTestFeedback(null);
    sound.playShieldActivate();
    try {
      const targetGId = activeGuildId || localStorage.getItem('m7r_selected_guild_id') || '';
      const res = await fetch('/api/welcome/test', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          guildId: targetGId,
          channelId: welcomeConfig.channelName,
          channelName: welcomeConfig.channelName,
          welcomeConfig
        })
      });
      const data = await res.json();
      setTestFeedback(
        data.message ||
          data.error ||
          (res.ok
            ? '✅ تم توليد بطاقة الترحيب وإرسال الترحيب التجريبي مع الأزرار التفاعلية إلى ديسكورد بنجاح!'
            : '❌ تعذر إرسال رسالة الترحيب إلى ديسكورد.')
      );
      setTimeout(() => setTestFeedback(null), 9000);
    } catch (err: any) {
      setTestFeedback(`❌ حدث خطأ أثناء إرسال تجربة الترحيب: ${err?.message || 'Error'}`);
    } finally {
      setTestingWelcome(false);
    }
  };

  const handleQuickSetupWelcome = async () => {
    setQuickSettingUp(true);
    setTestFeedback(null);
    sound.playShieldActivate();
    try {
      const targetGId = activeGuildId || localStorage.getItem('m7r_selected_guild_id') || '';
      const res = await fetch('/api/quick-setup/welcome', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ guildId: targetGId, welcomeConfig })
      });
      const data = await res.json();
      if (data?.welcomeConfig) {
        onChangeWelcomeConfig(data.welcomeConfig);
      }
      setTestFeedback(
        data?.message ||
          '⚡ تم الإعداد السريع لنظام الترحيب الملكي! تم إنشاء/تجهيز روم #welcome وإرسال بطاقة الترحيب المصورة (1024x450)!'
      );
      setTimeout(() => setTestFeedback(null), 6000);
    } catch {
      setTestFeedback('تعذر تنفيذ الإعداد السريع للترحيب.');
    } finally {
      setQuickSettingUp(false);
    }
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        updateField('bannerUrl', reader.result);
        sound.playShieldActivate();
      }
    };
    reader.readAsDataURL(file);
  };

  const formatPreview = (raw: string) => {
    return (raw || '')
      .replace(/\{user\}/g, '@M7R_Member')
      .replace(/\{username\}/g, 'M7R_Member')
      .replace(/\{server\}/g, serverName)
      .replace(/\{count\}/g, '1,285')
      .replace(/\{id\}/g, '1219299588402577532');
  };

  const activeNeonBorder = welcomeConfig.neonBorderColor || '#9D4EDD';
  const activeHeadline = welcomeConfig.cardHeadline || '✦ WELCOME TO THE EMPIRE ✦';
  const cardPreviewUrl = `/api/welcome/card-preview?username=M7R_Member&server=${encodeURIComponent(
    serverName
  )}&count=1285&theme=${welcomeConfig.vipCardTheme || 'purple_chrome'}&neon=${encodeURIComponent(
    activeNeonBorder
  )}&headline=${encodeURIComponent(activeHeadline)}`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-3 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <UserPlus className="w-6 h-6 text-purple-400" />
            {isAr
              ? '🎨 استوديو تصميم الترحيب الملكي (Ultra VIP Welcome Design & Studio)'
              : '🎨 Ultra VIP Welcome Design & Studio'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {isAr
              ? 'توليد بطاقة ترحيب جرافيكية (1024x450) بثيم الكروم البنفسجي، حلقة افتار مضيئة، إيمبد تفاعلي، وزر (👋 رحبوا فيه!)'
              : 'Generate 1024x450 M7R Purple Chrome welcome cards, glowing avatar ring, interactive embeds, and Say Welcome buttons'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleQuickSetupWelcome}
            disabled={quickSettingUp}
            className="px-3.5 py-2.5 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-black rounded-xl flex items-center gap-1.5 cursor-pointer transition-all whitespace-nowrap"
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <span>
              {quickSettingUp
                ? isAr
                  ? 'جاري التجهيز...'
                  : 'Setting up...'
                : isAr
                ? '⚡ إعداد سريع بضغطة زر'
                : '⚡ 1-Click Quick Setup'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleTestWelcomeInDiscord}
            disabled={testingWelcome}
            className="px-4 py-2.5 bg-purple-600/25 hover:bg-purple-600/35 border border-purple-500/50 text-purple-200 text-xs font-black rounded-xl flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap"
          >
            <SendHorizonal className="w-4 h-4 text-purple-300" />
            <span>
              {testingWelcome
                ? isAr
                  ? 'جاري الإرسال للديسكورد...'
                  : 'Sending...'
                : isAr
                ? '🧪 إرسال ترحيب تجريبي الآن'
                : '🧪 Send Test Welcome to Discord'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              sound.playShieldActivate();
              onSave();
            }}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-950/50 cursor-pointer transition-all whitespace-nowrap"
          >
            <Save className="w-4 h-4" />
            <span>{isAr ? 'حفظ إعدادات الترحيب ✅' : 'Save Welcome Settings ✅'}</span>
          </button>
        </div>
      </div>

      {testFeedback && (
        <div className="p-3.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{testFeedback}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: All Welcome Studio Settings */}
        <div className="lg:col-span-7 space-y-5">
          {/* 1. Primary Welcome Toggle & Channel Selection */}
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {isAr ? 'تفعيل نظام الترحيب وتحديد روم الاستقبال' : 'Enable Welcome System & Select Channel'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {isAr
                      ? 'إرسال بطاقة الترحيب الجرافيكية والإيمبد التفاعلي فور انضمام أي عضو جديد'
                      : 'Automatically send custom graphic welcome card and interactive embed on member join'}
                  </p>
                </div>
              </div>

              <label className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-bold text-white cursor-pointer">
                <input
                  type="checkbox"
                  checked={welcomeConfig.enabled}
                  onChange={(e) => updateField('enabled', e.target.checked)}
                  className="w-4 h-4 accent-purple-600 rounded"
                />
                <span>{welcomeConfig.enabled ? (isAr ? 'مفعل 🟢' : 'Active 🟢') : (isAr ? 'معطل' : 'Disabled')}</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <ChannelSelector
                lang={lang}
                guildId={activeGuildId}
                label={isAr ? 'تحديد روم الترحيب (#welcome)' : 'Welcome Channel (#welcome)'}
                value={welcomeConfig.channelName}
                onChange={(ch) => updateField('channelName', ch)}
                placeholder="welcome"
                helperText={
                  isAr ? 'اختر الروم الذي سيرسل فيه البوت بطاقة الترحيب' : 'Channel where welcome messages are posted'
                }
              />

              <div>
                <label className="text-slate-300 font-semibold block mb-1.5">
                  {isAr ? 'نمط عرض رسالة الترحيب' : 'Welcome Display Mode'}
                </label>
                <select
                  value={welcomeConfig.messageMode || 'embed_and_text'}
                  onChange={(e) => updateField('messageMode', e.target.value as WelcomeConfig['messageMode'])}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg px-3 py-2 text-white focus:outline-none"
                >
                  <option value="embed_and_text">
                    {isAr ? '✨ بطاقة جرافيكية 1024x450 + إيمبد تفاعلي (مستحسن)' : 'Graphic Card + Interactive Embed'}
                  </option>
                  <option value="embed_only">{isAr ? '🖼️ بطاقة Embed فقط مع منشن العضو' : 'Rich Embed Card Only'}</option>
                  <option value="text_only">{isAr ? '💬 رسالة نصية عادية فقط بدون Embed' : 'Plain Text Message Only'}</option>
                </select>
              </div>
            </div>

            {/* Smart Variables Bar */}
            <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800/90 space-y-2 text-xs">
              <span className="font-bold text-purple-400 block">
                {isAr
                  ? '💡 المتغيرات الذكية (اضغط لإضافتها في نص الترحيب):'
                  : '💡 Smart Variables (Click to insert):'}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { code: '{user}', desc: isAr ? 'منشن العضو' : 'Mention User' },
                  { code: '{username}', desc: isAr ? 'اسم العضو' : 'Username' },
                  { code: '{server}', desc: isAr ? 'اسم السيرفر' : 'Server Name' },
                  { code: '{count}', desc: isAr ? 'رقم العضو (#Count)' : 'Member Count' },
                  { code: '{id}', desc: isAr ? 'آيدي العضو' : 'User ID' }
                ].map((v) => (
                  <button
                    key={v.code}
                    type="button"
                    onClick={() => insertVariable('embedDescription', v.code)}
                    className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-purple-500/20 border border-slate-800 hover:border-purple-500/40 text-slate-200 text-[11px] font-mono flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <span className="text-purple-400 font-bold">{v.code}</span>
                    <span className="text-slate-400 font-sans">({v.desc})</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="text-xs">
              <label className="text-slate-300 font-semibold block mb-1">
                {isAr ? 'الرسالة النصية أعلى بطاقة الترحيب (Text Message)' : 'Top Text Greeting Message'}
              </label>
              <input
                type="text"
                value={welcomeConfig.welcomeMessage}
                onChange={(e) => updateField('welcomeMessage', e.target.value)}
                placeholder="✨ يا هلا ومليون غلا بك يا {user} في {server}!"
                className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg p-2.5 text-white focus:outline-none"
              />
            </div>
          </div>

          {/* 2. Ultra VIP 1024x450 Graphic Banner Studio */}
          <div className="rounded-xl border border-purple-500/40 bg-[#0d1017] p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Palette className="w-4 h-4 text-purple-400" />
                  <span>
                    {isAr
                      ? '🎨 تصميم بطاقة الترحيب الجرافيكية (1024x450 M7R Purple Chrome GFX)'
                      : '🎨 1024x450 M7R Purple Chrome Graphic Card Studio'}
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  تدمج افتار العضو داخل حلقة نيون مزدوجة مع شعار M7R وترتيب العضو (#Count) بدقة عالية
                </p>
              </div>
              <input
                type="checkbox"
                checked={welcomeConfig.vipCardEnabled ?? true}
                onChange={(e) => updateField('vipCardEnabled', e.target.checked)}
                className="w-4 h-4 accent-purple-600 rounded cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="sm:col-span-2">
                <label className="text-slate-300 font-semibold block mb-1">
                  العنوان العلوي داخل البطاقة (Top Chrome Header)
                </label>
                <input
                  type="text"
                  value={welcomeConfig.cardHeadline || '✦ WELCOME TO THE EMPIRE ✦'}
                  onChange={(e) => updateField('cardHeadline', e.target.value)}
                  placeholder="✦ WELCOME TO THE EMPIRE ✦"
                  className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg p-2 text-white font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">لون إطار النيون (Neon Border)</label>
                <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg p-1.5">
                  <input
                    type="color"
                    value={activeNeonBorder}
                    onChange={(e) => updateField('neonBorderColor', e.target.value)}
                    className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                  />
                  <span className="font-mono text-[11px] text-slate-200">{activeNeonBorder}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {[
                { id: 'purple_chrome', label: isAr ? '🔮 بنفسجي كروم ملكي (Purple Chrome)' : '🔮 Purple Chrome' },
                { id: 'obsidian_gold', label: isAr ? '👑 أسود وذهبي فاخر (Obsidian Gold)' : '👑 Obsidian Gold' },
                { id: 'cyber_emerald', label: isAr ? '🟢 زمردي سايبر (Cyber Emerald)' : '🟢 Cyber Emerald' }
              ].map((th) => (
                <button
                  key={th.id}
                  type="button"
                  onClick={() => updateField('vipCardTheme', th.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-bold border cursor-pointer transition-all ${
                    (welcomeConfig.vipCardTheme || 'purple_chrome') === th.id
                      ? 'bg-purple-600/30 border-purple-400 text-white shadow-md'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {th.label}
                </button>
              ))}
            </div>

            {/* Live 1024x450 Graphic Banner Preview */}
            <div className="rounded-xl overflow-hidden border border-purple-500/50 bg-[#070510] shadow-xl">
              <img
                src={cardPreviewUrl}
                alt="1024x450 VIP Welcome Card Live Preview"
                referrerPolicy="no-referrer"
                className="w-full h-auto block"
              />
            </div>
          </div>

          {/* 3. Embed Content & Interactive Welcome Buttons */}
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Hand className="w-4 h-4 text-purple-400" />
              {isAr
                ? 'تخصيص بطاقة الـ Embed والأزرار التفاعلية أسفل الترحيب'
                : 'Welcome Embed & Interactive Buttons'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div className="sm:col-span-3">
                <label className="text-slate-300 font-semibold block mb-1">
                  {isAr ? 'عنوان بطاقة الترحيب (Embed Title)' : 'Embed Title'}
                </label>
                <input
                  type="text"
                  value={welcomeConfig.embedTitle}
                  onChange={(e) => updateField('embedTitle', e.target.value)}
                  placeholder="✦ أهلاً بك في إمبراطورية {server} ✦"
                  className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg p-2 text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  {isAr ? 'لون الـ Embed' : 'Embed Color'}
                </label>
                <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg p-1.5">
                  <input
                    type="color"
                    value={welcomeConfig.embedColor || '#8A2BE2'}
                    onChange={(e) => updateField('embedColor', e.target.value)}
                    className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                  />
                  <span className="font-mono text-[11px] text-slate-300">{welcomeConfig.embedColor || '#8A2BE2'}</span>
                </div>
              </div>
            </div>

            <div className="text-xs">
              <label className="text-slate-300 font-semibold block mb-1">
                {isAr ? 'وصف الترحيب داخل البطاقة (Embed Description)' : 'Embed Description'}
              </label>
              <textarea
                rows={3}
                value={welcomeConfig.embedDescription}
                onChange={(e) => updateField('embedDescription', e.target.value)}
                placeholder="✨ يا هلا ومليون غلا بك يا {user} في {server}!\n🔒 نورتنا بوجودك، أنت الآن العضو رقم #{count} في عائلتنا!"
                className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg p-2.5 text-white focus:outline-none"
              />
            </div>

            {/* Background Image URL / Upload */}
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <label className="text-slate-300 font-semibold flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5 text-purple-400" />
                  <span>{isAr ? 'خلفية / بنر إضافي (أو رفع صورة من جهازك)' : 'Custom Background / Banner URL'}</span>
                </label>
                <label className="px-2.5 py-1 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 text-[11px] font-bold cursor-pointer">
                  <span>📤 رفع صورة من الجهاز</span>
                  <input type="file" accept="image/*" onChange={handleBannerUpload} className="hidden" />
                </label>
              </div>
              <input
                type="text"
                value={welcomeConfig.bannerUrl}
                onChange={(e) => updateField('bannerUrl', e.target.value)}
                placeholder="/assets/aistudio/IMG_3117_2cec6847.jpeg"
                dir="ltr"
                className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg p-2 text-white font-mono focus:outline-none"
              />
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[11px] text-slate-400">{isAr ? 'قوالب جاهزة:' : 'Presets:'}</span>
                {BANNER_PRESETS.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      updateField('bannerUrl', preset.url);
                    }}
                    className="px-2.5 py-1 rounded-md bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 cursor-pointer transition-colors"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive Buttons & Quick Channel Shortcuts */}
            <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Link2 className="w-4 h-4 text-purple-400" />
                  <span>أزرار التفاعل والاختصارات السريعة أسفل رسالة الترحيب</span>
                </span>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={welcomeConfig.sayWelcomeEnabled ?? true}
                    onChange={(e) => updateField('sayWelcomeEnabled', e.target.checked)}
                    className="accent-purple-600 rounded"
                  />
                  <span className="text-purple-300 font-bold">تفعيل زر (👋 رحبوا فيه!)</span>
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <ChannelSelector
                  lang={lang}
                  guildId={activeGuildId}
                  compact={true}
                  label="روم القوانين (#rules)"
                  value={welcomeConfig.rulesChannelName || 'القوانين'}
                  onChange={(ch) => updateField('rulesChannelName', ch)}
                  placeholder="القوانين"
                />
                <ChannelSelector
                  lang={lang}
                  guildId={activeGuildId}
                  compact={true}
                  label="روم الرتب (#roles)"
                  value={welcomeConfig.rolesChannelName || 'الرتب'}
                  onChange={(ch) => updateField('rolesChannelName', ch)}
                  placeholder="الرتب"
                />
                <ChannelSelector
                  lang={lang}
                  guildId={activeGuildId}
                  compact={true}
                  label="روم التذاكر (#tickets)"
                  value={welcomeConfig.ticketChannelName || 'التذاكر'}
                  onChange={(ch) => updateField('ticketChannelName', ch)}
                  placeholder="التذاكر"
                />
              </div>
            </div>
          </div>

          {/* 4. Auto-Role on Join */}
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {isAr ? 'الرتبة التلقائية عند دخول العضو (Auto-Role on Join)' : 'Auto-Role on Member Join'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {isAr
                      ? 'منح رتبة تلقائياً لكل عضو جديد يدخل السيرفر فور انضمامه'
                      : 'Automatically assign a role to new members when they join'}
                  </p>
                </div>
              </div>

              <input
                type="checkbox"
                checked={welcomeConfig.autoRoleEnabled}
                onChange={(e) => updateField('autoRoleEnabled', e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  {isAr ? 'اسم رتبة الأعضاء الجدد (Member Auto-Role)' : 'Member Auto-Role Name'}
                </label>
                <input
                  type="text"
                  value={welcomeConfig.autoRoleName}
                  onChange={(e) => updateField('autoRoleName', e.target.value)}
                  placeholder="Member"
                  className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-lg p-2 text-white font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  {isAr ? 'اسم رتبة البوتات عند إضافتها (Bot Auto-Role)' : 'Bot Auto-Role Name'}
                </label>
                <input
                  type="text"
                  value={welcomeConfig.botAutoRoleName}
                  onChange={(e) => updateField('botAutoRoleName', e.target.value)}
                  placeholder="Bots"
                  className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-lg p-2 text-white font-mono focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* 5. DM Welcome & Leave/Goodbye System */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-4 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-purple-400" />
                  {isAr ? 'ترحيب في خاص العضو (DM)' : 'DM Welcome Message'}
                </span>
                <input
                  type="checkbox"
                  checked={welcomeConfig.sendDm}
                  onChange={(e) => updateField('sendDm', e.target.checked)}
                  className="w-4 h-4 accent-purple-600 rounded cursor-pointer"
                />
              </div>
              <textarea
                rows={3}
                value={welcomeConfig.dmMessage}
                onChange={(e) => updateField('dmMessage', e.target.value)}
                placeholder="مرحباً بك يا {user} في سيرفر {server}! نتمنى لك قضاء أجمل الأوقات معنا."
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white focus:outline-none"
              />
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-4 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <UserMinus className="w-4 h-4 text-amber-400" />
                  {isAr ? 'رسالة المغادرة (Goodbye)' : 'Leave / Goodbye Message'}
                </span>
                <input
                  type="checkbox"
                  checked={welcomeConfig.leaveEnabled}
                  onChange={(e) => updateField('leaveEnabled', e.target.checked)}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>
              <ChannelSelector
                lang={lang}
                guildId={activeGuildId}
                compact={true}
                value={welcomeConfig.leaveChannelName || welcomeConfig.channelName}
                onChange={(ch) => updateField('leaveChannelName', ch)}
                placeholder="welcome"
              />
              <input
                type="text"
                value={welcomeConfig.leaveMessage}
                onChange={(e) => updateField('leaveMessage', e.target.value)}
                placeholder="غادرنا العضو {username}، نتمنى له التوفيق 👋"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Live Discord Welcome Preview */}
        <div className="lg:col-span-5 space-y-4 sticky top-20">
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-purple-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {isAr ? 'معاينة الترحيب المباشرة في ديسكورد' : 'Live Discord Welcome Preview'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {isAr ? `الروم المحدد: #${welcomeConfig.channelName || 'welcome'}` : `Channel: #${welcomeConfig.channelName}`}
                  </p>
                </div>
              </div>
              <span className="text-purple-300 text-[10px] font-mono">1024x450 GFX</span>
            </div>

            {/* Simulated Discord Message Container */}
            <div className="rounded-xl bg-[#313338] p-4 space-y-3 border border-slate-800 shadow-inner">
              {/* Bot Header */}
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-purple-700 flex items-center justify-center font-black text-white text-xs font-mono shrink-0">
                  M7R
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white">M7R</span>
                    <span className="bg-[#5865F2] text-white text-[9px] font-bold px-1.5 py-0.2 rounded">APP</span>
                    <span className="text-[10px] text-slate-400">{isAr ? 'اليوم عند 04:20 م' : 'Today at 4:20 PM'}</span>
                  </div>
                  {(welcomeConfig.messageMode === 'embed_and_text' || welcomeConfig.messageMode === 'text_only') && (
                    <p className="text-xs text-slate-100 mt-1">{formatPreview(welcomeConfig.welcomeMessage)}</p>
                  )}
                </div>
              </div>

              {/* Embed Card */}
              {(welcomeConfig.messageMode === 'embed_and_text' || welcomeConfig.messageMode === 'embed_only') && (
                <div
                  className="rounded-lg bg-[#2b2d31] p-4 border space-y-3"
                  style={{ borderColor: welcomeConfig.embedColor || '#8A2BE2' }}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1.5 flex-1">
                      <h4 className="text-sm font-bold text-white">{formatPreview(welcomeConfig.embedTitle)}</h4>
                      <div className="text-xs text-slate-200 leading-relaxed whitespace-pre-line font-sans">
                        {`╭─── ✦ ───╮\n✨ يا هلا ومليون غلا بك يا @M7R_Member في ${serverName}!\n🔒 نورتنا بوجودك، أنت الآن العضو رقم #1,285 في عائلتنا!\n╰─── ✦ ───╯\n`}
                        {formatPreview(welcomeConfig.embedDescription)}
                      </div>
                    </div>
                  </div>

                  {/* Generated 1024x450 Graphic Welcome Card inside Embed */}
                  {(welcomeConfig.vipCardEnabled ?? true) && (
                    <div className="rounded-lg overflow-hidden border border-purple-500/40 bg-black/60">
                      <img
                        src={cardPreviewUrl}
                        alt="VIP Welcome Graphic Card"
                        referrerPolicy="no-referrer"
                        className="w-full h-auto block"
                      />
                    </div>
                  )}

                  {welcomeConfig.footerText && (
                    <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800/70">
                      {formatPreview(welcomeConfig.footerText)}
                    </div>
                  )}
                </div>
              )}

              {/* Interactive Buttons Row Below Welcome Message */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {(welcomeConfig.sayWelcomeEnabled ?? true) && (
                  <button
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setPreviewWelcomeCount((c) => c + 1);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-[#5865F2] hover:bg-[#4752C4] text-white text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <span>👋 رحبوا فيه! ({previewWelcomeCount})</span>
                  </button>
                )}
                <span className="px-2.5 py-1.5 rounded-lg bg-[#4e5058] text-slate-200 text-[11px] font-semibold">
                  📜 #{welcomeConfig.rulesChannelName || 'القوانين'}
                </span>
                <span className="px-2.5 py-1.5 rounded-lg bg-[#4e5058] text-slate-200 text-[11px] font-semibold">
                  🎭 #{welcomeConfig.rolesChannelName || 'الرتب'}
                </span>
                <span className="px-2.5 py-1.5 rounded-lg bg-[#4e5058] text-slate-200 text-[11px] font-semibold">
                  🎫 #{welcomeConfig.ticketChannelName || 'التذاكر'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleTestWelcomeInDiscord}
              disabled={testingWelcome}
              className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-purple-950/60 cursor-pointer transition-all"
            >
              <SendHorizonal className="w-4 h-4" />
              <span>
                {testingWelcome
                  ? isAr
                    ? 'جاري إرسال الترحيب إلى ديسكورد...'
                    : 'Sending Welcome to Discord...'
                  : isAr
                  ? `🧪 إرسال ترحيب تجريبي الآن إلى #${welcomeConfig.channelName || 'welcome'}`
                  : `🧪 Send Test Welcome to #${welcomeConfig.channelName || 'welcome'} Now`}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
