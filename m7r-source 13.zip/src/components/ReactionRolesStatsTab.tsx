import React, { useState } from 'react';
import {
  Sparkles,
  Gamepad2,
  BarChart3,
  Plus,
  Trash2,
  Send,
  Save,
  RefreshCw,
  CheckCircle2,
  Users,
  Activity,
  Zap,
  Shield,
  Sliders,
  Layers,
  Eye,
  Volume2,
  Lock
} from 'lucide-react';
import {
  Language,
  ReactionRolesConfig,
  ReactionRoleItem,
  LiveServerStatsConfig,
  LiveServerStatCounter
} from '../types';

interface ReactionRolesStatsTabProps {
  lang: Language;
  reactionRolesConfig: ReactionRolesConfig;
  setReactionRolesConfig: React.Dispatch<React.SetStateAction<ReactionRolesConfig>>;
  onSaveReactionRoles: () => void;
  onDeployReactionRoles: () => void;
  isSavingReactionRoles: boolean;
  isDeployingReactionRoles: boolean;
  liveStatsConfig: LiveServerStatsConfig;
  setLiveStatsConfig: React.Dispatch<React.SetStateAction<LiveServerStatsConfig>>;
  onSaveLiveStats: () => void;
  onDeployLiveStats: () => void;
  isSavingLiveStats: boolean;
  isDeployingLiveStats: boolean;
  guildChannels: {
    textChannels: { id: string; name: string }[];
    voiceChannels: { id: string; name: string }[];
    categories?: { id: string; name: string }[];
  };
  guildRoles: { id: string; name: string; color: string }[];
  memberCount?: number;
  onlineCount?: number;
  boostCount?: number;
}

export const ReactionRolesStatsTab: React.FC<ReactionRolesStatsTabProps> = ({
  lang,
  reactionRolesConfig,
  setReactionRolesConfig,
  onSaveReactionRoles,
  onDeployReactionRoles,
  isSavingReactionRoles,
  isDeployingReactionRoles,
  liveStatsConfig,
  setLiveStatsConfig,
  onSaveLiveStats,
  onDeployLiveStats,
  isSavingLiveStats,
  isDeployingLiveStats,
  guildChannels,
  guildRoles,
  memberCount = 1420,
  onlineCount = 385,
  boostCount = 24
}) => {
  const isAr = lang === 'ar';
  const [newRoleItem, setNewRoleItem] = useState<Partial<ReactionRoleItem>>({
    label: '',
    roleName: '',
    emoji: '🎮',
    category: 'gaming',
    buttonStyle: 'Secondary',
    colorHex: '#8A2BE2',
    description: ''
  });

  const activeRoleItems = reactionRolesConfig.roles || reactionRolesConfig.items || [];

  const handleAddRoleItem = () => {
    if (!newRoleItem.label?.trim() || !newRoleItem.roleName?.trim()) return;
    const created: ReactionRoleItem = {
      id: `rr_${Date.now()}`,
      label: newRoleItem.label.trim(),
      roleId: newRoleItem.roleId || '',
      roleName: newRoleItem.roleName.trim(),
      roleColor: newRoleItem.colorHex || '#8A2BE2',
      emoji: newRoleItem.emoji?.trim() || '🎮',
      category: (newRoleItem.category as ReactionRoleItem['category']) || 'gaming',
      buttonStyle: (newRoleItem.buttonStyle as ReactionRoleItem['buttonStyle']) || 'Secondary',
      colorHex: newRoleItem.colorHex || '#8A2BE2',
      description: newRoleItem.description?.trim() || 'اضغط للحصول على هذه الرتبة أو إزالتها تلقائياً'
    };

    const nextList = [...activeRoleItems, created];
    setReactionRolesConfig(prev => ({
      ...prev,
      roles: nextList,
      items: nextList
    }));

    setNewRoleItem({
      label: '',
      roleName: '',
      emoji: '🎮',
      category: 'gaming',
      buttonStyle: 'Secondary',
      colorHex: '#8A2BE2',
      description: ''
    });
  };

  const handleDeleteRoleItem = (id: string) => {
    const nextList = activeRoleItems.filter(item => item.id !== id);
    setReactionRolesConfig(prev => ({
      ...prev,
      roles: nextList,
      items: nextList
    }));
  };

  const handleToggleCounter = (counterKey: string) => {
    setLiveStatsConfig(prev => ({
      ...prev,
      counters: (prev.counters || []).map(c =>
        (c.id || c.type) === counterKey ? { ...c, enabled: !c.enabled } : c
      )
    }));
  };

  const handleUpdateCounterTemplate = (counterKey: string, template: string) => {
    setLiveStatsConfig(prev => ({
      ...prev,
      counters: (prev.counters || []).map(c =>
        (c.id || c.type) === counterKey ? { ...c, formatTemplate: template, format: template } : c
      )
    }));
  };

  const getSimulatedCounterText = (counter: LiveServerStatCounter) => {
    const val =
      counter.type === 'total_members' || counter.type === 'members'
        ? memberCount
        : counter.type === 'online_members' || counter.type === 'online'
        ? onlineCount
        : counter.type === 'boosts_count' || counter.type === 'boosts'
        ? boostCount
        : Math.max(12, Math.floor(memberCount * 0.42));
    return (counter.formatTemplate || counter.format || '📊・{count}').replace('{count}', String(val));
  };

  const getButtonStyleClasses = (style: ReactionRoleItem['buttonStyle']) => {
    switch (style) {
      case 'Primary':
        return 'bg-[#5865F2] hover:bg-[#4752C4] text-white border-[#5865F2]';
      case 'Success':
        return 'bg-[#248046] hover:bg-[#1a6334] text-white border-[#248046]';
      case 'Danger':
        return 'bg-[#DA373C] hover:bg-[#a1282c] text-white border-[#DA373C]';
      default:
        return 'bg-[#2B2D31] hover:bg-[#35373C] text-slate-100 border-white/10';
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Top Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-purple-500/30 bg-gradient-to-br from-[#130924]/95 via-[#0B0614]/98 to-[#1A0B2E]/95 p-6 sm:p-8 shadow-[0_0_50px_rgba(138,43,226,0.18)]">
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-fuchsia-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-500/15 border border-purple-400/30 text-purple-300 text-xs font-bold tracking-wider uppercase">
              <Sparkles className="w-3.5 h-3.5 text-purple-400 animate-spin-slow" />
              {isAr ? 'منظومة الرتب التفاعلية والإحصائيات الحية • M7R PRO' : 'Interactive Reaction Roles & Live Server Stats'}
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
              <span>{isAr ? 'الرتب التفاعلية & رومات الإحصائيات الحية' : 'Reaction Roles & Live Stats Channels'}</span>
            </h2>
            <p className="text-slate-300 text-sm max-w-3xl leading-relaxed">
              {isAr
                ? 'امنح أعضاء السيرفر حرية اختيار رتب الألعاب (Roblox, GTA V, PlayStation, Valorant) والإشعارات بضغطة زر أو قائمة منسدلة مع إنشاء تلقائي للرتب غير الموجودة، بالإضافة إلى رومات صوتية مقفلة أعلى السيرفر تعرض إحصائيات السيرفر الحية لحظة بلحظة.'
                : 'Let members self-assign gaming and notification roles via buttons & dropdown menus with automatic missing-role creation, alongside auto-updating locked voice stat counters at the top of your server.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onSaveReactionRoles}
              disabled={isSavingReactionRoles}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-purple-500/30 text-white text-xs font-bold flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSavingReactionRoles ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4 text-purple-400" />}
              {isAr ? 'حفظ إعدادات الرتب' : 'Save Roles Config'}
            </button>

            <button
              onClick={onDeployReactionRoles}
              disabled={isDeployingReactionRoles}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-black flex items-center gap-2 shadow-[0_0_25px_rgba(138,43,226,0.45)] transition-all cursor-pointer disabled:opacity-50"
            >
              {isDeployingReactionRoles ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              {isAr ? 'إرسال لوحة الرتب للسيرفر الآن' : 'Deploy Reaction Roles Panel'}
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 1: INTERACTIVE REACTION ROLES */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left: Configuration & Role Builder */}
        <div className="xl:col-span-7 space-y-6">
          <div className="rounded-3xl border border-purple-500/25 bg-[#0D0718]/90 p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
                  <Gamepad2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">
                    {isAr ? 'إعدادات لوحة الرتب التفاعلية (Select Menu + Buttons)' : 'Reaction Roles Panel Settings'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {isAr ? 'تخصيص الروم، أسلوب العرض، والإنشاء التلقائي للرتب في الديسكورد' : 'Customize channel, interaction mode, and auto-create roles on Discord'}
                  </p>
                </div>
              </div>

              <label className="inline-flex items-center gap-2 cursor-pointer">
                <span className="text-xs font-bold text-slate-300">{isAr ? 'مفعل' : 'Enabled'}</span>
                <input
                  type="checkbox"
                  checked={reactionRolesConfig.enabled}
                  onChange={e => setReactionRolesConfig(prev => ({ ...prev, enabled: e.target.checked }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all relative peer-checked:bg-purple-600" />
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {isAr ? 'روم لوحة الرتب (Channel)' : 'Target Discord Channel'}
                </label>
                <select
                  value={reactionRolesConfig.channelId || ''}
                  onChange={e => setReactionRolesConfig(prev => ({ ...prev, channelId: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-purple-500/30 text-white text-xs focus:outline-none focus:border-purple-400"
                >
                  <option value="">{isAr ? '— تلقائي (روم الرتب أو أول روم نصي) —' : '— Auto-detect channel —'}</option>
                  {guildChannels.textChannels.map(ch => (
                    <option key={ch.id} value={ch.id}>
                      #{ch.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {isAr ? 'طريقة الاختيار والتفاعل' : 'Interaction Mode'}
                </label>
                <select
                  value={reactionRolesConfig.mode || 'both'}
                  onChange={e =>
                    setReactionRolesConfig(prev => ({
                      ...prev,
                      mode: e.target.value as ReactionRolesConfig['mode']
                    }))
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-purple-500/30 text-white text-xs focus:outline-none focus:border-purple-400"
                >
                  <option value="both">{isAr ? 'أزرار + قائمة منسدلة معاً (Buttons + Select Menu)' : 'Both Buttons & Select Menu'}</option>
                  <option value="buttons">{isAr ? 'أزرار تفاعلية فقط (Buttons Only)' : 'Buttons Only'}</option>
                  <option value="select">{isAr ? 'قائمة منسدلة فقط (Select Menu Only)' : 'Select Menu Only'}</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {isAr ? 'عنوان الإيمبد الفخم' : 'Panel Embed Title'}
                </label>
                <input
                  type="text"
                  value={reactionRolesConfig.panelTitle || ''}
                  onChange={e => setReactionRolesConfig(prev => ({ ...prev, panelTitle: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-purple-500/30 text-white text-xs focus:outline-none focus:border-purple-400"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {isAr ? 'وصف لوحة الرتب' : 'Panel Description'}
                </label>
                <textarea
                  rows={2}
                  value={reactionRolesConfig.panelDescription || ''}
                  onChange={e => setReactionRolesConfig(prev => ({ ...prev, panelDescription: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-purple-500/30 text-white text-xs focus:outline-none focus:border-purple-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {isAr ? 'رابط البنر الملكي (Purple Chrome Banner)' : 'Banner Image URL'}
                </label>
                <input
                  type="text"
                  value={reactionRolesConfig.bannerUrl || ''}
                  onChange={e => setReactionRolesConfig(prev => ({ ...prev, bannerUrl: e.target.value }))}
                  placeholder="/assets/aistudio/IMG_3117_2cec6847.jpeg"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-purple-500/30 text-white text-xs focus:outline-none focus:border-purple-400"
                />
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-xl bg-purple-950/30 border border-purple-500/30">
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-purple-400" />
                    {isAr ? 'إنشاء الرتب تلقائياً بالسيرفر' : 'Auto-Create Missing Roles'}
                  </div>
                  <p className="text-[11px] text-slate-400">
                    {isAr ? 'ينشئ البوت الرتبة بالاسم واللون تلقائياً إذا لم تكن موجودة' : 'Automatically creates missing Discord roles'}
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={reactionRolesConfig.autoCreateMissingRoles}
                  onChange={e =>
                    setReactionRolesConfig(prev => ({
                      ...prev,
                      autoCreateMissingRoles: e.target.checked
                    }))
                  }
                  className="w-4 h-4 accent-purple-600 cursor-pointer"
                />
              </div>
            </div>

            {/* Add New Reaction Role Form */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <h4 className="text-xs font-black text-purple-300 uppercase tracking-wider flex items-center gap-2">
                <Plus className="w-4 h-4" />
                {isAr ? 'إضافة رتبة تفاعلية جديدة للوحة' : 'Add New Interactive Role'}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder={isAr ? 'اسم الزر (مثال: Roblox)' : 'Button Label (e.g. Roblox)'}
                  value={newRoleItem.label || ''}
                  onChange={e => setNewRoleItem(prev => ({ ...prev, label: e.target.value }))}
                  className="px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs"
                />
                <input
                  type="text"
                  placeholder={isAr ? 'اسم الرتبة في ديسكورد (مثال: Roblox Player)' : 'Discord Role Name'}
                  value={newRoleItem.roleName || ''}
                  onChange={e => setNewRoleItem(prev => ({ ...prev, roleName: e.target.value }))}
                  className="px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs"
                />
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="🎮"
                    value={newRoleItem.emoji || ''}
                    onChange={e => setNewRoleItem(prev => ({ ...prev, emoji: e.target.value }))}
                    className="w-16 px-2.5 py-2 rounded-xl bg-black/40 border border-white/10 text-center text-white text-xs"
                  />
                  <select
                    value={newRoleItem.roleId || ''}
                    onChange={e => {
                      const selectedRole = guildRoles.find(r => r.id === e.target.value);
                      setNewRoleItem(prev => ({
                        ...prev,
                        roleId: e.target.value,
                        roleName: selectedRole ? selectedRole.name : prev.roleName
                      }));
                    }}
                    className="flex-1 px-2.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs"
                  >
                    <option value="">{isAr ? 'اختر رتبة أو أنشئ تلقائياً' : 'Select Role or Auto-Create'}</option>
                    {guildRoles.map(r => (
                      <option key={r.id} value={r.id}>
                        @{r.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <select
                  value={newRoleItem.category || 'gaming'}
                  onChange={e => setNewRoleItem(prev => ({ ...prev, category: e.target.value as ReactionRoleItem['category'] }))}
                  className="px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs"
                >
                  <option value="gaming">{isAr ? '🎮 ألعاب (Gaming)' : 'Gaming Role'}</option>
                  <option value="pings">{isAr ? '🔔 إشعارات (Pings)' : 'Notification Ping'}</option>
                  <option value="special">{isAr ? '👑 خاصة (VIP / Special)' : 'Special Role'}</option>
                </select>

                <select
                  value={newRoleItem.buttonStyle || 'Secondary'}
                  onChange={e => setNewRoleItem(prev => ({ ...prev, buttonStyle: e.target.value as ReactionRoleItem['buttonStyle'] }))}
                  className="px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs"
                >
                  <option value="Primary">Blurple (Primary)</option>
                  <option value="Secondary">Dark Glass (Secondary)</option>
                  <option value="Success">Emerald (Success)</option>
                  <option value="Danger">Crimson (Danger)</option>
                </select>

                <input
                  type="text"
                  placeholder={isAr ? 'وصف مختصر في القائمة' : 'Short description'}
                  value={newRoleItem.description || ''}
                  onChange={e => setNewRoleItem(prev => ({ ...prev, description: e.target.value }))}
                  className="px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs"
                />

                <button
                  type="button"
                  onClick={handleAddRoleItem}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  <Plus className="w-4 h-4" />
                  {isAr ? 'إضافة للوحة' : 'Add Role'}
                </button>
              </div>
            </div>

            {/* Active Roles List */}
            <div className="space-y-2.5 pt-2">
              {activeRoleItems.map(item => (
                <div
                  key={item.id}
                  className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-black/40 border border-white/10 hover:border-purple-500/40 transition-all"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="text-xl">{item.emoji}</span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-white truncate">{item.label}</span>
                        <span
                          className="px-2 py-0.5 rounded-md text-[10px] font-bold border"
                          style={{
                            borderColor: `${item.colorHex || '#8A2BE2'}55`,
                            backgroundColor: `${item.colorHex || '#8A2BE2'}20`,
                            color: '#E9D5FF'
                          }}
                        >
                          @{item.roleName}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">{item.description}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDeleteRoleItem(item.id)}
                    className="p-2 rounded-lg text-rose-400 hover:bg-rose-500/15 transition-colors cursor-pointer"
                    title={isAr ? 'حذف الرتبة' : 'Delete Role'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Live Discord Embed Preview */}
        <div className="xl:col-span-5 space-y-6">
          <div className="rounded-3xl border border-purple-500/25 bg-[#0D0718]/90 p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-purple-300 uppercase tracking-wider flex items-center gap-2">
                <Eye className="w-4 h-4" />
                {isAr ? 'معاينة حية للوحة الرتب في الديسكورد' : 'Live Discord Reaction Roles Preview'}
              </span>
              <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Discord.js v14 Ready
              </span>
            </div>

            {/* Simulated Discord Message */}
            <div className="rounded-2xl bg-[#313338] p-4 border border-black/40 space-y-3 font-sans">
              <div className="flex items-center gap-2.5">
                <img
                  src="/assets/aistudio/IMG_3117_2cec6847.jpeg"
                  alt="M7R"
                  className="w-9 h-9 rounded-full object-cover ring-2 ring-purple-500/50"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-white font-bold text-xs">M7R PRO</span>
                    <span className="px-1.5 py-0.5 rounded bg-[#5865F2] text-[9px] font-bold text-white">APP</span>
                  </div>
                  <span className="text-[10px] text-slate-400">{isAr ? 'اليوم الساعة ١٢:٠٠ م' : 'Today at 12:00 PM'}</span>
                </div>
              </div>

              {/* Embed Box */}
              <div
                className="rounded-xl bg-[#2B2D31] border-l-4 p-4 space-y-3"
                style={{ borderLeftColor: reactionRolesConfig.embedColor || '#8A2BE2' }}
              >
                <div className="text-sm font-black text-white">{reactionRolesConfig.panelTitle}</div>
                <div className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                  {`╭─── ✦ ───╮\n${reactionRolesConfig.panelDescription}\n╰─── ✦ ───╯`}
                </div>

                <div className="space-y-1.5 pt-1">
                  {activeRoleItems.map(r => (
                    <div key={r.id} className="text-xs text-slate-200 flex items-center gap-2">
                      <span>{r.emoji}</span>
                      <span className="font-bold text-purple-300">{r.label}</span>
                      <span className="text-slate-400">— {r.description}</span>
                    </div>
                  ))}
                </div>

                {reactionRolesConfig.bannerUrl && (
                  <div className="pt-2">
                    <img
                      src={reactionRolesConfig.bannerUrl}
                      alt="M7R Banner"
                      className="w-full h-36 object-cover rounded-xl border border-purple-500/30"
                    />
                  </div>
                )}

                <div className="text-[10px] text-slate-400 pt-1">
                  M7R PRO Reaction Roles • Created by u5r9 👑
                </div>
              </div>

              {/* Simulated Select Menu */}
              {((reactionRolesConfig.mode || reactionRolesConfig.displayMode || 'both') === 'select' ||
                (reactionRolesConfig.mode || reactionRolesConfig.displayMode || 'both') === 'both') && (
                <div className="w-full px-3.5 py-2.5 rounded-lg bg-[#1E1F22] border border-white/10 text-slate-300 text-xs flex items-center justify-between">
                  <span>✨ اختر الرتب التفاعلية الخاصة بك من القائمة...</span>
                  <span>▼</span>
                </div>
              )}

              {/* Simulated Buttons */}
              {((reactionRolesConfig.mode || reactionRolesConfig.displayMode || 'both') === 'buttons' ||
                (reactionRolesConfig.mode || reactionRolesConfig.displayMode || 'both') === 'both') && (
                <div className="flex flex-wrap gap-2 pt-1">
                  {activeRoleItems.map(r => (
                    <span
                      key={r.id}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border inline-flex items-center gap-1.5 ${getButtonStyleClasses(
                        r.buttonStyle
                      )}`}
                    >
                      <span>{r.emoji}</span>
                      <span>{r.label}</span>
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 2: LIVE SERVER STATS VOICE CHANNELS */}
      <div className="rounded-3xl border border-purple-500/25 bg-[#0D0718]/90 p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600/30 to-indigo-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300 shadow-lg">
              <BarChart3 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                {isAr ? 'رومات الإحصائيات الحية أعلى السيرفر (Live Server Stats)' : 'Live Server Stats Voice Channels'}
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold">
                  Auto-Sync
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {isAr
                  ? 'رومات صوتية مقفلة (Locked Voice Counters) تتحدث تلقائياً عند دخول أو خروج أي عضو أو تغير حالة الأونلاين والبوستات'
                  : 'Locked voice channels at the top of the server that automatically update member, online, and boost counts'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onSaveLiveStats}
              disabled={isSavingLiveStats}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-purple-500/30 text-white text-xs font-bold flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSavingLiveStats ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4 text-purple-400" />}
              {isAr ? 'حفظ القوالب' : 'Save Stats Templates'}
            </button>

            <button
              onClick={onDeployLiveStats}
              disabled={isDeployingLiveStats}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black flex items-center gap-2 shadow-[0_0_25px_rgba(16,185,129,0.35)] cursor-pointer disabled:opacity-50"
            >
              {isDeployingLiveStats ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              {isAr ? 'إنشاء وتحديث رومات الإحصائيات الآن' : 'Create & Sync Live Stat Channels'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Counter Templates Editor */}
          <div className="lg:col-span-7 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {isAr ? 'اسم كاتيجوري الإحصائيات' : 'Stats Category Name'}
                </label>
                <input
                  type="text"
                  value={liveStatsConfig.categoryName || ''}
                  onChange={e => setLiveStatsConfig(prev => ({ ...prev, categoryName: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-purple-500/30 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {isAr ? 'معدل التحديث التلقائي (بالدقائق)' : 'Auto-Refresh Interval (Minutes)'}
                </label>
                <input
                  type="number"
                  min={5}
                  max={60}
                  value={liveStatsConfig.updateIntervalMinutes || 5}
                  onChange={e =>
                    setLiveStatsConfig(prev => ({
                      ...prev,
                      updateIntervalMinutes: Number(e.target.value) || 5
                    }))
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-purple-500/30 text-white text-xs"
                />
              </div>
            </div>

            <div className="space-y-3">
              {(liveStatsConfig.counters || []).map(counter => {
                const cKey = counter.id || counter.type;
                return (
                  <div
                    key={cKey}
                    className={`p-4 rounded-2xl border transition-all ${
                      counter.enabled
                        ? 'bg-purple-950/20 border-purple-500/40'
                        : 'bg-black/30 border-white/10 opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3 mb-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={counter.enabled}
                          onChange={() => handleToggleCounter(cKey)}
                          className="w-4 h-4 accent-purple-600 cursor-pointer"
                        />
                        <span className="text-xs font-black text-white">
                          {counter.type === 'total_members' || counter.type === 'members'
                            ? isAr
                              ? '👥 إجمالي الأعضاء (Total Members)'
                              : 'Total Members Counter'
                            : counter.type === 'online_members' || counter.type === 'online'
                            ? isAr
                              ? '🟢 المتصلون الآن (Online Members)'
                              : 'Online Members Counter'
                            : counter.type === 'boosts_count' || counter.type === 'boosts'
                            ? isAr
                              ? '💎 عدد البوستات (Server Boosts)'
                              : 'Server Boosts Counter'
                            : isAr
                            ? '🎮 عداد اللاعبين/الرتبة (Role Counter)'
                            : 'Role Members Counter'}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded">
                        {'{count}'}
                      </span>
                    </div>

                    <input
                      type="text"
                      value={counter.formatTemplate || counter.format || ''}
                      onChange={e => handleUpdateCounterTemplate(cKey, e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-purple-400"
                    />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Live Discord Sidebar Voice Channels Simulation */}
          <div className="lg:col-span-5 rounded-2xl bg-[#2B2D31] border border-black/40 p-5 space-y-3">
            <div className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>▾ {liveStatsConfig.categoryName || '📊 إحصائيات السيرفر • M7R'}</span>
              <span className="text-[10px] text-emerald-400">LIVE</span>
            </div>

            <div className="space-y-2">
              {(liveStatsConfig.counters || [])
                .filter(c => c.enabled)
                .map(counter => (
                  <div
                    key={counter.id || counter.type}
                    className="flex items-center justify-between px-3 py-2.5 rounded-xl bg-[#1E1F22] border border-white/5 text-slate-200 text-xs font-bold"
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Volume2 className="w-4 h-4 text-slate-400 shrink-0" />
                      <span className="truncate">{getSimulatedCounterText(counter)}</span>
                    </div>
                    <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
