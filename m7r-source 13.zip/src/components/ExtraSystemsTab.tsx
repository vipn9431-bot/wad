import React, { useState, useEffect } from 'react';
import { 
  Award, 
  Bot, 
  Megaphone, 
  Radio, 
  Plus, 
  Trash2, 
  Save, 
  Check, 
  Send, 
  Vote, 
  MicOff, 
  Headphones, 
  Sparkles,
  Volume2,
  Square,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Play,
  RefreshCw,
  Power,
  Zap,
  MessageSquare,
  BookOpen,
  Clock,
  Calendar,
  Compass,
  Pause,
  Edit3,
  X,
  Mic
} from 'lucide-react';
import { AutoResponse, Voice247Config, LevelUser, QuranReciter, QuranScheduleSlot } from '../types';
import { ChannelSelector } from './ChannelSelector';
import { TempVoiceTab } from './TempVoiceTab';
import { sound } from '../utils/sound';

const DEFAULT_QURAN_RECITERS: QuranReciter[] = [
  { id: 'radio_live', name: 'إذاعة القرآن الكريم من القاهرة / السعودية (بث مباشر المستمر)', nameEn: 'Holy Quran Live Radio المستمر (Cairo / Saudi)', description: 'بث إذاعي مباشر ومتواصل يوم كامل لتلاوات القرآن الكريم', streamUrl: 'https://stream.radiojar.com/8s5u5tpdtwzuv', style: 'radio' },
  { id: 'muaiqly', name: 'الشيخ ماهر المعيقلي (Maher Al-Muaiqly)', nameEn: 'Maher Al-Muaiqly', description: 'ختمة القرآن الكريم بصوت عذب ومؤثر من الحرم المكي', streamUrl: 'https://backup.qurango.net/radio/maher', style: 'murattal' },
  { id: 'abdulbasit', name: 'الشيخ عبدالباسط عبدالصمد (Abdulbasit Abdulsamad - مرتل ومجود)', nameEn: 'Abdulbasit Abdulsamad', description: 'القرآن الكريم بصوت قوي ورائع (مرتل ومجود)', streamUrl: 'https://backup.qurango.net/radio/abdulbasit_abdulsamad_mojawwad', style: 'mujawwad' },
  { id: 'alafasy', name: 'الشيخ مشاري راشد العفاسي (Mishary Alafasy)', nameEn: 'Mishary Al-Afasy', description: 'ختمة القرآن الكريم بصوت مميز وقوي', streamUrl: 'https://backup.qurango.net/radio/mishary_alafasi', style: 'murattal' },
  { id: 'dosari', name: 'الشيخ ياسر الدوسري (Yasser Al-Dosari)', nameEn: 'Yasser Al-Dosari', description: 'القرآن الكريم بتلاوة متميزة وخاشعة', streamUrl: 'https://backup.qurango.net/radio/yasser_aldosari', style: 'murattal' },
  { id: 'shuraim', name: 'الشيخ سعود الشريم (Saud Al-Shuraim)', nameEn: 'Saud Al-Shuraim', description: 'تلاوات الحرم المكي الشريف بصوت الشيخ سعود الشريم', streamUrl: 'https://backup.qurango.net/radio/saud_alshuraim', style: 'murattal' },
  { id: 'qatami', name: 'الشيخ ناصر القطامي (Nasser Al-Qatami)', nameEn: 'Nasser Al-Qatami', description: 'تلاوات خاشعة ومؤثرة للشيخ ناصر القطامي', streamUrl: 'https://backup.qurango.net/radio/nasser_alqatami', style: 'murattal' },
  { id: 'minshawi', name: 'الشيخ محمد صديق المنشاوي (Al-Minshawi)', nameEn: 'Mohamed Siddiq Al-Minshawi', description: 'القرآن الكريم بتلاوة مصرية خاشعة وتقليدية', streamUrl: 'https://backup.qurango.net/radio/mohammed_siddiq_alminshawi_mojawwad', style: 'mujawwad' },
  { id: 'sudais', name: 'الشيخ عبد الرحمن السديس (Abdulrahman Al-Sudais)', nameEn: 'Abdulrahman Al-Sudais', description: 'القرآن الكريم بتلاوة حجازية فخمة من المسجد الحرام', streamUrl: 'https://backup.qurango.net/radio/abdulrahman_alsudaes', style: 'murattal' },
  { id: 'ghamdi', name: 'الشيخ سعد الغامدي (Saad Al-Ghamdi)', nameEn: 'Saad Al-Ghamdi', description: 'القرآن الكريم بتلاوة هادئة ومطمئنة', streamUrl: 'https://backup.qurango.net/radio/saad_alghamdi', style: 'murattal' },
  { id: 'musaad', name: 'الشيخ عبد الرحمن مسعد (Abdulrahman Mossad)', nameEn: 'Abdulrahman Mossad', description: 'القرآن الكريم بتلاوة عذبة وراقية', streamUrl: 'https://backup.qurango.net/radio/abdulrahman_mossad', style: 'murattal' },
  { id: 'balushi', name: 'الشيخ هزاع البلوشي (Hazza Al-Balushi)', nameEn: 'Hazza Al-Balushi', description: 'القرآن الكريم بتلاوة ندية ومؤثرة', streamUrl: 'https://backup.qurango.net/radio/hazza_albalushi', style: 'murattal' },
  { id: 'ajmy', name: 'الشيخ أحمد العجمي (Ahmad Al-Ajmy)', nameEn: 'Ahmad Al-Ajmy', description: 'القرآن الكريم بتلاوة حجازية مميزة', streamUrl: 'https://backup.qurango.net/radio/ahmad_alajmy', style: 'murattal' },
];

interface ExtraSystemsTabProps {
  lang: 'ar' | 'en';
  autoResponses: AutoResponse[];
  setAutoResponses: React.Dispatch<React.SetStateAction<AutoResponse[]>>;
  voice247: Voice247Config;
  setVoice247: React.Dispatch<React.SetStateAction<Voice247Config>>;
  onSave: () => void;
  quranOnly?: boolean;
}

export const ExtraSystemsTab: React.FC<ExtraSystemsTabProps> = ({
  lang,
  autoResponses,
  setAutoResponses,
  voice247,
  setVoice247,
  onSave,
  quranOnly = false,
}) => {
  const isAr = lang === 'ar';
  const [activeSection, setActiveSection] = useState<'levels' | 'autoresponder' | 'tempvoice' | 'broadcasts' | 'voice'>('voice');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Leveling state
  const [xpMultiplier, setXpMultiplier] = useState(1.5);
  const [levelUpChannel, setLevelUpChannel] = useState('#level-up');
  const [levelsEnabled, setLevelsEnabled] = useState(true);

  // Live Voice المستمر & Quran State
  const [voiceInChannel, setVoiceInChannel] = useState<boolean>(false);
  const [voicePaused, setVoicePaused] = useState<boolean>(false);
  const [voiceVolume, setVoiceVolume] = useState<number>(100);
  const [serverVoiceChannels, setServerVoiceChannels] = useState<{ id: string; name: string }[]>([]);
  const [selectedDropdownReciter, setSelectedDropdownReciter] = useState<string>(voice247.selectedReciter || 'alafasy');
  const [voiceLoading, setVoiceLoading] = useState<boolean>(false);
  const [voiceFeedback, setVoiceFeedback] = useState<string | null>(null);
  const [activeReciter, setActiveReciter] = useState<QuranReciter | null>(null);
  const [recitersList, setRecitersList] = useState<QuranReciter[]>(DEFAULT_QURAN_RECITERS);
  const [scheduleSlots, setScheduleSlots] = useState<QuranScheduleSlot[]>([]);
  const [currentHourMecca, setCurrentHourMecca] = useState<number>(new Date().getUTCHours() + 3);
  const [reciterSwitching, setReciterSwitching] = useState<string | null>(null);
  const [scheduleSaving, setScheduleSaving] = useState<boolean>(false);

  // Ultra Auto-Responder Pro V2 state
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [newTrigger, setNewTrigger] = useState('');
  const [newMatchType, setNewMatchType] = useState<'smart' | 'contains' | 'exact' | 'starts_with' | 'regex'>('smart');
  const [newResponseMode, setNewResponseMode] = useState<'text' | 'embed' | 'button' | 'reaction'>('text');
  const [newReply, setNewReply] = useState('');
  const [newEmbedTitle, setNewEmbedTitle] = useState('');
  const [newEmbedColor, setNewEmbedColor] = useState('#8A2BE2');
  const [newEmbedImageUrl, setNewEmbedImageUrl] = useState('');
  const [newEmbedThumbnailUrl, setNewEmbedThumbnailUrl] = useState('');
  const [newButtonLabel, setNewButtonLabel] = useState('');
  const [newButtonUrl, setNewButtonUrl] = useState('');
  const [newReaction, setNewReaction] = useState('❤️');
  const [newDeleteTrigger, setNewDeleteTrigger] = useState(false);
  const [newReplyMode, setNewReplyMode] = useState<'reply' | 'send'>('reply');
  const [newCooldownSec, setNewCooldownSec] = useState<number>(3);
  const [newAutoDeleteSec, setNewAutoDeleteSec] = useState<number>(0);
  const [newAllowedChannels, setNewAllowedChannels] = useState('');
  const [newIgnoredChannels, setNewIgnoredChannels] = useState('');
  const [newAllowedRoles, setNewAllowedRoles] = useState('');
  const [newIgnoredRoles, setNewIgnoredRoles] = useState('');
  const [testInput, setTestInput] = useState('');
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [loadingSaudiPresets, setLoadingSaudiPresets] = useState(false);

  // Fetch Voice Status on load
  const fetchVoiceStatus = async () => {
    try {
      const token = localStorage.getItem('m7r_auth_token');
      const res = await fetch('/api/voice/status', {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      const data = await res.json();
      if (data) {
        setVoiceInChannel(Boolean(data.inVoice));
        setVoicePaused(Boolean(data.paused));
        if (typeof data.volume === 'number') setVoiceVolume(data.volume);
        if (Array.isArray(data.voiceChannels) && data.voiceChannels.length > 0) {
          setServerVoiceChannels(data.voiceChannels);
        }
        if (data.activeReciter) {
          setActiveReciter(data.activeReciter);
          setSelectedDropdownReciter(data.activeReciter.id);
        }
        if (data.reciters && Array.isArray(data.reciters) && data.reciters.length > 0) {
          setRecitersList(data.reciters);
        }
        if (data.scheduleSlots && Array.isArray(data.scheduleSlots)) setScheduleSlots(data.scheduleSlots);
        if (typeof data.currentHourMecca === 'number') setCurrentHourMecca(data.currentHourMecca);
        setVoice247(prev => ({
          ...prev,
          channelName: data.channelName || prev.channelName,
          selectedReciter: data.selectedReciter || prev.selectedReciter,
          scheduleEnabled: data.scheduleEnabled !== undefined ? data.scheduleEnabled : prev.scheduleEnabled,
          audioMode: data.audioMode || prev.audioMode
        }));
      }
    } catch {
      // fallback
    }
  };

  useEffect(() => {
    fetchVoiceStatus();
    const interval = setInterval(fetchVoiceStatus, 6000);
    return () => clearInterval(interval);
  }, []);

  // Broadcasts state
  const [embedTitle, setEmbedTitle] = useState('تحديث أمني ضخم وتدشين متجر M7R Store 🛡️');
  const [embedDescription, setEmbedDescription] = useState('يسر إدارة سيرفر M7R الإعلان عن تفعيل أنظمة الحماية بالكامل وافتتاح الروم الخاص بطلبات المتجر الفورية.');
  const [embedColor, setEmbedColor] = useState('#8A2BE2');
  const [broadcastSent, setBroadcastSent] = useState(false);

  // Poll state
  const [pollQuestion, setPollQuestion] = useState('هل تؤيد تفعيل وضع القفل التلقائي للشات عند تجاوز 500 رسالة/دقيقة؟');
  const [pollVotes, setPollVotes] = useState({ yes: 84, no: 16 });
  const [hasVoted, setHasVoted] = useState<string | null>(null);

  const topUsers: LevelUser[] = [
    { rank: 1, name: 'Sultan_Leader', avatar: '', level: 52, xp: 26400, nextLevelXp: 28000, messagesCount: 8420 },
    { rank: 2, name: 'Fahad_Pro', avatar: '', level: 48, xp: 22100, nextLevelXp: 24000, messagesCount: 6910 },
    { rank: 3, name: 'Mishal_Dev', avatar: '', level: 41, xp: 18450, nextLevelXp: 20000, messagesCount: 5200 },
    { rank: 4, name: 'Rakan_Sniper', avatar: '', level: 36, xp: 14800, nextLevelXp: 16000, messagesCount: 4190 },
    { rank: 5, name: 'Bander_VIP', avatar: '', level: 32, xp: 11200, nextLevelXp: 13000, messagesCount: 3040 },
  ];

  const handleSave = () => {
    sound.playShieldActivate();
    onSave();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const resetAutoResponseForm = () => {
    setEditingRuleId(null);
    setNewTrigger('');
    setNewMatchType('smart');
    setNewResponseMode('text');
    setNewReply('');
    setNewEmbedTitle('');
    setNewEmbedColor('#8A2BE2');
    setNewEmbedImageUrl('');
    setNewEmbedThumbnailUrl('');
    setNewButtonLabel('');
    setNewButtonUrl('');
    setNewReaction('❤️');
    setNewDeleteTrigger(false);
    setNewReplyMode('reply');
    setNewCooldownSec(3);
    setNewAutoDeleteSec(0);
    setNewAllowedChannels('');
    setNewIgnoredChannels('');
    setNewAllowedRoles('');
    setNewIgnoredRoles('');
  };

  const handleEditAutoResponse = (item: AutoResponse) => {
    sound.playClick();
    setEditingRuleId(item.id);
    setNewTrigger(item.trigger);
    setNewMatchType(item.matchType || 'smart');
    setNewResponseMode(item.responseMode || 'text');
    setNewReply(item.reply || '');
    setNewEmbedTitle(item.embedTitle || '');
    setNewEmbedColor(item.embedColor || '#8A2BE2');
    setNewEmbedImageUrl(item.embedImageUrl || '');
    setNewEmbedThumbnailUrl(item.embedThumbnailUrl || '');
    setNewButtonLabel(item.buttonLabel || '');
    setNewButtonUrl(item.buttonUrl || '');
    setNewReaction(item.autoReaction || '');
    setNewDeleteTrigger(Boolean(item.deleteTriggerMessage));
    setNewReplyMode(item.replyMode || 'reply');
    setNewCooldownSec(item.cooldownSec ?? 3);
    setNewAutoDeleteSec(item.autoDeleteSec ?? 0);
    setNewAllowedChannels((item.allowedChannels || []).join(', '));
    setNewIgnoredChannels((item.ignoredChannels || []).join(', '));
    setNewAllowedRoles((item.allowedRoles || []).join(', '));
    setNewIgnoredRoles((item.ignoredRoles || []).join(', '));
  };

  const handleLoadReadySaudiPresets = async () => {
    sound.playShieldActivate();
    setLoadingSaudiPresets(true);
    const readyRules: AutoResponse[] = [
      {
        id: `ar-sa-salam-${Date.now()}`,
        trigger: 'السلام عليكم, سلام, السلام',
        matchType: 'smart',
        responseMode: 'text',
        reply: 'وعليكم السلام ورحمة الله وبركاته يا {user} نورتنا في **{server}**! 🌸✨',
        autoReaction: '🤍',
        replyMode: 'reply',
        cooldownSec: 3,
        enabled: true
      },
      {
        id: `ar-sa-back-${Date.now() + 1}`,
        trigger: 'باك, بااك, احلى باك',
        matchType: 'smart',
        responseMode: 'text',
        reply: 'ولكمووو أحلى باك يا {user} نورت الروم! 🔥💜',
        autoReaction: '🔥',
        replyMode: 'reply',
        cooldownSec: 3,
        enabled: true
      },
      {
        id: `ar-sa-brb-${Date.now() + 2}`,
        trigger: 'برب, بررب',
        matchType: 'smart',
        responseMode: 'text',
        reply: 'تيت يا الغالي {user}، لا تطول علينا! 🤍✨',
        autoReaction: '👋',
        replyMode: 'reply',
        cooldownSec: 3,
        enabled: true
      },
      {
        id: `ar-sa-ticket-${Date.now() + 3}`,
        trigger: 'تكت, شكوى, مساعدة, ادمن',
        matchType: 'smart',
        responseMode: 'embed',
        embedTitle: '🎫 مركز التذاكر والدعم الفني | {server}',
        embedColor: '#8A2BE2',
        reply: 'أبشر يا {user}! إذا عندك أي استفسار أو شكوى أو طلب إداري، توجه فوراً إلى روم التذاكر واضغط زر فتح تذكرة وبيخدمونك المشرفين بعيونهم! 🛠️✨',
        autoReaction: '🎫',
        replyMode: 'reply',
        cooldownSec: 5,
        enabled: true
      },
      {
        id: `ar-sa-roles-${Date.now() + 4}`,
        trigger: 'رتب, الرتب, رتبة',
        matchType: 'smart',
        responseMode: 'embed',
        embedTitle: '🎭 نظام الرتب التفاعلية | {server}',
        embedColor: '#10b981',
        reply: 'تفضل يا {user}! يمكنك اختيار رتب الألعاب والإشعارات الخاصة بك بضغطة زر من لوحة الرتب التفاعلية في السيرفر ✨',
        autoReaction: '🎭',
        replyMode: 'reply',
        cooldownSec: 5,
        enabled: true
      }
    ];

    try {
      for (const r of readyRules) {
        const res = await fetch('/api/auto-responses', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ rule: r })
        });
        const data = await res.json();
        if (Array.isArray(data.autoResponses)) {
          setAutoResponses(data.autoResponses);
        }
      }
    } catch {
      setAutoResponses((prev) => [...readyRules, ...prev]);
    } finally {
      setLoadingSaudiPresets(false);
    }
  };

  const handleAddAutoResponse = async () => {
    if (!newTrigger.trim()) return;
    if (newResponseMode !== 'reaction' && !newReply.trim()) return;

    const parseCsv = (val: string) =>
      val
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

    const ruleEntry: AutoResponse = {
      id: editingRuleId || `ar-${Date.now()}`,
      trigger: newTrigger.trim(),
      matchType: newMatchType,
      responseMode: newResponseMode,
      reply: newReply.trim(),
      embedTitle: newEmbedTitle.trim() || undefined,
      embedColor: newEmbedColor || '#8A2BE2',
      embedImageUrl: newEmbedImageUrl.trim() || undefined,
      embedThumbnailUrl: newEmbedThumbnailUrl.trim() || undefined,
      buttonLabel: newButtonLabel.trim() || undefined,
      buttonUrl: newButtonUrl.trim() || undefined,
      autoReaction: newReaction.trim() || undefined,
      deleteTriggerMessage: newDeleteTrigger,
      replyMode: newReplyMode,
      cooldownSec: Math.max(0, Number(newCooldownSec) || 0),
      autoDeleteSec: Math.max(0, Number(newAutoDeleteSec) || 0),
      allowedChannels: parseCsv(newAllowedChannels),
      ignoredChannels: parseCsv(newIgnoredChannels),
      allowedRoles: parseCsv(newAllowedRoles),
      ignoredRoles: parseCsv(newIgnoredRoles),
      enabled: true
    };

    sound.playShieldActivate();
    setAutoResponses((prev) => {
      const idx = prev.findIndex((r) => r.id === ruleEntry.id);
      if (idx !== -1) {
        const copy = [...prev];
        copy[idx] = ruleEntry;
        return copy;
      }
      return [ruleEntry, ...prev];
    });

    try {
      const res = await fetch('/api/auto-responses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rule: ruleEntry })
      });
      const data = await res.json();
      if (Array.isArray(data.autoResponses)) {
        setAutoResponses(data.autoResponses);
      }
    } catch {
      // offline fallback
    }

    resetAutoResponseForm();
  };

  const handleDeleteAutoResponse = async (id: string) => {
    sound.playClick();
    setAutoResponses((prev) => prev.filter((a) => a.id !== id));
    try {
      const res = await fetch('/api/auto-responses/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      const data = await res.json();
      if (Array.isArray(data.autoResponses)) {
        setAutoResponses(data.autoResponses);
      }
    } catch {}
  };

  const handleToggleAutoResponse = async (id: string) => {
    sound.playClick();
    let nextState = true;
    setAutoResponses((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          nextState = !a.enabled;
          return { ...a, enabled: nextState };
        }
        return a;
      })
    );
    try {
      const res = await fetch('/api/auto-responses/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, enabled: nextState })
      });
      const data = await res.json();
      if (Array.isArray(data.autoResponses)) {
        setAutoResponses(data.autoResponses);
      }
    } catch {}
  };

  const handleJoinVoiceNow = async (channelNameOverride?: string, reciterOverride?: string) => {
    const ch = channelNameOverride || voice247.channelName || serverVoiceChannels[0]?.name || '🔊 المستمر';
    const reciterIdToUse = reciterOverride || selectedDropdownReciter || voice247.selectedReciter || 'alafasy';
    setVoiceLoading(true);
    setVoiceFeedback(null);
    sound.playShieldActivate();
    try {
      const token = localStorage.getItem('m7r_auth_token');
      const res = await fetch('/api/voice/join', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          channelName: ch,
          deafened: voice247.deafened,
          muted: voice247.muted,
          audioMode: voice247.audioMode === 'silent' ? 'quran' : (voice247.audioMode || 'quran'),
          selectedReciter: reciterIdToUse,
          scheduleEnabled: false
        })
      });
      const data = await res.json();
      setVoiceInChannel(Boolean(data.inVoice || data.success));
      setVoicePaused(false);
      setVoiceFeedback(data.message || (isAr ? '▶️ تم دخول الروم الصوتي وتثبيت البث المستمر بنجاح!' : '▶️ Joined voice channel & locked المستمر Quran stream!'));
      if (data.channelName) {
        setVoice247(prev => ({ ...prev, channelName: data.channelName, selectedReciter: reciterIdToUse, enabled: true }));
      }
      if (data.activeReciter) {
        setActiveReciter(data.activeReciter);
        setSelectedDropdownReciter(data.activeReciter.id);
      }
    } catch {
      setVoiceFeedback(isAr ? 'تعذر الاتصال بالروم الصوتي.' : 'Voice connection failed.');
    } finally {
      setVoiceLoading(false);
    }
  };

  const handleTogglePauseResume = async () => {
    sound.playClick();
    try {
      const token = localStorage.getItem('m7r_auth_token');
      const res = await fetch('/api/voice/control', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ action: 'toggle_pause' })
      });
      const data = await res.json();
      if (typeof data.paused === 'boolean') {
        setVoicePaused(data.paused);
      }
      setVoiceFeedback(data.message || (voicePaused ? '▶️ تم استئناف التلاوة' : '⏸️ تم إيقاف التلاوة مؤقتاً'));
    } catch {
      setVoiceFeedback('تعذر تنفيذ أمر الإيقاف المؤقت / الاستئناف.');
    }
  };

  const handleVolumeChange = async (newVol: number) => {
    const clamped = Math.max(0, Math.min(100, Math.round(newVol)));
    setVoiceVolume(clamped);
    try {
      const token = localStorage.getItem('m7r_auth_token');
      const res = await fetch('/api/voice/volume', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ volume: clamped })
      });
      const data = await res.json();
      if (data.message) {
        setVoiceFeedback(data.message);
      }
    } catch {
      // ignore transient slider error
    }
  };

  const handleSwitchReciter = async (reciterId: string) => {
    setSelectedDropdownReciter(reciterId);
    setReciterSwitching(reciterId);
    sound.playClick();
    try {
      const token = localStorage.getItem('m7r_auth_token');
      const res = await fetch('/api/voice/reciter/switch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ reciterId })
      });
      const data = await res.json();
      if (data.success) {
        sound.playShieldActivate();
        setVoicePaused(false);
        setVoice247(prev => ({ ...prev, selectedReciter: reciterId, scheduleEnabled: false }));
        if (data.activeReciter) setActiveReciter(data.activeReciter);
        setVoiceFeedback(data.message);
      } else {
        setVoiceFeedback(data.message || 'تعذر تبديل القارئ.');
      }
    } catch {
      setVoiceFeedback('فشل الاتصال بالخادم لتبديل القارئ.');
    } finally {
      setReciterSwitching(null);
    }
  };

  const handleSendQuranPanelToDiscord = async () => {
    setVoiceLoading(true);
    setVoiceFeedback(null);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/voice/send-quran-panel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ allServers: true })
      });
      const data = await res.json();
      setVoiceInChannel(true);
      setVoiceFeedback(
        data.message ||
          (isAr
            ? '🕋 تم إرسال لوحة تحكم القرآن الكريم التفاعلية (مع قائمة القراء وأزرار التحكم المستمر) إلى السيرفر!'
            : '🕋 Interactive Quran Control Panel sent to Discord!')
      );
    } catch {
      setVoiceFeedback(isAr ? 'تعذر إرسال لوحة تحكم القرآن إلى السيرفر.' : 'Failed to send Quran panel.');
    } finally {
      setVoiceLoading(false);
    }
  };

  const handleSaveSchedule = async (newSlots: QuranScheduleSlot[], enabled: boolean) => {
    setScheduleSaving(true);
    sound.playClick();
    try {
      const res = await fetch('/api/voice/schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scheduleEnabled: enabled,
          scheduleSlots: newSlots
        })
      });
      const data = await res.json();
      if (data.success) {
        sound.playShieldActivate();
        setScheduleSlots(data.scheduleSlots || newSlots);
        setVoice247(prev => ({ ...prev, scheduleEnabled: enabled }));
        if (data.activeReciter) setActiveReciter(data.activeReciter);
        setVoiceFeedback(data.message);
      }
    } catch {
      setVoiceFeedback('فشل حفظ جدول القراء.');
    } finally {
      setScheduleSaving(false);
    }
  };

  const handleLeaveVoiceNow = async () => {
    setVoiceLoading(true);
    setVoiceFeedback(null);
    sound.playClick();
    try {
      const token = localStorage.getItem('m7r_auth_token');
      const res = await fetch('/api/voice/leave', {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      const data = await res.json();
      setVoiceInChannel(false);
      setVoicePaused(false);
      setVoice247(prev => ({ ...prev, enabled: false }));
      setVoiceFeedback(data.message || (isAr ? '⏹️ تم إيقاف البث والخروج من الروم الصوتي بنجاح!' : '⏹️ Stopped & disconnected from voice!'));
    } catch {
      setVoiceFeedback(isAr ? 'حدث خطأ أثناء الخروج.' : 'Failed to leave voice.');
    } finally {
      setVoiceLoading(false);
    }
  };

  const handleVoiceChannelChange = (ch: string) => {
    setVoice247(prev => ({ ...prev, channelName: ch, enabled: true }));
    handleJoinVoiceNow(ch);
  };

  const handleApplyPreset = (trigger: string, reply: string, reaction?: string) => {
    setNewTrigger(trigger);
    setNewReply(reply);
    if (reaction) setNewReaction(reaction);
    sound.playClick();
  };

  const handleTestAutoResponse = async () => {
    if (!testInput.trim()) return;
    setIsTesting(true);
    sound.playClick();
    try {
      const res = await fetch('/api/auto-responses/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ testMessage: testInput })
      });
      const data = await res.json();
      setTestResult(data.simulatedReply);
    } catch {
      setTestResult(isAr ? 'فحص تجريبي: لم يتطابق أي رد.' : 'Test completed: No match.');
    } finally {
      setIsTesting(false);
    }
  };

  const [broadcastTargetChannel, setBroadcastTargetChannel] = useState('announcements');
  const [broadcastEveryone, setBroadcastEveryone] = useState(false);

  const handleSendBroadcast = async () => {
    sound.playShieldActivate();
    try {
      await fetch('/api/broadcast/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: embedTitle,
          description: embedDescription,
          channelName: broadcastTargetChannel,
          color: embedColor,
          mentionEveryone: broadcastEveryone
        })
      });
      setBroadcastSent(true);
      setTimeout(() => setBroadcastSent(false), 5000);
    } catch {
      setBroadcastSent(true);
      setTimeout(() => setBroadcastSent(false), 4000);
    }
  };


  const handleVote = (option: 'yes' | 'no') => {
    if (hasVoted) return;
    sound.playClick();
    setHasVoted(option);
    setPollVotes(prev => ({
      ...prev,
      [option]: prev[option] + 1
    }));
  };

  const totalVotes = pollVotes.yes + pollVotes.no;
  const yesPercent = Math.round((pollVotes.yes / totalVotes) * 100);
  const noPercent = 100 - yesPercent;

  return (
    <div className="space-y-6">
      {/* Header & Section Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            {quranOnly ? (
              <>
                <span className="text-2xl">🕌</span>
                <span className="bg-gradient-to-r from-emerald-400 via-teal-200 to-amber-400 bg-clip-text text-transparent">
                  {isAr ? 'لوحة تحكم القرآن الكريم المستمر (Holy Quran Radio & Player)' : 'المستمر Holy Quran Radio & Player Studio'}
                </span>
              </>
            ) : (
              <>
                <Sparkles className="w-6 h-6 text-rose-500" />
                {isAr ? 'الأنظمة الإضافية ولوحة القرآن الكريم المستمر' : 'Extended Guild Systems & المستمر Quran'}
              </>
            )}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {quranOnly
              ? (isAr
                  ? 'تحكم كامل ببث إذاعة وتلاوات القرآن الكريم المستمر في الرومات الصوتية مع معادل صوتي حي وتبديل فوري للقراء بدون تقطيع'
                  : 'Full المستمر Holy Quran voice streaming engine with live equalizer, instant reciter switching, and inline volume control')
              : (isAr
                  ? 'لوحة تحكم القرآن الكريم المستمر، نظام المستويات، الردود التلقائية، والإعلانات'
                  : 'المستمر Holy Quran Studio, XP & Leveling, Auto-Responses, and Announcements')}
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg flex items-center gap-2 transition-all shadow-md cursor-pointer shrink-0"
        >
          {savedSuccess ? <Check className="w-4 h-4 text-emerald-200" /> : <Save className="w-4 h-4" />}
          <span>{savedSuccess ? (isAr ? 'تم الحفظ!' : 'Saved!') : (isAr ? 'حفظ التعديلات' : 'Save Changes')}</span>
        </button>
      </div>

      {/* Segmented Sub Tabs */}
      {!quranOnly && (
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-[#0d1017] border border-slate-800 rounded-lg max-w-4xl">
          <button
            onClick={() => { setActiveSection('voice'); sound.playClick(); }}
            className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeSection === 'voice'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 inline-block mr-1.5 text-emerald-400" />
            {isAr ? '🕌 لوحة تحكم القرآن المستمر' : '🕌 Holy Quran المستمر'}
          </button>
          <button
            onClick={() => { setActiveSection('autoresponder'); sound.playClick(); }}
            className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeSection === 'autoresponder'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Bot className="w-3.5 h-3.5 inline-block mr-1.5" />
            {isAr ? '🤖 الرد التلقائي المحسن' : '🤖 Smart Auto-Responder'}
          </button>
          <button
            onClick={() => { setActiveSection('tempvoice'); sound.playClick(); }}
            className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeSection === 'tempvoice'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Mic className="w-3.5 h-3.5 inline-block mr-1.5 text-purple-400" />
            {isAr ? '🎙️ الرومات المؤقتة (TempVoice)' : '🎙️ TempVoice Pro'}
          </button>
          <button
            onClick={() => { setActiveSection('broadcasts'); sound.playClick(); }}
            className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeSection === 'broadcasts'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Megaphone className="w-3.5 h-3.5 inline-block mr-1.5" />
            {isAr ? 'الإعلانات والتصويت' : 'Broadcasts'}
          </button>
          <button
            onClick={() => { setActiveSection('levels'); sound.playClick(); }}
            className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeSection === 'levels'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Award className="w-3.5 h-3.5 inline-block mr-1.5" />
            {isAr ? 'المستويات (XP)' : 'XP & Levels'}
          </button>
        </div>
      )}

      {/* TEMPVOICE PRO SUB-SECTION */}
      {activeSection === 'tempvoice' && <TempVoiceTab lang={lang} />}

      {/* 1. XP & LEVELING */}
      {activeSection === 'levels' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">{isAr ? 'إعدادات نظام المستويات' : 'XP System Settings'}</h3>
                <p className="text-[11px] text-slate-400">{isAr ? 'منح الأعضاء نقاط وتصنيف عند التفاعل في الرومات' : 'Grant XP points per message in text channels'}</p>
              </div>
              <input
                type="checkbox"
                checked={levelsEnabled}
                onChange={(e) => setLevelsEnabled(e.target.checked)}
                className="w-4 h-4 accent-rose-600 rounded cursor-pointer"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-slate-300">{isAr ? 'مضاعف النقاط (XP Multiplier)' : 'XP Multiplier'}</span>
                <span className="font-mono text-rose-400 font-bold">{xpMultiplier}x</span>
              </div>
              <input
                type="range"
                min="1"
                max="3"
                step="0.5"
                value={xpMultiplier}
                onChange={(e) => setXpMultiplier(parseFloat(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer"
              />
            </div>

            <div>
              <ChannelSelector
                lang={lang}
                label={isAr ? 'تحديد روم إعلانات الترقية (Level Up Channel)' : 'Level Up Channel'}
                value={levelUpChannel}
                onChange={(ch) => setLevelUpChannel(ch)}
                placeholder="general"
              />
            </div>

            {/* Rank Card Preview */}
            <div className="pt-2">
              <span className="text-xs font-bold text-slate-300 block mb-2">{isAr ? 'معاينة كارت الرتبة (Rank Card):' : 'Rank Card Live Preview:'}</span>
              <div className="rounded-xl bg-gradient-to-r from-slate-950 via-[#13111c] to-[#1c0f16] border border-rose-900/40 p-4 space-y-3 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center font-bold text-white text-sm shadow-md">
                      SL
                    </div>
                    <div>
                      <span className="text-sm font-bold text-white block">Sultan_Leader</span>
                      <span className="text-[10px] text-slate-400 font-mono">#1902 • Rank #1</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-slate-400 block font-mono">LEVEL</span>
                    <span className="text-xl font-black text-rose-400 font-mono">52</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[10px] text-slate-400 font-mono mb-1">
                    <span>26,400 XP</span>
                    <span>28,000 XP</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden border border-slate-800">
                    <div className="w-[88%] h-full bg-gradient-to-r from-rose-600 to-amber-500 rounded-full" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Leaderboard */}
          <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-3">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-white">{isAr ? 'لوحة المتصدرين (Top 5 Leaderboard)' : 'Top Active Members'}</h3>
              <span className="text-xs font-mono text-rose-400">M7R XP System</span>
            </div>

            <div className="space-y-2">
              {topUsers.map((user) => (
                <div
                  key={user.rank}
                  className="flex items-center justify-between p-3 rounded-lg bg-slate-900/60 border border-slate-800 text-xs hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center font-mono font-bold text-xs ${
                      user.rank === 1
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : user.rank === 2
                        ? 'bg-slate-400/20 text-slate-200 border border-slate-400/40'
                        : user.rank === 3
                        ? 'bg-amber-700/20 text-amber-500 border border-amber-700/40'
                        : 'bg-slate-800 text-slate-400'
                    }`}>
                      {user.rank}
                    </span>
                    <div>
                      <span className="font-bold text-white block">{user.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{user.messagesCount} {isAr ? 'رسالة' : 'msgs'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block font-mono">{user.xp.toLocaleString()} XP</span>
                      <span className="text-xs font-mono font-bold text-rose-400">Lvl {user.level}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. ULTRA AUTO-RESPONDER PRO V2 (نظام الرد التلقائي الخارق والمطور) */}
      {activeSection === 'autoresponder' && (
        <div className="space-y-6">
          {/* 1-Click Ready Saudi Presets Header + Single Presets Bar */}
          <div className="rounded-2xl border border-purple-500/35 bg-gradient-to-r from-[#130f24] via-[#0d1017] to-[#1a0f26] p-5 space-y-3 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
              <div>
                <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>
                    {isAr
                      ? '⚡ نظام الرد التلقائي الخارق والمطور (Ultra Auto-Responder Pro V2)'
                      : '⚡ Ultra Auto-Responder Pro V2'}
                  </span>
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  {isAr
                    ? 'يدعم عدة كلمات مفتاحية بنفس القاعدة (مفصولة بفاصلة)، والتعرف الذكي على المد العربي (بااااك = باك)، وأزرار الروابط، والمعاينة الحية!'
                    : 'Supports comma-separated triggers, Arabic fuzzy matching, link buttons, and live Discord preview!'}
                </p>
              </div>

              <button
                type="button"
                onClick={handleLoadReadySaudiPresets}
                disabled={loadingSaudiPresets}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white text-xs font-black flex items-center gap-2 shadow-lg cursor-pointer transition-all shrink-0"
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  {loadingSaudiPresets
                    ? isAr
                      ? 'جاري إضافة الردود الجاهزة...'
                      : 'Adding Presets...'
                    : isAr
                    ? '⚡ إضافة الردود التلقائية الأساسية بضغطة زر (بدون حذف القديم)'
                    : '⚡ 1-Click Add Essential Saudi Presets'}
                </span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2 pt-1">
              {[
                {
                  label: isAr ? '👋 السلام عليكم, سلام' : '👋 Greeting',
                  trigger: 'السلام عليكم, سلام, السلام',
                  reply: 'وعليكم السلام ورحمة الله وبركاته يا {user}! أهلاً بك في سيرفر **{server}** 🌸 (عدد الأعضاء: `{memberCount}`)',
                  reaction: '🤍'
                },
                {
                  label: isAr ? '🔥 باك, بااك' : '🔥 Welcome Back',
                  trigger: 'باك, بااك, احلى باك',
                  reply: 'ولكمووو أحلى باك يا {user} نورت الروم! 🔥💜',
                  reaction: '🔥'
                },
                {
                  label: isAr ? '👋 برب, بررب' : '👋 BRB',
                  trigger: 'برب, بررب',
                  reply: 'تيت يا الغالي {user}، لا تطول علينا! 🤍✨',
                  reaction: '👋'
                },
                {
                  label: isAr ? '🎫 تكت, شكوى, مساعدة' : '🎫 Ticket Help',
                  trigger: 'تكت, شكوى, مساعدة',
                  reply: 'أبشر يا {user}! توجه إلى روم التذاكر واضغط زر فتح تذكرة وبيخدمونك المشرفين فوراً 🛠️✨',
                  reaction: '🎫'
                },
                {
                  label: isAr ? '🎭 رتب, الرتب' : '🎭 Reaction Roles',
                  trigger: 'رتب, الرتب',
                  reply: '🎭 تفضل يا {user} باختيار رتب الألعاب والإشعارات الخاصة بك بضغطة زر في روم الرتب التفاعلية بسيرفر **{server}** ✨',
                  reaction: '🎭'
                }
              ].map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleApplyPreset(preset.trigger, preset.reply, preset.reaction)}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-rose-950/40 border border-slate-800 hover:border-rose-500/50 text-xs text-slate-300 hover:text-white transition-all cursor-pointer font-medium flex items-center gap-1.5"
                >
                  <Plus className="w-3 h-3 text-rose-400" />
                  <span>{preset.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Creator / Editor Box */}
            <div className="lg:col-span-6 rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Bot className="w-4 h-4 text-rose-400" />
                  <span>
                    {editingRuleId
                      ? isAr
                        ? '✏️ تعديل الرد التلقائي المطور'
                        : '✏️ Edit Ultra Auto-Responder'
                      : isAr
                      ? '➕ إنشاء رد تلقائي ذكي جديد (يدعم عدة كلمات بفاصلة)'
                      : '➕ Create Ultra Auto-Responder Rule'}
                  </span>
                </h3>
                {editingRuleId && (
                  <button
                    type="button"
                    onClick={resetAutoResponseForm}
                    className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إلغاء التعديل' : 'Cancel Edit'}</span>
                  </button>
                )}
              </div>

              <div className="space-y-3.5 text-xs">
                {/* Multi-Keyword Trigger */}
                <div>
                  <label className="text-slate-300 block mb-1 font-bold">
                    {isAr
                      ? 'الكلمات المفتاحية (افصل بين عدة كلمات بفاصلة , أو ،):'
                      : 'Trigger Keywords (comma-separated):'}
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: السلام عليكم, سلام, السلام  أو  باك, بااك"
                    value={newTrigger}
                    onChange={(e) => setNewTrigger(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 focus:border-rose-500 rounded-lg p-2.5 text-white transition-colors"
                  />
                </div>

                {/* 5 Match Types including Smart Fuzzy */}
                <div>
                  <label className="text-slate-300 block mb-1 font-bold">
                    {isAr ? 'نظام المطابقة الذكي (Match Engine):' : 'Match Type:'}
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                    {[
                      { id: 'smart', label: isAr ? '🧠 ذكي (يمسك المد)' : '🧠 Smart Fuzzy' },
                      { id: 'contains', label: isAr ? 'يحتوي الكلمة' : 'Contains' },
                      { id: 'exact', label: isAr ? 'تطابق تام' : 'Exact' },
                      { id: 'starts_with', label: isAr ? 'يبدأ بـ' : 'Starts With' },
                      { id: 'regex', label: 'Regex ⚙️' }
                    ].map((mt) => (
                      <button
                        key={mt.id}
                        type="button"
                        onClick={() => setNewMatchType(mt.id as any)}
                        className={`p-2 rounded-lg border text-center cursor-pointer transition-all text-[11px] ${
                          newMatchType === mt.id
                            ? 'bg-rose-950/60 border-rose-500 text-rose-200 font-bold'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {mt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 4 Response Modes */}
                <div>
                  <label className="text-slate-300 block mb-1 font-bold">
                    {isAr ? 'نمط استجابة البوت (Response Mode):' : 'Response Mode:'}
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'text', label: isAr ? '💬 نص مباشر' : '💬 Text' },
                      { id: 'embed', label: isAr ? '💎 إيمبد فخم' : '💎 Rich Embed' },
                      { id: 'button', label: isAr ? '🔗 رد + زر تفاعلي' : '🔗 Embed + Button' },
                      { id: 'reaction', label: isAr ? '❤️ إيموجي فقط' : '❤️ Reaction Only' }
                    ].map((rm) => (
                      <button
                        key={rm.id}
                        type="button"
                        onClick={() => setNewResponseMode(rm.id as any)}
                        className={`p-2 rounded-lg border text-center cursor-pointer transition-all text-[11px] ${
                          newResponseMode === rm.id
                            ? 'bg-purple-950/60 border-purple-500 text-purple-200 font-bold'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {rm.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Embed Customization when responseMode === 'embed' or 'button' */}
                {(newResponseMode === 'embed' || newResponseMode === 'button') && (
                  <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-500/30 space-y-2.5">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div className="sm:col-span-2">
                        <label className="text-[11px] text-purple-300 font-bold block mb-1">
                          {isAr ? 'عنوان الإيمبد (Embed Title):' : 'Embed Title:'}
                        </label>
                        <input
                          type="text"
                          value={newEmbedTitle}
                          onChange={(e) => setNewEmbedTitle(e.target.value)}
                          placeholder="مثال: 🎫 مركز خدمة أعضاء {server}"
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-purple-300 font-bold block mb-1">
                          {isAr ? 'لون الإيمبد:' : 'Color:'}
                        </label>
                        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-lg p-1.5">
                          <input
                            type="color"
                            value={newEmbedColor}
                            onChange={(e) => setNewEmbedColor(e.target.value)}
                            className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                          />
                          <span className="font-mono text-[10px] text-slate-300">{newEmbedColor}</span>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="text-[11px] text-purple-300 font-bold block mb-1">
                          {isAr ? 'رابط صورة الإيمبد (Banner URL):' : 'Embed Banner URL:'}
                        </label>
                        <input
                          type="text"
                          value={newEmbedImageUrl}
                          onChange={(e) => setNewEmbedImageUrl(e.target.value)}
                          placeholder="https://..."
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono text-[11px]"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-purple-300 font-bold block mb-1">
                          {isAr ? 'صورة مصغرة (Thumbnail URL):' : 'Thumbnail URL:'}
                        </label>
                        <input
                          type="text"
                          value={newEmbedThumbnailUrl}
                          onChange={(e) => setNewEmbedThumbnailUrl(e.target.value)}
                          placeholder="https://..."
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono text-[11px]"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Link Button Fields when responseMode === 'button' or user wants a button */}
                {newResponseMode === 'button' && (
                  <div className="p-3 rounded-xl bg-sky-950/20 border border-sky-500/30 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[11px] text-sky-300 font-bold block mb-1">
                        {isAr ? 'نص الزر التفاعلي (Button Label):' : 'Button Label:'}
                      </label>
                      <input
                        type="text"
                        value={newButtonLabel}
                        onChange={(e) => setNewButtonLabel(e.target.value)}
                        placeholder="مثال: 🎫 اضغط هنا لفتح تذكرة"
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-sky-300 font-bold block mb-1">
                        {isAr ? 'رابط الزر (أو اتركه لفتح الروم):' : 'Button Link URL:'}
                      </label>
                      <input
                        type="text"
                        value={newButtonUrl}
                        onChange={(e) => setNewButtonUrl(e.target.value)}
                        placeholder="https://discord.com/channels/..."
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono text-[11px]"
                      />
                    </div>
                  </div>
                )}

                {/* Reply Content + Smart Variables */}
                {newResponseMode !== 'reaction' && (
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-300 font-bold">
                        {isAr ? 'نص الرد التلقائي (Reply Message):' : 'Bot Reply Message:'}
                      </label>
                      <span className="text-[10px] text-slate-400">
                        {isAr ? 'اضغط المتغير الذكي لإدراجه:' : 'Click smart variable:'}
                      </span>
                    </div>
                    <textarea
                      rows={3}
                      placeholder="وعليكم السلام يا {user}! أهلاً بك في {server} (الأعضاء: {memberCount})..."
                      value={newReply}
                      onChange={(e) => setNewReply(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 focus:border-rose-500 rounded-lg p-2.5 text-white transition-colors"
                    />
                    <div className="flex flex-wrap gap-1.5 pt-1.5">
                      {[
                        { tag: '{user}', label: isAr ? 'منشن العضو' : 'Mention User' },
                        { tag: '{username}', label: isAr ? 'اسم العضو' : 'Username' },
                        { tag: '{server}', label: isAr ? 'اسم السيرفر' : 'Server Name' },
                        { tag: '{memberCount}', label: isAr ? 'عدد الأعضاء' : 'Member Count' },
                        { tag: '{channel}', label: isAr ? 'الروم الحالي' : 'Current Channel' }
                      ].map((v) => (
                        <button
                          key={v.tag}
                          type="button"
                          onClick={() => setNewReply((prev) => `${prev}${prev.endsWith(' ') || !prev ? '' : ' '}${v.tag} `)}
                          className="px-2 py-1 rounded-md bg-slate-900 hover:bg-rose-950/60 border border-slate-800 hover:border-rose-500/40 text-slate-200 font-mono text-[10px] cursor-pointer flex items-center gap-1"
                          title={v.label}
                        >
                          <span className="text-rose-400">{v.tag}</span>
                          <span className="text-slate-400 font-sans">({v.label})</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Emoji Reaction, Cooldown & Auto-Delete Timer */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="text-slate-300 block mb-1 font-bold text-[11px]">
                      {isAr ? 'تفاعل إيموجي تلقائي:' : 'Auto Reaction:'}
                    </label>
                    <input
                      type="text"
                      placeholder="❤️ أو 🛡️ أو ✅"
                      value={newReaction}
                      onChange={(e) => setNewReaction(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1 font-bold text-[11px]">
                      {isAr ? 'الانتظار (Cooldown ث):' : 'Cooldown (sec):'}
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={3600}
                      value={newCooldownSec}
                      onChange={(e) => setNewCooldownSec(Math.max(0, parseInt(e.target.value, 10) || 0))}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1 font-bold text-[11px]">
                      {isAr ? 'حذف رد البوت بعد (ث):' : 'Auto-Delete Reply (s):'}
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={300}
                      value={newAutoDeleteSec}
                      onChange={(e) => setNewAutoDeleteSec(Math.max(0, parseInt(e.target.value, 10) || 0))}
                      placeholder="0 = بدون حذف"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                    />
                  </div>
                </div>

                {/* Advanced Controls: Delete Trigger & Reply vs Send */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-slate-200">
                      {isAr ? '🗑️ حذف رسالة العضو تلقائياً عند التطابق' : '🗑️ Delete Trigger Message'}
                    </span>
                    <input
                      type="checkbox"
                      checked={newDeleteTrigger}
                      onChange={(e) => setNewDeleteTrigger(e.target.checked)}
                      className="w-4 h-4 accent-rose-600 rounded cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                    <span className="text-[11px] font-bold text-slate-200">
                      {isAr ? '↩️ طريقة الإرسال في الروم:' : '↩️ Delivery Mode:'}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setNewReplyMode('reply')}
                        className={`px-2.5 py-1 rounded text-[10px] font-bold cursor-pointer ${
                          newReplyMode === 'reply'
                            ? 'bg-rose-600 text-white'
                            : 'bg-slate-900 text-slate-400 border border-slate-800'
                        }`}
                      >
                        {isAr ? 'رد مباشر (Reply)' : 'Direct Reply'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewReplyMode('send')}
                        className={`px-2.5 py-1 rounded text-[10px] font-bold cursor-pointer ${
                          newReplyMode === 'send'
                            ? 'bg-rose-600 text-white'
                            : 'bg-slate-900 text-slate-400 border border-slate-800'
                        }`}
                      >
                        {isAr ? 'إرسال عام (Send)' : 'Channel Send'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Live Discord Preview Box */}
                <div className="p-3.5 rounded-xl bg-[#313338] border border-slate-700/80 space-y-2">
                  <div className="flex items-center justify-between text-[10px] text-slate-300 font-bold">
                    <span>👁️ {isAr ? 'معاينة حية لشكل الرد داخل ديسكورد (Live Discord Preview):' : 'Live Discord Preview:'}</span>
                    {newReaction && <span className="px-1.5 py-0.5 rounded bg-[#2b2d31]">{newReaction}</span>}
                  </div>
                  <div className="flex items-start gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white font-black text-xs shrink-0">
                      M7R
                    </div>
                    <div className="flex-1 space-y-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">M7R PRO</span>
                        <span className="px-1 py-0.2 rounded bg-[#5865F2] text-[9px] font-bold text-white">APP</span>
                      </div>

                      {newResponseMode === 'embed' || newResponseMode === 'button' ? (
                        <div
                          className="p-3 rounded-md bg-[#2b2d31] border-l-4 space-y-1"
                          style={{ borderLeftColor: newEmbedColor || '#8A2BE2' }}
                        >
                          {newEmbedTitle && (
                            <div className="text-xs font-bold text-white">
                              {newEmbedTitle.replace(/\{server\}/gi, 'M7R Server')}
                            </div>
                          )}
                          <div className="text-[11px] text-slate-200 whitespace-pre-wrap">
                            {(newReply || 'اكتب نص الرد التلقائي لرؤية المعاينة الحية هنا...')
                              .replace(/\{user\}/gi, '@u5r9')
                              .replace(/\{username\}/gi, 'u5r9')
                              .replace(/\{server\}/gi, 'M7R Server')
                              .replace(/\{memberCount\}/gi, '1,250')
                              .replace(/\{channel\}/gi, '#general')}
                          </div>
                        </div>
                      ) : newResponseMode === 'reaction' ? (
                        <div className="text-[11px] text-slate-300 italic">
                          {isAr ? `سيكتفي البوت بوضع الريأكشن (${newReaction || '❤️'}) على رسالة العضو.` : 'Bot will react with emoji only.'}
                        </div>
                      ) : (
                        <div className="text-xs text-slate-100 whitespace-pre-wrap">
                          {(newReply || 'اكتب نص الرد التلقائي لرؤية المعاينة الحية هنا...')
                            .replace(/\{user\}/gi, '@u5r9')
                            .replace(/\{username\}/gi, 'u5r9')
                            .replace(/\{server\}/gi, 'M7R Server')
                            .replace(/\{memberCount\}/gi, '1,250')
                            .replace(/\{channel\}/gi, '#general')}
                        </div>
                      )}

                      {newButtonLabel && (
                        <div className="pt-1">
                          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#4e5058] text-white text-[11px] font-semibold">
                            <span>{newButtonLabel}</span>
                            <span>↗</span>
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Allowed / Ignored Channels & Roles */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold block mb-1">
                      {isAr ? 'الرومات المسموحة فقط (اختياري، افصل بفاصلة):' : 'Allowed Channels:'}
                    </label>
                    <input
                      type="text"
                      value={newAllowedChannels}
                      onChange={(e) => setNewAllowedChannels(e.target.value)}
                      placeholder="general, شات-عام"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-[11px] text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold block mb-1">
                      {isAr ? 'الرومات المستثناة (Ignored Channels):' : 'Ignored Channels:'}
                    </label>
                    <input
                      type="text"
                      value={newIgnoredChannels}
                      onChange={(e) => setNewIgnoredChannels(e.target.value)}
                      placeholder="announcements, قوانين"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-[11px] text-white"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleAddAutoResponse}
                  className="w-full py-2.5 bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white rounded-xl font-black flex items-center justify-center gap-2 cursor-pointer shadow-lg transition-all"
                >
                  {editingRuleId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  <span>
                    {editingRuleId
                      ? isAr
                        ? 'حفظ تعديلات الرد التلقائي ✨'
                        : 'Update Auto-Responder Rule ✨'
                      : isAr
                      ? 'إضافة وتفعيل الرد التلقائي فوراً 🚀'
                      : 'Add & Enable Auto-Responder 🚀'}
                  </span>
                </button>
              </div>
            </div>

            {/* List of Active Responses & Live Test Simulator */}
            <div className="lg:col-span-6 space-y-4">
              <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    <span>
                      {isAr ? 'قائمة الردود التلقائية المفعلة في السيرفر' : 'Server Auto-Responders'} ({autoResponses.length})
                    </span>
                  </h3>
                  <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
                    {isAr ? '⚡ متزامنة مع ديسكورد فوراً' : 'Real-Time Discord Sync'}
                  </span>
                </div>

                <div className="space-y-2.5 max-h-[540px] overflow-y-auto pr-1">
                  {autoResponses.map((item) => {
                    const matchBadge =
                      item.matchType === 'smart'
                        ? isAr
                          ? '🧠 ذكي (يمسك المد)'
                          : '🧠 Smart'
                        : item.matchType === 'exact'
                        ? isAr
                          ? 'تطابق تام'
                          : 'Exact'
                        : item.matchType === 'starts_with'
                        ? isAr
                          ? 'يبدأ بـ'
                          : 'Starts With'
                        : item.matchType === 'regex'
                        ? 'Regex ⚙️'
                        : isAr
                        ? 'يحتوي الكلمة'
                        : 'Contains';

                    const modeBadge =
                      item.responseMode === 'button'
                        ? '🔗 Embed + Button'
                        : item.responseMode === 'embed'
                        ? '💎 Embed'
                        : item.responseMode === 'reaction'
                        ? '❤️ Reaction'
                        : '💬 Text';

                    return (
                      <div
                        key={item.id}
                        className={`p-3.5 rounded-xl border text-xs space-y-2 transition-all ${
                          item.enabled
                            ? 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                            : 'bg-slate-950/40 border-slate-900 opacity-60'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleToggleAutoResponse(item.id)}
                              className={`w-8 h-4 rounded-full transition-colors relative cursor-pointer ${
                                item.enabled ? 'bg-emerald-600' : 'bg-slate-700'
                              }`}
                              title={isAr ? 'تفعيل / إيقاف مؤقت' : 'Toggle Active/Paused'}
                            >
                              <span
                                className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform ${
                                  item.enabled ? 'right-0.5' : 'left-0.5'
                                }`}
                              />
                            </button>
                            <span className="font-black text-rose-400 font-mono text-xs">"{item.trigger}"</span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold">
                              {matchBadge}
                            </span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950/60 border border-purple-500/30 text-purple-300 font-bold">
                              {modeBadge}
                            </span>
                            {item.cooldownSec ? (
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-amber-300 font-mono">
                                ⏱️ {item.cooldownSec}s
                              </span>
                            ) : null}
                            {item.autoDeleteSec ? (
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-950/60 text-rose-300 font-mono">
                                ⏳ يحذف بعد {item.autoDeleteSec}s
                              </span>
                            ) : null}
                          </div>

                          <div className="flex items-center gap-1.5">
                            {item.autoReaction && (
                              <span className="bg-slate-800 px-2 py-0.5 rounded text-xs">{item.autoReaction}</span>
                            )}
                            <button
                              type="button"
                              onClick={() => handleEditAutoResponse(item)}
                              className="text-slate-400 hover:text-sky-400 cursor-pointer p-1.5 rounded bg-slate-950 border border-slate-800"
                              title={isAr ? 'تعديل الرد' : 'Edit'}
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteAutoResponse(item.id)}
                              className="text-slate-400 hover:text-red-400 cursor-pointer p-1.5 rounded bg-slate-950 border border-slate-800"
                              title={isAr ? 'حذف الرد' : 'Delete'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {item.responseMode !== 'reaction' && (
                          <div
                            className={`text-slate-200 font-sans leading-relaxed text-[11px] bg-slate-950/70 p-2.5 rounded-lg border ${
                              item.responseMode === 'embed' || item.responseMode === 'button'
                                ? 'border-l-4 border-slate-800'
                                : 'border-slate-800/60'
                            }`}
                            style={
                              item.responseMode === 'embed' || item.responseMode === 'button'
                                ? { borderLeftColor: item.embedColor || '#8A2BE2' }
                                : undefined
                            }
                          >
                            {(item.responseMode === 'embed' || item.responseMode === 'button') && item.embedTitle && (
                              <div className="font-bold text-white mb-1">{item.embedTitle}</div>
                            )}
                            <p>{item.reply}</p>
                            {item.buttonLabel && (
                              <div className="mt-1.5">
                                <span className="inline-block px-2 py-0.5 rounded bg-slate-800 text-sky-300 text-[10px] font-bold">
                                  🔗 {item.buttonLabel}
                                </span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Test Simulator Console */}
              <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-4 space-y-3">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
                  <Play className="w-3.5 h-3.5 text-sky-400" />
                  {isAr
                    ? 'صندوق تجربة الرد التلقائي والمطابقة العربية الذكية (جرب مثلاً: بااااك أو السلاااام عليكم):'
                    : 'Auto-Response Test Sandbox:'}
                </span>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={testInput}
                    onChange={(e) => setTestInput(e.target.value)}
                    placeholder={isAr ? 'اكتب رسالة تجريبية (مثال: بااااك، السلاااام عليكم، متجر)...' : 'Type test message...'}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={handleTestAutoResponse}
                    disabled={isTesting}
                    className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-lg cursor-pointer transition-colors shrink-0"
                  >
                    {isTesting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : isAr ? 'اختبار الرد 🧪' : 'Test Reply 🧪'}
                  </button>
                </div>
                {testResult && (
                  <div className="p-3 rounded-lg bg-sky-950/30 border border-sky-500/30 text-xs text-sky-200">
                    <span className="font-bold block text-[10px] text-sky-400 mb-0.5">
                      {isAr ? 'رد البوت المتوقع بعد تعويض المتغيرات الذكية:' : 'Bot Reply Simulation:'}
                    </span>
                    <p className="leading-relaxed">{testResult}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. BROADCASTS & POLLS */}
      {activeSection === 'broadcasts' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Embed Creator */}
          <div className="lg:col-span-6 rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-rose-400" />
              {isAr ? 'صانع الإعلانات الرسمية (Rich Embed Broadcast)' : 'Announcement Broadcast Designer'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1">{isAr ? 'عنوان الإعلان' : 'Title'}</label>
                <input
                  type="text"
                  value={embedTitle}
                  onChange={(e) => setEmbedTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">{isAr ? 'محتوى الإعلان' : 'Description'}</label>
                <textarea
                  rows={3}
                  value={embedDescription}
                  onChange={(e) => setEmbedDescription(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <ChannelSelector
                    lang={lang}
                    compact={true}
                    label={isAr ? 'تحديد الروم المستهدف للإعلان' : 'Target Channel'}
                    value={broadcastTargetChannel}
                    onChange={(ch) => setBroadcastTargetChannel(ch)}
                    placeholder="announcements"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1">{isAr ? 'لون الإيمبد' : 'Embed Color'}</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={embedColor}
                      onChange={(e) => setEmbedColor(e.target.value)}
                      className="w-8 h-8 rounded cursor-pointer bg-transparent border-0"
                    />
                    <span className="font-mono text-slate-300 text-xs">{embedColor}</span>
                  </div>
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={broadcastEveryone}
                  onChange={(e) => setBroadcastEveryone(e.target.checked)}
                  className="w-4 h-4 accent-rose-600 rounded"
                />
                <span>{isAr ? 'إرسال منشن جماعي (@everyone)' : 'Mention @everyone'}</span>
              </label>

              <button
                onClick={handleSendBroadcast}
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all"
              >
                <Send className="w-4 h-4" />
                <span>{isAr ? `إرسال ونشر الإعلان في #${broadcastTargetChannel} 📢` : `Broadcast to #${broadcastTargetChannel}`}</span>
              </button>

              {broadcastSent && (
                <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs text-center">
                  {isAr ? '✅ تم بث الإعلان بنجاح لجميع أعضاء السيرفر!' : 'Broadcast successfully sent!'}
                </div>
              )}
            </div>
          </div>

          {/* Discord Live Preview & Poll */}
          <div className="lg:col-span-6 space-y-5">
            {/* Embed Preview */}
            <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-3">
              <span className="text-xs font-bold text-slate-400 block">{isAr ? 'معاينة الإعلان في ديسكورد:' : 'Discord Embed Preview:'}</span>
              <div 
                className="rounded-lg bg-[#2b2d31] p-4 text-slate-100 space-y-2 border-l-4"
                style={{ borderLeftColor: embedColor }}
              >
                <h4 className="font-bold text-sm text-white">{embedTitle}</h4>
                <p className="text-xs text-slate-300 leading-relaxed">{embedDescription}</p>
                <div className="pt-2 text-[10px] text-slate-400 font-mono">
                  M7R Security Bot • Today at {new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>

            {/* Interactive Poll */}
            <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Vote className="w-4 h-4 text-amber-400" />
                  {isAr ? 'تصويت مجتمعي مباشر (Live Poll)' : 'Interactive Poll'}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">{totalVotes} {isAr ? 'صوت' : 'votes'}</span>
              </div>

              <p className="text-xs text-slate-200 font-medium">{pollQuestion}</p>

              <div className="space-y-2 pt-1">
                <button
                  onClick={() => handleVote('yes')}
                  className="w-full text-left p-2.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors cursor-pointer"
                >
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-medium text-slate-200">🟢 {isAr ? 'نعم، مؤيد بشدة' : 'Yes, strongly support'}</span>
                    <span className="font-mono text-emerald-400">{yesPercent}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full transition-all" style={{ width: `${yesPercent}%` }} />
                  </div>
                </button>

                <button
                  onClick={() => handleVote('no')}
                  className="w-full text-left p-2.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors cursor-pointer"
                >
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-medium text-slate-200">🔴 {isAr ? 'لا، غير مؤيد' : 'No, oppose'}</span>
                    <span className="font-mono text-red-400">{noPercent}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-red-500 rounded-full transition-all" style={{ width: `${noPercent}%` }} />
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. LUXURY المستمر HOLY QURAN CONTROL PANEL (WEB DASHBOARD + BOT VOICE ENGINE) */}
      {(activeSection === 'voice' || quranOnly) && (
        <div className="max-w-4xl mx-auto rounded-2xl border border-emerald-500/40 bg-gradient-to-br from-[#071512] via-[#0d1218] to-[#171209] p-6 sm:p-8 space-y-6 shadow-[0_0_45px_rgba(16,185,129,0.14)] animate-fade-in">
          {/* Top Luxury Islamic Header with Glowing Emblem & Animated CSS Equalizer Wave */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 pb-5 border-b border-emerald-500/20">
            <div className="flex items-start sm:items-center gap-4">
              {/* Spinning / Pulsing Glowing Islamic Emblem */}
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500/25 via-emerald-900/40 to-amber-500/25 border border-amber-400/50 flex items-center justify-center text-2xl shrink-0 quran-emblem-glow">
                🕌
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-lg font-black text-white tracking-tight">
                    {isAr
                      ? '🕌 لوحة تحكم القرآن الكريم المستمر (Holy Quran Radio & Player)'
                      : '🕌 المستمر Holy Quran Radio & Voice Player'}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-md text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-400/40">
                    المستمر STAY LOCK
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {isAr
                    ? 'نظام بث إذاعي وتلاوات خاشعة المستمر عبر محرك @discordjs/voice مع إعادة اتصال تلقائي وتبديل فوري للقراء بدون انقطاع.'
                    : 'Continuous المستمر Holy Quran streaming powered by @discordjs/voice with auto-reconnect and seamless live reciter switching.'}
                </p>
              </div>
            </div>

            {/* Animated CSS Audio Equalizer Wave (Active when streaming) */}
            <div className="flex items-center gap-3 self-end md:self-center bg-[#060d0b]/90 border border-emerald-500/30 px-4 py-2.5 rounded-xl">
              <div className="flex items-end gap-1 h-7 w-20 justify-center">
                {[0.1, 0.25, 0.4, 0.15, 0.35, 0.5, 0.2, 0.45, 0.3, 0.18].map((delay, i) => {
                  const isStreamingActive = voiceInChannel && !voicePaused;
                  return (
                    <span
                      key={i}
                      style={{
                        animationDelay: `${delay}s`,
                        height: isStreamingActive ? '100%' : '22%'
                      }}
                      className={`w-1.5 rounded-t-sm transition-all duration-300 ${
                        isStreamingActive
                          ? i % 2 === 0
                            ? 'bg-emerald-400 quran-eq-bar'
                            : 'bg-amber-400 quran-eq-bar'
                          : 'bg-slate-700'
                      }`}
                    />
                  );
                })}
              </div>
              <div className="text-right">
                <span className="text-[10px] font-mono uppercase tracking-wider block text-amber-400 font-bold">
                  {voiceInChannel && !voicePaused
                    ? (isAr ? 'يبث الآن 🔊' : 'STREAMING')
                    : voiceInChannel && voicePaused
                    ? (isAr ? 'متوقف مؤقتاً ⏸️' : 'PAUSED')
                    : (isAr ? 'في الانتظار' : 'STANDBY')}
                </span>
                <span className="text-[11px] font-mono text-emerald-300 font-bold">
                  {voiceVolume}% VOL
                </span>
              </div>
            </div>
          </div>

          {/* 5. LIVE STATUS BAR */}
          <div
            className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all ${
              voiceInChannel
                ? 'bg-emerald-950/50 border-emerald-500/50 text-emerald-200 shadow-[0_0_25px_rgba(16,185,129,0.15)]'
                : 'bg-slate-900/90 border-slate-800 text-slate-400'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="relative flex items-center justify-center shrink-0">
                <span
                  className={`w-3.5 h-3.5 rounded-full ${
                    voiceInChannel ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'
                  }`}
                />
                <span
                  className={`absolute w-3 h-3 rounded-full ${
                    voiceInChannel ? 'bg-emerald-400' : 'bg-slate-400'
                  }`}
                />
              </div>
              <div>
                <span className="text-xs sm:text-sm font-black block text-white">
                  {voiceInChannel
                    ? isAr
                      ? `🟢 متصل ويبث الآن في: [${voice247.channelName || 'الروم الصوتي'}] | القارئ: [${activeReciter?.name || 'الشيخ مشاري راشد العفاسي'}]`
                      : `🟢 Connected & Streaming in: [${voice247.channelName}] | Reciter: [${activeReciter?.nameEn || activeReciter?.name}]`
                    : isAr
                    ? '⚪ غير متصل حالياً'
                    : '⚪ Currently Disconnected'}
                </span>
                <span className="text-[11px] text-slate-300 mt-0.5 block">
                  {voiceInChannel
                    ? voicePaused
                      ? isAr
                        ? '⏸️ البث متوقف مؤقتاً — اضغط (إيقاف مؤقت / استئناف) لمواصلة التلاوة'
                        : '⏸️ Stream is paused — click Pause/Resume to continue'
                      : isAr
                      ? '🔒 تثبيت المستمر مفعل: سيعيد البوت تشغيل التلاوة تلقائياً عند انتهاء السورة أو انقطاع الشبكة'
                      : '🔒 المستمر Lock Active: Auto-restarts stream on completion or network drop'
                    : isAr
                    ? 'اختر الروم الصوتي والقارئ بالأسفل ثم اضغط (▶️ تشغيل وتثبيت المستمر)'
                    : 'Select a voice channel and reciter below then click Start & Lock المستمر'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={fetchVoiceStatus}
              className="px-3 py-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors self-end sm:self-center shrink-0"
              title={isAr ? 'تحديث الحالة' : 'Refresh'}
            >
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isAr ? 'تحديث' : 'Sync'}</span>
            </button>
          </div>

          {/* Instant Action Feedback Toast */}
          {voiceFeedback && (
            <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-amber-400/40 text-xs text-amber-200 font-bold flex items-center gap-2 animate-fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{voiceFeedback}</span>
            </div>
          )}

          {/* 1 & 2: VOICE CHANNEL SELECTOR (<select>) + RECITER / BROADCAST STATION SELECTOR (<select>) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 1. Dynamic Voice Channel Selector */}
            <div className="p-4 rounded-xl bg-[#091310]/90 border border-emerald-500/30 space-y-2.5">
              <label className="text-xs font-black text-emerald-300 flex items-center justify-between">
                <span>{isAr ? '1️⃣ اختر الروم الصوتي (Voice Channel Selector):' : '1️⃣ Select Server Voice Channel:'}</span>
                <span className="text-[10px] font-mono text-amber-400">GuildVoice</span>
              </label>

              <select
                value={voice247.channelName}
                onChange={(e) => {
                  const chosen = e.target.value;
                  setVoice247(prev => ({ ...prev, channelName: chosen, enabled: true }));
                }}
                className="w-full bg-[#0d1815] hover:bg-[#11211c] border border-emerald-500/40 focus:border-amber-400 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white cursor-pointer focus:outline-none transition-colors"
              >
                {serverVoiceChannels.length > 0 ? (
                  serverVoiceChannels.map((vc) => (
                    <option key={vc.id} value={vc.name}>
                      🔊 {vc.name}
                    </option>
                  ))
                ) : (
                  <>
                    {voice247.channelName && (
                      <option value={voice247.channelName}>🔊 {voice247.channelName}</option>
                    )}
                    <option value="🕌・إذاعة-القرآن-الكريم">🔊 🕌・إذاعة-القرآن-الكريم</option>
                    <option value="🔊 المستمر | خلوة وتلاوات عطرة">🔊 المستمر | خلوة وتلاوات عطرة</option>
                    <option value="General Voice">🔊 General Voice</option>
                  </>
                )}
              </select>

              <div className="pt-1">
                <ChannelSelector
                  lang={lang}
                  type="voice"
                  compact={true}
                  label={isAr ? 'أو ابحث/اكتب اسم أي روم صوتي في السيرفر:' : 'Or search/type any voice channel name:'}
                  value={voice247.channelName}
                  onChange={handleVoiceChannelChange}
                  placeholder="🔊 المستمر | القرآن الكريم"
                />
              </div>
            </div>

            {/* 2. Reciter / Broadcast Station Selector (<select>) */}
            <div className="p-4 rounded-xl bg-[#091310]/90 border border-amber-500/30 space-y-2.5 flex flex-col justify-between">
              <div className="space-y-2.5">
                <label className="text-xs font-black text-amber-300 flex items-center justify-between">
                  <span>{isAr ? '2️⃣ اختر القارئ أو الإذاعة المباشرة (Reciter / Station):' : '2️⃣ Select Quran Reciter / Live Radio:'}</span>
                  <span className="text-[10px] font-mono text-emerald-400">MP3 المستمر Stream</span>
                </label>

                <select
                  value={selectedDropdownReciter}
                  onChange={(e) => setSelectedDropdownReciter(e.target.value)}
                  className="w-full bg-[#0d1815] hover:bg-[#11211c] border border-amber-500/40 focus:border-emerald-400 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white cursor-pointer focus:outline-none transition-colors"
                >
                  {(recitersList.length > 0 ? recitersList : DEFAULT_QURAN_RECITERS).map((r) => (
                    <option key={r.id} value={r.id}>
                      🕋 {r.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">
                  {isAr ? 'القارئ المحدد حالياً:' : 'Selected Stream:'}
                </span>
                <span className="font-bold text-emerald-300 truncate max-w-[220px]">
                  {(recitersList.find(r => r.id === selectedDropdownReciter) || activeReciter || DEFAULT_QURAN_RECITERS[0])?.name}
                </span>
              </div>
            </div>
          </div>

          {/* 3. LIVE PLAYBACK ACTION BUTTONS (THE 4 PRIMARY CONTROLS) */}
          <div className="space-y-2">
            <span className="text-xs font-black text-slate-200 block">
              {isAr ? '3️⃣ أزرار التحكم الصوتي المباشر (Live المستمر Playback Controls):' : '3️⃣ Live المستمر Playback Action Buttons:'}
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {/* Button 1: Start & Lock المستمر */}
              <button
                type="button"
                onClick={() => handleJoinVoiceNow(voice247.channelName, selectedDropdownReciter)}
                disabled={voiceLoading}
                className="py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/70 border border-emerald-400/30 cursor-pointer transition-all disabled:opacity-60"
              >
                {voiceLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
                <span>{isAr ? '▶️ تشغيل وتثبيت المستمر' : '▶️ Start & Lock المستمر'}</span>
              </button>

              {/* Button 2: Pause / Resume */}
              <button
                type="button"
                onClick={handleTogglePauseResume}
                disabled={voiceLoading}
                className="py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-950/70 border border-amber-400/30 cursor-pointer transition-all disabled:opacity-60"
              >
                <Pause className="w-4 h-4" />
                <span>
                  {voicePaused
                    ? (isAr ? '▶️ استئناف التلاوة (Resume)' : '▶️ Resume Stream')
                    : (isAr ? '⏸️ إيقاف مؤقت / استئناف' : '⏸️ Pause / Resume')}
                </span>
              </button>

              {/* Button 3: Switch Reciter Live */}
              <button
                type="button"
                onClick={() => handleSwitchReciter(selectedDropdownReciter)}
                disabled={reciterSwitching !== null}
                className="py-3.5 px-4 rounded-xl bg-gradient-to-r from-teal-700 to-emerald-800 hover:from-teal-600 hover:to-emerald-700 text-amber-200 font-black text-xs flex items-center justify-center gap-2 shadow-lg border border-amber-400/40 cursor-pointer transition-all disabled:opacity-60"
              >
                {reciterSwitching ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4 text-amber-300" />}
                <span>{isAr ? '🔄 تغيير القارئ فوراً' : '🔄 Switch Reciter Live'}</span>
              </button>

              {/* Button 4: Stop & Leave */}
              <button
                type="button"
                onClick={handleLeaveVoiceNow}
                disabled={voiceLoading}
                className="py-3.5 px-4 rounded-xl bg-gradient-to-r from-rose-700 to-red-800 hover:from-rose-600 hover:to-red-700 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-950/70 border border-rose-500/30 cursor-pointer transition-all disabled:opacity-60"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>{isAr ? '⏹️ إيقاف وخروج' : '⏹️ Stop & Leave'}</span>
              </button>
            </div>
          </div>

          {/* 4. REAL-TIME VOLUME CONTROL SLIDER (0% - 100%) + DEPLOY DISCORD PANEL */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center p-4 rounded-xl bg-[#091310]/90 border border-emerald-500/30">
            <div className="md:col-span-8 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-black text-white flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                  <span>{isAr ? '4️⃣ التحكم الفوري بمستوى الصوت (Live Volume 0% - 100%):' : '4️⃣ Real-Time Inline Audio Volume (0% - 100%):'}</span>
                </span>
                <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-500/40 font-mono font-black text-emerald-300">
                  {voiceVolume}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={voiceVolume}
                onChange={(e) => handleVolumeChange(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer h-2 rounded-lg bg-slate-800"
              />
              <div className="flex justify-between text-[10px] font-mono text-slate-400">
                <span>0% (كتم)</span>
                <span>25%</span>
                <span>50%</span>
                <span>75%</span>
                <span>100% (صوت كامل نقي)</span>
              </div>
            </div>

            <div className="md:col-span-4">
              <button
                type="button"
                onClick={handleSendQuranPanelToDiscord}
                disabled={voiceLoading}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500/20 to-emerald-500/20 hover:from-amber-500/30 hover:to-emerald-500/30 border border-amber-400/50 text-amber-200 font-black text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
              >
                <Send className="w-4 h-4 text-amber-400" />
                <span>{isAr ? '🕋 إرسال بانل /quran في ديسكورد' : '🕋 Post /quran Panel in Discord'}</span>
              </button>
            </div>
          </div>

          <div className="space-y-4 text-xs">
            {/* Currently Playing Reciter Highlight Banner */}
            {activeReciter && (
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-[#0d1017] border border-emerald-500/40 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-emerald-400 font-bold block uppercase tracking-wider">
                      {isAr ? 'القارئ النشط في محرك الصوت الآن 🔊' : 'Active Reciter in Voice Engine'}
                    </span>
                    <h4 className="text-sm font-black text-white">{activeReciter.name}</h4>
                    <span className="text-[10px] text-slate-400 block mt-0.5">{activeReciter.description}</span>
                  </div>
                </div>

                <div className="text-left shrink-0">
                  <span className="inline-block px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    {activeReciter.style === 'mujawwad' ? 'مصحف مجود' : activeReciter.style === 'radio' ? 'إذاعة مباشرة المستمر' : 'مصحف مرتل'}
                  </span>
                </div>
              </div>
            )}

            {/* HOLY QURAN RECITERS GRID */}
            {(voice247.audioMode !== 'silent' || quranOnly) && (
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-black text-white flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-400" />
                      <span>{isAr ? 'اختر قارئ القرآن الكريم أو الإذاعة للبث الفوري (13 قارئ وإذاعة المستمر)' : 'Choose Quran Reciter or Live Radio (13 Streams)'}</span>
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {isAr
                        ? 'انقر على أي شيخ أو إذاعة لتشغيل التلاوة فوراً في الروم الصوتي على مدار المستمر'
                        : 'Click any Sheikh or radio station to immediately stream their recitation المستمر'}
                    </p>
                  </div>
                  <span className="text-[10px] text-emerald-300 font-mono bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded">
                    {recitersList.length || 13} {isAr ? 'شيوخ وإذاعات' : 'Streams'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {(recitersList.length > 0 ? recitersList : DEFAULT_QURAN_RECITERS).map((reciter) => {
                    const isPlayingThis = (activeReciter?.id === reciter.id) || (voice247.selectedReciter === reciter.id && !voice247.scheduleEnabled);
                    const isSwitching = reciterSwitching === reciter.id;

                    return (
                      <div
                        key={reciter.id}
                        className={`p-3.5 rounded-xl border text-right transition-all flex flex-col justify-between gap-3 ${
                          isPlayingThis
                            ? 'bg-emerald-950/40 border-emerald-500/70 ring-1 ring-emerald-500/50 shadow-md'
                            : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center justify-between">
                            <h5 className="font-bold text-white text-xs flex items-center gap-1.5">
                              {isPlayingThis && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />}
                              <span>{reciter.name}</span>
                            </h5>
                            <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                              reciter.style === 'mujawwad'
                                ? 'bg-amber-950/60 text-amber-300 border border-amber-500/30'
                                : reciter.style === 'radio'
                                ? 'bg-sky-950/60 text-sky-300 border border-sky-500/30'
                                : 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30'
                            }`}>
                              {reciter.style === 'mujawwad' ? 'مجود' : reciter.style === 'radio' ? 'إذاعة' : 'مرتل'}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-2">
                            {reciter.description}
                          </p>
                        </div>

                        <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                          <span className="text-[10px] text-slate-500 font-mono">
                            {reciter.nameEn}
                          </span>

                          <button
                            type="button"
                            onClick={() => handleSwitchReciter(reciter.id)}
                            disabled={isSwitching || isPlayingThis}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                              isPlayingThis
                                ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 cursor-default'
                                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow'
                            }`}
                          >
                            {isSwitching ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : isPlayingThis ? (
                              <>
                                <Check className="w-3.5 h-3.5" />
                                <span>{isAr ? 'يعمل الآن' : 'Playing'}</span>
                              </>
                            ) : (
                              <>
                                <Play className="w-3.5 h-3.5 fill-current" />
                                <span>{isAr ? 'تشغيل الآن' : 'Play Now'}</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 24-HOUR QURAN RECITATION SCHEDULE BUILDER */}
            {voice247.audioMode === 'quran' && (
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 sm:p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-emerald-400" />
                      <h4 className="text-sm font-bold text-white">
                        {isAr ? 'جدول تلاوات القرآن الكريم على مدار يوم كامل (Auto Schedule)' : 'Daily Quran Recitation Schedule'}
                      </h4>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {isAr
                        ? 'يبدل البوت القراء تلقائياً حسب ساعات اليوم دون أي تدخل بشري لضمان أجواء إيمانية مستمرة'
                        : 'Automatically transitions reciters based on hour of day for continuous spiritual ambiance'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <span className="text-[11px] text-slate-300 font-medium">
                      {voice247.scheduleEnabled ? (isAr ? 'الجدول مفعل ✅' : 'Schedule On') : (isAr ? 'الجدول معطل ⏹️' : 'Schedule Off')}
                    </span>
                    <input
                      type="checkbox"
                      checked={voice247.scheduleEnabled ?? true}
                      onChange={(e) => {
                        const en = e.target.checked;
                        setVoice247({ ...voice247, scheduleEnabled: en });
                        handleSaveSchedule(scheduleSlots, en);
                      }}
                      className="w-5 h-5 accent-emerald-500 rounded cursor-pointer"
                    />
                  </div>
                </div>

                {/* Current Mecca Time Display */}
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 text-xs">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Compass className="w-3.5 h-3.5 text-amber-400" />
                    <span>{isAr ? 'التوقيت المعتمد لتبديل الفترات (توقيت مكة المكرمة):' : 'Active Timezone (Mecca UTC+3):'}</span>
                  </span>
                  <span className="font-mono font-bold text-emerald-400">
                    {String(currentHourMecca).padStart(2, '0')}:00
                  </span>
                </div>

                {/* Schedule Slots List */}
                <div className="space-y-2.5">
                  {(scheduleSlots.length > 0 ? scheduleSlots : [
                    { id: 'slot-1', startHour: 4, endHour: 8, reciterId: 'alafasy', label: 'الفجر والصباح الباكر (04:00 - 08:00)' },
                    { id: 'slot-2', startHour: 8, endHour: 12, reciterId: 'muaiqly', label: 'الضحى والظهيرة (08:00 - 12:00)' },
                    { id: 'slot-3', startHour: 12, endHour: 16, reciterId: 'minshawi', label: 'الظهر والعصر (12:00 - 16:00)' },
                    { id: 'slot-4', startHour: 16, endHour: 20, reciterId: 'abdulbasit', label: 'المساء والمغرب (16:00 - 20:00)' },
                    { id: 'slot-5', startHour: 20, endHour: 24, reciterId: 'sudais', label: 'العشاء والحرم المكي (20:00 - 00:00)' },
                    { id: 'slot-6', startHour: 0, endHour: 4, reciterId: 'ghamdi', label: 'قيام الليل والأسحار (00:00 - 04:00)' },
                  ]).map((slot, index) => {
                    const isSlotCurrent = (slot.startHour < slot.endHour)
                      ? (currentHourMecca >= slot.startHour && currentHourMecca < slot.endHour)
                      : (currentHourMecca >= slot.startHour || currentHourMecca < slot.endHour);

                    return (
                      <div
                        key={slot.id}
                        className={`p-3 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
                          isSlotCurrent && voice247.scheduleEnabled
                            ? 'bg-emerald-950/40 border-emerald-500/60 ring-1 ring-emerald-500/40'
                            : 'bg-slate-950/50 border-slate-800/80'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                            isSlotCurrent && voice247.scheduleEnabled
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-slate-800 text-slate-300'
                          }`}>
                            {index + 1}
                          </span>
                          <div>
                            <span className="font-bold text-white block flex items-center gap-2">
                              <span>{slot.label}</span>
                              {isSlotCurrent && voice247.scheduleEnabled && (
                                <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold">
                                  {isAr ? 'الفترة الحالية الآن ⭐' : 'ACTIVE NOW ⭐'}
                                </span>
                              )}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {String(slot.startHour).padStart(2, '0')}:00 ⬅️ {String(slot.endHour === 24 ? 0 : slot.endHour).padStart(2, '0')}:00
                            </span>
                          </div>
                        </div>

                        {/* Reciter Picker for this Slot */}
                        <div className="flex items-center gap-2">
                          <label className="text-[11px] text-slate-400 shrink-0">{isAr ? 'القارئ المخصص:' : 'Assigned Reciter:'}</label>
                          <select
                            value={slot.reciterId}
                            onChange={(e) => {
                              const newReciterId = e.target.value;
                              const updated = (scheduleSlots.length > 0 ? scheduleSlots : [
                                { id: 'slot-1', startHour: 4, endHour: 8, reciterId: 'alafasy', label: 'الفجر والصباح الباكر (04:00 - 08:00)' },
                                { id: 'slot-2', startHour: 8, endHour: 12, reciterId: 'muaiqly', label: 'الضحى والظهيرة (08:00 - 12:00)' },
                                { id: 'slot-3', startHour: 12, endHour: 16, reciterId: 'minshawi', label: 'الظهر والعصر (12:00 - 16:00)' },
                                { id: 'slot-4', startHour: 16, endHour: 20, reciterId: 'abdulbasit', label: 'المساء والمغرب (16:00 - 20:00)' },
                                { id: 'slot-5', startHour: 20, endHour: 24, reciterId: 'sudais', label: 'العشاء والحرم المكي (20:00 - 00:00)' },
                                { id: 'slot-6', startHour: 0, endHour: 4, reciterId: 'ghamdi', label: 'قيام الليل والأسحار (00:00 - 04:00)' },
                              ]).map(s => s.id === slot.id ? { ...s, reciterId: newReciterId } : s);
                              setScheduleSlots(updated);
                            }}
                            className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:border-emerald-500 transition-colors"
                          >
                            {(recitersList.length > 0 ? recitersList : [
                              { id: 'alafasy', name: 'مشاري راشد العفاسي' },
                              { id: 'minshawi', name: 'محمد صديق المنشاوي' },
                              { id: 'abdulbasit', name: 'عبد الباسط عبد الصمد' },
                              { id: 'sudais', name: 'عبد الرحمن السديس' },
                              { id: 'muaiqly', name: 'ماهر المعيقلي' },
                              { id: 'ghamdi', name: 'سعد الغامدي' },
                              { id: 'cairo_radio', name: 'إذاعة القرآن الكريم (القاهرة)' },
                              { id: 'tarateel', name: 'إذاعة تراتيل وتلاوات نادرة المستمر' },
                            ]).map(r => (
                              <option key={r.id} value={r.id}>
                                الشيخ {r.name}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Save Schedule Button */}
                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    onClick={() => handleSaveSchedule(scheduleSlots, voice247.scheduleEnabled ?? true)}
                    disabled={scheduleSaving}
                    className="py-2.5 px-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all shadow-md disabled:opacity-50"
                  >
                    {scheduleSaving ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4" />
                    )}
                    <span>{isAr ? 'حفظ وتفعيل جدول الـ يوم كامل للروم الصوتي' : 'Save & Activate المستمر Quran Schedule'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Mute and Deafen toggles */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 cursor-pointer">
                <span className="flex items-center gap-2 text-slate-200 font-bold">
                  <Headphones className="w-4 h-4 text-sky-400" />
                  {isAr ? 'كتم السمع (Server Deafen)' : 'Server Deafen'}
                </span>
                <input
                  type="checkbox"
                  checked={voice247.deafened}
                  onChange={(e) => setVoice247({ ...voice247, deafened: e.target.checked })}
                  className="w-4 h-4 accent-emerald-500 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 cursor-pointer">
                <span className="flex items-center gap-2 text-slate-200 font-bold">
                  <MicOff className="w-4 h-4 text-amber-400" />
                  {isAr ? 'كتم المايك (Server Mute)' : 'Server Mute'}
                </span>
                <input
                  type="checkbox"
                  checked={voice247.muted}
                  onChange={(e) => setVoice247({ ...voice247, muted: e.target.checked })}
                  className="w-4 h-4 accent-emerald-500 rounded"
                />
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
