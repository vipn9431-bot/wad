import React, { useState, useEffect, useRef } from 'react';
import { Hash, ChevronDown, CheckCircle2, RefreshCw, Sparkles, Search, Copy } from 'lucide-react';

import { getAuthHeaders } from './TokenAuthGate';

export interface ChannelItem {
  id: string;
  name: string;
  type: 'text' | 'voice' | 'category';
  parentId?: string | null;
}

export interface ChannelSelectorProps {
  value: string;
  onChange: (channelNameOrId: string) => void;
  placeholder?: string;
  typeFilter?: 'text' | 'voice' | 'category' | 'all';
  type?: 'text' | 'voice' | 'category' | 'all' | string;
  label?: string;
  helperText?: string;
  compact?: boolean;
  allowAllChannelsOption?: boolean;
  allChannelsLabel?: string;
  lang?: 'ar' | 'en' | string;
  accentColor?: 'indigo' | 'emerald' | 'amber' | 'rose' | 'purple' | 'cyan';
  className?: string;
  guildId?: string;
}

let cachedChannels: ChannelItem[] = [];
let cachedGuildId = '';
let cachedGuildName = '';
let cachedIsLive = false;

export function invalidateChannelsCache() {
  cachedChannels = [];
  cachedGuildId = '';
  cachedGuildName = '';
  cachedIsLive = false;
}

export function setGuildChannelsCache(
  channels: ChannelItem[],
  guildId?: string,
  guildName?: string
) {
  cachedChannels = Array.isArray(channels) ? channels : [];
  cachedGuildId = guildId || '';
  if (guildName) cachedGuildName = guildName;
  cachedIsLive = cachedChannels.length > 0;
}

export const ChannelSelector: React.FC<ChannelSelectorProps> = ({
  value,
  onChange,
  placeholder = 'اختر الروم من السيرفر أو الصق معرف الروم (Channel ID)...',
  typeFilter,
  type,
  label,
  helperText,
  compact = false,
  allowAllChannelsOption = false,
  allChannelsLabel,
  accentColor = 'indigo',
  className = '',
  guildId
}) => {
  const effectiveFilter = (type || typeFilter || 'text') as 'text' | 'voice' | 'category' | 'all';
  const activeGId = (guildId || (typeof window !== 'undefined' ? localStorage.getItem('m7r_selected_guild_id') : '') || '').trim();
  const isSameCachedGuild = Boolean(activeGId && activeGId === cachedGuildId);

  const [channels, setChannels] = useState<ChannelItem[]>(isSameCachedGuild ? cachedChannels : []);
  const [isLive, setIsLive] = useState<boolean>(isSameCachedGuild ? cachedIsLive : false);
  const [guildName, setGuildName] = useState<string>(isSameCachedGuild ? cachedGuildName : '');
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  const fetchChannels = async () => {
    const targetGId = (guildId || (typeof window !== 'undefined' ? localStorage.getItem('m7r_selected_guild_id') : '') || '').trim();
    if (!targetGId) {
      setChannels([]);
      setIsLive(false);
      setGuildName('');
      return;
    }
    if (targetGId !== cachedGuildId) {
      setChannels([]);
      setIsLive(false);
      setGuildName('');
    }
    setLoading(true);
    try {
      const res = await fetch(`/api/guild/channels?guildId=${encodeURIComponent(targetGId)}`, {
        credentials: 'include',
        headers: { ...getAuthHeaders() }
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.channels)) {
          setChannels(data.channels);
          setIsLive(Boolean(data.live));
          setGuildName(data.guildName || '');
          cachedChannels = data.channels;
          cachedGuildId = data.guildId || targetGId;
          cachedIsLive = Boolean(data.live);
          cachedGuildName = data.guildName || '';
        }
      } else {
        setChannels([]);
        setIsLive(false);
      }
    } catch {
      // ignore fetch errors
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchChannels();
  }, [guildId, activeGId]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredChannels = channels.filter((c) => {
    if (effectiveFilter === 'text' && c.type !== 'text') return false;
    if (effectiveFilter === 'voice' && c.type !== 'voice') return false;
    if (effectiveFilter === 'category' && c.type !== 'category') return false;
    if (!searchTerm.trim()) return true;
    const q = searchTerm.trim().toLowerCase();
    return c.name.toLowerCase().includes(q) || c.id.includes(q);
  });

  const borderMap: Record<string, string> = {
    indigo: 'focus-within:border-indigo-500/70',
    emerald: 'focus-within:border-emerald-500/70',
    amber: 'focus-within:border-amber-500/70',
    rose: 'focus-within:border-rose-500/70',
    purple: 'focus-within:border-purple-500/70',
    cyan: 'focus-within:border-cyan-500/70'
  };

  return (
    <div ref={wrapperRef} className={`relative space-y-1.5 ${className}`}>
      {label && (
        <label className="text-xs font-bold text-slate-300 block">{label}</label>
      )}

      <div
        className={`flex items-center bg-[#090d16] border border-white/10 rounded-xl overflow-hidden transition-all ${
          borderMap[accentColor] || borderMap.indigo
        }`}
      >
        <span className="pr-3 pl-1.5 text-slate-400 flex items-center select-none">
          <Hash className="w-4 h-4 text-indigo-400" />
        </span>

        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value.replace(/^#/, ''))}
          onFocus={() => {
            setIsOpen(true);
            if (channels.length === 0) fetchChannels();
          }}
          placeholder={placeholder}
          className={`w-full bg-transparent ${
            compact ? 'py-2' : 'py-2.5'
          } px-1 text-white text-xs font-bold focus:outline-none placeholder:text-slate-500`}
        />

        <button
          type="button"
          onClick={() => {
            if (!isOpen) fetchChannels();
            setIsOpen(!isOpen);
          }}
          className={`px-3 ${
            compact ? 'py-2' : 'py-2.5'
          } text-slate-400 hover:text-white hover:bg-white/5 transition-colors flex items-center gap-1.5 border-r border-white/10 shrink-0`}
          title="اختر من رومات السيرفر الحية أو الصق Channel ID"
        >
          {isLive && (
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" title="متصل برومات السيرفر الحية" />
          )}
          <span className="text-[11px] font-bold text-slate-300 hidden sm:inline">رومات السيرفر</span>
          <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180 text-white' : ''}`} />
        </button>
      </div>

      {helperText && (
        <p className="text-[10px] text-slate-500 leading-relaxed">{helperText}</p>
      )}

      {isOpen && (
        <div className="absolute z-50 left-0 right-0 mt-1.5 bg-[#0b101b] border border-white/15 rounded-xl shadow-2xl overflow-hidden backdrop-blur-xl">
          <div className="px-3 py-2 bg-white/[0.03] border-b border-white/10 flex items-center justify-between gap-2">
            <span className="text-[11px] font-black text-slate-300 flex items-center gap-1.5 truncate">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              {isLive
                ? `رومات السيرفر الحية (${guildName || 'متصل'}) — (${filteredChannels.length})`
                : 'اختر روماً أو اكتب اسمه أو Channel ID'}
            </span>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                fetchChannels();
              }}
              className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-bold shrink-0"
            >
              <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
              تحديث
            </button>
          </div>

          <div className="p-2 border-b border-white/5 bg-[#070a12]">
            <div className="flex items-center gap-2 bg-[#0d121f] border border-white/10 rounded-lg px-2.5 py-1.5">
              <Search className="w-3.5 h-3.5 text-slate-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث باسم الروم أو بمعرف الـ ID..."
                className="w-full bg-transparent text-[11px] text-white focus:outline-none"
              />
            </div>
          </div>

          <div className="max-h-56 overflow-y-auto divide-y divide-white/5">
            {allowAllChannelsOption && (
              <button
                type="button"
                onClick={() => {
                  onChange('all');
                  setIsOpen(false);
                }}
                className="w-full px-3.5 py-2 text-right text-xs text-amber-300 hover:bg-white/5 font-bold flex items-center justify-between"
              >
                <span>🌐 جميع الرومات (All Channels)</span>
              </button>
            )}

            {filteredChannels.length === 0 ? (
              <div className="p-3 text-center text-xs text-slate-500">
                لا توجد رومات مطابقة — يمكنك كتابة اسم الروم أو لصق Channel ID مباشرة في الحقل أعلاه
              </div>
            ) : (
              filteredChannels.map((ch) => {
                const isSelected =
                  value.trim() === ch.id ||
                  value.trim().toLowerCase() === ch.name.toLowerCase();
                return (
                  <div
                    key={ch.id}
                    className={`w-full px-3.5 py-2.5 text-right text-xs flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-indigo-600/20 text-indigo-200 font-black'
                        : 'text-slate-300 hover:bg-white/5 hover:text-white font-semibold'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        onChange(ch.name);
                        setIsOpen(false);
                      }}
                      className="flex items-center gap-2 truncate flex-1 text-right"
                    >
                      <Hash className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span className="truncate">{ch.name}</span>
                      <span className="text-[10px] font-mono text-slate-500 tabular-nums">({ch.id})</span>
                    </button>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onChange(ch.id);
                          setIsOpen(false);
                        }}
                        className="px-2 py-0.5 rounded bg-white/5 hover:bg-indigo-500/20 text-[10px] font-mono text-indigo-300 border border-white/10 flex items-center gap-1"
                        title="اختيار الروم بواسطة الـ Channel ID"
                      >
                        <Copy className="w-2.5 h-2.5" />
                        استخدام ID
                      </button>
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
