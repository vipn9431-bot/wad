import React, { useState, useEffect } from 'react';
import {
  FileText,
  AlertTriangle,
  ShieldAlert,
  CheckCircle2,
  RefreshCw,
  PlusCircle,
  Send,
  Trash2,
  Edit3,
  Hash,
  Users,
  MessageSquare,
  Mic,
  Shield,
  Link2,
  Sparkles,
  Award,
  Bell,
  Clock,
  UserCheck,
  Filter
} from 'lucide-react';
import { getAuthHeaders } from './TokenAuthGate';
import { sound } from '../utils/sound';

export interface MasterAuditLogCategories {
  messages: boolean;
  members: boolean;
  roles: boolean;
  channels: boolean;
  voice: boolean;
  moderation: boolean;
  invitesServer: boolean;
}

export interface MasterAuditLogConfig {
  enabled: boolean;
  masterLogChannelId: string;
  masterLogChannelName: string;
  categories: MasterAuditLogCategories;
}

export interface ServerAuditEventItem {
  id: string;
  category: keyof MasterAuditLogCategories;
  eventType: string;
  title: string;
  description: string;
  executorTag: string;
  executorId: string;
  executorUsername?: string;
  executorDisplayName?: string;
  executorAvatar?: string;
  executorRoleId?: string;
  executorRoleName?: string;
  targetTag?: string;
  targetId?: string;
  channelName?: string;
  color: string;
  timestamp: string;
  unixTimestamp: number;
}

export interface StaffWarningsConfig {
  enabled: boolean;
  announcementChannelId: string;
  announcementChannelName: string;
  generalWarnRoleId: string;
  generalWarnRoleName: string;
  warn1RoleId: string;
  warn1RoleName: string;
  warn2RoleId: string;
  warn2RoleName: string;
  warn3RoleId: string;
  warn3RoleName: string;
  autoStripStaffOnWarn3: boolean;
}

export interface StaffWarningRecord {
  id: string;
  guildId: string;
  userId: string;
  username: string;
  userTag: string;
  avatar: string;
  warnRoleId: string;
  warnRoleName: string;
  executorId: string;
  executorTag: string;
  executorUsername?: string;
  executorDisplayName?: string;
  executorAvatar?: string;
  executorRoleId?: string;
  executorRoleName?: string;
  reason: string;
  warningNumber: number;
  source: 'role_trigger' | 'slash_command' | 'dashboard';
  announcementChannelId?: string;
  announcementMessageId?: string;
  createdAt: string;
  unixTimestamp: number;
  active: boolean;
}

interface AuditLogsStaffWarningsTabProps {
  lang: 'ar' | 'en';
  initialSection?: 'audit_logs' | 'staff_warnings';
  guildId?: string;
  serverName?: string;
}

export const AuditLogsStaffWarningsTab: React.FC<AuditLogsStaffWarningsTabProps> = ({
  lang,
  initialSection = 'audit_logs',
  guildId = 'default',
  serverName = 'M7R Server'
}) => {
  const isAr = lang === 'ar';
  const [activeSubTab, setActiveSubTab] = useState<'audit_logs' | 'staff_warnings'>(initialSection);

  useEffect(() => {
    setActiveSubTab(initialSection);
  }, [initialSection]);

  // Channels, Roles & Members from Live Guild
  const [textChannels, setTextChannels] = useState<{ id: string; name: string }[]>([]);
  const [roles, setRoles] = useState<{ id: string; name: string; color?: string }[]>([]);
  const [members, setMembers] = useState<{ id: string; username: string; tag: string; avatar?: string }[]>([]);
  const [bannerMsg, setBannerMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // 1. Master Audit Logs State
  const [auditConfig, setAuditConfig] = useState<MasterAuditLogConfig>({
    enabled: true,
    masterLogChannelId: '',
    masterLogChannelName: 'سجل-الأحداث-الشامل',
    categories: {
      messages: true,
      members: true,
      roles: true,
      channels: true,
      voice: true,
      moderation: true,
      invitesServer: true
    }
  });
  const [auditEvents, setAuditEvents] = useState<ServerAuditEventItem[]>([]);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [isSavingAudit, setIsSavingAudit] = useState(false);
  const [isCreatingLogChannel, setIsCreatingLogChannel] = useState(false);

  // 2. Staff Warnings State
  const [warningsConfig, setWarningsConfig] = useState<StaffWarningsConfig>({
    enabled: true,
    announcementChannelId: '',
    announcementChannelName: 'إعلانات-الإنذارات-الإدارية',
    generalWarnRoleId: '',
    generalWarnRoleName: '⚠️ إنذار إداري',
    warn1RoleId: '',
    warn1RoleName: '⚠️ إنذار إداري أول',
    warn2RoleId: '',
    warn2RoleName: '🚨 إنذار إداري ثاني',
    warn3RoleId: '',
    warn3RoleName: '⛔ إنذار إداري ثالث / سحب إدارة',
    autoStripStaffOnWarn3: true
  });
  const [warningsList, setWarningsList] = useState<StaffWarningRecord[]>([]);
  const [isSavingWarningsConfig, setIsSavingWarningsConfig] = useState(false);
  const [isQuickSettingUpWarnings, setIsQuickSettingUpWarnings] = useState(false);

  // Quick Issue Warning Form State
  const [issueTargetUserId, setIssueTargetUserId] = useState<string>('');
  const [issueTargetUsername, setIssueTargetUsername] = useState<string>('');
  const [issueSelectedRoleId, setIssueSelectedRoleId] = useState<string>('');
  const [issueReason, setIssueReason] = useState<string>('مخالفة قوانين الإدارة / تقصير في أداء المهام الإدارية');
  const [isIssuingWarning, setIsIssuingWarning] = useState(false);

  // Inline Reason Editor State
  const [editingWarningId, setEditingWarningId] = useState<string | null>(null);
  const [editingReasonText, setEditingReasonText] = useState<string>('');

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setBannerMsg({ text, type });
    setTimeout(() => setBannerMsg(null), 5500);
  };

  const fetchAllData = async () => {
    try {
      const headers = getAuthHeaders();
      const [detailsRes, auditRes, warnRes] = await Promise.all([
        fetch(`/api/guilds/${guildId}/details`, { headers, credentials: 'include' }).catch(() => null),
        fetch(`/api/guilds/${guildId}/audit-logs`, { headers, credentials: 'include' }).catch(() => null),
        fetch(`/api/guilds/${guildId}/staff-warnings`, { headers, credentials: 'include' }).catch(() => null)
      ]);

      if (detailsRes && detailsRes.ok) {
        const det = await detailsRes.json();
        const chs = Array.isArray(det.channels)
          ? det.channels.filter((c: any) => !c.type || c.type === 'text' || c.type === 0)
          : [];
        setTextChannels(chs.map((c: any) => ({ id: String(c.id), name: String(c.name) })));
        if (Array.isArray(det.roles)) {
          setRoles(
            det.roles
              .filter((r: any) => r.name !== '@everyone')
              .map((r: any) => ({ id: String(r.id), name: String(r.name), color: r.color }))
          );
        }
        if (Array.isArray(det.members)) {
          setMembers(
            det.members.map((m: any) => ({
              id: String(m.id),
              username: String(m.username || m.displayName || m.id),
              tag: String(m.tag || m.username || m.id),
              avatar: m.avatar
            }))
          );
        }
      }

      if (auditRes && auditRes.ok) {
        const aud = await auditRes.json();
        if (aud.config) setAuditConfig(aud.config);
        if (Array.isArray(aud.events)) setAuditEvents(aud.events);
        if (Array.isArray(aud.channels) && aud.channels.length > 0) {
          setTextChannels(aud.channels);
        }
      }

      if (warnRes && warnRes.ok) {
        const wrn = await warnRes.json();
        if (wrn.config) setWarningsConfig(wrn.config);
        if (Array.isArray(wrn.warnings)) setWarningsList(wrn.warnings);
        if (Array.isArray(wrn.members) && wrn.members.length > 0) {
          setMembers(wrn.members);
        }
        if (Array.isArray(wrn.roles) && wrn.roles.length > 0) {
          setRoles(wrn.roles);
        }
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetchAllData();
    const timer = setInterval(fetchAllData, 8000);
    return () => clearInterval(timer);
  }, [guildId]);

  // ================= 1. AUDIT LOGS HANDLERS =================
  const handleSaveAuditConfig = async (customCfg?: MasterAuditLogConfig) => {
    const cfgToSave = customCfg || auditConfig;
    setIsSavingAudit(true);
    sound.playShieldActivate();
    try {
      const res = await fetch(`/api/guilds/${guildId}/audit-logs/config`, {
        method: 'POST',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify(cfgToSave)
      });
      const data = await res.json();
      if (data.config) setAuditConfig(data.config);
      showToast(data.message || '✅ تم حفظ إعدادات نظام اللوق الشامل بنجاح!');
    } catch {
      showToast('تعذر حفظ إعدادات اللوق الشامل', 'error');
    } finally {
      setIsSavingAudit(false);
    }
  };

  const handleToggleAuditCategory = async (catKey: keyof MasterAuditLogCategories) => {
    const updated: MasterAuditLogConfig = {
      ...auditConfig,
      categories: {
        ...auditConfig.categories,
        [catKey]: !auditConfig.categories[catKey]
      }
    };
    setAuditConfig(updated);
    await handleSaveAuditConfig(updated);
  };

  const handleAutoCreateAuditChannel = async () => {
    setIsCreatingLogChannel(true);
    sound.playShieldActivate();
    try {
      const res = await fetch(`/api/guilds/${guildId}/audit-logs/create-channel`, {
        method: 'POST',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelName: auditConfig.masterLogChannelName || 'سجل-الأحداث-الشامل' })
      });
      const data = await res.json();
      if (data.success) {
        if (data.config) setAuditConfig(data.config);
        if (Array.isArray(data.events)) setAuditEvents(data.events);
        showToast(data.message || '⚡ تم إنشاء روم اللوق الشامل وتفعيله تلقائياً!');
        fetchAllData();
      } else {
        showToast(data.error || 'تعذر إنشاء روم اللوق تلقائياً', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء إنشاء روم اللوق', 'error');
    } finally {
      setIsCreatingLogChannel(false);
    }
  };

  const handleSendTestAuditLog = async () => {
    sound.playClick();
    try {
      const res = await fetch(`/api/audit-logs/test`, {
        method: 'POST',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId })
      });
      const data = await res.json();
      if (data.success) {
        if (Array.isArray(data.events)) setAuditEvents(data.events);
        showToast(data.message || '🧪 تم إرسال إيمبد فحص اللوق الشامل إلى ديسكورد!');
      } else {
        showToast(data.error || 'تعذر إرسال تجربة اللوق', 'error');
      }
    } catch {
      showToast('تعذر الاتصال بالسيرفر', 'error');
    }
  };

  // ================= 2. STAFF WARNINGS HANDLERS =================
  const handleSaveWarningsConfig = async () => {
    setIsSavingWarningsConfig(true);
    sound.playShieldActivate();
    try {
      const res = await fetch(`/api/guilds/${guildId}/staff-warnings/config`, {
        method: 'POST',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify(warningsConfig)
      });
      const data = await res.json();
      if (data.config) setWarningsConfig(data.config);
      showToast(data.message || '✅ تم حفظ إعدادات نظام إنذارات الإدارة ورتب الإنذار بنجاح!');
    } catch {
      showToast('تعذر حفظ إعدادات إنذارات الإدارة', 'error');
    } finally {
      setIsSavingWarningsConfig(false);
    }
  };

  const handleQuickSetupStaffWarnings = async () => {
    setIsQuickSettingUpWarnings(true);
    sound.playShieldActivate();
    try {
      const res = await fetch(`/api/staff-warnings/quick-setup`, {
        method: 'POST',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId })
      });
      const data = await res.json();
      if (data.success) {
        if (data.config) setWarningsConfig(data.config);
        showToast(
          data.message ||
            '⚡ تم إنشاء روم إعلانات الإنذارات ورتب الإنذار الإداري (1 و 2 و 3) تلقائياً في السيرفر!'
        );
        fetchAllData();
      } else {
        showToast(data.error || 'تعذر تنفيذ الإعداد السريع لإنذارات الإدارة', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء الإعداد السريع', 'error');
    } finally {
      setIsQuickSettingUpWarnings(false);
    }
  };

  const handleIssueWarningNow = async () => {
    if (!issueTargetUserId.trim() && !issueTargetUsername.trim()) {
      showToast('⚠️ يرجى اختيار الإداري أو كتابة الـ User ID الخاص به أولاً!', 'error');
      return;
    }
    setIsIssuingWarning(true);
    sound.playShieldActivate();
    try {
      const res = await fetch(`/api/guilds/${guildId}/staff-warnings/issue`, {
        method: 'POST',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: issueTargetUserId.trim(),
          username: issueTargetUsername.trim(),
          warnRoleId: issueSelectedRoleId,
          reason: issueReason.trim() || 'مخالفة قوانين الإدارة / تقصير إداري'
        })
      });
      const data = await res.json();
      if (data.success) {
        if (Array.isArray(data.warnings)) setWarningsList(data.warnings);
        showToast(
          data.message ||
            '🚨 تم إعطاء رتبة الإنذار، إرسال تنبيه خاص للمشرف، ونشر الإعلان الرسمي في روم إعلانات الإدارة!'
        );
      } else {
        showToast(data.error || 'تعذر إرسال الإنذار الإداري', 'error');
      }
    } catch {
      showToast('خطأ في الاتصال بالسيرفر أثناء إصدار الإنذار', 'error');
    } finally {
      setIsIssuingWarning(false);
    }
  };

  const handleSaveEditedReason = async (warningId: string) => {
    if (!editingReasonText.trim()) return;
    try {
      const res = await fetch(`/api/staff-warnings/${warningId}/update-reason`, {
        method: 'POST',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId, reason: editingReasonText.trim() })
      });
      const data = await res.json();
      if (data.success) {
        if (Array.isArray(data.warnings)) setWarningsList(data.warnings);
        setEditingWarningId(null);
        showToast(data.message || '✏️ تم تحديث سبب الإنذار في رسالة الإعلان وإشعار الإداري في الخاص!');
      } else {
        showToast(data.error || 'تعذر تحديث سبب الإنذار', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء تحديث السبب', 'error');
    }
  };

  const handleClearWarning = async (warningId: string) => {
    sound.playClick();
    try {
      const res = await fetch(`/api/staff-warnings/${warningId}/clear`, {
        method: 'POST',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId })
      });
      const data = await res.json();
      if (data.success) {
        if (Array.isArray(data.warnings)) setWarningsList(data.warnings);
        showToast(data.message || '🔄 تم إزالة الإنذار الإداري وسحب رتبة الإنذار من العضو بنجاح!');
      } else {
        showToast(data.error || 'تعذر إزالة الإنذار', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء إزالة الإنذار', 'error');
    }
  };

  const AUDIT_CATEGORIES_META: {
    key: keyof MasterAuditLogCategories;
    title: string;
    desc: string;
    icon: any;
    badgeColor: string;
  }[] = [
    {
      key: 'messages',
      title: '💬 الرسائل (Messages)',
      desc: 'حذف الرسائل (مع المحتوى والمرفقات)، تعديل الرسائل (قبل/بعد مع رابط الرسالة)، والمسح الجماعي',
      icon: MessageSquare,
      badgeColor: 'text-sky-400 border-sky-500/30 bg-sky-500/10'
    },
    {
      key: 'members',
      title: '👥 الأعضاء والحسابات (Members)',
      desc: 'دخول الأعضاء (مع فحص عمر الحساب)، الخروج أو الطرد (Kick)، وتغييرات اللقب (الاسم القديم ← الجديد)',
      icon: Users,
      badgeColor: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10'
    },
    {
      key: 'roles',
      title: '🎭 الرتب والصلاحيات (Roles)',
      desc: 'إعطاء رتبة (➕) أو سحب رتبة (➖) مع منشن الرتبة والعضو والإداري الفاعل، وإنشاء/حذف/تعديل الرتب',
      icon: Award,
      badgeColor: 'text-purple-400 border-purple-500/30 bg-purple-500/10'
    },
    {
      key: 'channels',
      title: '📁 الرومات والكاتيجوري (Channels)',
      desc: 'إنشاء الرومات، حذفها، تغيير أسمائها، وتعديلات الصلاحيات (قفل / فتح / إخفاء / إظهار)',
      icon: Hash,
      badgeColor: 'text-amber-400 border-amber-500/30 bg-amber-500/10'
    },
    {
      key: 'voice',
      title: '🎙️ الرومات الصوتية (Voice State)',
      desc: 'دخول صوتي (🟢)، خروج صوتي (🔴)، انتقال بين الرومات (🔄)، والميوت/الديفن/الفصل الإداري',
      icon: Mic,
      badgeColor: 'text-pink-400 border-pink-500/30 bg-pink-500/10'
    },
    {
      key: 'moderation',
      title: '🔨 العقوبات والحماية (Moderation & Bans)',
      desc: 'الباند (Ban)، فك الباند (Unban)، التايم أوت (Timeout) وفكه مع المدة والسبب والمسؤول',
      icon: Shield,
      badgeColor: 'text-rose-400 border-rose-500/30 bg-rose-500/10'
    },
    {
      key: 'invitesServer',
      title: '🔗 الدعوات والسيرفر (Invites & Server)',
      desc: 'إنشاء وحذف روابط الدعوة، وتغييرات اسم السيرفر أو أيقونته أو البنر الرسمي',
      icon: Link2,
      badgeColor: 'text-indigo-400 border-indigo-500/30 bg-indigo-500/10'
    }
  ];

  const filteredEvents =
    selectedCategoryFilter === 'all'
      ? auditEvents
      : auditEvents.filter((ev) => ev.category === selectedCategoryFilter);

  return (
    <div className="space-y-6" dir="rtl">
      {/* Top Switcher Bar between Master Audit Logs & Staff Warnings */}
      <div className="rounded-2xl bg-[#0c0f17]/95 border border-purple-500/30 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setActiveSubTab('audit_logs');
            }}
            className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 cursor-pointer transition-all ${
              activeSubTab === 'audit_logs'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-950/50 border border-purple-400/50'
                : 'bg-slate-900/90 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>📜 سجل الأحداث الشامل (Server Audit Logs)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setActiveSubTab('staff_warnings');
            }}
            className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 cursor-pointer transition-all ${
              activeSubTab === 'staff_warnings'
                ? 'bg-gradient-to-r from-rose-600 to-purple-600 text-white shadow-lg shadow-rose-950/50 border border-rose-400/50'
                : 'bg-slate-900/90 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>⚠️ نظام إنذارات الإدارة التلقائي (Staff Warnings)</span>
            <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-200 font-mono text-[10px]">
              {warningsList.filter((w) => w.active).length}
            </span>
          </button>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span>السيرفر النشط:</span>
          <span className="font-black text-purple-300">{serverName}</span>
          <button
            type="button"
            onClick={fetchAllData}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 cursor-pointer"
            title="تحديث السجلات"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {bannerMsg && (
        <div
          className={`p-4 rounded-2xl border text-xs font-black flex items-center justify-between shadow-lg ${
            bannerMsg.type === 'error'
              ? 'bg-rose-950/90 border-rose-500/50 text-rose-200'
              : 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{bannerMsg.text}</span>
          </div>
          <button onClick={() => setBannerMsg(null)} className="text-slate-400 hover:text-white cursor-pointer">
            ✕
          </button>
        </div>
      )}

      {/* =====================================================================
          SECTION 1: MASTER ALL-SEEING SERVER AUDIT LOGS SYSTEM
      ===================================================================== */}
      {activeSubTab === 'audit_logs' && (
        <div className="space-y-6">
          {/* Header & Master Channel Selector */}
          <div className="rounded-2xl bg-[#0e101a]/95 border border-purple-500/30 p-6 space-y-5 shadow-2xl">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-xl font-black text-white flex items-center gap-2.5">
                  <FileText className="w-6 h-6 text-purple-400" />
                  <span>📜 نظام اللوق الشامل لكل أحداث السيرفر (Master All-Seeing Audit Logs)</span>
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  يرصد كل حركة في السيرفر بالثانية مع جلب الفاعل الحقيقي من سجل التدقيق (Audit Log) وإرسال إيمبدات M7R ملونة وفخمة مع الأفتار والتوقيت الدقيق والآيديات
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const updated = { ...auditConfig, enabled: !auditConfig.enabled };
                    setAuditConfig(updated);
                    handleSaveAuditConfig(updated);
                  }}
                  className={`px-4 py-2.5 rounded-xl text-xs font-black border cursor-pointer transition-all ${
                    auditConfig.enabled
                      ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300'
                      : 'bg-rose-950/80 border-rose-500/50 text-rose-300'
                  }`}
                >
                  {auditConfig.enabled ? '🟢 اللوق الشامل مفعل المستمر' : '🔴 اللوق الشامل متوقف'}
                </button>

                <button
                  type="button"
                  onClick={handleAutoCreateAuditChannel}
                  disabled={isCreatingLogChannel}
                  className="px-4 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-black flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {isCreatingLogChannel
                      ? 'جاري الإنشاء...'
                      : '⚡ إنشاء روم اللوق تلقائياً بضغطة زر'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={handleSendTestAuditLog}
                  className="px-4 py-2.5 rounded-xl bg-purple-600/25 hover:bg-purple-600/40 border border-purple-500/50 text-purple-200 text-xs font-black flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>🧪 إرسال لوق تجريبي</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSaveAuditConfig()}
                  disabled={isSavingAudit}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black cursor-pointer shadow-lg shadow-emerald-950/50"
                >
                  {isSavingAudit ? 'جاري الحفظ...' : '💾 حفظ إعدادات اللوق'}
                </button>
              </div>
            </div>

            {/* Master Channel Selector Row */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
              <div className="lg:col-span-5">
                <label className="text-xs font-black text-slate-200 block mb-2">
                  📌 اختر روم اللوق الشامل من رومات السيرفر (`Master Log Channel`):
                </label>
                <select
                  value={auditConfig.masterLogChannelId || ''}
                  onChange={(e) => {
                    const chId = e.target.value;
                    const found = textChannels.find((c) => c.id === chId);
                    setAuditConfig((prev) => ({
                      ...prev,
                      masterLogChannelId: chId,
                      masterLogChannelName: found ? found.name : prev.masterLogChannelName
                    }));
                  }}
                  className="w-full bg-slate-950 border border-purple-500/40 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white focus:outline-none focus:border-purple-400"
                >
                  <option value="">-- اختر روم اللوق من القائمة أو اكتب اسمه --</option>
                  {textChannels.map((ch) => (
                    <option key={ch.id} value={ch.id}>
                      #{ch.name} ({ch.id})
                    </option>
                  ))}
                </select>
              </div>

              <div className="lg:col-span-4">
                <label className="text-xs font-bold text-slate-300 block mb-2">
                  أو اسم روم اللوق الشامل (يُستخدم أيضاً عند الإنشاء التلقائي):
                </label>
                <input
                  type="text"
                  value={auditConfig.masterLogChannelName}
                  onChange={(e) =>
                    setAuditConfig((prev) => ({ ...prev, masterLogChannelName: e.target.value }))
                  }
                  placeholder="سجل-الأحداث-الشامل"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white font-bold"
                />
              </div>

              <div className="lg:col-span-3 p-3 rounded-xl bg-slate-900/90 border border-slate-800 text-[11px] text-slate-300">
                <div className="font-black text-purple-300 mb-0.5">💡 أمر السلاش السريع في ديسكورد:</div>
                <code className="font-mono text-emerald-300">/set-logs-channel</code> أو{' '}
                <code className="font-mono text-emerald-300">تحديد-روم-اللوق</code>
              </div>
            </div>

            {/* 7 Audit Log Categories Toggles */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-black text-white">
                  🎛️ أقسام اللوق الشامل الـ 7 (جميعها مفعلة افتراضياً — تحكم بضغطة زر):
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    const updated: MasterAuditLogConfig = {
                      ...auditConfig,
                      categories: {
                        messages: true,
                        members: true,
                        roles: true,
                        channels: true,
                        voice: true,
                        moderation: true,
                        invitesServer: true
                      }
                    };
                    setAuditConfig(updated);
                    handleSaveAuditConfig(updated);
                  }}
                  className="text-xs font-bold text-purple-300 hover:underline cursor-pointer"
                >
                  ✅ تفعيل جميع الأقسام الـ 7
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {AUDIT_CATEGORIES_META.map((cat) => {
                  const Icon = cat.icon;
                  const isOn = auditConfig.categories[cat.key];
                  return (
                    <div
                      key={cat.key}
                      onClick={() => handleToggleAuditCategory(cat.key)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                        isOn
                          ? 'bg-slate-900/95 border-purple-500/40 shadow-md shadow-purple-950/20'
                          : 'bg-slate-950/60 border-slate-800/80 opacity-65'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className={`p-2 rounded-xl border ${cat.badgeColor}`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <span className="text-xs font-black text-white">{cat.title}</span>
                        </div>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                            isOn
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {isOn ? 'مفعل ✓' : 'معطل'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">{cat.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Live Real-Time Server Audit Feed Table (Latest 50 Events) */}
          <div className="rounded-2xl bg-[#0e101a]/95 border border-slate-800 p-6 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-black text-white flex items-center gap-2">
                  <Clock className="w-4 h-4 text-purple-400" />
                  <span>📡 البث المباشر لأحداث السيرفر (آخر 50 حدث في الوقت الفعلي)</span>
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  يتم تحديث الجدول تلقائياً فور حدوث أي رسالة محذوفة/معدلة، إعطاء/سحب رتبة، دخول/خروج صوتي، أو عقوبة إدارية
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <Filter className="w-3.5 h-3.5 text-slate-400 me-1" />
                {[
                  { id: 'all', label: 'الكل' },
                  { id: 'messages', label: '💬 الرسائل' },
                  { id: 'roles', label: '🎭 الرتب' },
                  { id: 'members', label: '👥 الأعضاء' },
                  { id: 'channels', label: '📁 الرومات' },
                  { id: 'voice', label: '🎙️ الصوتي' },
                  { id: 'moderation', label: '🔨 العقوبات' },
                  { id: 'invitesServer', label: '🔗 الدعوات' }
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setSelectedCategoryFilter(f.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                      selectedCategoryFilter === f.id
                        ? 'bg-purple-600 text-white'
                        : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-3 px-3">نوع الحدث</th>
                    <th className="py-3 px-3">التفاصيل الكاملة (قبل / بعد / الرتبة / الروم)</th>
                    <th className="py-3 px-3">👮‍♂️ الشخص المسؤول (اليوزر + الرتبة + ID)</th>
                    <th className="py-3 px-3">الهدف (Target)</th>
                    <th className="py-3 px-3 text-left">الوقت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {filteredEvents.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-10 text-center text-slate-400">
                        لا توجد أحداث مسجلة في هذا التصنيف حالياً — يمكنك الضغط على "🧪 إرسال لوق تجريبي" لاختبار النظام فوراً.
                      </td>
                    </tr>
                  ) : (
                    filteredEvents.slice(0, 50).map((ev) => {
                      const cleanExecUser = (ev.executorUsername || ev.executorTag || 'System').replace(/^@/, '');
                      return (
                        <tr key={ev.id} className="hover:bg-slate-900/60 transition-colors">
                          <td className="py-3 px-3 whitespace-nowrap">
                            <span
                              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-black text-[11px] border"
                              style={{
                                borderColor: `${ev.color || '#8A2BE2'}55`,
                                backgroundColor: `${ev.color || '#8A2BE2'}18`,
                                color: '#f8fafc'
                              }}
                            >
                              {ev.title}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-slate-200 max-w-md leading-relaxed whitespace-pre-line">
                            {ev.description}
                          </td>
                          <td className="py-3 px-3 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              {ev.executorAvatar && (
                                <img
                                  src={ev.executorAvatar}
                                  alt={cleanExecUser}
                                  className="w-7 h-7 rounded-full border border-purple-500/40 shrink-0"
                                />
                              )}
                              <div>
                                <div className="font-mono font-bold text-purple-300">
                                  @{cleanExecUser}
                                  {ev.executorDisplayName && ev.executorDisplayName !== cleanExecUser && (
                                    <span className="text-slate-300 font-sans ms-1">
                                      ({ev.executorDisplayName})
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                                  <span className="px-1.5 py-0.5 rounded bg-purple-500/15 border border-purple-500/30 text-[10px] text-purple-200 font-bold">
                                    🎖️ {ev.executorRoleName || 'أونر / إدارة السيرفر'}
                                  </span>
                                  {ev.executorId && (
                                    <span className="text-[10px] font-mono text-slate-500">
                                      ID: {ev.executorId}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-3 font-mono text-slate-300 whitespace-nowrap">
                            {ev.targetTag || ev.channelName || '—'}
                            {ev.targetId && (
                              <span className="block text-[10px] text-slate-500">ID: {ev.targetId}</span>
                            )}
                          </td>
                          <td className="py-3 px-3 text-left font-mono text-[11px] text-slate-400 whitespace-nowrap">
                            {ev.timestamp}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SECTION 2: AUTOMATED STAFF WARNING & ROLE-TRIGGER SYSTEM
      ===================================================================== */}
      {activeSubTab === 'staff_warnings' && (
        <div className="space-y-6">
          {/* Header & Quick Setup */}
          <div className="rounded-2xl bg-[#0e101a]/95 border border-rose-500/35 p-6 space-y-5 shadow-2xl">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-xl font-black text-white flex items-center gap-2.5">
                  <ShieldAlert className="w-6 h-6 text-rose-400" />
                  <span>⚠️ نظام إنذارات الإدارة التلقائي بالرتب والإشعارات (Staff Warnings & Strikes System)</span>
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  يعمل تلقائياً بطريقتين: (1) بمجرد إعطاء الإداري رتبة الإنذار داخل ديسكورد يرسل له البوت بالخاص وينشر إعلان الإنذار مع زر تعديل السبب، أو (2) عبر الأمر <code className="text-rose-300 font-mono">/warn-staff</code> ومن لوحة التحكم
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleQuickSetupStaffWarnings}
                  disabled={isQuickSettingUpWarnings}
                  className="px-4 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-black flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {isQuickSettingUpWarnings
                      ? 'جاري الإنشاء...'
                      : '⚡ إنشاء روم الإعلانات ورتب الإنذار (1-3) تلقائياً'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveWarningsConfig}
                  disabled={isSavingWarningsConfig}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black cursor-pointer shadow-lg shadow-emerald-950/50"
                >
                  {isSavingWarningsConfig ? 'جاري الحفظ...' : '💾 حفظ إعدادات رتب وروم الإنذارات'}
                </button>
              </div>
            </div>

            {/* Configuration Grid: Announcement Channel + Tiered Warning Roles */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left 7 Cols: Channel & Roles Config */}
              <div className="lg:col-span-7 space-y-4">
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 text-xs">
                  <h3 className="text-sm font-black text-white flex items-center gap-2 border-b border-slate-800 pb-2.5">
                    <Bell className="w-4 h-4 text-rose-400" />
                    <span>1. روم إعلانات وإنذارات الإدارة + رتب الإنذار التلقائية</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 font-bold block mb-1.5">
                        📢 روم إعلانات وإنذارات الإدارة (Dropdown):
                      </label>
                      <select
                        value={warningsConfig.announcementChannelId || ''}
                        onChange={(e) => {
                          const chId = e.target.value;
                          const found = textChannels.find((c) => c.id === chId);
                          setWarningsConfig((prev) => ({
                            ...prev,
                            announcementChannelId: chId,
                            announcementChannelName: found ? found.name : prev.announcementChannelName
                          }));
                        }}
                        className="w-full bg-slate-950 border border-rose-500/40 rounded-xl px-3 py-2 text-white font-bold"
                      >
                        <option value="">-- اختر روم إعلانات الإدارة --</option>
                        {textChannels.map((ch) => (
                          <option key={ch.id} value={ch.id}>
                            #{ch.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1.5">
                        اسم روم إعلانات الإنذارات الإدارية:
                      </label>
                      <input
                        type="text"
                        value={warningsConfig.announcementChannelName}
                        onChange={(e) =>
                          setWarningsConfig((prev) => ({
                            ...prev,
                            announcementChannelName: e.target.value
                          }))
                        }
                        placeholder="إعلانات-الإنذارات-الإدارية"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                      />
                    </div>
                  </div>

                  {/* Warning Trigger Roles (General + Warn 1, 2, 3) */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 space-y-1.5">
                      <label className="text-amber-300 font-black block">
                        ⚠️ رتبة الإنذار الإداري العام (`General Warning Role`)
                      </label>
                      <select
                        value={warningsConfig.generalWarnRoleId || ''}
                        onChange={(e) => {
                          const rId = e.target.value;
                          const rObj = roles.find((r) => r.id === rId);
                          setWarningsConfig((prev) => ({
                            ...prev,
                            generalWarnRoleId: rId,
                            generalWarnRoleName: rObj ? rObj.name : prev.generalWarnRoleName
                          }));
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                      >
                        <option value="">اختر رتبة أو اتركها على الاسم...</option>
                        {roles.map((r) => (
                          <option key={r.id} value={r.id}>
                            @{r.name}
                          </option>
                        ))}
                      </select>
                      <input
                        type="text"
                        value={warningsConfig.generalWarnRoleName}
                        onChange={(e) =>
                          setWarningsConfig((prev) => ({ ...prev, generalWarnRoleName: e.target.value }))
                        }
                        placeholder="⚠️ إنذار إداري"
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 text-[11px]"
                      />
                    </div>

                    <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 space-y-1.5">
                      <label className="text-amber-400 font-black block">
                        1️⃣ رتبة إنذار إداري أول (`Warning 1 Role`)
                      </label>
                      <select
                        value={warningsConfig.warn1RoleId || ''}
                        onChange={(e) => {
                          const rId = e.target.value;
                          const rObj = roles.find((r) => r.id === rId);
                          setWarningsConfig((prev) => ({
                            ...prev,
                            warn1RoleId: rId,
                            warn1RoleName: rObj ? rObj.name : prev.warn1RoleName
                          }));
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                      >
                        <option value="">اختر رتبة الإنذار الأول...</option>
                        {roles.map((r) => (
                          <option key={r.id} value={r.id}>
                            @{r.name}
                          </option>
                        ))}
                      </select>
                      <input
                        type="text"
                        value={warningsConfig.warn1RoleName}
                        onChange={(e) =>
                          setWarningsConfig((prev) => ({ ...prev, warn1RoleName: e.target.value }))
                        }
                        placeholder="⚠️ إنذار إداري أول"
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 text-[11px]"
                      />
                    </div>

                    <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 space-y-1.5">
                      <label className="text-orange-400 font-black block">
                        2️⃣ رتبة إنذار إداري ثاني (`Warning 2 Role`)
                      </label>
                      <select
                        value={warningsConfig.warn2RoleId || ''}
                        onChange={(e) => {
                          const rId = e.target.value;
                          const rObj = roles.find((r) => r.id === rId);
                          setWarningsConfig((prev) => ({
                            ...prev,
                            warn2RoleId: rId,
                            warn2RoleName: rObj ? rObj.name : prev.warn2RoleName
                          }));
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                      >
                        <option value="">اختر رتبة الإنذار الثاني...</option>
                        {roles.map((r) => (
                          <option key={r.id} value={r.id}>
                            @{r.name}
                          </option>
                        ))}
                      </select>
                      <input
                        type="text"
                        value={warningsConfig.warn2RoleName}
                        onChange={(e) =>
                          setWarningsConfig((prev) => ({ ...prev, warn2RoleName: e.target.value }))
                        }
                        placeholder="🚨 إنذار إداري ثاني"
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 text-[11px]"
                      />
                    </div>

                    <div className="p-3 rounded-xl bg-slate-950/90 border border-rose-500/30 space-y-1.5">
                      <label className="text-rose-400 font-black block">
                        3️⃣ رتبة إنذار إداري ثالث / سحب إدارة (`Warning 3 Role`)
                      </label>
                      <select
                        value={warningsConfig.warn3RoleId || ''}
                        onChange={(e) => {
                          const rId = e.target.value;
                          const rObj = roles.find((r) => r.id === rId);
                          setWarningsConfig((prev) => ({
                            ...prev,
                            warn3RoleId: rId,
                            warn3RoleName: rObj ? rObj.name : prev.warn3RoleName
                          }));
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                      >
                        <option value="">اختر رتبة الإنذار الثالث...</option>
                        {roles.map((r) => (
                          <option key={r.id} value={r.id}>
                            @{r.name}
                          </option>
                        ))}
                      </select>
                      <input
                        type="text"
                        value={warningsConfig.warn3RoleName}
                        onChange={(e) =>
                          setWarningsConfig((prev) => ({ ...prev, warn3RoleName: e.target.value }))
                        }
                        placeholder="⛔ إنذار إداري ثالث / سحب إدارة"
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 text-[11px]"
                      />
                    </div>
                  </div>

                  {/* Auto-Strip Staff Roles on 3rd Warning Toggle */}
                  <label className="flex items-center justify-between p-3 rounded-xl bg-rose-950/30 border border-rose-500/30 cursor-pointer">
                    <div>
                      <span className="font-black text-rose-200 block">
                        ⛔ سحب الرتب الإدارية تلقائياً عند وصول الإداري إلى 3 إنذارات (Auto-Strip Staff Roles)
                      </span>
                      <span className="text-[11px] text-slate-400">
                        يقوم البوت بسحب صلاحيات الإدارة تلقائياً عند الإنذار الثالث وتوثيق ذلك في روم إعلانات الإدارة
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={warningsConfig.autoStripStaffOnWarn3}
                      onChange={(e) =>
                        setWarningsConfig((prev) => ({
                          ...prev,
                          autoStripStaffOnWarn3: e.target.checked
                        }))
                      }
                      className="w-5 h-5 accent-rose-500"
                    />
                  </label>
                </div>
              </div>

              {/* Right 5 Cols: Quick Issue Warning Form in Dashboard */}
              <div className="lg:col-span-5">
                <div className="p-5 rounded-2xl bg-gradient-to-b from-rose-950/25 to-slate-900/90 border border-rose-500/40 space-y-4 text-xs h-full flex flex-col justify-between">
                  <div className="space-y-3.5">
                    <h3 className="text-sm font-black text-white flex items-center gap-2 border-b border-slate-800 pb-2.5">
                      <UserCheck className="w-4 h-4 text-rose-400" />
                      <span>🚨 إعطاء إنذار إداري فوري من الموقع (Quick Issue Warning)</span>
                    </h3>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1">
                        1. اختر الإداري من السيرفر (أو الصق الـ User ID):
                      </label>
                      <select
                        value={issueTargetUserId}
                        onChange={(e) => {
                          const uid = e.target.value;
                          setIssueTargetUserId(uid);
                          const m = members.find((mem) => mem.id === uid);
                          if (m) setIssueTargetUsername(m.username);
                        }}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white mb-2"
                      >
                        <option value="">-- اختر عضو/إداري من القائمة --</option>
                        {members.map((m) => (
                          <option key={m.id} value={m.id}>
                            {m.username} ({m.id})
                          </option>
                        ))}
                      </select>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={issueTargetUserId}
                          onChange={(e) => setIssueTargetUserId(e.target.value)}
                          placeholder="User ID (مثال: 1219299588402577532)"
                          className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                        />
                        <input
                          type="text"
                          value={issueTargetUsername}
                          onChange={(e) => setIssueTargetUsername(e.target.value)}
                          placeholder="اسم الإداري (اختياري)"
                          className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1">
                        2. اختر رتبة الإنذار المراد منحها للإداري:
                      </label>
                      <select
                        value={issueSelectedRoleId}
                        onChange={(e) => setIssueSelectedRoleId(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                      >
                        <option value="">
                          ⚡ تلقائي (يمنح رتبة الإنذار 1 ثم 2 ثم 3 حسب سجل الإداري)
                        </option>
                        {roles.map((r) => (
                          <option key={r.id} value={r.id}>
                            @{r.name} ({r.id})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1">
                        3. اكتب سبب الإنذار الإداري (`Reason`):
                      </label>
                      <textarea
                        rows={3}
                        value={issueReason}
                        onChange={(e) => setIssueReason(e.target.value)}
                        placeholder="اكتب سبب الإنذار بدقة ليظهر في إعلان الإدارة وفي رسالة الخاص للإداري..."
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white"
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleIssueWarningNow}
                    disabled={isIssuingWarning}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-black text-xs shadow-lg shadow-rose-950/60 cursor-pointer transition-all"
                  >
                    {isIssuingWarning
                      ? '⏳ جاري إعطاء الرتبة وإرسال الإعلان...'
                      : '🚨 إرسال الإنذار وإعطاء الرتبة الآن (Issue Warning & Role)'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Active Staff Warnings Table */}
          <div className="rounded-2xl bg-[#0e101a]/95 border border-slate-800 p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-black text-white">
                  📋 جدول إنذارات الإدارة النشطة والسجل الكامل (Active Staff Warnings Table)
                </h3>
                <p className="text-[11px] text-slate-400">
                  يمكنك تعديل سبب أي إنذار مباشرة (سيتم تحديث رسالة الإعلان في ديسكورد وإشعار الإداري بالخاص) أو إزالة الإنذار وسحب الرتبة بضغطة زر
                </p>
              </div>
              <button
                type="button"
                onClick={fetchAllData}
                className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-200 cursor-pointer"
              >
                🔄 تحديث السجل
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-3 px-3">الإداري المُنذر</th>
                    <th className="py-3 px-3">رتبة الإنذار</th>
                    <th className="py-3 px-3">رقم الإنذار</th>
                    <th className="py-3 px-3">السبب (قابل للتعديل الفوري)</th>
                    <th className="py-3 px-3">المسؤول المُصدر</th>
                    <th className="py-3 px-3">التاريخ والطريقة</th>
                    <th className="py-3 px-3 text-left">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {warningsList.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-10 text-center text-slate-400">
                        لا توجد إنذارات إدارية مسجلة حالياً. عند إعطاء أي مشرف رتبة إنذار في ديسكورد أو عبر /warn-staff سيظهر هنا فوراً.
                      </td>
                    </tr>
                  ) : (
                    warningsList.map((w) => (
                      <tr key={w.id} className="hover:bg-slate-900/60 transition-colors">
                        <td className="py-3 px-3 font-bold text-white">
                          <div>@{w.username.replace(/^@/, '')}</div>
                          <span className="text-[10px] font-mono text-slate-400">ID: {w.userId}</span>
                        </td>
                        <td className="py-3 px-3">
                          <span className="px-2.5 py-1 rounded-lg bg-rose-500/15 border border-rose-500/40 text-rose-300 font-bold">
                            @{w.warnRoleName}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-mono font-black text-amber-300">
                          الإنذار #{w.warningNumber}
                        </td>
                        <td className="py-3 px-3 max-w-sm">
                          {editingWarningId === w.id ? (
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                value={editingReasonText}
                                onChange={(e) => setEditingReasonText(e.target.value)}
                                className="flex-1 bg-slate-950 border border-purple-500 rounded-lg px-2.5 py-1 text-white text-xs"
                              />
                              <button
                                type="button"
                                onClick={() => handleSaveEditedReason(w.id)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold cursor-pointer"
                              >
                                حفظ
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingWarningId(null)}
                                className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300 cursor-pointer"
                              >
                                إلغاء
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-slate-200">{w.reason}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingWarningId(w.id);
                                  setEditingReasonText(w.reason);
                                }}
                                className="text-purple-400 hover:text-purple-300 shrink-0 cursor-pointer"
                                title="تعديل السبب وتحديث الإعلان في ديسكورد"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <div className="font-mono font-bold text-purple-300">
                            @{(w.executorUsername || w.executorTag || 'Admin').replace(/^@/, '')}
                          </div>
                          <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                            <span className="px-1.5 py-0.5 rounded bg-purple-500/15 border border-purple-500/30 text-[10px] text-purple-200 font-bold">
                              🎖️ {w.executorRoleName || 'أونر / الإدارة العليا'}
                            </span>
                            {w.executorId && (
                              <span className="text-[10px] font-mono text-slate-500">
                                ID: {w.executorId}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-3 text-[11px] text-slate-400">
                          <div>{w.createdAt}</div>
                          <span className="text-[10px] text-purple-300">
                            {w.source === 'role_trigger'
                              ? '⚡ تلقائي عند إعطاء الرتبة'
                              : w.source === 'slash_command'
                              ? '⌨️ أمر /warn-staff'
                              : '🌐 لوحة التحكم'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-left">
                          {w.active ? (
                            <button
                              type="button"
                              onClick={() => handleClearWarning(w.id)}
                              className="px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/35 border border-rose-500/40 text-rose-200 font-bold text-[11px] inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>🔄 إزالة الإنذار وسحب الرتبة</span>
                            </button>
                          ) : (
                            <span className="text-emerald-400 font-bold text-[11px]">
                              ✅ تمت إزالته وسحب الرتبة
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
