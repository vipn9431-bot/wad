import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Activity,
  BarChart3,
  RefreshCw,
  Terminal,
  Zap,
  LogIn,
  Server,
  Crown,
  Users,
  Search,
  CheckCircle2,
  PlusCircle,
  Clock
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { ThreatLog, GuildJoinNotification, AccessRoleMode } from '../types';
import { sound } from '../utils/sound';
import { DEFAULT_CONNECTED_GUILDS, OFFICIAL_OWNER_ID } from './TokenAuthGate';

export interface RealTimeAuthLogItem {
  id: string;
  userId: string;
  username: string;
  tag: string;
  avatar: string;
  isOwner: boolean;
  accessMode: AccessRoleMode;
  guildId: string;
  guildName: string;
  source: string;
  timestamp: string;
}

interface LogVisualizerTabProps {
  lang: 'ar' | 'en';
  threatLogs: ThreatLog[];
  attacksThwarted: number;
}

const DEFAULT_AUTH_LOGS: RealTimeAuthLogItem[] = [];

const DEFAULT_SERVER_JOIN_LOGS: GuildJoinNotification[] = DEFAULT_CONNECTED_GUILDS.map((g, idx) => ({
  id: `join-default-${g.id}`,
  guildId: g.id,
  guildName: g.name,
  guildIcon: g.icon || '',
  memberCount: g.memberCount || 0,
  channelsCount: g.channelsCount || 32,
  ownerId: OFFICIAL_OWNER_ID,
  ownerTag: 'u5r9',
  joinedAt: new Date(Date.now() - idx * 1800_000).toLocaleTimeString('ar-EG', {
    hour: '2-digit',
    minute: '2-digit'
  }),
  permissionGranted: 'Administrator (0x8)',
  accessMode: 'server_admin',
  read: false
}));

export const LogVisualizerTab: React.FC<LogVisualizerTabProps> = ({
  lang,
  threatLogs: propThreatLogs,
  attacksThwarted
}) => {
  const isAr = lang === 'ar';
  const [activeCategory, setActiveCategory] = useState<'all' | 'auth' | 'joins' | 'threats'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string>(() =>
    new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  );

  const [authLogs, setAuthLogs] = useState<RealTimeAuthLogItem[]>(DEFAULT_AUTH_LOGS);
  const [serverJoinLogs, setServerJoinLogs] = useState<GuildJoinNotification[]>(DEFAULT_SERVER_JOIN_LOGS);
  const [liveThreatLogs, setLiveThreatLogs] = useState<ThreatLog[]>(propThreatLogs || []);

  const fetchRealTimeLogs = useCallback(async (showSpinner = false) => {
    if (showSpinner) setIsRefreshing(true);
    try {
      const savedToken = localStorage.getItem('m7r_session_token') || '';
      const res = await fetch('/api/logs/realtime', {
        credentials: 'include',
        headers: savedToken ? { Authorization: `Bearer ${savedToken}` } : {}
      });
      const ct = res.headers.get('content-type') || '';
      if (res.ok && ct.includes('application/json')) {
        const data = await res.json();
        if (Array.isArray(data?.authLogs)) {
          setAuthLogs(data.authLogs);
        }
        if (Array.isArray(data?.serverJoinLogs) && data.serverJoinLogs.length > 0) {
          setServerJoinLogs(data.serverJoinLogs);
        }
        if (Array.isArray(data?.threatLogs) && data.threatLogs.length > 0) {
          const uniqueMap = new Map<string, ThreatLog>();
          for (const item of data.threatLogs) {
            if (item?.id && !uniqueMap.has(item.id)) uniqueMap.set(item.id, item);
          }
          setLiveThreatLogs(Array.from(uniqueMap.values()));
        }
        setLastSyncedAt(
          new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        );
      }
    } catch {
      // Fallback to local state if offline or on static host
    } finally {
      if (showSpinner) {
        setTimeout(() => setIsRefreshing(false), 400);
      }
    }
  }, []);

  useEffect(() => {
    fetchRealTimeLogs(false);
    const interval = setInterval(() => fetchRealTimeLogs(false), 5000);
    return () => clearInterval(interval);
  }, [fetchRealTimeLogs]);

  useEffect(() => {
    if (Array.isArray(propThreatLogs) && propThreatLogs.length > 0) {
      const uniqueMap = new Map<string, ThreatLog>();
      for (const item of propThreatLogs) {
        if (item?.id && !uniqueMap.has(item.id)) uniqueMap.set(item.id, item);
      }
      setLiveThreatLogs(Array.from(uniqueMap.values()));
    }
  }, [propThreatLogs]);

  const handleSimulateServerJoin = async () => {
    sound.playShieldActivate();
    setIsRefreshing(true);
    try {
      const res = await fetch('/api/notifications/guilds/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      if (res.ok) {
        await fetchRealTimeLogs(false);
      }
    } catch {
      const mockJoin: GuildJoinNotification = {
        id: `join-sim-${Date.now()}`,
        guildId: `${Math.floor(100000000000000000 + Math.random() * 900000000000000000)}`,
        guildName: `سيرفر نخبة M7R #${Math.floor(10 + Math.random() * 89)}`,
        guildIcon: '',
        memberCount: Math.floor(80 + Math.random() * 900),
        channelsCount: 34,
        ownerId: OFFICIAL_OWNER_ID,
        ownerTag: 'u5r9',
        joinedAt: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
        permissionGranted: 'Administrator (0x8)',
        accessMode: 'server_admin',
        read: false
      };
      setServerJoinLogs((prev) => [mockJoin, ...prev]);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Hourly aggregated data for chart
  const chartData = [
    { time: '00:00', auth: 4, joins: 1, threats: 12 },
    { time: '04:00', auth: 3, joins: 1, threats: 8 },
    { time: '08:00', auth: 9, joins: 2, threats: 19 },
    { time: '12:00', auth: 14, joins: 3, threats: 34 },
    { time: '16:00', auth: 18, joins: 4, threats: 29 },
    { time: '20:00', auth: 22 + authLogs.length, joins: serverJoinLogs.length, threats: 41 }
  ];

  const filteredAuthLogs = authLogs.filter(
    (item) =>
      item.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.userId.includes(searchQuery) ||
      item.guildName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredJoinLogs = serverJoinLogs.filter(
    (item) =>
      item.guildName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.guildId.includes(searchQuery)
  );

  const filteredThreatLogs = liveThreatLogs.filter(
    (item) =>
      (item.details || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.executor || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.target || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 animate-in fade-in">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-indigo-950/60 via-[#0b0e17] to-rose-950/50 border border-indigo-500/30 p-6 shadow-2xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shrink-0 shadow-lg shadow-indigo-950/50">
            <Activity className="w-7 h-7" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-wide font-mono">
                {isAr
                  ? 'مركز السجلات الفورية (المصادقة ودخول السيرفرات)'
                  : 'Real-Time Authentication & Server Join Visualizer'}
              </h1>
              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                {isAr ? 'مزامنة حية (Real-Time API)' : 'Live API Sync'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {isAr
                ? 'مراقبة فورية لجميع عمليات تسجيل الدخول عبر Discord OAuth2، دخول البوت إلى السيرفرات الجديدة، وسجلات الدرع الأمني.'
                : 'Real-time feed of all Discord OAuth2 user authentication events, bot-server join actions, and security logs.'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
          <button
            type="button"
            onClick={handleSimulateServerJoin}
            className="px-3.5 py-2.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-xs font-bold text-emerald-300 flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <PlusCircle className="w-4 h-4 text-emerald-400" />
            <span>{isAr ? 'اختبار حدث دخول سيرفر جديد' : 'Simulate Bot Server Join'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              sound.playClick();
              fetchRealTimeLogs(true);
            }}
            className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-white flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <RefreshCw className={`w-4 h-4 text-indigo-400 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>{isAr ? 'تحديث السجلات الآن' : 'Refresh Logs'}</span>
          </button>
        </div>
      </div>

      {/* 4 Real-Time KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl border border-indigo-500/30 bg-[#0d1017] p-5 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-slate-400 font-medium">
              {isAr ? 'عمليات مصادقة الدخول (OAuth2)' : 'User Auth Events (OAuth2)'}
            </span>
            <div className="text-3xl font-black text-white font-mono tabular-nums mt-1">
              {authLogs.length}
            </div>
            <span className="text-[11px] text-indigo-400 font-bold mt-1 block">
              {isAr ? '🔐 توثيق رسمي عبر Discord API' : '🔐 Verified via Discord API'}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <LogIn className="w-6 h-6" />
          </div>
        </div>

        <div className="rounded-2xl border border-emerald-500/30 bg-[#0d1017] p-5 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-slate-400 font-medium">
              {isAr ? 'سجلات دخول البوت للسيرفرات' : 'Bot-Server Join Actions'}
            </span>
            <div className="text-3xl font-black text-white font-mono tabular-nums mt-1">
              {serverJoinLogs.length}
            </div>
            <span className="text-[11px] text-emerald-400 font-bold mt-1 block">
              {isAr ? '🟢 سيرفرات متصلة ونشطة' : '🟢 Active Bot Guilds'}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Server className="w-6 h-6" />
          </div>
        </div>

        <div className="rounded-2xl border border-rose-500/30 bg-[#0d1017] p-5 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-slate-400 font-medium">
              {isAr ? 'إجمالي الهجمات المصدودة' : 'Total Thwarted Attacks'}
            </span>
            <div className="text-3xl font-black text-white font-mono tabular-nums mt-1">
              {attacksThwarted.toLocaleString()}
            </div>
            <span className="text-[11px] text-rose-400 font-bold mt-1 block">
              {isAr ? '🛡️ حماية فورية المستمر' : '🛡️ Instant المستمر Shield'}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
        </div>

        <div className="rounded-2xl border border-amber-500/30 bg-[#0d1017] p-5 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-slate-400 font-medium">
              {isAr ? 'آخر مزامنة للسجلات الحية' : 'Last Real-Time Sync'}
            </span>
            <div className="text-xl font-black text-amber-400 font-mono mt-1.5">{lastSyncedAt}</div>
            <span className="text-[11px] text-slate-400 font-medium mt-1 block">
              {isAr ? 'تحديث تلقائي كل 5 ثوانٍ' : 'Auto-polling every 5s'}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Zap className="w-6 h-6 animate-pulse" />
          </div>
        </div>
      </div>

      {/* Category Filter Tabs & Search Bar */}
      <div className="rounded-3xl border border-slate-800 bg-[#0d1017] p-4 sm:p-6 space-y-5 shadow-xl">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'all', label: isAr ? 'الكل (جميع السجلات)' : 'All Events', count: authLogs.length + serverJoinLogs.length + liveThreatLogs.length },
              { id: 'auth', label: isAr ? 'مصادقة المستخدمين (OAuth2)' : 'User Auth Logs', count: authLogs.length },
              { id: 'joins', label: isAr ? 'دخول البوت للسيرفرات' : 'Bot-Server Joins', count: serverJoinLogs.length },
              { id: 'threats', label: isAr ? 'سجلات الحماية' : 'Security Logs', count: liveThreatLogs.length }
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  sound.playClick();
                  setActiveCategory(tab.id as any);
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                  activeCategory === tab.id
                    ? 'bg-[#5865F2] text-white shadow-lg shadow-[#5865F2]/30'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <span>{tab.label}</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-black/30 text-white font-black">
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute start-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isAr ? 'بحث بالاسم أو الـ ID أو السيرفر...' : 'Search by user, ID, or server...'}
              className="w-full ps-10 pe-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#5865F2]"
            />
          </div>
        </div>

        {/* SECTION 1: USER AUTHENTICATION EVENTS (DISCORD OAUTH2) */}
        {(activeCategory === 'all' || activeCategory === 'auth') && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <LogIn className="w-4 h-4 text-indigo-400" />
                {isAr
                  ? 'سجلات مصادقة المستخدمين عبر ديسكورد (Real-Time User Authentication Logs)'
                  : 'Real-Time User Authentication Events (Discord OAuth2)'}
              </h3>
              <span className="text-[11px] font-mono text-indigo-400">
                {filteredAuthLogs.length} {isAr ? 'عملية تسجيل دخول' : 'auth events'}
              </span>
            </div>

            <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
              {filteredAuthLogs.map((auth) => (
                <div
                  key={auth.id}
                  className="p-4 rounded-2xl bg-slate-900/85 border border-slate-800 hover:border-indigo-500/40 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={auth.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}
                      alt={auth.username}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/40 shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-black text-white text-sm">{auth.username}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                          ID: {auth.userId}
                        </span>
                        {auth.isOwner ? (
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                            <Crown className="w-3 h-3 text-amber-400" />
                            {isAr ? 'المالك الرسمي (Full Bot Owner)' : 'Official Bot Owner'}
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                            🛡️ {isAr ? 'إداري سيرفر (Server Admin)' : 'Server Admin'}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-2 mt-1">
                        <span>🌐 {auth.source}</span>
                        <span>•</span>
                        <span>🏠 {auth.guildName}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end justify-between gap-1 shrink-0">
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      {isAr ? 'تم التوثيق بنجاح' : 'Authenticated'}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {auth.timestamp}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION 2: BOT-SERVER JOIN ACTIONS */}
        {(activeCategory === 'all' || activeCategory === 'joins') && (
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Server className="w-4 h-4 text-emerald-400" />
                {isAr
                  ? 'سجلات دخول البوت إلى السيرفرات (Bot-Server Join Actions)'
                  : 'Real-Time Bot-Server Join Actions'}
              </h3>
              <span className="text-[11px] font-mono text-emerald-400">
                {filteredJoinLogs.length} {isAr ? 'سيرفر مسجل' : 'servers joined'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-80 overflow-y-auto pr-1">
              {filteredJoinLogs.map((join) => (
                <div
                  key={join.id}
                  className="p-4 rounded-2xl bg-slate-900/85 border border-slate-800 hover:border-emerald-500/40 transition-all flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {join.guildIcon ? (
                      <img
                        src={join.guildIcon}
                        alt={join.guildName}
                        className="w-11 h-11 rounded-2xl object-cover shrink-0 ring-1 ring-emerald-500/40"
                      />
                    ) : (
                      <div className="w-11 h-11 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center font-black text-emerald-300 text-xs shrink-0">
                        {join.guildName.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="font-black text-white text-sm truncate">{join.guildName}</div>
                      <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                        Guild ID: {join.guildId}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {(join.memberCount || 0).toLocaleString()} {isAr ? 'عضو' : 'members'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-end shrink-0">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 block">
                      {isAr ? '🟢 انضمام ناجح' : '🟢 Bot Joined'}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono mt-1.5 block">
                      {join.joinedAt}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION 3: SECURITY & THREAT LOGS */}
        {(activeCategory === 'all' || activeCategory === 'threats') && (
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-rose-400" />
                {isAr
                  ? 'سجل العمليات والتهديدات الأمنية الفورية (Security & Protection Logs)'
                  : 'Live Security & Protection Feed'}
              </h3>
              <span className="text-[11px] font-mono text-rose-400">
                {filteredThreatLogs.length} {isAr ? 'حدث أمني' : 'security events'}
              </span>
            </div>

            <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
              {filteredThreatLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
                      <ShieldAlert className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-bold text-white truncate">{log.details || log.action || log.type}</div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                        <span>👤 {log.executor}</span>
                        <span>•</span>
                        <span>📍 {log.target}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-end shrink-0">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold block">
                      {log.type}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono mt-1 block">{log.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Real-Time Recharts Timeline Visualizer */}
      <div className="rounded-3xl border border-slate-800 bg-[#0d1017] p-6 space-y-4 shadow-xl">
        <div>
          <h3 className="text-sm font-black text-white flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-indigo-400" />
            {isAr
              ? 'المخطط البياني الفوري للمصادقة ودخول السيرفرات والحماية'
              : 'Real-Time Authentication, Server Joins & Protection Chart'}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            {isAr
              ? 'تحليل حي لنشاط تسجيل الدخول عبر ديسكورد وانضمام السيرفرات على مدار الـ يوم كامل'
              : 'Live 24-hour activity timeline'}
          </p>
        </div>

        <div className="w-full h-72 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorAuth" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="colorJoins" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="time" stroke="#64748b" style={{ fontSize: '11px' }} />
              <YAxis stroke="#64748b" style={{ fontSize: '11px' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0c0f17',
                  borderColor: '#334155',
                  borderRadius: '12px',
                  color: '#fff',
                  fontSize: '12px'
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
              <Area
                type="monotone"
                dataKey="auth"
                name={isAr ? 'مصادقة الدخول (OAuth2)' : 'User Logins'}
                stroke="#6366f1"
                fillOpacity={1}
                fill="url(#colorAuth)"
              />
              <Area
                type="monotone"
                dataKey="joins"
                name={isAr ? 'دخول السيرفرات' : 'Server Joins'}
                stroke="#10b981"
                fillOpacity={1}
                fill="url(#colorJoins)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
