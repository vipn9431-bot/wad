import React, { useMemo, useState } from 'react';
import {
  Shield,
  ShieldAlert,
  Volume2,
  VolumeX,
  Globe,
  Server,
  ChevronDown,
  Check,
  Users,
  Bell,
  Sparkles,
  Radio,
  Ticket as TicketIcon,
  FileText,
  Moon,
  Settings,
  LogOut,
  Menu,
  X,
  RotateCw,
  Palette,
  ShieldCheck,
  Database,
  MessageSquare,
  BarChart3,
  Wrench,
  Home,
  Mic,
  Gamepad2,
  BookOpen,
  Trophy,
  Minus,
  Layout,
  Smile,
  Send,
  Wand2,
  Lightbulb,
  CheckCircle2,
  Rocket,
  Search
} from 'lucide-react';
import { sound } from '../utils/sound';
import { ConnectedBotData, getAuthHeaders } from './TokenAuthGate';
import { ConnectedGuildItem, AccessRoleMode, GuildJoinNotification, ThemeMode } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { HashLink, useHashRouter } from '../utils/hashRouter';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  panicMode: boolean;
  onTogglePanicMode: () => void;
  lang: 'ar' | 'en';
  setLang: (lang: 'ar' | 'en') => void;
  soundEnabled: boolean;
  setSoundEnabled: (v: boolean) => void;
  botInfo: ConnectedBotData | null;
  onOpenTokenGate: () => void;
  onSelectGuild?: (guild: ConnectedGuildItem) => void;
  accessMode: AccessRoleMode;
  onToggleAccessMode: (mode: AccessRoleMode) => void;
  notifications: GuildJoinNotification[];
  unreadCount: number;
  onMarkNotificationsRead: () => void;
  onSimulateServerJoin: () => void;
  onLogout?: () => void;
  onTriggerRefresh?: () => void;
  externalMenuOpen?: boolean;
  onExternalMenuOpenChange?: (open: boolean) => void;
}

export interface SidebarNavItem {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}

export interface SidebarCategoryGroup {
  categoryTitle: string;
  items: SidebarNavItem[];
}

export function getCategorizedNavGroups(isAr: boolean): SidebarCategoryGroup[] {
  return [
    {
      categoryTitle: isAr ? 'عام' : 'General',
      items: [
        { id: 'overview', icon: Home, label: isAr ? 'نظرة عامة' : 'Overview' },
        { id: 'analytics', icon: BarChart3, label: isAr ? 'الإحصائيات والتحليلات' : 'Analytics' },
        { id: 'audit_logs', icon: FileText, label: isAr ? 'سجلات السيرفر' : 'Audit Logs' },
        { id: 'wizard', icon: CheckCircle2, label: isAr ? 'فحص جهوزية البوت' : 'Pre-Publish Check' }
      ]
    },
    {
      categoryTitle: isAr ? 'الإشراف والحماية' : 'Protection',
      items: [
        { id: 'antinuke', icon: Shield, label: isAr ? 'الحماية والرادار' : 'Protection' },
        { id: 'staff_warnings', icon: ShieldAlert, label: isAr ? 'الإشراف والرقابة' : 'Staff Warnings' },
        { id: 'rules_builder', icon: BookOpen, label: isAr ? 'القوانين' : 'Server Rules' }
      ]
    },
    {
      categoryTitle: isAr ? 'المجتمع والتفاعل' : 'Community',
      items: [
        { id: 'ready_rooms', icon: Wand2, label: isAr ? 'الرومات الجاهزة ومنشئ السيرفر' : 'Ready Rooms & Builder' },
        { id: 'tickets', icon: TicketIcon, label: isAr ? 'التذاكر' : 'Tickets' },
        { id: 'welcome', icon: Sparkles, label: isAr ? 'الترحيب' : 'Welcome Studio' },
        { id: 'staff_apps', icon: ShieldCheck, label: isAr ? 'التقديمات' : 'Applications' },
        { id: 'suggestions', icon: Lightbulb, label: isAr ? 'الاقتراحات' : 'Suggestions' },
        { id: 'levels_ranks', icon: Trophy, label: isAr ? 'المستويات والرتب' : 'Levels & Ranks' },
        { id: 'roles_stats', icon: Users, label: isAr ? 'الرتب التلقائية' : 'Auto Roles' },
        { id: 'games', icon: Gamepad2, label: isAr ? 'الألعاب' : 'Games Arena' }
      ]
    },
    {
      categoryTitle: isAr ? 'التخصيص والأتمتة' : 'Automation',
      items: [
        { id: 'extras', icon: MessageSquare, label: isAr ? 'الردود التلقائية' : 'Auto-Replies' },
        { id: 'auto_line', icon: Minus, label: isAr ? 'الخط التلقائي' : 'Auto-Line' },
        { id: 'embed_builder', icon: Layout, label: isAr ? 'صانع الإيمبد' : 'Embed Builder' },
        { id: 'auto_emoji', icon: Smile, label: isAr ? 'الإيموجي التلقائي' : 'Auto-Emoji' },
        { id: 'tempvoice', icon: Mic, label: isAr ? 'رومات صوتية مؤقتة' : 'TempVoice' },
        { id: 'azkar', icon: Moon, label: isAr ? 'الأذكار والأدعية' : 'Azkar & Duas' },
        { id: 'quran', icon: Radio, label: isAr ? 'إذاعة القرآن الكريم' : 'Holy Quran Radio' }
      ]
    },
    {
      categoryTitle: isAr ? 'أدوات البوت والإدارة' : 'Admin Tools',
      items: [
        { id: 'mass_dm', icon: Send, label: isAr ? 'الإرسال الجماعي' : 'Mass Role DM' },
        { id: 'commands', icon: Wrench, label: isAr ? 'إعدادات الأوامر' : 'Commands' },
        { id: 'backup', icon: Database, label: isAr ? 'النسخ الاحتياطي' : 'Backup' },
        { id: 'basics', icon: Settings, label: isAr ? 'إعدادات البوت والذكاء' : 'Bot & AI Settings' },
        { id: 'replit', icon: Rocket, label: isAr ? 'النشر على Replit' : 'Deploy to Replit' }
      ]
    }
  ];
}

interface DashboardSidebarProps {
  lang: 'ar' | 'en';
  botInfo: ConnectedBotData | null;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onNavigateComplete?: (tabId: string) => void;
}

export const DashboardSidebar: React.FC<DashboardSidebarProps> = ({
  lang,
  botInfo,
  mobileOpen,
  onCloseMobile,
  onNavigateComplete
}) => {
  const isAr = lang === 'ar';
  const { currentRoute, navigate } = useHashRouter();
  const [navFilter, setNavFilter] = useState('');

  const groups = useMemo(() => getCategorizedNavGroups(isAr), [isAr]);

  const filteredGroups = useMemo(() => {
    const q = navFilter.trim().toLowerCase();
    if (!q) return groups;
    return groups
      .map((group) => ({
        ...group,
        items: group.items.filter(
          (item) =>
            item.label.toLowerCase().includes(q) ||
            item.id.toLowerCase().includes(q)
        )
      }))
      .filter((group) => group.items.length > 0);
  }, [groups, navFilter]);

  const activeGuild =
    botInfo?.selectedGuild ||
    botInfo?.guilds?.find((g) => g.hasBot !== false && g.botPresent !== false) ||
    botInfo?.guilds?.[0] || {
      id: '',
      name: isAr ? 'اختر سيرفراً' : 'Select Server',
      memberCount: botInfo?.membersCount || 0
    };

  const renderSidebarInner = (isMobileDrawer: boolean) => (
    <div className="flex flex-col h-full justify-between">
      <div className="p-4 space-y-4 overflow-y-auto flex-1">
        {isMobileDrawer && (
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <span className="text-sm font-bold text-white tracking-tight">
              {isAr ? 'أقسام لوحة التحكم' : 'Dashboard Navigation'}
            </span>
            <button
              type="button"
              onClick={onCloseMobile}
              aria-label={isAr ? 'إغلاق القائمة' : 'Close menu'}
              className="min-h-[40px] min-w-[40px] rounded-lg border border-slate-800 bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Quick Route Filter */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={navFilter}
            onChange={(e) => setNavFilter(e.target.value)}
            placeholder={isAr ? 'تصفية الأنظمة...' : 'Filter systems...'}
            aria-label={isAr ? 'تصفية الأنظمة' : 'Filter systems'}
            className="w-full h-10 ps-9 pe-3 rounded-lg bg-[#0d121d] border border-slate-800/90 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500/60 focus-visible:ring-2 focus-visible:ring-indigo-400/50 transition-colors"
          />
        </div>

        {/* Categorized HashRouter Links */}
        <nav aria-label={isAr ? 'التنقل الرئيسي' : 'Primary Navigation'} className="space-y-5">
          {filteredGroups.length > 0 ? (
            filteredGroups.map((group) => (
              <div key={group.categoryTitle} className="space-y-1">
                <div className="px-2.5 pb-1 text-[11px] font-semibold text-slate-500">
                  {group.categoryTitle}
                </div>
                {group.items.map((item) => {
                  const isActive = currentRoute === item.id;
                  const Icon = item.icon;
                  return (
                    <HashLink
                      key={item.id}
                      to={item.id}
                      onNavigate={(routeId) => {
                        sound.playClick();
                        if (onNavigateComplete) onNavigateComplete(routeId);
                        if (isMobileDrawer) onCloseMobile();
                      }}
                      className={`min-h-[40px] px-3 py-2 rounded-lg flex items-center gap-2.5 text-xs font-medium transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 ${
                        isActive
                          ? 'bg-indigo-500/15 text-white border border-indigo-500/35 font-semibold'
                          : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 border border-transparent'
                      }`}
                    >
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive ? 'text-indigo-400' : 'text-slate-500'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </HashLink>
                  );
                })}
              </div>
            ))
          ) : (
            <div className="px-3 py-6 text-center text-xs text-slate-500">
              {isAr ? 'لا توجد نتائج مطابقة' : 'No matching views'}
            </div>
          )}
        </nav>
      </div>

      {/* Bottom Active Guild Metadata Footer */}
      <div className="p-4 border-t border-slate-800/80 bg-[#070a11]">
        <div className="flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <Server className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="font-medium text-slate-200 truncate">{activeGuild.name}</span>
          </div>
          <span className="font-mono tabular-nums text-[11px] text-slate-400 shrink-0">
            {activeGuild.memberCount}
          </span>
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
          <HashLink
            to="replit"
            onNavigate={(routeId) => {
              sound.playClick();
              if (onNavigateComplete) onNavigateComplete(routeId);
              if (isMobileDrawer) onCloseMobile();
            }}
            className="hover:text-slate-200 transition-colors focus-visible:outline-none focus-visible:underline"
          >
            {isAr ? 'دليل النشر السحابي' : 'Cloud Deployment Setup'}
          </HashLink>
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              navigate('wizard');
              if (onNavigateComplete) onNavigateComplete('wizard');
              if (isMobileDrawer) onCloseMobile();
            }}
            className="text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
          >
            {isAr ? 'فحص الجهوزية' : 'Diagnostics'}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Persistent Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 border-e border-slate-800/80 bg-[#080b12] sticky top-16 h-[calc(100vh-4rem)] select-none">
        {renderSidebarInner(false)}
      </aside>

      {/* Responsive Mobile Slide-Over Drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-[100] flex bg-black/70 backdrop-blur-sm">
          <aside
            dir={isAr ? 'rtl' : 'ltr'}
            className="w-[290px] max-w-[85vw] h-screen bg-[#080b12] border-e border-slate-800 flex flex-col justify-between shadow-2xl"
          >
            {renderSidebarInner(true)}
          </aside>
          <div className="flex-1 cursor-pointer" onClick={onCloseMobile} />
        </div>
      )}
    </>
  );
};

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  panicMode,
  onTogglePanicMode,
  lang,
  setLang,
  soundEnabled,
  setSoundEnabled,
  botInfo,
  onOpenTokenGate,
  onSelectGuild,
  notifications,
  unreadCount,
  onMarkNotificationsRead,
  onSimulateServerJoin,
  onLogout,
  onTriggerRefresh,
  externalMenuOpen,
  onExternalMenuOpenChange
}) => {
  const isAr = lang === 'ar';
  const { theme, setTheme } = useTheme();
  const { currentRoute, routeMeta } = useHashRouter();
  const [themeDropdownOpen, setThemeDropdownOpen] = useState(false);
  const [guildDropdownOpen, setGuildDropdownOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [internalMenuOpen, setInternalMenuOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const resolvedRoute = currentRoute || activeTab;

  const mobileMenuOpen = externalMenuOpen !== undefined ? externalMenuOpen : internalMenuOpen;
  const setMobileMenuOpen = (val: boolean) => {
    setInternalMenuOpen(val);
    if (onExternalMenuOpenChange) {
      onExternalMenuOpenChange(val);
    }
  };

  const handleQuickRefresh = async () => {
    setIsRefreshing(true);
    sound.playShieldActivate();
    if (onTriggerRefresh) {
      onTriggerRefresh();
    } else {
      try {
        await fetch('/api/bot/refresh', {
          method: 'POST',
          credentials: 'include',
          headers: getAuthHeaders()
        });
      } catch {}
    }
    setTimeout(() => setIsRefreshing(false), 1800);
  };

  const rawGuilds = botInfo?.guilds && botInfo.guilds.length > 0 ? botInfo.guilds : [];
  const botPresentGuilds = rawGuilds.filter((g) => g.hasBot !== false && g.botPresent !== false);
  const availableGuilds = botPresentGuilds.length > 0 ? botPresentGuilds : rawGuilds;

  const activeGuild =
    botInfo?.selectedGuild ||
    availableGuilds[0] || {
      id: '',
      name: isAr ? 'اختر سيرفراً' : 'Select Server',
      icon: '',
      memberCount: botInfo?.membersCount || 0,
      channelsCount: botInfo?.channelsCount || 0,
      rolesCount: 0
    };

  const primaryTopLinks = [
    { id: 'overview', label: isAr ? 'نظرة عامة' : 'Overview' },
    { id: 'antinuke', label: isAr ? 'الحماية' : 'Protection' },
    { id: 'tickets', label: isAr ? 'التذاكر' : 'Tickets' },
    { id: 'ready_rooms', label: isAr ? 'الرومات الجاهزة' : 'Ready Rooms' },
    { id: 'commands', label: isAr ? 'الأوامر' : 'Commands' }
  ];

  return (
    <header className="sticky top-0 z-50 h-16 bg-[#080b12]/95 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-6 flex items-center">
      <div className="w-full flex items-center justify-between gap-6">
        {/* Zone 1: Mobile Menu Trigger + Clean Brand Wordmark + Contextual Breadcrumb */}
        <div className="flex items-center gap-3 min-w-0 shrink-0">
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setMobileMenuOpen(!mobileMenuOpen);
            }}
            aria-label={isAr ? 'فتح قائمة التنقل' : 'Toggle navigation menu'}
            className="lg:hidden min-h-[40px] min-w-[40px] rounded-lg border border-slate-800 bg-slate-900/90 hover:bg-slate-800 text-slate-200 flex items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>

          <HashLink
            to="overview"
            onNavigate={(routeId) => {
              sound.playClick();
              setActiveTab(routeId);
            }}
            className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 rounded-md px-1"
          >
            M7R
          </HashLink>

          <nav
            aria-label="Breadcrumb"
            className="hidden md:flex items-center gap-2 text-xs text-slate-400 ps-3 border-s border-slate-800 whitespace-nowrap"
          >
            <span>{isAr ? routeMeta.categoryAr : routeMeta.categoryEn}</span>
            <span aria-hidden="true" className="text-slate-600">/</span>
            <span className="font-medium text-slate-200">
              {isAr ? routeMeta.labelAr : routeMeta.labelEn}
            </span>
          </nav>
        </div>

        {/* Zone 2: 5 Concise Single-Line Top Nav Links (Desktop xl+) */}
        <nav
          aria-label={isAr ? 'روابط سريعة' : 'Quick Links'}
          className="hidden xl:flex items-center gap-6"
        >
          {primaryTopLinks.map((link) => {
            const isActive = resolvedRoute === link.id;
            return (
              <HashLink
                key={link.id}
                to={link.id}
                onNavigate={(routeId) => {
                  sound.playClick();
                  setActiveTab(routeId);
                }}
                className={`py-1.5 text-xs font-medium whitespace-nowrap shrink-0 border-b-2 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 ${
                  isActive
                    ? 'text-white border-indigo-500'
                    : 'text-slate-400 border-transparent hover:text-slate-100 hover:border-slate-700'
                }`}
              >
                {link.label}
              </HashLink>
            );
          })}
        </nav>

        {/* Zone 3: Active Server Selector + Essential Workspace Utilities + Primary Action */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Active Guild Selector Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setGuildDropdownOpen(!guildDropdownOpen);
                setNotifDropdownOpen(false);
                setThemeDropdownOpen(false);
              }}
              className="min-h-[40px] px-3 py-1.5 rounded-lg bg-[#0d121d] hover:bg-slate-800/80 border border-slate-800 text-xs text-slate-100 flex items-center gap-2 cursor-pointer transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
              title={isAr ? 'تبديل السيرفر النشط' : 'Switch active server'}
            >
              {activeGuild.icon ? (
                <img
                  src={activeGuild.icon}
                  alt={activeGuild.name}
                  className="w-4 h-4 rounded-full object-cover shrink-0"
                />
              ) : (
                <Server className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              )}
              <span className="font-semibold max-w-[110px] sm:max-w-[150px] truncate">
                {activeGuild.name}
              </span>
              <span className="hidden sm:inline font-mono tabular-nums text-[11px] text-slate-400">
                {activeGuild.memberCount}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            </button>

            {guildDropdownOpen && (
              <div className="absolute end-0 mt-2 w-72 rounded-xl bg-[#0d121d] border border-slate-800 shadow-2xl p-2 z-50 space-y-1">
                <div className="px-2.5 py-1.5 text-[11px] font-semibold text-slate-400 border-b border-slate-800 flex items-center justify-between">
                  <span>{isAr ? 'السيرفرات المتاحة' : 'Authorized Servers'}</span>
                  <button
                    type="button"
                    onClick={() => setGuildDropdownOpen(false)}
                    className="text-slate-400 hover:text-white cursor-pointer"
                  >
                    {isAr ? 'إغلاق' : 'Close'}
                  </button>
                </div>

                {availableGuilds.map((g) => {
                  const isCurrent = g.id === activeGuild.id;
                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        sound.playClick();
                        if (onSelectGuild) onSelectGuild(g);
                        setGuildDropdownOpen(false);
                      }}
                      className={`w-full text-start p-2 rounded-lg flex items-center justify-between gap-2 cursor-pointer transition-colors ${
                        isCurrent
                          ? 'bg-indigo-500/15 border border-indigo-500/35 text-white'
                          : 'hover:bg-slate-800/70 text-slate-300 border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {g.icon ? (
                          <img
                            src={g.icon}
                            alt={g.name}
                            className="w-7 h-7 rounded-md object-cover shrink-0"
                          />
                        ) : (
                          <div className="w-7 h-7 rounded-md bg-slate-800 border border-slate-700 flex items-center justify-center font-semibold text-slate-200 text-xs shrink-0">
                            {g.name.slice(0, 2).toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0">
                          <span className="text-xs font-semibold block truncate">{g.name}</span>
                          <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                            {g.memberCount} {isAr ? 'عضو' : 'members'}
                          </span>
                        </div>
                      </div>
                      {isCurrent && <Check className="w-4 h-4 text-indigo-400 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Refresh Bot Sync */}
          <button
            type="button"
            onClick={handleQuickRefresh}
            disabled={isRefreshing}
            title={isAr ? 'تحديث ومزامنة حالة البوت' : 'Sync Bot Status'}
            className="hidden sm:flex min-h-[40px] min-w-[40px] rounded-lg bg-[#0d121d] hover:bg-slate-800/80 border border-slate-800 text-slate-300 hover:text-white items-center justify-center cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
          >
            <RotateCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-indigo-400' : ''}`} />
          </button>

          {/* Notifications Bell */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                const nextOpen = !notifDropdownOpen;
                setNotifDropdownOpen(nextOpen);
                setGuildDropdownOpen(false);
                setThemeDropdownOpen(false);
                if (nextOpen && unreadCount > 0) {
                  onMarkNotificationsRead();
                }
              }}
              className={`relative min-h-[40px] min-w-[40px] px-2.5 rounded-lg border text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 ${
                unreadCount > 0
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                  : 'bg-[#0d121d] border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800/80'
              }`}
              title={isAr ? 'إشعارات السيرفرات' : 'Server Notifications'}
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="font-mono tabular-nums text-[11px] font-bold">
                  {unreadCount}
                </span>
              )}
            </button>

            {notifDropdownOpen && (
              <div className="absolute end-0 mt-2 w-80 sm:w-96 rounded-xl bg-[#0d121d] border border-slate-800 shadow-2xl p-3 z-50 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h4 className="text-xs font-semibold text-white">
                    {isAr ? 'إشعارات دخول البوت للسيرفرات' : 'Server Join Notifications'}
                  </h4>
                  <button
                    type="button"
                    onClick={() => setNotifDropdownOpen(false)}
                    className="text-xs text-slate-400 hover:text-white cursor-pointer"
                  >
                    {isAr ? 'إغلاق' : 'Close'}
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    sound.playShieldActivate();
                    onSimulateServerJoin();
                  }}
                  className="w-full py-2 px-3 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>{isAr ? 'اختبار إشعار دخول سيرفر جديد' : 'Simulate Server Join Alert'}</span>
                </button>

                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {notifications.length > 0 ? (
                    notifications.map((n) => (
                      <div
                        key={n.id}
                        className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-2.5"
                      >
                        <div className="w-8 h-8 rounded-md bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-semibold text-slate-200 shrink-0">
                          {n.guildName.slice(0, 2).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <h5 className="text-xs font-semibold text-white truncate">{n.guildName}</h5>
                          <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                            {n.memberCount} {isAr ? 'عضو' : 'members'} · {n.joinedAt}
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="py-6 text-center text-xs text-slate-500">
                      {isAr ? 'لا توجد إشعارات جديدة حالياً' : 'No new notifications'}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={() => {
              setSoundEnabled(!soundEnabled);
              if (!soundEnabled) sound.playClick();
            }}
            title={isAr ? 'كتم/تشغيل المؤثرات الصوتية' : 'Toggle sound effects'}
            className="hidden md:flex min-h-[40px] min-w-[40px] rounded-lg bg-[#0d121d] hover:bg-slate-800/80 border border-slate-800 text-slate-300 hover:text-white items-center justify-center transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-indigo-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Theme Selector */}
          <div className="relative hidden md:block">
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setThemeDropdownOpen(!themeDropdownOpen);
                setGuildDropdownOpen(false);
                setNotifDropdownOpen(false);
              }}
              title={isAr ? 'نمط التباين' : 'Theme'}
              className="min-h-[40px] px-2.5 rounded-lg bg-[#0d121d] hover:bg-slate-800/80 border border-slate-800 text-slate-300 hover:text-white flex items-center gap-1 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
            >
              <Palette className="w-4 h-4 text-slate-300" />
              <ChevronDown className="w-3 h-3 text-slate-500" />
            </button>

            {themeDropdownOpen && (
              <div className="absolute end-0 mt-2 w-52 rounded-xl bg-[#0d121d] border border-slate-800 shadow-2xl p-1.5 z-50 space-y-1">
                {[
                  { id: 'dark', label: isAr ? 'داكن كلاسيكي' : 'Dark Classic' },
                  { id: 'midnight', label: isAr ? 'منتصف الليل' : 'Midnight Indigo' },
                  { id: 'cyber', label: isAr ? 'سايبر عالي التباين' : 'High Contrast' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setTheme(item.id as ThemeMode);
                      sound.playClick();
                      setThemeDropdownOpen(false);
                    }}
                    className={`w-full text-start px-3 py-2 rounded-lg flex items-center justify-between text-xs cursor-pointer transition-colors ${
                      theme === item.id
                        ? 'bg-indigo-500/15 border border-indigo-500/35 text-white font-semibold'
                        : 'hover:bg-slate-800/70 text-slate-300 border border-transparent'
                    }`}
                  >
                    <span>{item.label}</span>
                    {theme === item.id && <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Language Toggle */}
          <button
            type="button"
            onClick={() => {
              setLang(isAr ? 'en' : 'ar');
              sound.playClick();
            }}
            className="min-h-[40px] px-2.5 rounded-lg bg-[#0d121d] hover:bg-slate-800/80 border border-slate-800 text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-mono">{isAr ? 'EN' : 'عربي'}</span>
          </button>

          {/* Primary Lockdown / Panic Action */}
          <button
            type="button"
            onClick={() => {
              onTogglePanicMode();
              if (!panicMode) sound.playAlarm();
              else sound.playClick();
            }}
            className={`min-h-[40px] px-3.5 py-2 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400 ${
              panicMode
                ? 'bg-rose-600 text-white border border-rose-500'
                : 'bg-rose-950/60 hover:bg-rose-900/70 text-rose-200 border border-rose-800/70'
            }`}
          >
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span className="hidden sm:inline">
              {panicMode
                ? isAr
                  ? 'إغلاق الطوارئ نشط'
                  : 'Lockdown Active'
                : isAr
                ? 'وضع الطوارئ'
                : 'Panic Mode'}
            </span>
          </button>

          {/* Logged-in Discord User Avatar + Username + Logout */}
          {botInfo?.discordUser && (
            <div className="hidden sm:flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-[#0d121d] border border-slate-800">
              <img
                src={botInfo.discordUser.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}
                alt={botInfo.discordUser.username}
                className="w-5 h-5 rounded-full object-cover border border-[#38bdf8]/40 shrink-0"
              />
              <span className="text-xs font-semibold text-slate-200 font-mono max-w-[90px] truncate">
                {botInfo.discordUser.username}
              </span>
            </div>
          )}

          {/* Logout */}
          <button
            type="button"
            onClick={() => {
              if (onLogout) {
                onLogout();
              } else {
                onOpenTokenGate();
              }
            }}
            title={isAr ? 'تسجيل الخروج' : 'Sign Out'}
            className="min-h-[40px] min-w-[40px] rounded-lg bg-[#0d121d] hover:bg-rose-950/40 border border-slate-800 hover:border-rose-700/50 text-slate-400 hover:text-rose-200 flex items-center justify-center transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
