import React, { useState } from 'react';
import {
  Ticket as TicketIcon,
  UserCheck,
  Lock,
  Trash2,
  UserPlus,
  ArrowRightLeft,
  BellRing,
  Send,
  Download,
  Plus,
  X,
  Palette,
  SendHorizonal,
  CheckCircle2,
  Settings2,
  Bot,
  Clock,
  HelpCircle,
  Hash,
  Unlock,
  Loader2,
  ShieldCheck,
  Image as ImageIcon,
  Upload,
  RotateCcw,
  Star,
  Trophy,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  Eye
} from 'lucide-react';
import { Ticket, TicketPanelConfig, TicketPanelButton, TicketTranscriptItem, StaffRatingMember } from '../types';
import { ChannelSelector } from './ChannelSelector';
import { sound } from '../utils/sound';

interface TicketsTabProps {
  lang: 'ar' | 'en';
  tickets: Ticket[];
  onTicketAction: (ticketId: string, action: string, staffName?: string, extra?: string) => void;
  onCreateSimulatedTicket: (category: 'store' | 'support' | 'complaints' | 'partnerships', categoryLabel: string) => void;
  panelConfig: TicketPanelConfig;
  onChangePanelConfig: (updated: TicketPanelConfig) => void;
  guildId?: string;
}

export const TicketsTab: React.FC<TicketsTabProps> = ({
  lang,
  tickets,
  onTicketAction,
  onCreateSimulatedTicket,
  panelConfig,
  onChangePanelConfig,
  guildId
}) => {
  const isAr = lang === 'ar';
  const activeGuildId = (guildId || (typeof window !== 'undefined' ? localStorage.getItem('m7r_selected_guild_id') : '') || '').trim();
  const [selectedTicketId, setSelectedTicketId] = useState<string>(tickets[0]?.id || '');
  const [replyInput, setReplyInput] = useState('');
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [targetUsername, setTargetUsername] = useState('');
  const [targetDepartment, setTargetDepartment] = useState('إدارة المبيعات');
  const [activeView, setActiveView] = useState<'builder' | 'desk' | 'transcripts'>('builder');
  const [deployFeedback, setDeployFeedback] = useState<string | null>(null);
  const [isDeploying, setIsDeploying] = useState(false);
  const [creatingTicketLoading, setCreatingTicketLoading] = useState<string | null>(null);
  const [htmlTranscripts, setHtmlTranscripts] = useState<TicketTranscriptItem[]>([]);
  const [staffLeaderboard, setStaffLeaderboard] = useState<StaffRatingMember[]>([]);
  const [previewTranscript, setPreviewTranscript] = useState<TicketTranscriptItem | null>(null);
  const [previewPage, setPreviewPage] = useState(0);
  const [generatingHtml, setGeneratingHtml] = useState(false);
  const [sendingStaffTop, setSendingStaffTop] = useState(false);

  const fetchSummariesAndLeaderboard = () => {
    const targetGId = activeGuildId || (typeof window !== 'undefined' ? localStorage.getItem('m7r_selected_guild_id') : '') || '';
    const q = targetGId ? `?guildId=${encodeURIComponent(targetGId)}` : '';
    fetch(`/api/tickets/transcripts${q}`)
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data?.transcripts)) {
          setHtmlTranscripts(data.transcripts);
        }
        if (Array.isArray(data?.staffLeaderboard)) {
          setStaffLeaderboard(data.staffLeaderboard);
        }
      })
      .catch(() => {});
  };

  React.useEffect(() => {
    fetchSummariesAndLeaderboard();
  }, [activeView, activeGuildId]);

  const selectedTicket = tickets.find((t) => t.id === selectedTicketId) || tickets[0];

  const effectiveBannerUrl =
    panelConfig.bannerUrl !== undefined
      ? panelConfig.bannerUrl
      : '/assets/aistudio/IMG_3117_2cec6847.jpeg';

  const updatePanelField = <K extends keyof TicketPanelConfig>(key: K, value: TicketPanelConfig[K]) => {
    onChangePanelConfig({
      ...panelConfig,
      [key]: value
    });
  };

  const handleBannerFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        sound.playShieldActivate();
        updatePanelField('bannerUrl', reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const updateButtonItem = (btnId: string, field: keyof TicketPanelButton, value: any) => {
    const nextButtons = panelConfig.buttons.map((b) =>
      b.id === btnId ? { ...b, [field]: value } : b
    );
    updatePanelField('buttons', nextButtons);
  };

  const [askCloseReasonModal, setAskCloseReasonModal] = useState(true);
  const [maxOpenTicketsPerUser, setMaxOpenTicketsPerUser] = useState(4);
  const [editingButtonId, setEditingButtonId] = useState<string | null>(null);

  const handleAddButton = () => {
    sound.playClick();
    const newBtn: TicketPanelButton = {
      id: `btn_${Date.now()}`,
      label: isAr ? `قسم جديد #${panelConfig.buttons.length + 1}` : `New Category #${panelConfig.buttons.length + 1}`,
      emoji: '🎫',
      style: 'Primary',
      categoryDescription: isAr ? 'وصف القسم الجديد في لوحة التذاكر' : 'Description for this ticket button',
      enabled: true
    };
    updatePanelField('buttons', [...panelConfig.buttons, newBtn]);
    setEditingButtonId(newBtn.id);
  };

  const handleRemoveButton = (btnId: string) => {
    sound.playClick();
    updatePanelField(
      'buttons',
      panelConfig.buttons.filter((b) => b.id !== btnId)
    );
  };

  const handleDeployPanelToDiscord = async () => {
    setIsDeploying(true);
    setDeployFeedback(null);
    sound.playShieldActivate();
    try {
      const targetGId = activeGuildId || localStorage.getItem('m7r_selected_guild_id') || '';
      const res = await fetch('/api/tickets/deploy-panel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guildId: targetGId,
          panelConfig,
          channelId: panelConfig.targetChannelName,
          channelName: panelConfig.targetChannelName,
          ratingChannelId: panelConfig.ratingChannelName || panelConfig.ticketLogChannelName || panelConfig.targetChannelName,
          ratingChannelName: panelConfig.ratingChannelName || panelConfig.ticketLogChannelName || panelConfig.targetChannelName
        })
      });
      const data = await res.json();
      setDeployFeedback(
        data.message || data.error || (res.ok ? '✅ تم إرسال البانل بنجاح!' : '❌ فشل إرسال البانل إلى ديسكورد.')
      );
      setTimeout(() => setDeployFeedback(null), 9000);
    } catch (err: any) {
      setDeployFeedback(`❌ حدث خطأ أثناء الاتصال بالخادم: ${err?.message || 'Error'}`);
    } finally {
      setIsDeploying(false);
    }
  };

  const handleTestStaffRatingInDiscord = async () => {
    setIsDeploying(true);
    setDeployFeedback(null);
    sound.playClick();
    try {
      const targetGId = activeGuildId || localStorage.getItem('m7r_selected_guild_id') || '';
      const res = await fetch('/api/tickets/test-rating', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guildId: targetGId,
          ratingChannelId: panelConfig.ratingChannelName || panelConfig.ticketLogChannelName || panelConfig.targetChannelName,
          ratingChannelName: panelConfig.ratingChannelName || panelConfig.ticketLogChannelName || panelConfig.targetChannelName,
          staffId: '1219299588402577532',
          staffUsername: 'إداري الدعم الفني',
          stars: 5,
          mode: 'both'
        })
      });
      const data = await res.json();
      setDeployFeedback(
        data.message || data.error || (res.ok ? '✅ تم إرسال تقييم الإداري (5 نجوم) بنجاح!' : '❌ فشل إرسال التقييم.')
      );
      setTimeout(() => setDeployFeedback(null), 9000);
    } catch (err: any) {
      setDeployFeedback(`❌ حدث خطأ أثناء إرسال التقييم: ${err?.message || 'Error'}`);
    } finally {
      setIsDeploying(false);
    }
  };

  const getDiscordBtnColorClass = (style: TicketPanelButton['style']) => {
    switch (style) {
      case 'Primary':
        return 'bg-[#5865F2] hover:bg-[#4752c4] text-white';
      case 'Success':
        return 'bg-[#248046] hover:bg-[#1a6334] text-white';
      case 'Danger':
        return 'bg-[#da373c] hover:bg-[#a12828] text-white';
      case 'Secondary':
      default:
        return 'bg-[#4e5058] hover:bg-[#6d6f78] text-white';
    }
  };

  const syncTicketActionToBackend = async (ticketId: string, channelName: string, action: string, staffName?: string, extra?: string) => {
    try {
      const token = localStorage.getItem('m7r_auth_token');
      const targetGId = activeGuildId || localStorage.getItem('m7r_selected_guild_id') || '';
      await fetch('/api/tickets/action', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ guildId: targetGId, ticketId, channelName, action, staffName, extra })
      });
    } catch {
      // ignore offline simulation
    }
  };

  const handleSendReply = () => {
    if (!replyInput.trim() || !selectedTicket) return;
    const text = replyInput.trim();
    onTicketAction(selectedTicket.id, 'send_reply', 'M7R Support Agent', text);
    syncTicketActionToBackend(selectedTicket.id, selectedTicket.channelName, 'send_reply', 'M7R Support Agent', text);
    setReplyInput('');
    sound.playClick();
  };

  const handleClaim = () => {
    if (!selectedTicket) return;
    sound.playShieldActivate();
    onTicketAction(selectedTicket.id, 'claim', 'u5r9 [M7R Admin]');
    syncTicketActionToBackend(selectedTicket.id, selectedTicket.channelName, 'claim', 'u5r9 [M7R Admin]');
  };

  const handleUnclaim = () => {
    if (!selectedTicket) return;
    sound.playClick();
    onTicketAction(selectedTicket.id, 'unclaim', 'u5r9 [M7R Admin]');
    syncTicketActionToBackend(selectedTicket.id, selectedTicket.channelName, 'unclaim', 'u5r9 [M7R Admin]');
  };

  const handleClose = () => {
    if (!selectedTicket) return;
    sound.playClick();
    onTicketAction(selectedTicket.id, 'close');
    syncTicketActionToBackend(selectedTicket.id, selectedTicket.channelName, 'close');
  };

  const handleSaveFileNow = async () => {
    if (!selectedTicket) return;
    sound.playShieldActivate();
    onTicketAction(selectedTicket.id, 'save_file', 'u5r9 [M7R Admin]');
    await syncTicketActionToBackend(selectedTicket.id, selectedTicket.channelName, 'save_file', 'u5r9 [M7R Admin]');
    handleGenerateSmartSummary();
  };

  const handleDelete = () => {
    if (!selectedTicket) return;
    sound.playAlarm();
    syncTicketActionToBackend(selectedTicket.id, selectedTicket.channelName, 'delete');
    onTicketAction(selectedTicket.id, 'delete');
    if (tickets.length > 1) {
      const remaining = tickets.filter((t) => t.id !== selectedTicket.id);
      setSelectedTicketId(remaining[0]?.id || '');
    }
  };

  const handleRemind = () => {
    if (!selectedTicket) return;
    sound.playClick();
    onTicketAction(selectedTicket.id, 'remind');
    syncTicketActionToBackend(selectedTicket.id, selectedTicket.channelName, 'remind');
  };

  const handleAddUserSubmit = () => {
    if (!targetUsername.trim() || !selectedTicket) return;
    sound.playClick();
    onTicketAction(
      selectedTicket.id,
      'send_reply',
      'M7R Bot [Permission]',
      `➕ تم إضافة العضو @${targetUsername} بنجاح إلى التذكرة.`
    );
    setShowAddUserModal(false);
    setTargetUsername('');
  };

  const handleTransferSubmit = () => {
    if (!selectedTicket) return;
    sound.playShieldActivate();
    onTicketAction(selectedTicket.id, 'transfer', undefined, targetDepartment);
    setShowTransferModal(false);
  };

  const handleGenerateSmartSummary = async () => {
    if (!selectedTicket) return;
    sound.playShieldActivate();
    setGeneratingHtml(true);
    try {
      const targetGId = activeGuildId || localStorage.getItem('m7r_selected_guild_id') || '';
      const res = await fetch('/api/tickets/transcripts/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guildId: targetGId,
          ticketId: selectedTicket.id,
          sendToDiscord: true
        })
      });
      const data = await res.json();
      if (Array.isArray(data?.transcripts)) {
        setHtmlTranscripts(data.transcripts);
      }
      if (data?.transcript) {
        setPreviewPage(0);
        setPreviewTranscript(data.transcript);
      }
      if (data?.message) {
        setDeployFeedback(data.message);
        setTimeout(() => setDeployFeedback(null), 5000);
      }
    } catch {
      // fallback
    } finally {
      setGeneratingHtml(false);
    }
  };

  const handleSendTopStaffToDiscord = async () => {
    sound.playShieldActivate();
    setSendingStaffTop(true);
    try {
      const targetGId = activeGuildId || localStorage.getItem('m7r_selected_guild_id') || '';
      const res = await fetch('/api/staff-leaderboard/send-to-discord', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId: targetGId })
      });
      const data = await res.json();
      if (Array.isArray(data?.leaderboard)) {
        setStaffLeaderboard(data.leaderboard);
      }
      if (data?.message) {
        setDeployFeedback(data.message);
        setTimeout(() => setDeployFeedback(null), 5000);
      }
    } catch {} finally {
      setSendingStaffTop(false);
    }
  };

  const handleDeleteTranscriptItem = async (id: string) => {
    sound.playClick();
    setHtmlTranscripts((prev) => prev.filter((t) => t.id !== id));
    try {
      const targetGId = activeGuildId || localStorage.getItem('m7r_selected_guild_id') || '';
      await fetch('/api/tickets/transcripts/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId: targetGId, id })
      });
    } catch {}
  };

  return (
    <div className="space-y-6">
      {/* Header & View Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <TicketIcon className="w-6 h-6 text-rose-500" />
            {isAr ? 'استوديو تعديل التذاكر والبانل المتقدم (M7R Ticket Studio)' : 'M7R Custom Ticket Studio & Desk'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {isAr
              ? 'عدّل على عنوان التكت، الوصف، الأزرار، الإيموجي، الألوان، ورسالة الترحيب وأرسل البانل مباشرة لسيرفرك في ديسكورد!'
              : 'Customize every detail of your ticket embed, buttons, colors, and deploy directly to your Discord server!'}
          </p>
        </div>

        {/* Segmented view switch */}
        <div className="flex items-center gap-1 p-1 bg-[#0d1017] border border-slate-800 rounded-lg shrink-0">
          <button
            onClick={() => {
              setActiveView('builder');
              sound.playClick();
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeView === 'builder'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>{isAr ? 'تخصيص وتعديل التكت 🎨' : 'Customize Ticket Panel 🎨'}</span>
          </button>
          <button
            onClick={() => {
              setActiveView('desk');
              sound.playClick();
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeView === 'desk'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>{isAr ? `إدارة التذاكر (${tickets.length})` : `Active Tickets (${tickets.length})`}</span>
          </button>
          <button
            onClick={() => {
              setActiveView('transcripts');
              sound.playClick();
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeView === 'transcripts'
                ? 'bg-purple-500/25 text-purple-200 border border-purple-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? `ملخصات التذاكر وتوب المشرفين ⭐ (${htmlTranscripts.length})` : `Smart Summaries & Top Staff ⭐ (${htmlTranscripts.length})`}</span>
          </button>
        </div>
      </div>

      {/* VIEW 1: FULL INTERACTIVE TICKET CUSTOMIZER & LIVE DISCORD PREVIEW */}
      {activeView === 'builder' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left/Right Editor Form */}
          <div className="lg:col-span-7 space-y-5">
            {/* General Panel Settings */}
            <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Palette className="w-4 h-4 text-rose-500" />
                {isAr ? 'تعديل نصوص وألوان بانل التذاكر الأساسي' : 'Ticket Embed Content & Styling'}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    {isAr ? 'اسم المتجر / السيرفر' : 'Store / Server Name'}
                  </label>
                  <input
                    type="text"
                    value={panelConfig.storeName}
                    onChange={(e) => updatePanelField('storeName', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 focus:border-rose-500 rounded-lg p-2 text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    {isAr ? 'رتبة الدعم الفني المسؤولة (Support Role)' : 'Support Staff Role'}
                  </label>
                  <input
                    type="text"
                    value={panelConfig.supportRoleName}
                    onChange={(e) => updatePanelField('supportRoleName', e.target.value)}
                    placeholder="Support"
                    className="w-full bg-slate-900 border border-slate-800 focus:border-rose-500 rounded-lg p-2 text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Comprehensive Room Selectors for Tickets */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-rose-500/20 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-rose-400 block">
                    {isAr ? '📍 تحديد الرومات والكاتيجوري وروم تقييم الإداريين بالنجوم:' : '📍 Ticket Channels, Category & Staff Rating Channel:'}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-md bg-amber-500/15 border border-amber-500/35 text-amber-300 text-[10px] font-bold">
                    ⭐ {isAr ? 'يدعم التقييم الفوري (1 إلى 5 نجوم) وأمر /set-rating-channel' : 'Supports 1-5 Star Staff Rating & /set-rating-channel'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <ChannelSelector
                    lang={lang}
                    guildId={activeGuildId}
                    label={isAr ? 'تحديد روم إرسال البانل' : 'Panel Channel'}
                    value={panelConfig.targetChannelName}
                    onChange={(ch) => updatePanelField('targetChannelName', ch)}
                    placeholder="tickets"
                    helperText={isAr ? 'الروم الذي يظهر فيه بانل فتح التكت' : 'Channel where ticket panel is posted'}
                  />

                  <ChannelSelector
                    lang={lang}
                    guildId={activeGuildId}
                    label={isAr ? '⭐ روم تقييم الإداريين' : '⭐ Staff Rating Channel'}
                    value={panelConfig.ratingChannelName || panelConfig.ticketLogChannelName || 'تقييمات-الإدارة'}
                    onChange={(ch) => updatePanelField('ratingChannelName', ch)}
                    placeholder="تقييمات-الإدارة"
                    helperText={isAr ? 'الروم الذي تُرسل إليه بطاقة تقييم الإداري (1-5 نجوم)' : 'Channel where 1-5 star staff ratings are posted'}
                  />

                  <ChannelSelector
                    lang={lang}
                    guildId={activeGuildId}
                    label={isAr ? 'تحديد روم لوق التذاكر' : 'Ticket Logs Channel'}
                    value={panelConfig.ticketLogChannelName || 'ticket-logs'}
                    onChange={(ch) => updatePanelField('ticketLogChannelName', ch)}
                    placeholder="ticket-logs"
                    helperText={isAr ? 'روم حفظ نسخ التذاكر المغلقة' : 'Channel for closed ticket transcripts'}
                  />

                  <ChannelSelector
                    lang={lang}
                    guildId={activeGuildId}
                    type="all"
                    label={isAr ? 'تحديد كاتيجوري فتح التكت' : 'Tickets Category'}
                    value={panelConfig.ticketCategoryName || '🎫 | قسم التذاكر (Tickets)'}
                    onChange={(ch) => updatePanelField('ticketCategoryName', ch)}
                    placeholder="tickets-category"
                    helperText={isAr ? 'القسم الذي تنشأ بداخله رومات التذاكر' : 'Category where new tickets open'}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <div className="sm:col-span-3">
                  <label className="text-slate-300 font-semibold block mb-1">
                    {isAr ? 'عنوان بانل التذاكر (Embed Title)' : 'Embed Title'}
                  </label>
                  <input
                    type="text"
                    value={panelConfig.embedTitle}
                    onChange={(e) => updatePanelField('embedTitle', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 focus:border-rose-500 rounded-lg p-2 text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    {isAr ? 'لون الـ Embed' : 'Embed Color'}
                  </label>
                  <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg p-1.5">
                    <input
                      type="color"
                      value={panelConfig.embedColor}
                      onChange={(e) => updatePanelField('embedColor', e.target.value)}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                    <span className="font-mono text-[11px] text-slate-300">{panelConfig.embedColor}</span>
                  </div>
                </div>
              </div>

              <div className="text-xs">
                <label className="text-slate-300 font-semibold block mb-1">
                  {isAr ? 'وصف البانل الرئيسي (Embed Description)' : 'Embed Description'}
                </label>
                <textarea
                  rows={2}
                  value={panelConfig.embedDescription}
                  onChange={(e) => updatePanelField('embedDescription', e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-rose-500 rounded-lg p-2 text-white focus:outline-none"
                />
              </div>

              <div className="text-xs">
                <label className="text-slate-300 font-semibold block mb-1">
                  {isAr ? 'رسالة الترحيب التلقائية داخل التذكرة عند فتحها' : 'Welcome Message Inside Ticket'}
                </label>
                <textarea
                  rows={2}
                  value={panelConfig.welcomeMessage}
                  onChange={(e) => updatePanelField('welcomeMessage', e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-rose-500 rounded-lg p-2 text-white focus:outline-none"
                />
              </div>

              {/* NEW: Upload / Set Ticket Banner Image (M7R Purple Metallic Banner) */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-purple-950/40 via-slate-950 to-slate-950 border border-purple-500/40 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-purple-400" />
                    <span className="text-xs font-black text-white">
                      {isAr
                        ? '🖼️ رفع / تحديد صورة بنر التذاكر الكبير (Upload / Set Ticket Banner Image)'
                        : '🖼️ Upload / Set Ticket Banner Image'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      sound.playShieldActivate();
                      onChangePanelConfig({
                        ...panelConfig,
                        bannerUrl: '/assets/aistudio/IMG_3117_2cec6847.jpeg',
                        embedColor: '#8A2BE2'
                      });
                    }}
                    className="px-2.5 py-1 rounded-lg bg-purple-600/25 hover:bg-purple-600/40 border border-purple-500/50 text-purple-200 text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-all"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>{isAr ? 'استعادة بنر M7R البنفسجي الرسمي ⚜️' : 'Restore Official M7R Purple Banner ⚜️'}</span>
                  </button>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isAr
                    ? 'تظهر هذه الصورة كبنر عريض (Large Embed Image) في أسفل بانل التذاكر الرئيسي وداخل رسالة الترحيب في كل تذكرة جديدة تُفتح في ديسكورد!'
                    : 'Displayed as the main large banner inside both the Ticket Panel Embed and every newly opened Ticket channel!'}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                  <div className="sm:col-span-8 space-y-2">
                    <label className="text-[11px] text-slate-400 font-semibold block">
                      {isAr ? 'رابط صورة البنر (Image URL أو المسار المحلي):' : 'Banner Image URL:'}
                    </label>
                    <input
                      type="text"
                      value={effectiveBannerUrl}
                      onChange={(e) => updatePanelField('bannerUrl', e.target.value)}
                      placeholder="https://... أو /assets/aistudio/IMG_3117_2cec6847.jpeg"
                      className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg p-2 text-xs text-white font-mono focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-4 pt-1 sm:pt-5">
                    <label className="w-full py-2 px-3 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{isAr ? 'رفع صورة من جهازك' : 'Upload Banner File'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleBannerFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>

                {effectiveBannerUrl && (
                  <div className="relative rounded-xl overflow-hidden border border-purple-500/40 bg-black/60 max-h-44 flex items-center justify-center">
                    <img
                      src={effectiveBannerUrl}
                      alt="M7R Ticket Banner Preview"
                      className="w-full max-h-44 object-cover"
                    />
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded bg-black/75 border border-purple-500/50 text-[10px] font-bold text-purple-300">
                      {isAr ? '✨ بنر التذاكر المفعل (Panel + Ticket Rooms)' : '✨ Active Ticket Banner'}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* NEW: Ticket Naming Format, Reason Modal & AI Waiting Assistant */}
            <div className="rounded-xl border border-indigo-500/30 bg-[#0d1017] p-5 space-y-4">
              <div className="flex items-center gap-2">
                <Hash className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-white">
                  {isAr ? 'تسمية روم التذكرة، سبب الفتح والمساعد الذكي 🤖' : 'Ticket Channel Naming, Reason & AI Waiting Assistant'}
                </h3>
              </div>
              <p className="text-[11px] text-slate-400">
                {isAr
                  ? 'تحكم في اسم الروم المنشأ (رقم التذكرة أو اسم الشخص أو كلاهما)، وطلب سبب الفتح، وتفعيل إجابات الذكاء الاصطناعي أثناء انتظار الإدارة.'
                  : 'Control channel naming (number, username or both), prompt for reason upon opening, and enable AI waiting replies.'}
              </p>

              {/* 1. Ticket Naming Format */}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
                <label className="text-xs font-bold text-slate-200 block">
                  {isAr ? '🏷️ نمط تسمية روم التذكرة عند فتحها:' : '🏷️ Ticket Channel Naming Pattern:'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {[
                    {
                      id: 'username_number',
                      label: isAr ? 'اسم الشخص + رقم' : 'Username + Number',
                      example: `${panelConfig.channelPrefix || 'ticket'}-ahmed-042`
                    },
                    {
                      id: 'number',
                      label: isAr ? 'رقم التذكرة فقط' : 'Number Only',
                      example: `${panelConfig.channelPrefix || 'ticket'}-042`
                    },
                    {
                      id: 'username',
                      label: isAr ? 'اسم الشخص فقط' : 'Username Only',
                      example: `${panelConfig.channelPrefix || 'ticket'}-ahmed`
                    }
                  ].map((pat) => (
                    <button
                      key={pat.id}
                      type="button"
                      onClick={() => updatePanelField('namingFormat', pat.id as any)}
                      className={`p-2.5 rounded-xl border text-start cursor-pointer transition-all ${
                        (panelConfig.namingFormat || 'username_number') === pat.id
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-md shadow-indigo-950/40'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span className="text-xs font-bold block">{pat.label}</span>
                      <span className="text-[10px] font-mono text-indigo-300 mt-1 block">
                        مثال: {pat.example}
                      </span>
                    </button>
                  ))}
                </div>

                {/* Channel Prefix Input */}
                <div className="pt-2 flex items-center gap-3">
                  <div className="flex-1">
                    <label className="text-[11px] text-slate-400 font-bold block mb-1">
                      {isAr ? 'بادئة اسم الروم (Prefix):' : 'Channel Name Prefix:'}
                    </label>
                    <input
                      type="text"
                      value={panelConfig.channelPrefix || 'ticket'}
                      onChange={(e) => updatePanelField('channelPrefix', e.target.value.trim().toLowerCase())}
                      placeholder="ticket"
                      className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-lg p-2 text-xs text-white font-mono"
                    />
                  </div>
                  <div className="text-[11px] text-slate-400 pt-5">
                    {isAr ? 'مثال: ticket- أو تذكرة-' : 'e.g. ticket- or help-'}
                  </div>
                </div>
              </div>

              {/* ⚙️ إعدادات التذاكر والدعم الفني (Module 4 Card) */}
              <div className="p-5 rounded-2xl bg-[#090d1b] border border-purple-500/40 space-y-4 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h4 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                    <span>⚙️ إعدادات التذاكر والدعم الفني</span>
                  </h4>
                  <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 text-[11px] font-black">
                    🙋‍♂️ استلام التذكرة الحصري مفعل
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      اسم تصنيف التذاكر الافتراضي:
                    </label>
                    <input
                      type="text"
                      value={panelConfig.ticketCategoryName || 'التذاكر'}
                      onChange={(e) => updatePanelField('ticketCategoryName', e.target.value)}
                      placeholder="التذاكر"
                      className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      الحد الأقصى للتذاكر المفتوحة لكل مستخدم:
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={maxOpenTicketsPerUser}
                      onChange={(e) => setMaxOpenTicketsPerUser(Math.max(1, Number(e.target.value) || 4))}
                      className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-black text-purple-300"
                    />
                  </div>

                  <div>
                    <ChannelSelector
                      lang={lang}
                      guildId={activeGuildId}
                      compact={true}
                      type="text"
                      label="قناة سجل التذاكر (اختياري):"
                      value={panelConfig.transcriptChannelName || 'ticket-logs'}
                      onChange={(ch) => updatePanelField('transcriptChannelName', ch)}
                      placeholder="اختر قناة..."
                    />
                  </div>
                </div>

                {/* Toggle Card 1 & Toggle Card 2: طلب سبب عند فتح التذكرة + طلب سبب عند إغلاق التذكرة */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <label className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500/40 flex items-start justify-between gap-3 cursor-pointer transition-all">
                    <div className="space-y-1">
                      <span className="text-xs font-black text-white block">
                        طلب سبب عند فتح التذكرة
                      </span>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        عند التفعيل، تظهر نافذة منبثقة للمستخدم تطلب منه كتابة سبب فتح التذكرة أو تفاصيل المشكلة قبل إنشاء التذكرة
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={panelConfig.askReasonModal ?? true}
                      onChange={(e) => updatePanelField('askReasonModal', e.target.checked)}
                      className="w-4 h-4 mt-1 accent-purple-500 rounded cursor-pointer"
                    />
                  </label>

                  <label className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500/40 flex items-start justify-between gap-3 cursor-pointer transition-all">
                    <div className="space-y-1">
                      <span className="text-xs font-black text-white block">
                        طلب سبب عند إغلاق التذكرة
                      </span>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        عند التفعيل، تظهر نافذة منبثقة لكتابة سبب الإغلاق قبل إنهاء التذكرة وأرشفتها
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={askCloseReasonModal}
                      onChange={(e) => {
                        sound.playClick();
                        setAskCloseReasonModal(e.target.checked);
                      }}
                      className="w-4 h-4 mt-1 accent-purple-500 rounded cursor-pointer"
                    />
                  </label>
                </div>

                {/* 3. AI Waiting Assistant Toggle */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Bot className="w-3.5 h-3.5 text-emerald-400" />
                        {isAr ? 'المساعد الذكي أثناء انتظار الإدارة (M7R AI Waiting Assistant) 🤖' : 'AI Waiting Assistant While Waiting for Staff 🤖'}
                      </span>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        {isAr
                          ? 'أول ما يفتح العضو التذكرة تظهر له رسالة تفيد بانتظار الإدارة مع إمكانية سؤال الذكاء الاصطناعي (ai ask) ليجيبه فوراً حتى يتفرغ الدعم الفني!'
                          : 'Sends an automated wait message offering M7R AI replies inside the ticket room until staff arrives.'}
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={panelConfig.aiWaitingAssistant ?? true}
                      onChange={(e) => updatePanelField('aiWaitingAssistant', e.target.checked)}
                      className="w-4 h-4 mt-1 accent-emerald-600 rounded cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 4 TOP ACTION BUTTONS + 🎛️ الأزرار الحالية (UNLIMITED BUTTONS!) */}
            <div className="rounded-2xl border border-purple-500/40 bg-[#0d1017] p-5 space-y-5 shadow-xl">
              {/* 4 Top Action Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pb-4 border-b border-slate-800">
                <button
                  type="button"
                  onClick={handleAddButton}
                  className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] hover:opacity-95 text-white text-xs font-black flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-purple-950/50"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ إضافة زر تذكرة جديد</span>
                </button>

                <button
                  type="button"
                  onClick={handleDeployPanelToDiscord}
                  disabled={isDeploying}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-950/50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isDeploying ? 'جاري النشر...' : '📤 نشر اللوحة'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setActiveView('transcripts');
                  }}
                  className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-500/40 text-amber-300 text-xs font-black flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>🛡️ إحصاءات الإداريين</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    window.scrollTo({ top: 180, behavior: 'smooth' });
                  }}
                  className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-purple-500/40 text-purple-200 text-xs font-black flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>🎨 تخصيص روم التذكرة</span>
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <span>🎛️ الأزرار الحالية ({panelConfig.buttons.length} زر — غير محدود 100%)</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    يمكنك إضافة عدد غير محدود من أزرار التذاكر، تعديل كل زر، أو نشره مباشرة في ديسكورد:
                  </p>
                </div>
              </div>

              {/* Structured Current Buttons Cards List */}
              <div className="space-y-3.5">
                {panelConfig.buttons.map((btn, idx) => {
                  const isEditingThis = editingButtonId === btn.id;
                  return (
                    <div
                      key={btn.id}
                      className="p-4 rounded-2xl bg-[#090d1b] border border-slate-800 hover:border-purple-500/50 space-y-3.5 text-xs transition-all"
                    >
                      {/* Structured Info Row */}
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 items-center pb-3 border-b border-slate-800/80">
                        <div>
                          <span className="text-[10px] text-slate-400 block">القسم:</span>
                          <span className="font-black text-white text-xs">
                            #{idx + 1} — {btn.label}
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-400 block mb-1">الزر في ديسكورد:</span>
                          <span
                            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold shadow ${getDiscordBtnColorClass(
                              btn.style
                            )}`}
                          >
                            <span>{btn.emoji}</span>
                            <span>{btn.label}</span>
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-400 block">من يرى التذكرة:</span>
                          <span className="px-2 py-0.5 rounded bg-purple-500/15 border border-purple-500/30 text-purple-200 font-bold text-[11px] inline-block mt-0.5">
                            [ المشرفين فقط ]
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-400 block">من يفتحها:</span>
                          <span className="px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[11px] inline-block mt-0.5">
                            [ الجميع ]
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-400 block">التصنيف:</span>
                          <span className="text-slate-200 font-bold text-xs block mt-0.5">
                            {btn.targetCategoryName || panelConfig.ticketCategoryName || 'افتراضي'}
                          </span>
                        </div>
                      </div>

                      {/* Bottom Action Row: ✈️ Send/Deploy, 📝 تعديل, 🗑️ حذف */}
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-[11px] text-slate-400 truncate max-w-md">
                          {btn.categoryDescription}
                        </span>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={handleDeployPanelToDiscord}
                            title="إرسال ونشر هذا الزر في ديسكورد"
                            className="px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/35 border border-emerald-500/40 text-emerald-300 font-black text-xs flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <span>✈️</span>
                            <span>نشر</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              sound.playClick();
                              setEditingButtonId(isEditingThis ? null : btn.id);
                            }}
                            className="px-3 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/35 border border-indigo-500/40 text-indigo-200 font-black text-xs flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <span>📝 تعديل</span>
                          </button>

                          {panelConfig.buttons.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveButton(btn.id)}
                              className="px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/35 border border-rose-500/40 text-rose-300 font-black text-xs flex items-center gap-1 cursor-pointer transition-all"
                            >
                              <span>🗑️ حذف</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Editable Fields (always accessible when 📝 تعديل is clicked or for quick edit) */}
                      {isEditingThis && (
                        <div className="pt-3 border-t border-slate-800 space-y-3 animate-in fade-in">
                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                            <div>
                              <label className="text-[11px] text-slate-400 block mb-1">الإيموجي</label>
                              <input
                                type="text"
                                value={btn.emoji}
                                onChange={(e) => updateButtonItem(btn.id, 'emoji', e.target.value)}
                                className="w-full bg-[#07090e] border border-slate-800 rounded-lg p-2 text-center text-white"
                              />
                            </div>

                            <div className="sm:col-span-2">
                              <label className="text-[11px] text-slate-400 block mb-1">اسم الزر</label>
                              <input
                                type="text"
                                value={btn.label}
                                onChange={(e) => updateButtonItem(btn.id, 'label', e.target.value)}
                                className="w-full bg-[#07090e] border border-slate-800 rounded-lg p-2 text-white font-bold"
                              />
                            </div>

                            <div>
                              <label className="text-[11px] text-slate-400 block mb-1">لون الزر</label>
                              <select
                                value={btn.style}
                                onChange={(e) => updateButtonItem(btn.id, 'style', e.target.value)}
                                className="w-full bg-[#07090e] border border-slate-800 rounded-lg p-2 text-white"
                              >
                                <option value="Primary">🔵 أزرق (Primary)</option>
                                <option value="Secondary">⚫ رمادي (Secondary)</option>
                                <option value="Success">🟢 أخضر (Success)</option>
                                <option value="Danger">🔴 أحمر (Danger)</option>
                              </select>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-end">
                            <div>
                              <label className="text-[11px] text-slate-400 block mb-1">وصف هذا القسم في البانل</label>
                              <input
                                type="text"
                                value={btn.categoryDescription}
                                onChange={(e) => updateButtonItem(btn.id, 'categoryDescription', e.target.value)}
                                className="w-full bg-[#07090e] border border-slate-800 rounded-lg p-2 text-slate-200"
                              />
                            </div>

                            <ChannelSelector
                              lang={lang}
                              guildId={activeGuildId}
                              compact={true}
                              type="all"
                              label="تحديد روم/كاتيجوري هذا الزر"
                              value={btn.targetCategoryName || panelConfig.ticketCategoryName || 'tickets'}
                              onChange={(ch) => updateButtonItem(btn.id, 'targetCategoryName', ch)}
                              placeholder="tickets"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right/Left Column: Live Discord Embed Preview & One-Click Send */}
          <div className="lg:col-span-5 space-y-4">
            <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4 sticky top-20">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {isAr ? 'معاينة البانل الحية في ديسكورد' : 'Live Discord Panel Preview'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {isAr ? `سيتم إرساله في روم #${panelConfig.targetChannelName}` : `Target: #${panelConfig.targetChannelName}`}
                  </p>
                </div>
                <span className="text-[10px] font-mono text-emerald-400">Live Sync</span>
              </div>

              {/* Authentic Discord Embed Box with Luxury Unicode Box-Drawing Borders */}
              <div
                className="rounded-xl bg-[#2b2d31] p-4 text-slate-100 border-l-4 space-y-3 shadow-inner ticket-glow-card animate-fade-in"
                style={{ borderLeftColor: panelConfig.embedColor }}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center font-bold font-mono text-xs text-white shadow-md"
                      style={{ backgroundColor: panelConfig.embedColor }}
                    >
                      M7R
                    </div>
                    <div>
                      <span className="font-bold text-sm text-white block">✨ {panelConfig.embedTitle} ✨</span>
                      <span className="text-[10px] text-slate-400 font-mono">🛡️ {panelConfig.storeName} • Ticket System</span>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 font-mono">
                    💎 VIP Embed
                  </span>
                </div>

                {/* Luxury Unicode Box-Drawing Header */}
                <div className="text-xs font-mono text-rose-300/90 bg-[#1e1f22]/90 px-3 py-2 rounded-lg border border-slate-700/60 space-y-1">
                  <div className="text-amber-300 font-bold">╭─── ✦ ───╮</div>
                  <p className="text-xs leading-relaxed text-slate-100 font-sans">
                    💎 {panelConfig.embedDescription}
                  </p>
                  <div className="text-amber-300 font-bold">╰─── ✦ ───╯</div>
                </div>

                <div className="text-[11px] font-mono text-slate-400 text-center">
                  ━━━━━━━━━━━━━━━━━━━━
                </div>

                {/* Custom Emoji Bullet Points */}
                <div className="text-xs space-y-1.5 bg-[#1e1f22] p-3 rounded-lg text-slate-200 border border-slate-800">
                  <div className="text-[11px] font-bold text-amber-300 mb-1">
                    ⚡ أقسام التذاكر المتاحة (اضغط لفتح تذكرة فورية):
                  </div>
                  {panelConfig.buttons
                    .filter((b) => b.enabled)
                    .map((b, i) => {
                      const bullet = ['💎', '⚡', '🛡️', '✨', '👑'][i % 5];
                      return (
                        <p key={b.id} className="leading-relaxed">
                          {bullet} {b.emoji} <b className="text-white">{b.label}:</b>{' '}
                          <span className="text-slate-300">{b.categoryDescription}</span>
                        </p>
                      );
                    })}
                </div>

                <div className="text-[10px] text-emerald-300 bg-emerald-950/40 border border-emerald-500/30 px-2.5 py-1.5 rounded-lg flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>نظام الاستلام الحصري مفعل: عند استلام المشرف للتذكرة تُقفل الكتابة عن بقية المشرفين تلقائياً 🔒</span>
                </div>

                {/* Large M7R Purple Metallic Banner inside Ticket Panel Embed */}
                {effectiveBannerUrl && (
                  <div className="rounded-xl overflow-hidden border border-purple-500/40 shadow-lg bg-black/50">
                    <img
                      src={effectiveBannerUrl}
                      alt="M7R Official Ticket Panel Banner"
                      className="w-full max-h-56 object-cover"
                    />
                  </div>
                )}

                {/* Interactive Ticket Creation Animation Feedback */}
                {creatingTicketLoading && (
                  <div className="p-2.5 rounded-lg bg-amber-950/60 border border-amber-500/50 text-amber-200 text-xs font-bold flex items-center gap-2 animate-pulse">
                    <Loader2 className="w-4 h-4 animate-spin text-amber-400 shrink-0" />
                    <span>{creatingTicketLoading}</span>
                  </div>
                )}

                {/* Live Discord Buttons Preview */}
                <div className="pt-1 flex flex-wrap gap-2">
                  {panelConfig.buttons
                    .filter((b) => b.enabled)
                    .map((b) => (
                      <button
                        key={b.id}
                        onClick={() => {
                          sound.playClick();
                          setCreatingTicketLoading('⏳ جاري تجهيز تذكرتك الخاصة وإعداد الصلاحيات...');
                          setTimeout(() => {
                            setCreatingTicketLoading(null);
                            onCreateSimulatedTicket('store', `${b.emoji} ${b.label}`);
                            setActiveView('desk');
                          }, 900);
                        }}
                        className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md hover:scale-[1.02] ${getDiscordBtnColorClass(
                          b.style
                        )}`}
                      >
                        <span>{b.emoji}</span>
                        <span>{b.label}</span>
                      </button>
                    ))}
                </div>
              </div>

              {/* Deploy directly to Discord Server Button + Live 5-Star Staff Rating Test Button */}
              <div className="space-y-2.5">
                <button
                  onClick={handleDeployPanelToDiscord}
                  disabled={isDeploying}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-red-700 hover:from-rose-500 hover:to-red-600 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-rose-950/60 cursor-pointer transition-all"
                >
                  <SendHorizonal className="w-4 h-4" />
                  <span>
                    {isDeploying
                      ? isAr
                        ? 'جاري التنفيذ والإرسال الفعلي إلى ديسكورد...'
                        : 'Sending to Discord...'
                      : isAr
                      ? `إرسال ونشر بانل التذاكر فعلياً في ديسكورد الآن 🚀 (#${panelConfig.targetChannelName})`
                      : 'Send Ticket Panel to Discord Now 🚀'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={handleTestStaffRatingInDiscord}
                  disabled={isDeploying}
                  className="w-full py-2.5 px-4 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-black flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <Star className="w-4 h-4 text-amber-400" />
                  <span>
                    ⭐ اعتماد روم التقييمات (#{panelConfig.ticketLogChannelName || panelConfig.targetChannelName}) وإرسال تقييم إداري (1–5 نجوم + منشن) للديسكورد
                  </span>
                </button>
              </div>

              {deployFeedback && (
                <div
                  className={`p-3 rounded-lg border text-xs flex items-center gap-2 animate-fade-in ${
                    deployFeedback.startsWith('❌')
                      ? 'bg-rose-950/60 border-rose-500/40 text-rose-200'
                      : 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{deployFeedback}</span>
                </div>
              )}

              <p className="text-[11px] text-slate-400 text-center">
                {isAr
                  ? '💡 يمكنك أيضاً كتابة الأمر !panel أو /panel داخل أي روم في ديسكورد ليقوم البوت بإرسال هذا البانل فوراً!'
                  : 'You can also type !panel or /panel inside any Discord channel to post this panel!'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: ACTIVE TICKET DESK */}
      {activeView === 'desk' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Ticket List */}
          <div className="lg:col-span-4 rounded-xl border border-slate-800 bg-[#0d1017] p-4 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  {isAr ? 'التذاكر الحالية' : 'Open Tickets'} ({tickets.length})
                </span>
                <span className="text-[10px] text-slate-400 font-mono">Live Sync</span>
              </div>

              <div className="space-y-2 max-h-[480px] overflow-y-auto">
                {tickets.map((t) => {
                  const isSelected = t.id === selectedTicket?.id;
                  const isClaimed = t.status === 'claimed';
                  const isClosed = t.status === 'closed';

                  return (
                    <div
                      key={t.id}
                      onClick={() => {
                        setSelectedTicketId(t.id);
                        sound.playClick();
                      }}
                      className={`p-3 rounded-xl border transition-all cursor-pointer animate-fade-in ${
                        isSelected
                          ? isClaimed
                            ? 'bg-emerald-950/25 border-emerald-500/60 claimed-lock-card'
                            : 'bg-rose-950/25 border-rose-500/60 ticket-glow-card'
                          : 'bg-slate-900/40 border-slate-800/80 hover:bg-slate-900/80 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-200 font-mono flex items-center gap-1.5">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              isClosed
                                ? 'bg-slate-500'
                                : isClaimed
                                ? 'bg-emerald-400 animate-pulse'
                                : 'bg-rose-500 animate-ping'
                            }`}
                          />
                          <span>#{t.channelName}</span>
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 ${
                            isClosed
                              ? 'bg-slate-800 text-slate-400'
                              : isClaimed
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/40'
                              : 'bg-rose-500/15 text-rose-300 border border-rose-500/40'
                          }`}
                        >
                          {isClosed
                            ? isAr
                              ? '🔒 مغلقة'
                              : '🔒 Closed'
                            : isClaimed
                            ? isAr
                              ? '🙋‍♂️ مستلمة حصرياً'
                              : '🙋‍♂️ Claimed'
                            : isAr
                            ? '🟢 مفتوحة'
                            : '🟢 Open'}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-300 mt-1 truncate">{t.categoryLabel}</div>

                      {t.claimedBy && (
                        <div className="mt-1.5 text-[10px] text-emerald-300 bg-emerald-950/50 border border-emerald-500/30 px-2 py-0.5 rounded truncate">
                          👨‍💻 {t.claimedBy} 🔒
                        </div>
                      )}

                      <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/60 text-[10px] text-slate-400">
                        <span>{t.user.name}</span>
                        <span className="font-mono">{t.createdAt}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Ticket Detail & Room */}
          <div
            className={`lg:col-span-8 rounded-xl border bg-[#0d1017] p-5 flex flex-col justify-between space-y-4 transition-all ${
              selectedTicket?.status === 'claimed'
                ? 'border-emerald-500/50 claimed-lock-card'
                : 'border-slate-800 ticket-glow-card'
            }`}
          >
            {selectedTicket ? (
              <>
                <div className="pb-4 border-b border-slate-800 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-black text-white font-mono">#{selectedTicket.channelName}</span>
                        <span className="text-xs text-rose-400 font-medium">({selectedTicket.categoryLabel})</span>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 mt-1">
                        <span>
                          {isAr ? '👤 صاحب التذكرة:' : '👤 Creator:'}{' '}
                          <b className="text-slate-200">{selectedTicket.user.name}</b>
                        </span>
                        <span>•</span>
                        <span>
                          {isAr ? '👨‍💻 المستلم الحالي:' : '👨‍💻 Claimed By:'}{' '}
                          {selectedTicket.claimedBy ? (
                            <b className="text-emerald-400">
                              {selectedTicket.claimedBy} {isAr ? '(مقفلة للمشرفين الآخرين 🔒)' : '(Locked to other staff 🔒)'}
                            </b>
                          ) : (
                            <b className="text-amber-400">
                              {isAr ? '⏳ بانتظار استلام أحد المشرفين...' : '⏳ Waiting for staff claim...'}
                            </b>
                          )}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={handleGenerateSmartSummary}
                      disabled={generatingHtml}
                      className="px-3 py-1.5 bg-purple-950/50 hover:bg-purple-900/60 border border-purple-500/40 text-xs font-bold text-purple-200 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
                      <span>{generatingHtml ? (isAr ? 'جاري الإرسال...' : 'Sending...') : (isAr ? 'إرسال إيمبد الملخص الذكي للوق 📜' : 'Send Smart Summary Embed 📜')}</span>
                    </button>
                  </div>

                  {/* STRICT SINGLE-ADMIN CLAIM LOCK BANNER */}
                  <div
                    className={`p-3 rounded-xl border text-xs flex items-center justify-between gap-3 ${
                      selectedTicket.claimedBy
                        ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="space-y-0.5">
                      <div className="font-black flex items-center gap-1.5">
                        <span>{selectedTicket.claimedBy ? '🔒' : '🛡️'}</span>
                        <span>
                          {selectedTicket.claimedBy
                            ? isAr
                              ? `استلام التذكرة الحصري مفعل — المستلم: ${selectedTicket.claimedBy}`
                              : `Strict Single-Admin Claim Lock Active — Claimed by ${selectedTicket.claimedBy}`
                            : isAr
                            ? 'نظام الاستلام الحصري جاهز (Single-Admin Claim Lock)'
                            : 'Single-Admin Claim Lock Ready'}
                        </span>
                      </div>
                      <p className="text-[11px] opacity-85">
                        {selectedTicket.claimedBy
                          ? isAr
                            ? 'تم قفل الكتابة عن بقية المشرفين والإداريين في هذه التذكرة لمنع التداخل. اضغط (🔓 فك الاستلام) لإعادة فتحها للطاقم.'
                            : 'Other staff members are locked out from sending messages in this ticket. Click Unclaim to unlock.'
                          : isAr
                          ? 'عند الضغط على (🙋‍♂️ استلام التذكرة) سيتم منحك صلاحية الرد الحصرية وقفل الشات عن بقية المشرفين تلقائياً.'
                          : 'Clicking Claim Ticket grants you exclusive reply rights and locks out other staff.'}
                      </p>
                    </div>
                  </div>

                  {/* PRIMARY CONTROL BAR + OPERATIONAL TICKET BUTTONS */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 gap-2 pt-1">
                    {/* 1. Claim Ticket (Success/Green) */}
                    <button
                      onClick={handleClaim}
                      disabled={Boolean(selectedTicket.claimedBy)}
                      className="p-2.5 rounded-xl bg-emerald-600/25 hover:bg-emerald-600/40 disabled:opacity-40 border border-emerald-500/60 text-emerald-200 text-xs font-black flex flex-col items-center justify-center gap-1 transition-all cursor-pointer disabled:cursor-not-allowed shadow-sm"
                    >
                      <UserCheck className="w-4 h-4 text-emerald-400" />
                      <span className="text-[11px]">{isAr ? '🙋‍♂️ استلام التذكرة' : '🙋‍♂️ Claim'}</span>
                    </button>

                    {/* 2. Unclaim Ticket (Secondary/Grey - disabled until claimed) */}
                    <button
                      onClick={handleUnclaim}
                      disabled={!selectedTicket.claimedBy}
                      className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 disabled:opacity-40 border border-slate-600/60 text-slate-200 text-xs font-black flex flex-col items-center justify-center gap-1 transition-all cursor-pointer disabled:cursor-not-allowed"
                    >
                      <Unlock className="w-4 h-4 text-amber-300" />
                      <span className="text-[11px]">{isAr ? '🔓 فك الاستلام' : '🔓 Unclaim'}</span>
                    </button>

                    {/* 3. Smart Summary Embed (Primary/Purple) */}
                    <button
                      onClick={handleSaveFileNow}
                      disabled={generatingHtml}
                      className="p-2.5 rounded-xl bg-purple-600/25 hover:bg-purple-600/40 border border-purple-500/60 text-purple-200 text-xs font-black flex flex-col items-center justify-center gap-1 transition-all cursor-pointer shadow-sm"
                    >
                      <MessageSquare className="w-4 h-4 text-purple-300" />
                      <span className="text-[11px]">{isAr ? '📜 إيمبد الملخص' : '📜 Summary Embed'}</span>
                    </button>

                    {/* 4. Close Ticket (Danger/Red) */}
                    <button
                      onClick={handleClose}
                      className="p-2.5 rounded-xl bg-rose-950/60 hover:bg-rose-900/70 border border-rose-500/50 text-rose-200 text-xs font-black flex flex-col items-center justify-center gap-1 transition-all cursor-pointer"
                    >
                      <Lock className="w-4 h-4 text-rose-400" />
                      <span className="text-[11px]">{isAr ? '🔒 إغلاق التذكرة' : '🔒 Close'}</span>
                    </button>

                    <button
                      onClick={handleDelete}
                      className="p-2.5 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-200 text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span className="text-[11px]">{isAr ? 'حذف (Delete)' : 'Delete'}</span>
                    </button>

                    <button
                      onClick={() => setShowAddUserModal(true)}
                      className="p-2.5 rounded-xl bg-sky-950/40 hover:bg-sky-900/60 border border-sky-500/40 text-sky-200 text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span className="text-[11px]">{isAr ? 'إضافة عضو' : 'Add User'}</span>
                    </button>

                    <button
                      onClick={() => setShowTransferModal(true)}
                      className="p-2.5 rounded-xl bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/40 text-indigo-200 text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer"
                    >
                      <ArrowRightLeft className="w-4 h-4" />
                      <span className="text-[11px]">{isAr ? 'تحويل' : 'Transfer'}</span>
                    </button>

                    <button
                      onClick={handleRemind}
                      className="p-2.5 rounded-xl bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/40 text-amber-200 text-xs font-bold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer"
                    >
                      <BellRing className="w-4 h-4" />
                      <span className="text-[11px]">{isAr ? 'تذكير' : 'Remind'}</span>
                    </button>
                  </div>
                </div>

                {/* Messages Live Feed (Includes Welcome/Control Embed with M7R Purple Banner) */}
                <div className="space-y-3 min-h-[260px] max-h-[380px] overflow-y-auto p-3 rounded-lg bg-[#07090e] border border-slate-900">
                  {/* Welcome/Control Embed inside Newly Created Ticket Channel */}
                  <div
                    className="rounded-xl bg-[#2b2d31] p-3.5 text-slate-100 border-l-4 space-y-2.5 shadow-md"
                    style={{
                      borderLeftColor: selectedTicket.claimedBy
                        ? '#10b981'
                        : panelConfig.embedColor || '#8A2BE2'
                    }}
                  >
                    <div className="text-xs font-black text-white">
                      {selectedTicket.categoryLabel} | #{selectedTicket.channelName}
                    </div>
                    <div className="text-[11px] font-mono text-slate-200 bg-[#1e1f22] p-2.5 rounded-lg border border-slate-800 space-y-1">
                      <div className="text-purple-300 font-bold">
                        ╭─── ✦ {panelConfig.storeName || 'M7R Ticket System'} ✦ ───╮
                      </div>
                      <p className="font-sans text-slate-200">
                        💎 أهلاً وسهلاً بك يا <b className="text-white">@{selectedTicket.user.name}</b> في تذكرتك الخاصة!
                      </p>
                      <p className="font-sans text-slate-300">⚡ {panelConfig.welcomeMessage}</p>
                      <div className="text-purple-300 font-bold">╰───────────────────────────╯</div>
                    </div>
                    {effectiveBannerUrl && (
                      <div className="rounded-lg overflow-hidden border border-purple-500/40 bg-black/50">
                        <img
                          src={effectiveBannerUrl}
                          alt="Ticket Welcome Embed Banner"
                          className="w-full max-h-44 object-cover"
                        />
                      </div>
                    )}
                    <div className="text-[10px] text-slate-400 font-mono">
                      {panelConfig.storeName} • Exclusive Single-Admin Claim System 👑
                    </div>
                  </div>

                  {selectedTicket.messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`p-3 rounded-lg border text-xs ${
                        msg.isStaff
                          ? 'bg-rose-950/15 border-rose-900/30 text-rose-100 ml-4'
                          : 'bg-slate-900/70 border-slate-800 text-slate-200 mr-4'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold flex items-center gap-1.5">
                          {msg.author}
                          {msg.isStaff && (
                            <span className="text-[9px] bg-rose-600/30 text-rose-300 border border-rose-500/40 px-1 rounded font-mono">
                              STAFF
                            </span>
                          )}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">{msg.timestamp}</span>
                      </div>
                      <p className="leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                    </div>
                  ))}
                </div>

                {/* Staff Reply Input */}
                <div className="flex items-center gap-2 pt-2">
                  <input
                    type="text"
                    value={replyInput}
                    onChange={(e) => setReplyInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendReply()}
                    placeholder={isAr ? 'اكتب رد المشرف هنا وإرساله في تذكرة الديسكورد...' : 'Type staff reply here...'}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-rose-500"
                  />
                  <button
                    onClick={handleSendReply}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-md"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إرسال' : 'Send'}</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="py-16 text-center text-slate-400 text-xs">
                {isAr ? 'لا توجد تذاكر حالياً.' : 'No active tickets.'}
              </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW 3: SMART INTERACTIVE TICKET SUMMARIES & 5-STAR STAFF LEADERBOARD */}
      {activeView === 'transcripts' && (
        <div className="space-y-6 animate-fade-in">
          {/* 5-STAR STAFF LEADERBOARD (توب المشرفين ونقاط الإدارة 🏆) */}
          <div className="rounded-2xl border border-amber-500/35 bg-gradient-to-br from-[#191124] via-[#0d1017] to-[#17120a] p-5 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="space-y-1">
                <h3 className="text-base font-black text-white flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-amber-400" />
                  <span>{isAr ? '🏆 لوحة شرف المشرفين وتقييمات 5 نجوم (/top-staff • نقاط الإدارة)' : '🏆 5-Star Staff Rating & Points Leaderboard (/top-staff)'}</span>
                </h3>
                <p className="text-xs text-slate-300">
                  {isAr
                    ? 'عند إغلاق أي تذكرة يرسل البوت إيمبد تقييم تفاعلي (⭐ 1 إلى ⭐⭐⭐⭐⭐ 5) لصاحب التذكرة، وتُحتسب نقاط الإدارة 🏆 تلقائياً للمشرف المستلم!'
                    : 'Automatically sends a 1-5 Star interactive rating Embed upon ticket close and awards Staff Points 🏆 to the claiming admin.'}
                </p>
              </div>
              <button
                onClick={handleSendTopStaffToDiscord}
                disabled={sendingStaffTop}
                className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black flex items-center gap-2 shrink-0 cursor-pointer shadow-lg"
              >
                <Send className="w-4 h-4" />
                <span>{sendingStaffTop ? (isAr ? 'جاري النشر...' : 'Sending...') : (isAr ? 'نشر توب المشرفين في ديسكورد (/top-staff) 🏆' : 'Send /top-staff to Discord 🏆')}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              {staffLeaderboard.map((staff, idx) => {
                const avg = staff.ratingsCount > 0 ? (staff.totalStars / staff.ratingsCount).toFixed(1) : '5.0';
                return (
                  <div
                    key={staff.userId}
                    className="p-4 rounded-2xl bg-[#090c12] border border-purple-500/30 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-base font-black text-amber-300 shrink-0">
                        {idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `#${idx + 1}`}
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-black text-white truncate">{staff.username}</div>
                        <div className="text-[11px] text-amber-300 flex items-center gap-1 mt-0.5">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span className="font-mono font-bold">{avg}/5.0</span>
                          <span className="text-slate-400">({staff.ratingsCount} تقييم)</span>
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          🎫 استلم: <b className="text-emerald-400">{staff.ticketsClaimed}</b> • 🔒 أغلق: <b className="text-purple-300">{staff.ticketsClosed}</b>
                        </div>
                      </div>
                    </div>
                    <div className="text-end shrink-0">
                      <span className="px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-300 font-mono text-xs font-black block">
                        {staff.staffPoints} 🏆
                      </span>
                      <span className="text-[9px] text-slate-400 mt-1 block">{isAr ? 'نقاط الإدارة' : 'Staff Pts'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* SMART INTERACTIVE TICKET SUMMARY EMBEDS */}
          <div className="rounded-2xl border border-purple-500/30 bg-gradient-to-r from-[#130824] via-[#0d1017] to-[#1a0b2e] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-purple-400" />
                {isAr ? '📜 سجل إيمبد ملخصات التذاكر الذكية (M7R Interactive Ticket Summary Embeds)' : '📜 Smart Interactive Ticket Summary Embeds'}
              </h3>
              <p className="text-xs text-slate-300">
                {isAr
                  ? `بدلاً من الملفات التقليدية، يرسل البوت إيمبد بنفسجي كروم فخم (#8A2BE2) إلى روم (#${panelConfig.ticketLogChannelName || 'سجل-التذاكر'}) يضم معلومات التذكرة، المدة الزمنية، إحصائيات الرسائل، ومقتطف المحادثة مع زر تصفح الرسائل بالصفحات (⬅️ السابق / التالي ➡️)!`
                  : 'Replaces HTML files with a luxury multi-field M7R Purple Chrome Embed (#8A2BE2) with conversation stats, preview, and paginated message browsing!'}
              </p>
            </div>
            <button
              onClick={handleGenerateSmartSummary}
              disabled={generatingHtml}
              className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black flex items-center gap-2 shrink-0 cursor-pointer shadow-lg shadow-purple-950/50"
            >
              <Send className="w-4 h-4" />
              <span>{isAr ? 'إرسال إيمبد ملخص التذكرة الحالية للوق 🚀' : 'Send Smart Summary Embed to Log 🚀'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {htmlTranscripts.map((tr) => (
              <div
                key={tr.id}
                className="rounded-2xl border border-purple-500/30 bg-[#0d1017] p-4 space-y-3 hover:border-purple-500/60 transition-all flex flex-col justify-between shadow-lg"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-purple-300 font-mono">#{tr.channelName}</span>
                    <span className="px-2 py-0.5 rounded bg-purple-500/15 border border-purple-500/30 text-[10px] font-mono text-purple-200">
                      {tr.messagesCount} {isAr ? 'رسالة' : 'msgs'} • {tr.durationText || '14 دقيقة'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-300 space-y-1 bg-slate-900/70 p-2.5 rounded-xl border border-slate-800">
                    <div>🔖 {isAr ? 'القسم:' : 'Category:'} <b className="text-purple-200">{tr.categoryLabel}</b></div>
                    <div>👤 {isAr ? 'صاحب التذكرة:' : 'Opener:'} <b className="text-white">{tr.openerName || tr.openedBy}</b></div>
                    <div>👨‍💻 {isAr ? 'الإداري المستلم:' : 'Claimed By:'} <b className="text-emerald-400">{tr.claimedBy || 'غير مستلمة'}</b></div>
                    <div>🔒 {isAr ? 'أُغلقت بواسطة:' : 'Closed By:'} <b className="text-rose-300">{tr.closedBy}</b></div>
                    <div>📝 {isAr ? 'سبب الإغلاق:' : 'Close Reason:'} <span className="text-slate-200">{tr.closeReason || 'تم حل المشكلة بنجاح'}</span></div>
                    {tr.staffRating && (
                      <div className="text-amber-300 font-bold pt-1">
                        ⭐ تقييم المشرف: {'⭐'.repeat(tr.staffRating)} ({tr.staffRating}/5)
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => {
                      setPreviewPage(0);
                      setPreviewTranscript(tr);
                    }}
                    className="flex-1 py-2 px-3 rounded-xl bg-purple-600/25 hover:bg-purple-600/40 border border-purple-500/50 text-purple-200 text-xs font-black flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{isAr ? '💬 عرض سجل الرسائل والإيمبد الذكي' : '💬 View Smart Summary & Messages'}</span>
                  </button>
                  <button
                    onClick={() => handleDeleteTranscriptItem(tr.id)}
                    className="p-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/30 text-rose-300 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: SMART TICKET SUMMARY EMBED & PAGINATED MESSAGES VIEWER */}
      {previewTranscript && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b0714] border border-purple-500/50 rounded-2xl max-w-3xl w-full max-h-[88vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-purple-500/30 bg-[#120924]">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-black text-white">
                  {isAr ? `💜 إيمبد ملخص التذكرة الذكي | #${previewTranscript.channelName}` : `💜 Smart Ticket Summary Embed | #${previewTranscript.channelName}`}
                </span>
              </div>
              <button
                onClick={() => setPreviewTranscript(null)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4">
              {/* Discord Luxury Multi-Field Purple Chrome Embed Representation */}
              <div className="rounded-xl bg-[#2b2d31] border-s-4 border-[#8A2BE2] p-4 space-y-3 text-xs text-slate-100 shadow-lg">
                <div className="font-black text-sm text-white flex items-center justify-between">
                  <span>💜 ملخص التذكرة الذكي | #{previewTranscript.channelName}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">
                    #8A2BE2 • M7R Smart Summary
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 bg-[#1e1f22] p-3 rounded-xl border border-slate-800">
                  <div>
                    <div className="text-purple-300 font-bold mb-1">🔖 معلومات التذكرة</div>
                    <div>• الاسم: <code className="text-white">#{previewTranscript.channelName}</code></div>
                    <div>• القسم: <b>{previewTranscript.categoryLabel}</b></div>
                  </div>
                  <div>
                    <div className="text-purple-300 font-bold mb-1">👤 صاحب التذكرة</div>
                    <div>• العضو: <b className="text-white">@{previewTranscript.openedBy}</b></div>
                    <div>• المعرف: <code className="text-slate-400">{previewTranscript.openedById || 'Member'}</code></div>
                  </div>
                  <div>
                    <div className="text-purple-300 font-bold mb-1">👨‍💻 الإداري المستلم</div>
                    <div>• المستلم: <b className="text-emerald-400">{previewTranscript.claimedBy || 'لم يتم الاستلام'}</b></div>
                    <div>• أُغلقت بواسطة: <b className="text-rose-300">{previewTranscript.closedBy}</b></div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 bg-[#1e1f22] p-3 rounded-xl border border-slate-800">
                  <div>
                    <div className="text-purple-300 font-bold mb-1">⏱️ التوقيت والمدة</div>
                    <div>• وقت الفتح: <code>{previewTranscript.openedAt || 'قبل 14 دقيقة'}</code></div>
                    <div>• وقت الإغلاق: <code>{previewTranscript.closedAt}</code></div>
                    <div>• المدة الإجمالية: <b className="text-amber-300">{previewTranscript.durationText || '14 دقيقة'}</b></div>
                  </div>
                  <div>
                    <div className="text-purple-300 font-bold mb-1">📊 إحصائيات المحادثة</div>
                    <div>• إجمالي الرسائل: <code>{previewTranscript.messagesCount}</code> رسالة</div>
                    <div>• رسائل العضو: <code>{previewTranscript.userMessagesCount ?? Math.ceil(previewTranscript.messagesCount / 2)}</code> | ردود الإدارة: <code>{previewTranscript.staffRepliesCount ?? Math.floor(previewTranscript.messagesCount / 2)}</code></div>
                    <div>• سبب الإغلاق: <span className="text-slate-300">{previewTranscript.closeReason || 'تم حل المشكلة بنجاح'}</span></div>
                  </div>
                </div>

                {/* Paginated Messages Viewer (💬 عرض سجل الرسائل بالكامل) */}
                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between">
                    <span className="text-purple-300 font-bold">
                      📜 سجل المحادثة المقسم لصفحات (صفحة {previewPage + 1} من {Math.max(1, Math.ceil((previewTranscript.messages?.length || 1) / 5))}):
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={previewPage <= 0}
                        onClick={() => setPreviewPage((p) => Math.max(0, p - 1))}
                        className="px-2.5 py-1 rounded-lg bg-[#4e5058] hover:bg-[#6d6f78] disabled:opacity-40 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <ChevronRight className="w-3.5 h-3.5" />
                        <span>⬅️ السابق</span>
                      </button>
                      <button
                        type="button"
                        disabled={previewPage >= Math.max(1, Math.ceil((previewTranscript.messages?.length || 1) / 5)) - 1}
                        onClick={() => setPreviewPage((p) => p + 1)}
                        className="px-2.5 py-1 rounded-lg bg-[#5865F2] hover:bg-[#4752c4] disabled:opacity-40 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <span>التالي ➡️</span>
                        <ChevronLeft className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="bg-[#111214] border border-slate-800 rounded-xl p-3 font-mono text-[11px] space-y-2 max-h-60 overflow-y-auto">
                    {(previewTranscript.messages || []).slice(previewPage * 5, previewPage * 5 + 5).map((m, idx) => (
                      <div key={m.id || idx} className="pb-1.5 border-b border-slate-800/70 last:border-0">
                        <span className="text-slate-500">[{m.timestamp}]</span>{' '}
                        <span className={m.isStaff ? 'text-purple-400 font-bold' : 'text-emerald-400 font-bold'}>
                          {m.isStaff ? '👨‍💻' : '👤'} {m.author}:
                        </span>{' '}
                        <span className="text-slate-200 font-sans">{m.content}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADD USER */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0e121a] border border-slate-800 rounded-xl max-w-sm w-full p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-sky-400" />
                {isAr ? 'إضافة عضو إلى التذكرة' : 'Add User to Ticket'}
              </h4>
              <button onClick={() => setShowAddUserModal(false)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <input
              type="text"
              placeholder="@Username or ID..."
              value={targetUsername}
              onChange={(e) => setTargetUsername(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-sky-500"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowAddUserModal(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs text-slate-300 hover:text-white cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={handleAddUserSubmit}
                className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-xs font-bold text-white cursor-pointer"
              >
                {isAr ? 'تأكيد الإضافة' : 'Confirm Add'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: TRANSFER TICKET */}
      {showTransferModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0e121a] border border-slate-800 rounded-xl max-w-sm w-full p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <ArrowRightLeft className="w-4 h-4 text-indigo-400" />
                {isAr ? 'تحويل التذكرة إلى قسم آخر' : 'Transfer Ticket Department'}
              </h4>
              <button onClick={() => setShowTransferModal(false)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <select
              value={targetDepartment}
              onChange={(e) => setTargetDepartment(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="إدارة المبيعات">إدارة المبيعات</option>
              <option value="فريق الأمن والحماية M7R">فريق الأمن والحماية M7R</option>
              <option value="الإدارة العليا (Co-Owners)">الإدارة العليا (Co-Owners)</option>
              <option value="فريق الشراكات والإعلانات">فريق الشراكات والإعلانات</option>
            </select>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowTransferModal(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs text-slate-300 hover:text-white cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={handleTransferSubmit}
                className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white cursor-pointer"
              >
                {isAr ? 'تحويل التذكرة' : 'Confirm Transfer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
