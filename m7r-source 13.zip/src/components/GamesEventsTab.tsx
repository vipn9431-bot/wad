import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Trophy,
  Sparkles,
  Rocket,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Zap,
  Crown,
  Gift,
  Trash2,
  Send,
  Hash,
  Flame,
  ShoppingBag,
  Swords
} from 'lucide-react';
import { GamesConfig, GameItemConfig, GameLeaderboardPlayer, MiniGameKey, GamesShopItem } from '../types';
import { ChannelSelector } from './ChannelSelector';
import { sound } from '../utils/sound';
import { getAuthHeaders } from './TokenAuthGate';

interface GamesEventsTabProps {
  lang: 'ar' | 'en';
}

const DEFAULT_SHOP_ITEMS: GamesShopItem[] = [
  {
    key: 'shield',
    nameAr: 'درع الحماية الملكي (Shield)',
    emoji: '🛡️',
    descriptionAr: 'يحميك تلقائياً من الإقصاء ويعكس الطلقة على من استهدفك في روليت M7R!',
    price: 45,
    enabled: true
  },
  {
    key: 'extraLife',
    nameAr: 'حياة إضافية (Extra Life)',
    emoji: '❤️',
    descriptionAr: 'تمنحك فرصة نجاة إضافية تلقائية عند الخسارة في الروليت أو القنبلة الموقوتة!',
    price: 60,
    enabled: true
  },
  {
    key: 'doublePoints',
    nameAr: 'مضاعف النقاط (2x M7R Points)',
    emoji: '⚡',
    descriptionAr: 'يضاعف جائزة نقاط M7R 💎 تلقائياً في فوزك القادم بأي لعبة (x2)!',
    price: 30,
    enabled: true
  },
  {
    key: 'doubleKick',
    nameAr: 'الضربة المزدوجة (Double Strike)',
    emoji: '🔥',
    descriptionAr: 'تمنحك قوة إقصاء مزدوجة في جولات التحدي الجماعية!',
    price: 55,
    enabled: true
  }
];

const DEFAULT_GAMES_LIST: GameItemConfig[] = [
  {
    key: 'roulette',
    titleAr: '🎡 روليت الإقصاء والدروع (M7R Battle Roulette)',
    titleEn: 'M7R Battle Roulette',
    emoji: '🎡',
    category: 'party',
    descriptionAr: 'دوران عجلة الروليت الحماسية مع أزرار (🔫 طرد لاعب)، (🎲 حظك نصيبك: حدث عشوائي مجنون)، و(🛡️ تفعيل درع الحماية لعكس الطرد)!',
    enabled: true,
    pointsReward: 60,
    xpReward: 150
  },
  {
    key: 'mafia',
    titleAr: '🕵️‍♂️ مافيا M7R التفاعلية (M7R Mafia Party)',
    titleEn: 'M7R Mafia Party',
    emoji: '🕵️‍♂️',
    category: 'party',
    descriptionAr: 'توزيع أدوار سرية خاصة (🔪 مافيا، 🩺 طبيب، 🕵️ محقق، 👤 مواطن) مع تحركات ليلية وتصويت نهاري درامي لكشف المافيا!',
    enabled: true,
    pointsReward: 70,
    xpReward: 160
  },
  {
    key: 'out_of_loop',
    titleAr: '🤫 برا السالفة (M7R Out of the Loop)',
    titleEn: 'Out of the Loop',
    emoji: '🤫',
    category: 'party',
    descriptionAr: 'اختيار تصنيف (ألعاب، أكلات، دول، سيارات، أنمي) وكشف الكلمة السرية للجميع ما عدا المحتال (برا السالفة) مع تصويت وتخمين نهائي!',
    enabled: true,
    pointsReward: 55,
    xpReward: 130
  },
  {
    key: 'bomb',
    titleAr: '💣 القنبلة الموقوتة (Hot Potato Bomb)',
    titleEn: 'Hot Potato Bomb',
    emoji: '💣',
    category: 'party',
    descriptionAr: 'تحدي الأدرينالين السريع! قنبلة موقوتة تنتقل بين اللاعبين ويجب تمريرها بالزر التفاعلي قبل الانفجار!',
    enabled: true,
    pointsReward: 50,
    xpReward: 120
  },
  {
    key: 'wyr',
    titleAr: '🤔 لو خيروك والتحديات الجريئة (Would You Rather)',
    titleEn: 'Would You Rather Live Poll',
    emoji: '🤔',
    category: 'party',
    descriptionAr: 'سيناريو محير وتحدٍ جريء مع زرين للتصويت المباشر (🔴 الخيار الأول ضد 🔵 الخيار الثاني) وشريط نسب مئوية حي (▓▓▓▓▓░░░░░)!',
    enabled: true,
    pointsReward: 25,
    xpReward: 60
  },
  {
    key: 'mystery_box',
    titleAr: '💰 تحدي المزاد والصناديق الغامضة (Mystery Box)',
    titleEn: 'Mystery Box & Bidding',
    emoji: '💰',
    category: 'blitz',
    descriptionAr: 'اختر 1 من 4 صناديق غامضة (📦 صندوق 1 .. 4) لربح جوائز نقاط M7R 💎 ضخمة، درع حماية ملكي، أو الوقوع في فخ طريف!',
    enabled: true,
    pointsReward: 45,
    xpReward: 95
  },
  {
    key: 'xo',
    titleAr: '⚔️ تحديات راس براس بالرهان (XO / حجرة ورقة مقص)',
    titleEn: '1v1 PvP Duels (XO & RPS)',
    emoji: '⚔️',
    category: 'duel',
    descriptionAr: 'تحدَّ صديقك أو الذكاء الاصطناعي M7R AI في إكس أو التفاعلية 3×3 (xo) أو حجرة ورقة مقص (حجرة) على نقاط M7R 💎!',
    enabled: true,
    pointsReward: 35,
    xpReward: 80
  },
  {
    key: 'tournament',
    titleAr: '🏆 بطولة السرعة الخاطفة (Blitz Tournament Mode)',
    titleEn: '5-Round Blitz Tournament',
    emoji: '🏆',
    category: 'blitz',
    descriptionAr: 'بطولة M7R السريعة من 5 جولات أوتوماتيكية متتالية تمزج (أسرع كاتب، فكك، أعلام، وإيموجي) وتتوج أصحاب المراكز الـ 3 الأولى!',
    enabled: true,
    pointsReward: 80,
    xpReward: 200
  }
];

export const GamesEventsTab: React.FC<GamesEventsTabProps> = ({ lang }) => {
  const isAr = lang === 'ar';

  const [config, setConfig] = useState<GamesConfig>({
    enabled: true,
    allowedChannel: 'all',
    hubChannelName: 'فعاليات-وألعاب',
    embedColor: '#8A2BE2',
    games: DEFAULT_GAMES_LIST,
    shopItems: DEFAULT_SHOP_ITEMS
  });

  const [leaderboard, setLeaderboard] = useState<GameLeaderboardPlayer[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'party' | 'duel' | 'blitz'>('all');
  const [tournamentRounds, setTournamentRounds] = useState<number>(5);
  const [startingTournament, setStartingTournament] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [deployingHub, setDeployingHub] = useState<boolean>(false);
  const [launchingGameKey, setLaunchingGameKey] = useState<string | null>(null);
  const [quickSetupSystem, setQuickSetupSystem] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [bonusUsername, setBonusUsername] = useState<string>('');
  const [bonusPoints, setBonusPoints] = useState<number>(50);

  const showToast = (type: 'success' | 'error', text: string) => {
    setStatusMsg({ type, text });
    setTimeout(() => setStatusMsg(null), 6000);
  };

  const fetchGamesData = async () => {
    try {
      const res = await fetch('/api/games/config', {
        credentials: 'include',
        headers: getAuthHeaders()
      });
      const data = await res.json();
      if (data?.config) {
        const incomingGames: GameItemConfig[] =
          Array.isArray(data.config.games) && data.config.games.length >= 8
            ? data.config.games
            : DEFAULT_GAMES_LIST;
        setConfig({
          ...data.config,
          games: incomingGames,
          shopItems:
            Array.isArray(data.config.shopItems) && data.config.shopItems.length > 0
              ? data.config.shopItems
              : DEFAULT_SHOP_ITEMS
        });
      }
      if (Array.isArray(data?.leaderboard)) {
        setLeaderboard(data.leaderboard);
      }
    } catch {
      // keep defaults
    }
  };

  useEffect(() => {
    fetchGamesData();
  }, []);

  const handleSaveConfig = async () => {
    sound.playShieldActivate();
    setSaving(true);
    try {
      const res = await fetch('/api/games/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(config)
      });
      const data = await res.json();
      if (data?.success) {
        showToast('success', data.message || '✅ تم حفظ إعدادات منظومة ألعاب ومتجر M7R GAMES بنجاح!');
      } else {
        showToast('error', data?.error || 'حدث خطأ أثناء حفظ الإعدادات.');
      }
    } catch {
      showToast('error', 'تعذر الاتصال بالسيرفر لحفظ الإعدادات.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeployGamesHub = async () => {
    sound.playShieldActivate();
    setDeployingHub(true);
    try {
      const res = await fetch('/api/games/deploy-hub', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({ channelName: config.hubChannelName })
      });
      const data = await res.json();
      if (data?.success) {
        showToast('success', data.message || `🎮 تم نشر لوحة ساحة M7R GAMES في #${config.hubChannelName} بنجاح!`);
      } else {
        showToast('error', data?.error || 'تعذر نشر لوحة الألعاب.');
      }
    } catch {
      showToast('error', 'حدث خطأ أثناء نشر لوحة الألعاب.');
    } finally {
      setDeployingHub(false);
    }
  };

  const handleStartAutoTournament = async () => {
    sound.playShieldActivate();
    setStartingTournament(true);
    try {
      const targetCh =
        config.allowedChannel && config.allowedChannel !== 'all'
          ? config.allowedChannel
          : config.hubChannelName || 'فعاليات-وألعاب';

      const res = await fetch('/api/games/tournament', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          channelName: targetCh,
          roundsCount: tournamentRounds
        })
      });
      const data = await res.json();
      if (data?.success) {
        showToast('success', data.message || `🏆 تم إطلاق بطولة M7R GAMES (${tournamentRounds} جولات) بنجاح!`);
      } else {
        showToast('error', data?.error || 'تعذر إطلاق البطولة، تأكد من اتصال البوت.');
      }
    } catch {
      showToast('error', 'تعذر الاتصال بالسيرفر لإطلاق البطولة.');
    } finally {
      setStartingTournament(false);
    }
  };

  const handleLaunchGameNow = async (gameKey: MiniGameKey) => {
    sound.playClick();
    setLaunchingGameKey(gameKey);
    try {
      const targetCh =
        config.allowedChannel && config.allowedChannel !== 'all'
          ? config.allowedChannel
          : config.hubChannelName || 'فعاليات-وألعاب';

      const res = await fetch('/api/games/launch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          gameKey,
          channelName: targetCh
        })
      });
      const data = await res.json();
      if (data?.success) {
        showToast('success', data.message || '🚀 تم إطلاق اللعبة في السيرفر بنجاح!');
      } else {
        showToast('error', data?.error || 'تعذر إطلاق اللعبة، تأكد من اتصال البوت.');
      }
    } catch {
      showToast('error', 'تعذر الاتصال بالسيرفر لإطلاق اللعبة.');
    } finally {
      setLaunchingGameKey(null);
    }
  };

  const handleQuickSetup = async (system: 'games' | 'tickets' | 'ai' | 'files') => {
    sound.playShieldActivate();
    setQuickSetupSystem(system);
    try {
      const res = await fetch(`/api/quick-setup/${system}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        }
      });
      const data = await res.json();
      if (data?.success) {
        showToast('success', data.message || '⚡ تم الإعداد السريع بضغطة زر بنجاح!');
        if (system === 'games') fetchGamesData();
      } else {
        showToast('error', data?.error || 'تعذر تنفيذ الإعداد السريع.');
      }
    } catch {
      showToast('error', 'حدث خطأ أثناء تنفيذ الإعداد السريع.');
    } finally {
      setQuickSetupSystem(null);
    }
  };

  const handleAwardBonus = async () => {
    if (!bonusUsername.trim()) return;
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/games/leaderboard/manage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          action: 'bonus',
          username: bonusUsername.trim(),
          points: bonusPoints
        })
      });
      const data = await res.json();
      if (data?.success) {
        setLeaderboard(data.leaderboard || []);
        setBonusUsername('');
        showToast('success', data.message || '🏆 تم منح نقاط M7R 💎 الإضافية بنجاح!');
      }
    } catch {
      showToast('error', 'تعذر منح النقاط.');
    }
  };

  const handleResetLeaderboard = async () => {
    sound.playClick();
    try {
      const res = await fetch('/api/games/leaderboard/manage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({ action: 'reset' })
      });
      const data = await res.json();
      if (data?.success) {
        setLeaderboard([]);
        showToast('success', data.message || '🔄 تم تصفير قائمة المتصدرين وبدء موسم جديد!');
      }
    } catch {
      showToast('error', 'تعذر تصفير المتصدرين.');
    }
  };

  const updateGameItem = (key: MiniGameKey, patch: Partial<GameItemConfig>) => {
    setConfig((prev) => ({
      ...prev,
      games: prev.games.map((g) => (g.key === key ? { ...g, ...patch } : g))
    }));
  };

  const updateShopItem = (key: GamesShopItem['key'], patch: Partial<GamesShopItem>) => {
    setConfig((prev) => ({
      ...prev,
      shopItems: (prev.shopItems || DEFAULT_SHOP_ITEMS).map((item) =>
        item.key === key ? { ...item, ...patch } : item
      )
    }));
  };

  const filteredGames = config.games.filter((g) =>
    selectedCategory === 'all' ? true : g.category === selectedCategory
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Status Toast Banner */}
      {statusMsg && (
        <div
          className={`p-4 rounded-2xl border flex items-center justify-between gap-3 shadow-xl ${
            statusMsg.type === 'success'
              ? 'bg-emerald-950/90 border-emerald-500/60 text-emerald-200'
              : 'bg-rose-950/90 border-rose-500/60 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2.5 text-xs sm:text-sm font-bold">
            {statusMsg.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            )}
            <span>{statusMsg.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusMsg(null)}
            className="text-xs opacity-75 hover:opacity-100 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Hero Header + 1-Click Auto-Setup Wizard Bar */}
      <div className="rounded-3xl bg-gradient-to-br from-[#16102c] via-[#0e111a] to-[#1a0f2e] border border-purple-500/40 p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 border border-purple-400/40 text-purple-300 text-xs font-black">
              <Gamepad2 className="w-4 h-4 text-purple-400" />
              <span>{isAr ? 'ساحة ألعاب وفعاليات M7R GAMES 🎮 • نقاط M7R 💎' : 'M7R GAMES & ARENA Suite 🎮'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <span>
                {isAr
                  ? 'الألعاب الـ 8 الأكثر حماساً وانجذاباً + متجر نقاط M7R 💎 (M7R Addictive Games Suite)'
                  : 'M7R 8 Most Addictive Games Suite & Perks Shop'}
              </span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              {isAr
                ? 'منظومة ألعاب M7R GAMES المركزة على الألعاب الـ 8 الأكثر إدماناً وتفاعلاً: روليت الإقصاء والدروع 🎡، مافيا M7R التفاعلية 🕵️‍♂️، برا السالفة 🤫، القنبلة الموقوتة 💣، لو خيروك بشريط نسب حي 🤔، الصناديق الغامضة 💰، تحديات راس براس XO/حجرة ⚔️، وبطولة السرعة الخاطفة (5 جولات) 🏆!'
                : 'Exclusive 8 high-engagement M7R GAMES with multiplayer lobbies, mystery boxes, live polls, and 5-round blitz tournaments!'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => handleQuickSetup('games')}
              disabled={quickSetupSystem === 'games'}
              className="px-4 py-3 rounded-2xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-black flex items-center gap-2 shadow-lg shadow-purple-950/60 border border-purple-400/40 cursor-pointer transition-all disabled:opacity-60"
            >
              <Zap className="w-4 h-4 text-amber-300 animate-pulse" />
              <span>
                {quickSetupSystem === 'games'
                  ? isAr
                    ? 'جاري الإعداد السريع...'
                    : 'Setting up...'
                  : isAr
                  ? '⚡ إعداد سريع بضغطة زر (إنشاء الروم + نشر ساحة M7R GAMES)'
                  : '⚡ 1-Click Auto-Setup & Deploy Hub'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleSaveConfig}
              disabled={saving}
              className="px-4 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-black flex items-center gap-2 shadow-lg shadow-emerald-950/50 cursor-pointer transition-all disabled:opacity-60"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? (isAr ? 'جاري الحفظ...' : 'Saving...') : isAr ? 'حفظ الإعدادات ✅' : 'Save Settings ✅'}</span>
            </button>
          </div>
        </div>

        {/* 1-Click Auto-Setup Bar for All Major Server Systems */}
        <div className="mt-5 pt-4 border-t border-purple-500/20 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-bold text-purple-200">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{isAr ? 'معالج التجهيز السريع للسيرفر بضغطة زر (1-Click Quick Setup):' : '1-Click Server Auto-Setup Wizards:'}</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'games', label: isAr ? '🎮 تجهيز ساحة ألعاب M7R GAMES' : '🎮 Setup M7R Games Hub' },
              { id: 'tickets', label: isAr ? '🎫 تجهيز روم وبانل التذاكر' : '🎫 Setup Ticket System' },
              { id: 'ai', label: isAr ? '🤖 تجهيز غرفة الذكاء الاصطناعي #m7r-ai' : '🤖 Setup #m7r-ai Room' }
            ].map((wiz) => (
              <button
                key={wiz.id}
                type="button"
                onClick={() => handleQuickSetup(wiz.id as any)}
                disabled={quickSetupSystem === wiz.id}
                className="px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-purple-900/40 border border-purple-500/30 hover:border-purple-400 text-xs font-bold text-slate-200 hover:text-white cursor-pointer transition-all"
              >
                {quickSetupSystem === wiz.id ? '⏳ ...' : wiz.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Global Games Configuration, Auto-Tournament & Cheat Sheet */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 rounded-2xl bg-[#0c0f17] border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
              <Hash className="w-4 h-4 text-purple-400" />
              <span>{isAr ? 'إعدادات رومات اللعب ولوحة ساحة M7R GAMES والبطولات التلقائية' : 'M7R GAMES Room, Hub & Tournament Settings'}</span>
            </h3>
            <label className="flex items-center gap-2 cursor-pointer">
              <span className="text-xs font-bold text-slate-300">
                {config.enabled ? (isAr ? 'النظام مفعل 🟢' : 'Enabled 🟢') : isAr ? 'معطل 🔴' : 'Disabled 🔴'}
              </span>
              <input
                type="checkbox"
                checked={config.enabled}
                onChange={(e) => setConfig({ ...config, enabled: e.target.checked })}
                className="w-4 h-4 accent-purple-500 rounded cursor-pointer"
              />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">
                {isAr ? '🎯 صلاحية تشغيل الألعاب في الرومات:' : 'Allowed Channels for Games:'}
              </label>
              <ChannelSelector
                value={config.allowedChannel}
                onChange={(val) => setConfig({ ...config, allowedChannel: val || 'all' })}
                allowAllChannelsOption={true}
                allChannelsLabel={isAr ? '🌐 جميع رومات السيرفر (أو الروم المحدد)' : '🌐 All Server Channels'}
                placeholder={isAr ? 'اختر روم الألعاب أو اتركه للجميع' : 'Select channel'}
              />
              <p className="text-[11px] text-slate-400">
                {isAr
                  ? 'يدعم البادئة m7r <اسم اللعبة> أو كتابة اسم اللعبة مباشرة بدون بادئة داخل روم الألعاب!'
                  : 'Supports m7r <game> or direct game names inside the games room.'}
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">
                {isAr ? '🎮 روم ساحة ألعاب M7R GAMES الرئيسية:' : 'Main M7R GAMES Hub Channel:'}
              </label>
              <ChannelSelector
                value={config.hubChannelName}
                onChange={(val) => setConfig({ ...config, hubChannelName: val || 'فعاليات-وألعاب' })}
                allowAllChannelsOption={false}
                placeholder="فعاليات-وألعاب"
              />
              <p className="text-[11px] text-slate-400">
                {isAr
                  ? 'إذا لم يكن الروم موجوداً في السيرفر، سيقوم البوت بإنشائه تلقائياً عند نشر اللوحة!'
                  : 'Created automatically if missing when deploying hub.'}
              </p>
            </div>
          </div>

          {/* Auto-Tournament Bar */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/30 via-purple-950/30 to-slate-900 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-amber-400" />
                <span>{isAr ? '🏆 نظام البطولات والجولات المتتالية التلقائية (M7R Auto-Tournament)' : '🏆 M7R Auto-Tournament Mode'}</span>
              </div>
              <p className="text-[11px] text-slate-300">
                {isAr
                  ? 'يشغل جولات سرعة متنوعة متتالية تلقائياً في الروم ويعلن بطل البطولة في النهاية!'
                  : 'Runs consecutive mixed blitz rounds automatically and crowns the tournament champion!'}
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <select
                value={tournamentRounds}
                onChange={(e) => setTournamentRounds(Number(e.target.value) || 5)}
                className="px-2.5 py-2 rounded-xl bg-slate-950 border border-amber-500/40 text-xs font-bold text-amber-200"
              >
                <option value={3}>{isAr ? '3 جولات متتالية' : '3 Rounds'}</option>
                <option value={5}>{isAr ? '5 جولات متتالية' : '5 Rounds'}</option>
                <option value={7}>{isAr ? '7 جولات متتالية' : '7 Rounds'}</option>
                <option value={10}>{isAr ? '10 جولات متتالية' : '10 Rounds'}</option>
              </select>

              <button
                type="button"
                onClick={handleStartAutoTournament}
                disabled={startingTournament}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black flex items-center gap-1.5 cursor-pointer transition-all shadow-md"
              >
                <Flame className="w-3.5 h-3.5" />
                <span>
                  {startingTournament
                    ? isAr
                      ? 'جاري إطلاق البطولة...'
                      : 'Starting...'
                    : isAr
                    ? 'إطلاق بطولة الآن 🏆'
                    : 'Start Tournament 🏆'}
                </span>
              </button>
            </div>
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/80">
            <div className="text-xs text-slate-400">
              {isAr ? (
                <span>
                  أوامر ديسكورد: <code className="text-purple-300 font-mono">/m7r-play</code> •{' '}
                  <code className="text-purple-300 font-mono">m7r العاب</code> •{' '}
                  <code className="text-purple-300 font-mono">m7r متجر</code> •{' '}
                  <code className="text-purple-300 font-mono">m7r بطولة</code>
                </span>
              ) : (
                <span>Commands: /m7r-play, m7r games, m7r shop, m7r tournament</span>
              )}
            </div>

            <button
              type="button"
              onClick={handleDeployGamesHub}
              disabled={deployingHub}
              className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black flex items-center gap-2 shadow-md shadow-purple-950/50 cursor-pointer transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>
                {deployingHub
                  ? isAr
                    ? 'جاري إرسال اللوحة لديسكورد...'
                    : 'Deploying...'
                  : isAr
                  ? `🎮 نشر لوحة ساحة M7R GAMES في #${config.hubChannelName}`
                  : `Deploy M7R GAMES Hub to #${config.hubChannelName}`}
              </span>
            </button>
          </div>
        </div>

        {/* Quick Commands Cheat Sheet Card */}
        <div className="rounded-2xl bg-[#0c0f17] border border-slate-800 p-5 space-y-3">
          <h3 className="text-sm font-black text-white flex items-center gap-2 border-b border-slate-800 pb-2.5">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>{isAr ? 'أوامر ألعاب M7R في ديسكورد (بدون بادئة أو بـ m7r)' : 'M7R Game Triggers'}</span>
          </h3>
          <div className="grid grid-cols-2 gap-1.5 text-[11px]">
            {[
              { cmd: 'روليت', desc: 'روليت الإقصاء والدروع 🎡' },
              { cmd: 'مافيا', desc: 'مافيا M7R التفاعلية 🕵️‍♂️' },
              { cmd: 'برا السالفة', desc: 'برا السالفة (5 تصنيفات) 🤫' },
              { cmd: 'قنبلة', desc: 'القنبلة الموقوتة 💣' },
              { cmd: 'لو خيروك', desc: 'لو خيروك بشريط نسب 🤔' },
              { cmd: 'صندوق / حظ', desc: 'الصناديق الغامضة 💰' },
              { cmd: 'xo / حجرة', desc: 'تحديات راس براس ⚔️' },
              { cmd: 'بطولة / اسرع', desc: 'بطولة السرعة (5 جولات) 🏆' },
              { cmd: 'فكك / اعلام / ايموجي', desc: 'تحديات السرعة الخاطفة ⚡' },
              { cmd: 'متجر / نقاطي', desc: 'متجر ونقاط M7R 💎' }
            ].map((item, i) => (
              <div
                key={i}
                className="p-2 rounded-xl bg-slate-900/90 border border-slate-800/80 flex items-center justify-between gap-1"
              >
                <code className="text-purple-300 font-mono font-bold">{item.cmd}</code>
                <span className="text-slate-300 truncate">{item.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* M7R Perks Shop Configuration Section */}
      <div className="rounded-2xl bg-[#0c0f17] border border-purple-500/30 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              <span>
                {isAr
                  ? '🛒 متجر إضافات ومزايا نقاط M7R 💎 (تتفعل تلقائياً داخل الروليت والألعاب الجماعية)'
                  : '🛒 M7R Points Perks Shop Configuration'}
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isAr
                ? 'يشتري الأعضاء هذه الإضافات من داخل ديسكورد عبر الأمر (m7r متجر) أو زر المتجر في لوحة الألعاب!'
                : 'Members purchase these perks in Discord using m7r shop or the Games Hub button.'}
            </p>
          </div>
          <span className="text-xs font-mono text-amber-300 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-xl font-bold">
            {isAr ? 'العملة الرسمية: نقاط M7R 💎' : 'Currency: M7R Points 💎'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {(config.shopItems || DEFAULT_SHOP_ITEMS).map((perk) => (
            <div
              key={perk.key}
              className={`p-4 rounded-2xl border flex flex-col justify-between space-y-3 ${
                perk.enabled
                  ? 'bg-slate-900/90 border-purple-500/35'
                  : 'bg-slate-950/60 border-slate-800 opacity-60'
              }`}
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-lg font-black text-white flex items-center gap-1.5">
                    <span>{perk.emoji}</span>
                    <span className="text-xs sm:text-sm">{perk.nameAr}</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={perk.enabled}
                    onChange={(e) => updateShopItem(perk.key, { enabled: e.target.checked })}
                    className="w-4 h-4 accent-purple-500 rounded cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">{perk.descriptionAr}</p>
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                <span className="text-[11px] font-bold text-amber-300">
                  {isAr ? 'السعر بنقاط M7R 💎:' : 'Price (💎):'}
                </span>
                <input
                  type="number"
                  min={5}
                  max={1000}
                  value={perk.price}
                  onChange={(e) =>
                    updateShopItem(perk.key, { price: Math.max(5, parseInt(e.target.value, 10) || 30) })
                  }
                  className="w-20 px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-700 text-xs font-mono text-white text-center"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 18 Interactive Mini-Games Grid with Category Tabs */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
            <Swords className="w-5 h-5 text-purple-400" />
            <span>
              {isAr
                ? `ترسانة ألعاب M7R GAMES التفاعلية (${config.games.length} لعبة جاهزة للإطلاق الفوري)`
                : `M7R GAMES Interactive Arsenal (${config.games.length} Games)`}
            </span>
          </h3>

          {/* Category Filter Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 bg-[#0c0f17] p-1.5 rounded-2xl border border-slate-800">
            {[
              { id: 'all', label: isAr ? `الألعاب الـ 8 الحماسية (${config.games.length})` : 'All 8 Games' },
              { id: 'party', label: isAr ? '🎡 ألعاب جماعية وتفاعلية' : 'Party & Live Polls' },
              { id: 'duel', label: isAr ? '⚔️ تحديات راس براس' : '1v1 Duels' },
              { id: 'blitz', label: isAr ? '🏆 الصناديق والبطولات السريعة' : 'Mystery Box & Blitz' }
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSelectedCategory(tab.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-black cursor-pointer transition-all ${
                  selectedCategory === tab.id
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredGames.map((game) => (
            <div
              key={game.key}
              className={`rounded-2xl p-5 border transition-all flex flex-col justify-between space-y-4 ${
                game.enabled
                  ? 'bg-[#0d1018] border-purple-500/35 hover:border-purple-400/70 shadow-lg shadow-purple-950/20'
                  : 'bg-slate-950/60 border-slate-800/70 opacity-70'
              }`}
            >
              <div className="space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-2xl bg-purple-500/15 border border-purple-500/40 flex items-center justify-center text-xl shrink-0">
                      {game.emoji}
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white">{isAr ? game.titleAr : game.titleEn}</h4>
                      <span className="text-[10px] font-mono text-purple-300">
                        +{game.pointsReward} {isAr ? 'نقطة M7R 💎' : 'M7R pts'} • +{game.xpReward} XP
                      </span>
                    </div>
                  </div>

                  <input
                    type="checkbox"
                    checked={game.enabled}
                    onChange={(e) => updateGameItem(game.key, { enabled: e.target.checked })}
                    className="w-4 h-4 accent-purple-500 rounded cursor-pointer mt-1"
                    title={isAr ? 'تفعيل / تعطيل اللعبة' : 'Enable / Disable Game'}
                  />
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{game.descriptionAr}</p>
              </div>

              <div className="space-y-3 pt-3 border-t border-slate-800/80">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">
                      {isAr ? '💎 نقاط الفوز:' : 'Win Points:'}
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={500}
                      value={game.pointsReward}
                      onChange={(e) =>
                        updateGameItem(game.key, { pointsReward: Math.max(1, parseInt(e.target.value, 10) || 15) })
                      }
                      className="w-full px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">
                      {isAr ? '✨ جائزة الـ XP:' : 'XP Reward:'}
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={1000}
                      value={game.xpReward}
                      onChange={(e) =>
                        updateGameItem(game.key, { xpReward: Math.max(1, parseInt(e.target.value, 10) || 40) })
                      }
                      className="w-full px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-white"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleLaunchGameNow(game.key)}
                  disabled={launchingGameKey === game.key || !game.enabled}
                  className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-purple-600/80 to-indigo-600/80 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-black flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                >
                  <Rocket className="w-3.5 h-3.5" />
                  <span>
                    {launchingGameKey === game.key
                      ? isAr
                        ? 'جاري إطلاق الفعالية في السيرفر...'
                        : 'Launching in Discord...'
                      : isAr
                      ? '🚀 إطلاق اللعبة في السيرفر الآن'
                      : '🚀 Launch Game in Server Now'}
                  </span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Live Games Leaderboard & Points Management Section */}
      <div className="rounded-3xl bg-[#0c0f17] border border-slate-800 p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              <span>{isAr ? '🏆 قائمة متصدري نقاط M7R 💎 (M7R GAMES Leaderboard)' : '🏆 M7R GAMES Leaderboard'}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isAr
                ? 'يتم حفظ نقاط M7R 💎 والـ XP وإضافات المتجر تلقائياً عند فوز الأعضاء في أي لعبة داخل ديسكورد.'
                : 'M7R Points, XP, and shop perks are automatically saved whenever members win games in Discord.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={fetchGamesData}
              className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-200 flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-purple-400" />
              <span>{isAr ? 'تحديث القائمة' : 'Refresh'}</span>
            </button>

            <button
              type="button"
              onClick={handleResetLeaderboard}
              className="px-3 py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 border border-rose-500/40 text-xs font-bold text-rose-300 flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تصفير الموسم (Reset)' : 'Reset Season'}</span>
            </button>
          </div>
        </div>

        {/* Award Bonus Points Bar */}
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-purple-500/30 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-bold text-purple-200">
            <Gift className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{isAr ? 'منح نقاط M7R 💎 إضافية لعضو (مكافأة إدارية):' : 'Award Bonus M7R Points:'}</span>
          </div>
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <input
              type="text"
              value={bonusUsername}
              onChange={(e) => setBonusUsername(e.target.value)}
              placeholder={isAr ? 'اسم العضو (مثال: u5r9)' : 'Member username'}
              className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
            />
            <input
              type="number"
              min={5}
              max={5000}
              value={bonusPoints}
              onChange={(e) => setBonusPoints(parseInt(e.target.value, 10) || 50)}
              className="w-24 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono text-amber-300"
            />
            <button
              type="button"
              onClick={handleAwardBonus}
              className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black cursor-pointer transition-all"
            >
              {isAr ? '+ منح نقاط M7R 💎' : '+ Award Points'}
            </button>
          </div>
        </div>

        {/* Leaderboard Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-start border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] font-black text-slate-400 uppercase">
                <th className="py-3 px-3 text-start">#</th>
                <th className="py-3 px-3 text-start">{isAr ? 'البطل / العضو' : 'Player'}</th>
                <th className="py-3 px-3 text-start">{isAr ? 'نقاط M7R 💎' : 'M7R Points 💎'}</th>
                <th className="py-3 px-3 text-start">{isAr ? 'ممتلكات المتجر 🛡️' : 'Perks Inventory'}</th>
                <th className="py-3 px-3 text-start">{isAr ? 'الخبرة ✨ (XP)' : 'XP ✨'}</th>
                <th className="py-3 px-3 text-start">{isAr ? 'مرات الفوز 🎯' : 'Wins 🎯'}</th>
                <th className="py-3 px-3 text-start">{isAr ? 'اللعبة المفضلة 🎮' : 'Favorite Game'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs">
              {leaderboard.length > 0 ? (
                leaderboard.map((player, idx) => (
                  <tr key={player.userId} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3 px-3 font-mono font-black">
                      {idx === 0 ? '🥇 1' : idx === 1 ? '🥈 2' : idx === 2 ? '🥉 3' : `#${idx + 1}`}
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={player.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}
                          alt={player.username}
                          className="w-7 h-7 rounded-full object-cover ring-1 ring-purple-500/50"
                        />
                        <div>
                          <div className="font-bold text-white flex items-center gap-1">
                            <span>{player.username}</span>
                            {idx === 0 && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                          </div>
                          <div className="text-[10px] font-mono text-slate-500">{player.userId}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 font-mono font-black">
                        {player.points} 💎
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-[11px] text-slate-300">
                      🛡️{player.perks?.shield || 0} • ❤️{player.perks?.extraLife || 0} • ⚡{player.perks?.doublePoints || 0}
                    </td>
                    <td className="py-3 px-3 font-mono text-purple-300 font-bold">{player.xp} XP</td>
                    <td className="py-3 px-3 font-mono text-emerald-400 font-bold">{player.wins}</td>
                    <td className="py-3 px-3 text-slate-300">{player.favoriteGame}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    {isAr
                      ? 'لا يوجد متصدرون حالياً. أطلق أي لعبة في السيرفر لتبدأ المنافسة!'
                      : 'No players on the leaderboard yet. Launch a game to start!'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
