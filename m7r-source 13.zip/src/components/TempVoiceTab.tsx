import React, { useState, useEffect } from 'react';
import {
  Mic,
  Lock,
  Unlock,
  EyeOff,
  Eye,
  Edit3,
  UserMinus,
  Save,
  Download,
  SendHorizonal,
  CheckCircle2,
  Trash2,
  RefreshCw,
  Volume2,
  Sparkles,
  Users,
  ShieldCheck
} from 'lucide-react';
import { TempVoiceConfig, TempVoiceRoomItem } from '../types';
import { ChannelSelector } from './ChannelSelector';
import { sound } from '../utils/sound';

interface TempVoiceTabProps {
  lang: 'ar' | 'en';
}

export const TempVoiceTab: React.FC<TempVoiceTabProps> = ({ lang }) => {
  const isAr = lang === 'ar';

  const [config, setConfig] = useState<TempVoiceConfig>({
    enabled: true,
    categoryName: '🎙️ الرومات الصوتية المؤقتة',
    panelTextChannelName: 'انشاء-رومك',
    masterVoiceChannelName: 'أنشئ رومك',
    defaultRoomPrefix: '🔊・',
    defaultUserLimit: 0,
    embedColor: '#8A2BE2',
    autoDeleteEmpty: true
  });

  const [activeRooms, setActiveRooms] = useState<TempVoiceRoomItem[]>([]);
  const [savedProfilesCount, setSavedProfilesCount] = useState<number>(0);
  const [isDeploying, setIsDeploying] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [previewToast, setPreviewToast] = useState<string | null>(null);

  const fetchTempVoiceStatus = async () => {
    try {
      const res = await fetch('/api/tempvoice/status');
      const data = await res.json();
      if (data.config) setConfig(data.config);
      if (Array.isArray(data.activeRooms)) setActiveRooms(data.activeRooms);
      if (typeof data.savedProfilesCount === 'number') setSavedProfilesCount(data.savedProfilesCount);
    } catch {
      // ignore offline
    }
  };

  useEffect(() => {
    fetchTempVoiceStatus();
  }, []);

  const handleSaveConfig = async () => {
    setIsSaving(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/tempvoice/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config })
      });
      const data = await res.json();
      setFeedback(data.message || 'تم حفظ إعدادات منظومة الرومات المؤقتة بنجاح!');
      setTimeout(() => setFeedback(null), 5000);
    } catch {
      setFeedback('حدث خطأ أثناء الاتصال بالخادم.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeployPanel = async () => {
    setIsDeploying(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/tempvoice/deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config, createMissingChannels: true })
      });
      const data = await res.json();
      setFeedback(data.message || 'تم نشر لوحة الرومات الصوتية المؤقتة بنجاح!');
      fetchTempVoiceStatus();
      setTimeout(() => setFeedback(null), 6000);
    } catch {
      setFeedback('حدث خطأ أثناء نشر اللوحة في ديسكورد.');
    } finally {
      setIsDeploying(false);
    }
  };

  const handleDeleteActiveRoom = async (channelId: string) => {
    sound.playAlarm();
    try {
      const res = await fetch('/api/tempvoice/rooms/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelId })
      });
      const data = await res.json();
      if (Array.isArray(data.activeRooms)) setActiveRooms(data.activeRooms);
    } catch {
      setActiveRooms((prev) => prev.filter((r) => r.channelId !== channelId));
    }
  };

  const triggerPreviewAction = (msg: string) => {
    sound.playClick();
    setPreviewToast(msg);
    setTimeout(() => setPreviewToast(null), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2.5">
            <Mic className="w-6 h-6 text-purple-400" />
            <span>
              {isAr
                ? 'منظومة الرومات الصوتية المؤقتة — TempVoice Pro 🎙️'
                : 'TempVoice Pro — Temporary Voice Channels Studio 🎙️'}
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isAr
              ? 'نظام (أنشئ رومك) التلقائي مع لوحة التحكم التفاعلية ذات الـ 5 صفوف، التحقق الصارم من صاحب الروم، وحفظ الإعدادات (PRO).'
              : 'Join-to-Create temporary voice rooms with a 5-row interactive Discord control panel, owner verification & PRO profile saving.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sound.playClick();
              fetchTempVoiceStatus();
            }}
            className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-300 flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-purple-400" />
            <span>{isAr ? 'تحديث الرومات النشطة' : 'Refresh Active Rooms'}</span>
          </button>

          <button
            onClick={handleDeployPanel}
            disabled={isDeploying}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-black flex items-center gap-2 shadow-lg shadow-purple-950/60 cursor-pointer transition-all"
          >
            <SendHorizonal className="w-4 h-4" />
            <span>
              {isDeploying
                ? isAr
                  ? 'جاري التجهيز والإرسال...'
                  : 'Deploying...'
                : isAr
                ? 'إنشاء الرومات وإرسال اللوحة في ديسكورد 🚀'
                : 'Deploy TempVoice Pro to Discord 🚀'}
            </span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs font-bold flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Configuration & Active Temporary Voice Rooms */}
        <div className="lg:col-span-7 space-y-5">
          {/* Configuration Card */}
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-purple-400" />
                <span>{isAr ? 'إعدادات رومات الإنشاء السريع واللوحة' : 'Join-to-Create & Panel Settings'}</span>
              </h3>

              <label className="flex items-center gap-2 cursor-pointer">
                <span className="text-xs font-bold text-slate-300">
                  {config.enabled ? (isAr ? '🟢 المنظومة مفعلة' : '🟢 Enabled') : isAr ? '🔴 معطلة' : '🔴 Disabled'}
                </span>
                <input
                  type="checkbox"
                  checked={config.enabled}
                  onChange={(e) => setConfig({ ...config, enabled: e.target.checked })}
                  className="w-4 h-4 accent-purple-600 rounded cursor-pointer"
                />
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <ChannelSelector
                lang={lang}
                type="all"
                label={isAr ? 'اسم الكاتيجوري (Category)' : 'Category Name'}
                value={config.categoryName}
                onChange={(val) => setConfig({ ...config, categoryName: val })}
                placeholder="🎙️ الرومات الصوتية المؤقتة"
                helperText={isAr ? 'القسم الذي تُنشأ فيه الرومات المؤقتة' : 'Parent category for temp rooms'}
              />

              <ChannelSelector
                lang={lang}
                type="text"
                label={isAr ? 'روم لوحة التحكم النصي' : 'Control Panel Text Room'}
                value={config.panelTextChannelName}
                onChange={(val) => setConfig({ ...config, panelTextChannelName: val })}
                placeholder="انشاء-رومك"
                helperText={isAr ? 'مثل: #انشاء-رومك' : 'e.g. #create-your-room'}
              />

              <ChannelSelector
                lang={lang}
                type="voice"
                label={isAr ? 'الروم الصوتي الرئيسي (Join-to-Create)' : 'Master Join-to-Create Voice'}
                value={config.masterVoiceChannelName}
                onChange={(val) => setConfig({ ...config, masterVoiceChannelName: val })}
                placeholder="أنشئ رومك"
                helperText={isAr ? 'عند دخوله يُنشأ روم العضو فوراً' : 'Joining creates member room'}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  {isAr ? 'بادئة اسم الروم المؤقت (Prefix)' : 'Room Name Prefix'}
                </label>
                <input
                  type="text"
                  value={config.defaultRoomPrefix}
                  onChange={(e) => setConfig({ ...config, defaultRoomPrefix: e.target.value })}
                  placeholder="🔊・"
                  className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg p-2 text-white font-mono"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  مثال: {config.defaultRoomPrefix || '🔊・'}u5r9
                </span>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  {isAr ? 'السعة الافتراضية للروم (0 = مفتوح)' : 'Default User Limit (0 = Unlimited)'}
                </label>
                <input
                  type="number"
                  min={0}
                  max={99}
                  value={config.defaultUserLimit}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      defaultUserLimit: Math.max(0, Math.min(99, parseInt(e.target.value, 10) || 0))
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  {isAr ? 'لون إيمبد اللوحة' : 'Panel Embed Color'}
                </label>
                <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg p-1.5">
                  <input
                    type="color"
                    value={config.embedColor || '#8A2BE2'}
                    onChange={(e) => setConfig({ ...config, embedColor: e.target.value })}
                    className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                  />
                  <span className="font-mono text-[11px] text-slate-300">{config.embedColor}</span>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-white block">
                  {isAr
                    ? '🗑️ الحذف التلقائي الفوري عند خلو الروم (Auto-Delete Empty Rooms)'
                    : '🗑️ Auto-Delete Room Immediately When Empty'}
                </span>
                <span className="text-[11px] text-slate-400 block">
                  {isAr
                    ? 'يُحذف الروم الصوتي المؤقت تلقائياً فور خروج كافة المتواجدين منه (`channel.members.size === 0`).'
                    : 'Automatically deletes the temporary voice channel as soon as the last member leaves.'}
                </span>
              </div>
              <input
                type="checkbox"
                checked={config.autoDeleteEmpty}
                onChange={(e) => setConfig({ ...config, autoDeleteEmpty: e.target.checked })}
                className="w-4 h-4 accent-purple-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="text-[11px] text-slate-400 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>
                  {isAr
                    ? `ملفات إعدادات الأعضاء المحفوظة (PRO): ${savedProfilesCount} ملف`
                    : `Saved PRO Member Profiles: ${savedProfilesCount}`}
                </span>
              </div>

              <button
                onClick={handleSaveConfig}
                disabled={isSaving}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{isSaving ? (isAr ? 'جاري الحفظ...' : 'Saving...') : isAr ? 'حفظ الإعدادات' : 'Save Settings'}</span>
              </button>
            </div>
          </div>

          {/* Active Temporary Voice Rooms Table */}
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-400" />
                  <span>
                    {isAr
                      ? `الرومات الصوتية المؤقتة النشطة حالياً (${activeRooms.length})`
                      : `Active Temporary Voice Channels (${activeRooms.length})`}
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isAr
                    ? 'تظهر هنا جميع الغرف المؤقتة المفتوحة حالياً في السيرفر مع صاحب كل غرفة وحالة القفل والإخفاء.'
                    : 'Real-time list of currently open temporary voice channels and their owners.'}
                </p>
              </div>
            </div>

            {activeRooms.length === 0 ? (
              <div className="py-10 text-center rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-2">
                <Mic className="w-7 h-7 text-slate-600 mx-auto" />
                <p className="text-xs font-bold text-slate-400">
                  {isAr
                    ? 'لا توجد رومات صوتية مؤقتة نشطة في هذه اللحظة.'
                    : 'No active temporary voice channels right now.'}
                </p>
                <p className="text-[11px] text-slate-500">
                  {isAr
                    ? `بمجرد دخول أي عضو إلى روم "${config.masterVoiceChannelName}" أو الضغط على زر "إنشاء روم صوتي 🎙️" سيظهر الروم هنا فوراً.`
                    : 'When a member joins the master voice channel or clicks Create Room, it appears here.'}
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {activeRooms.map((room) => (
                  <div
                    key={room.channelId}
                    className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-wrap items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-white font-mono">{room.channelName}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          👑 {room.ownerUsername}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                        <span>👥 المتواجدون: {room.memberCount}</span>
                        <span>•</span>
                        <span>السعة: {room.userLimit === 0 ? 'مفتوح' : room.userLimit}</span>
                        <span>•</span>
                        <span>{room.locked ? '🔒 مقفل' : '🔓 مفتوح'}</span>
                        <span>•</span>
                        <span>{room.hidden ? '🙈 مخفي' : '👁️ ظاهر'}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteActiveRoom(room.channelId)}
                      className="px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 border border-rose-500/40 text-rose-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{isAr ? 'حذف الروم' : 'Delete'}</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Exact 5-Row Discord Embed & ActionRows Live Preview */}
        <div className="lg:col-span-5">
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4 sticky top-20">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>{isAr ? 'معاينة لوحة الرومات المؤقتة (5 صفوف أزرار)' : '5-Row Discord Panel Preview'}</span>
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isAr
                    ? `تُرسل في روم #${config.panelTextChannelName} أو بالأمر !انشاء-رومك`
                    : `Posted in #${config.panelTextChannelName}`}
                </p>
              </div>
              <span className="text-[10px] font-mono text-purple-400 bg-purple-950/50 border border-purple-500/30 px-2 py-0.5 rounded">
                5 ActionRows
              </span>
            </div>

            {/* Discord Embed Container */}
            <div
              className="rounded-xl bg-[#2b2d31] p-4 text-slate-100 border-l-4 space-y-3 shadow-inner"
              style={{ borderLeftColor: config.embedColor || '#8A2BE2' }}
            >
              <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <span>منظومة الرومات الصوتية المؤقتة 🎙️</span>
              </div>

              <div className="text-sm font-black text-white">إنشاء وإدارة الرومات الصوتية</div>

              <div className="text-xs text-slate-200 space-y-2.5 leading-relaxed">
                <p>تمتع بإنشاء غرفتك الصوتية المؤقتة والتحكم بكامل خصوصيتها وإعداداتها.</p>

                <div className="space-y-1">
                  <div className="font-bold text-white">🚀 طريقة الإنشاء السريع:</div>
                  <div>
                    1️⃣ انضم إلى الروم الصوتي <b className="text-white">{config.masterVoiceChannelName || 'أنشئ رومك'}</b> ليتم إنشاء رومك الخاص فوراً.
                  </div>
                  <div>
                    2️⃣ أو اضغط على زر <b className="text-white">إنشاء روم صوتي</b> بالأسفل.
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="font-bold text-white">🛠️ لوحة التحكم (لصاحب الروم فقط):</div>
                  <div className="text-[11px] leading-relaxed">
                    • 🔒 <code className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-200">قفل الروم</code> • 🔓{' '}
                    <code className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-200">فتح الروم</code> • 🙈{' '}
                    <code className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-200">إخفاء</code> • 👁️{' '}
                    <code className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-200">إظهار</code>
                  </div>
                  <div className="text-[11px] leading-relaxed">
                    • ✏️ <code className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-200">تعديل الاسم</code> • 👢{' '}
                    <code className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-200">طرد الأعضاء</code> • 👥{' '}
                    <code className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-200">تحديد السعة</code>
                  </div>
                  <div className="text-[11px] leading-relaxed">
                    • 💾 <b className="text-white">حفظ واسترداد الإعدادات (PRO):</b>{' '}
                    <code className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-200">حفظ الإعدادات</code> •{' '}
                    <code className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-200">استرداد الإعدادات</code>
                  </div>
                </div>

                <p className="text-[11px] text-amber-300/90">
                  💡 ملاحظة: يُحذف الروم تلقائياً فور خروج كافة المتواجدين منه.
                </p>
              </div>

              <div className="text-[10px] text-slate-400 font-mono pt-1 border-t border-slate-700/60">
                M7R Empire ⚜️
              </div>
            </div>

            {/* Interactive 5 ActionRows Preview */}
            <div className="space-y-2 pt-1">
              {/* Row 1 */}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => triggerPreviewAction('🎙️ [tempvc_create] يتم إنشاء غرفة صوتية مؤقتة باسمك ونقلك إليها فوراً!')}
                  className="px-4 py-2 rounded-lg bg-[#248046] hover:bg-[#1a6334] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <span>🎙️</span>
                  <span>إنشاء روم صوتي</span>
                </button>
              </div>

              {/* Row 2 */}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => triggerPreviewAction('🔒 [tempvc_lock] تم قفل الروم الصوتي عن بقية الأعضاء (Connect: false)!')}
                  className="px-4 py-2 rounded-lg bg-[#da373c] hover:bg-[#a12828] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>إغلاق 🔒</span>
                </button>
                <button
                  type="button"
                  onClick={() => triggerPreviewAction('🔓 [tempvc_unlock] تم فتح الروم الصوتي لجميع الأعضاء!')}
                  className="px-4 py-2 rounded-lg bg-[#248046] hover:bg-[#1a6334] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>فتح 🔓</span>
                </button>
              </div>

              {/* Row 3 */}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => triggerPreviewAction('🙈 [tempvc_hide] تم إخفاء الروم الصوتي عن الجميع (ViewChannel: false)!')}
                  className="px-4 py-2 rounded-lg bg-[#4e5058] hover:bg-[#6d6f78] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>إخفاء 🙈</span>
                </button>
                <button
                  type="button"
                  onClick={() => triggerPreviewAction('👁️ [tempvc_unhide] تم إظهار الروم الصوتي لجميع الأعضاء!')}
                  className="px-4 py-2 rounded-lg bg-[#4e5058] hover:bg-[#6d6f78] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>إظهار 👁️</span>
                </button>
              </div>

              {/* Row 4 */}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => triggerPreviewAction('✏️ [tempvc_rename] يفتح نافذة (Modal) لتغيير اسم الروم وتحديد السعة القصوى!')}
                  className="px-4 py-2 rounded-lg bg-[#5865F2] hover:bg-[#4752c4] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>تغيير الاسم ✏️</span>
                </button>
                <button
                  type="button"
                  onClick={() => triggerPreviewAction('👢 [tempvc_kick] يعرض قائمة الأعضاء المتواجدين داخل الروم لطرد وفصل العضو المحدد!')}
                  className="px-4 py-2 rounded-lg bg-[#da373c] hover:bg-[#a12828] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <UserMinus className="w-3.5 h-3.5" />
                  <span>طرد عضو 👢</span>
                </button>
              </div>

              {/* Row 5 */}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => triggerPreviewAction('💾 [tempvc_save] تم حفظ اسم الروم، السعة، وحالة القفل/الإخفاء في ملفك الشخصي (PRO)!')}
                  className="px-4 py-2 rounded-lg bg-[#4e5058] hover:bg-[#6d6f78] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>حفظ الإعدادات 💾</span>
                </button>
                <button
                  type="button"
                  onClick={() => triggerPreviewAction('📥 [tempvc_load] تم استرداد وتطبيق إعداداتك المحفوظة على غرفتك الصوتية الحالية فوراً!')}
                  className="px-4 py-2 rounded-lg bg-[#4e5058] hover:bg-[#6d6f78] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>استرداد الإعدادات 📥</span>
                </button>
              </div>
            </div>

            {previewToast && (
              <div className="p-2.5 rounded-lg bg-purple-950/70 border border-purple-500/40 text-purple-200 text-xs font-bold animate-fade-in">
                {previewToast}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
