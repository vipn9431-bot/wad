import React, { useState, useEffect } from 'react';
import {
  Wand2,
  Lightbulb,
  CheckCircle2,
  Sparkles,
  Rocket,
  Send,
  ThumbsUp,
  ThumbsDown,
  MessageSquare,
  Shield,
  Ticket,
  Gamepad2,
  Mic,
  Radio,
  FileText,
  Users,
  Check,
  XCircle,
  Star,
  ArrowLeft,
  Flame
} from 'lucide-react';
import { SuggestionItem } from '../types';
import { getAuthHeaders } from './TokenAuthGate';
import { sound } from '../utils/sound';

interface ReadyRoomsAndSuggestionsTabProps {
  lang: 'ar' | 'en';
  view: 'ready_rooms' | 'suggestions';
  guildId?: string;
  serverName?: string;
  onNavigateTab?: (tabId: string) => void;
  onNavigateToStaffApps?: () => void;
}

interface ReadyRoomBundle {
  key: string;
  title: string;
  channelsPreview: string;
  description: string;
  badge: string;
  icon: any;
  color: string;
}

const READY_ROOM_BUNDLES: ReadyRoomBundle[] = [
  {
    key: 'welcome',
    title: '👋 روم الترحيب (#الترحيب)',
    channelsPreview: '#الترحيب',
    description: 'ينشئ روم الترحيب ويربطه باستوديو بطاقة الترحيب المصورة (1024×450) وزر (رحبوا فيه) تلقائياً!',
    badge: 'يربط استوديو الترحيب',
    icon: Sparkles,
    color: 'text-purple-400'
  },
  {
    key: 'general_chat',
    title: '💬 روم الشات العام (#الشات-العام)',
    channelsPreview: '#الشات-العام',
    description: 'ينشئ روم النقاش العام ويفعّل فيه الردود التلقائية الذكية والخط التلقائي!',
    badge: 'يفعّل الرد الذكي',
    icon: MessageSquare,
    color: 'text-sky-400'
  },
  {
    key: 'tickets',
    title: '🎫 روم التذاكر والدعم (#فتح-تذكرة + #لوق-التذاكر)',
    channelsPreview: '#فتح-تذكرة ، #لوق-التذاكر',
    description: 'ينشئ رومات التذاكر وينشر بانل التذاكر الملكي مع قفل الاستلام الحصري وتقييم 5 نجوم ⭐!',
    badge: 'ينشر بانل التذاكر',
    icon: Ticket,
    color: 'text-indigo-400'
  },
  {
    key: 'applications',
    title: '📋 روم التقديمات (#التقديم-على-الإدارة + #مراجعة-التقديمات + #نتائج-التقديم)',
    channelsPreview: '#التقديم-على-الإدارة ، #مراجعة-التقديمات ، #نتائج-التقديم',
    description: 'ينشئ رومات التقديم والمراجعة والنتائج وينشر لوحة التقديم التفاعلية فوراً!',
    badge: 'ينشر لوحة التقديم',
    icon: Shield,
    color: 'text-emerald-400'
  },
  {
    key: 'suggestions',
    title: '💡 روم الاقتراحات (#الاقتراحات)',
    channelsPreview: '#الاقتراحات',
    description: 'ينشئ روم الاقتراحات التفاعلي بحيث تتحول أي رسالة فيه إلى بطاقة تصويت بشريط تأييد حي!',
    badge: 'تصويت حي تلقائي',
    icon: Lightbulb,
    color: 'text-amber-400'
  },
  {
    key: 'games',
    title: '🎮 روم الألعاب (#ساحة-الألعاب)',
    channelsPreview: '#ساحة-الألعاب',
    description: 'ينشئ روم الفعاليات وينشر لوحة ألعاب M7R (15+ لعبة جماعية وفردية ومتجر الدروع)!',
    badge: 'ينشر لوحة الألعاب',
    icon: Gamepad2,
    color: 'text-pink-400'
  },
  {
    key: 'audit_logs',
    title: '📜 روم سجلات السيرفر (#لوق-السيرفر + #إعلانات-الإدارة)',
    channelsPreview: '#لوق-السيرفر ، #إعلانات-الإدارة',
    description: 'ينشئ رومات خاصة للإدارة فقط ويربطها بنظام اللوق الشامل وكاشف المسؤول وإنذارات الإدارة!',
    badge: 'خاص للإدارة 🔒',
    icon: FileText,
    color: 'text-rose-400'
  },
  {
    key: 'tempvoice',
    title: '🎙️ روم صوتي مؤقت (#انشاء-رومك + #تحكم-الروم)',
    channelsPreview: '🔊 انشاء-رومك ، #تحكم-الروم',
    description: 'ينشئ الروم الصوتي الذكي مع لوحة التحكم الـ 9 أزرار (قفل، إخفاء، عدد، طرد، ونقل ملكية)!',
    badge: '9 أزرار تحكم',
    icon: Mic,
    color: 'text-cyan-400'
  },
  {
    key: 'quran_azkar',
    title: '🕌 إذاعة القرآن والأذكار (#القرآن-الكريم + #الأذكار)',
    channelsPreview: '🔊 القرآن-الكريم المستمر ، #الأذكار',
    description: 'ينشئ روم إذاعة القرآن الكريم المستمر وروم الأذكار الإسلامية الدورية مع لوحة القراء!',
    badge: 'بث المستمر 🕋',
    icon: Radio,
    color: 'text-teal-400'
  }
];

const SERVER_IDEA_PRESETS = [
  {
    id: 'gaming_clan',
    label: '🎮 سيرفر ألعاب وكلان',
    ideaText: 'سيرفر كلان ألعاب وبطولات تنافسية وتحديات يومية ورومات سكوادات صوتية'
  },
  {
    id: 'community_chill',
    label: '☕ سيرفر مجتمع وسوالف',
    ideaText: 'سيرفر مجتمع وسوالف ووناسة وفعاليات يومية ومسابقات وجوائز'
  },
  {
    id: 'esports_tournaments',
    label: '🏆 سيرفر بطولات وتحديات تنافسية',
    ideaText: 'سيرفر بطولات وتحديات رياضات إلكترونية مع رومات تسجيل الفرق والنتائج والتحكيم'
  },
  {
    id: 'roleplay_life',
    label: '🚓 سيرفر رول بلاي وحياة واقعية',
    ideaText: 'سيرفر رول بلاي وحياة واقعية مع تقديمات شرطة وإسعاف ورقابة إدارية وتذاكر دعم'
  }
];

export const ReadyRoomsAndSuggestionsTab: React.FC<ReadyRoomsAndSuggestionsTabProps> = ({
  view,
  guildId = 'default',
  serverName = 'M7R Server',
  onNavigateTab
}) => {
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 6000);
  };

  // ================= STATE FOR READY ROOMS & SERVER IDEA BUILDER =================
  const [selectedRooms, setSelectedRooms] = useState<Record<string, boolean>>({
    welcome: true,
    general_chat: true,
    tickets: true,
    applications: true,
    suggestions: true,
    games: true,
    audit_logs: true,
    tempvoice: true,
    quran_azkar: true
  });
  const [deployingBundleKey, setDeployingBundleKey] = useState<string | null>(null);
  const [deployingAllRooms, setDeployingAllRooms] = useState(false);
  const [createdRoomsLog, setCreatedRoomsLog] = useState<string[]>([]);

  const [serverIdeaInput, setServerIdeaInput] = useState(
    'سيرفر كلان ألعاب وبطولات تنافسية وتحديات يومية ورومات سكوادات صوتية'
  );
  const [buildingIdea, setBuildingIdea] = useState(false);
  const [ideaBuildResult, setIdeaBuildResult] = useState<{
    ideaTitle: string;
    createdChannels: string[];
    createdRoles: string[];
    generatedQuestions: string[];
  } | null>(null);

  // ================= STATE FOR SUGGESTIONS HUB =================
  const [suggestions, setSuggestions] = useState<SuggestionItem[]>([]);
  const [sugAuthorName, setSugAuthorName] = useState('');
  const [sugCategory, setSugCategory] = useState<
    'فكرة للبوت' | 'فكرة للسيرفر' | 'لعبة جديدة' | 'أمر جديد'
  >('فكرة للسيرفر');
  const [sugContent, setSugContent] = useState('');
  const [sugSendToDiscord, setSugSendToDiscord] = useState(true);
  const [sugChannelName, setSugChannelName] = useState('الاقتراحات');
  const [submittingSug, setSubmittingSug] = useState(false);

  const fetchSuggestions = async () => {
    try {
      const res = await fetch('/api/suggestions', {
        headers: getAuthHeaders()
      });
      const data = await res.json();
      if (Array.isArray(data?.suggestions)) {
        setSuggestions(data.suggestions);
      }
      if (data?.channelName) {
        setSugChannelName(data.channelName);
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetchSuggestions();
  }, [guildId]);

  const handleDeployReadyRooms = async (keysToDeploy: string[], singleKey?: string) => {
    if (keysToDeploy.length === 0) {
      showToast('يرجى تحديد روم واحد على الأقل للإنشاء.', 'error');
      return;
    }
    sound.playShieldActivate();
    if (singleKey) setDeployingBundleKey(singleKey);
    else setDeployingAllRooms(true);

    try {
      const guestToken = localStorage.getItem('m7r_guest_bot_token') || '';
      const targetGuildId = guildId || 'default';
      const res = await fetch(`/api/guilds/${encodeURIComponent(targetGuildId)}/create-ready-rooms`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          token: guestToken || undefined,
          guildId: targetGuildId,
          rooms: keysToDeploy,
          serverIdea: serverIdeaInput.trim()
        })
      });
      const data = await res.json();
      if (data?.success) {
        if (Array.isArray(data.createdChannels)) {
          setCreatedRoomsLog(data.createdChannels);
        }
        showToast(
          data.message ||
            `✅ تم إنشاء الرومات وإرسال اللوحات بنجاح! (${(data.createdChannels || []).map((c: string) => `#${c}`).join(' ، ')})`
        );
      } else {
        showToast(data?.error || 'تعذر إنشاء الرومات حالياً. تأكد من صلاحية Manage Channels للبوت.', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء الاتصال بالخادم.', 'error');
    } finally {
      setDeployingBundleKey(null);
      setDeployingAllRooms(false);
    }
  };

  const handleBuildByServerIdea = async () => {
    if (!serverIdeaInput.trim()) {
      showToast('يرجى كتابة فكرة سيرفرك أولاً!', 'error');
      return;
    }
    sound.playShieldActivate();
    setBuildingIdea(true);
    try {
      const res = await fetch('/api/ready-rooms/idea-builder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          guildId,
          idea: serverIdeaInput.trim()
        })
      });
      const data = await res.json();
      if (data?.success) {
        setIdeaBuildResult({
          ideaTitle: data.ideaTitle || serverIdeaInput.trim(),
          createdChannels: data.createdChannels || [],
          createdRoles: data.createdRoles || [],
          generatedQuestions: data.generatedQuestions || []
        });
        showToast(
          data.message ||
            '🧠 تم تصميم وإنشاء الرومات وتوليد أسئلة التقديم المناسبة لفكرة سيرفرك ونشر البانل تلقائياً!'
        );
      } else {
        showToast(data?.error || 'تعذر بناء فكرة السيرفر.', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء توليد هيكل السيرفر.', 'error');
    } finally {
      setBuildingIdea(false);
    }
  };

  const handleSubmitSuggestion = async () => {
    if (!sugContent.trim()) {
      showToast('يرجى كتابة فكرتك أو اقتراحك أولاً!', 'error');
      return;
    }
    sound.playShieldActivate();
    setSubmittingSug(true);
    try {
      const res = await fetch('/api/suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          guildId,
          authorName: sugAuthorName.trim() || 'عضو M7R المبدع',
          category: sugCategory,
          content: sugContent.trim(),
          sendToDiscord: sugSendToDiscord,
          channelName: sugChannelName.trim() || 'الاقتراحات'
        })
      });
      const data = await res.json();
      if (data?.success) {
        setSugContent('');
        if (Array.isArray(data.suggestions)) {
          setSuggestions(data.suggestions);
        }
        showToast(data.message || '💡 تم نشر فكرتك بنجاح وإرسالها إلى لوحة الاقتراحات!');
      } else {
        showToast(data?.error || 'تعذر إرسال الاقتراح.', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء إرسال الاقتراح.', 'error');
    } finally {
      setSubmittingSug(false);
    }
  };

  const handleVoteSuggestion = async (id: string, voteType: 'up' | 'down') => {
    sound.playClick();
    try {
      const res = await fetch(`/api/suggestions/${id}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ voteType })
      });
      const data = await res.json();
      if (Array.isArray(data?.suggestions)) {
        setSuggestions(data.suggestions);
      }
    } catch {
      // ignore
    }
  };

  const handleSuggestionDecision = async (
    id: string,
    status: 'implemented' | 'in_progress' | 'featured' | 'rejected'
  ) => {
    sound.playShieldActivate();
    try {
      const res = await fetch(`/api/suggestions/${id}/decision`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ status, guildId })
      });
      const data = await res.json();
      if (Array.isArray(data?.suggestions)) {
        setSuggestions(data.suggestions);
      }
      if (data?.message) showToast(data.message);
    } catch {
      // ignore
    }
  };

  const handlePushSuggestionToDiscord = async (id: string) => {
    sound.playShieldActivate();
    try {
      const res = await fetch(`/api/suggestions/${id}/push-discord`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ guildId, channelName: sugChannelName })
      });
      const data = await res.json();
      if (data?.success) {
        showToast(data.message || `📢 تم إرسال الاقتراح كإيمبد تصويت تفاعلي إلى روم #${sugChannelName}!`);
      } else {
        showToast(data?.error || 'تعذر الإرسال للديسكورد.', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء إرسال الاقتراح للديسكورد.', 'error');
    }
  };

  return (
    <div dir="rtl" className="space-y-8 select-none">
      {/* Toast Notification */}
      {toast && (
        <div
          className={`p-4 rounded-2xl border text-xs font-black flex items-center justify-between shadow-2xl ${
            toast.type === 'error'
              ? 'bg-rose-950/90 border-rose-500/50 text-rose-200'
              : 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{toast.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* ================= VIEW 1: 1-CLICK READY ROOMS & AI SERVER IDEA BUILDER ================= */}
      {view === 'ready_rooms' && (
        <div className="space-y-8">
          {/* Header Banner */}
          <div className="rounded-3xl bg-[#060913] border border-purple-500/35 p-6 sm:p-8 shadow-2xl space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1.5">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 text-xs font-black">
                  ⚡ حصرياً في M7R • مجاني 100% لجميع السيرفرات
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-white">
                  🏗️ الرومات الجاهزة ومصمم السيرفر الذكي (1-Click Ready Rooms & AI Builder)
                </h2>
                <p className="text-xs sm:text-sm text-slate-300">
                  اختر الرومات التي تريدها ليقوم البوت بإنشائها وربط أنظمتها تلقائياً في سيرفرك ({serverName})، أو اكتب فكرة سيرفرك ليصمم البوت الرومات وأسئلة التقديم المناسبة لك في ثانية!
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const allChecked: Record<string, boolean> = {};
                    READY_ROOM_BUNDLES.forEach((b) => {
                      allChecked[b.key] = true;
                    });
                    setSelectedRooms(allChecked);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
                >
                  تحديد الكل ✓
                </button>
                <button
                  type="button"
                  disabled={deployingAllRooms}
                  onClick={() => {
                    const keys = Object.keys(selectedRooms).filter((k) => selectedRooms[k]);
                    handleDeployReadyRooms(keys);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#2563EB] hover:from-[#6D28D9] hover:to-[#1D4ED8] text-white text-xs sm:text-sm font-black shadow-lg flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Rocket className="w-4 h-4" />
                  <span>
                    {deployingAllRooms
                      ? '⏳ جاري إنشاء الرومات ونشر اللوحات...'
                      : '🚀 إنشاء وتفعيل الرومات المحددة بضغطة زر'}
                  </span>
                </button>
              </div>
            </div>

            {createdRoomsLog.length > 0 && (
              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-2">
                <div className="text-xs font-black text-emerald-300">
                  ✅ الرومات التي تم إنشاؤها وربط أنظمتها بنجاح في سيرفرك:
                </div>
                <div className="flex flex-wrap gap-2">
                  {createdRoomsLog.map((ch, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-slate-950 border border-emerald-500/30 text-emerald-200 font-mono text-xs font-bold"
                    >
                      #{ch}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 1. 9 Ready Room Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {READY_ROOM_BUNDLES.map((bundle) => {
              const Icon = bundle.icon;
              const isSelected = Boolean(selectedRooms[bundle.key]);
              const isDeployingThis = deployingBundleKey === bundle.key;

              return (
                <div
                  key={bundle.key}
                  className={`rounded-2xl bg-[#060913]/95 border p-5 flex flex-col justify-between gap-4 transition-all ${
                    isSelected
                      ? 'border-purple-500/50 shadow-lg shadow-purple-950/25'
                      : 'border-slate-800/90 opacity-80'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <label className="flex items-center gap-2.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={(e) =>
                            setSelectedRooms((prev) => ({
                              ...prev,
                              [bundle.key]: e.target.checked
                            }))
                          }
                          className="w-4 h-4 accent-purple-600 rounded cursor-pointer"
                        />
                        <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                          <Icon className={`w-4 h-4 ${bundle.color}`} />
                        </div>
                      </label>
                      <span className="px-2.5 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-[10px] font-black text-slate-300">
                        {bundle.badge}
                      </span>
                    </div>

                    <h3 className="text-sm font-black text-white">{bundle.title}</h3>
                    <div className="text-[11px] font-mono text-purple-300 bg-slate-950/90 px-2.5 py-1 rounded-lg border border-slate-800/80 inline-block">
                      {bundle.channelsPreview}
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">{bundle.description}</p>
                  </div>

                  <button
                    type="button"
                    disabled={isDeployingThis}
                    onClick={() => handleDeployReadyRooms([bundle.key], bundle.key)}
                    className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-purple-600/25 border border-slate-700 hover:border-purple-500/50 text-xs font-black text-slate-200 hover:text-white flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                  >
                    <Wand2 className="w-3.5 h-3.5 text-purple-400" />
                    <span>
                      {isDeployingThis ? '⏳ جاري الإنشاء...' : '⚡ إنشاء وتفعيل هذا الروم الآن'}
                    </span>
                  </button>
                </div>
              );
            })}
          </div>

          {/* 2. AI Server Idea & Custom Application Generator */}
          <div className="rounded-3xl bg-[#060913] border border-indigo-500/40 p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="space-y-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-500/20 border border-purple-500/40 text-purple-300 text-xs font-black">
                🧠 الذكاء الاصطناعي لبناء السيرفر والتقديمات
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-white">
                🧠 صمم سيرفرك وتقديماتك حسب فكرة سيرفرك (AI Server Idea & Application Generator)
              </h3>
              <p className="text-xs sm:text-sm text-slate-300">
                اكتب فكرة سيرفرك أو اختر أحد القوالب السريعة بالأسفل، وسيقوم البوت بإنشاء الرومات والرتب المناسبة لفكرتك + توليد أفضل أسئلة التقديم ونشر لوحة التقديم في الديسكورد تلقائياً!
              </p>
            </div>

            {/* Quick Idea Preset Buttons */}
            <div className="flex flex-wrap gap-2">
              {SERVER_IDEA_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setServerIdeaInput(preset.ideaText);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-purple-600/25 border border-slate-700 hover:border-purple-500/50 text-xs font-black text-slate-200 hover:text-white cursor-pointer transition-all"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            {/* Idea Input Box */}
            <div className="space-y-3">
              <label className="block text-xs font-black text-slate-300">
                💡 اكتب فكرة سيرفرك هنا (مثال: سيرفر كلان ألعاب وبطولات، سيرفر مجتمع وسوالف، سيرفر رول بلاي، سيرفر تصميم وبرمجة، سيرفر متجر...):
              </label>
              <textarea
                rows={3}
                value={serverIdeaInput}
                onChange={(e) => setServerIdeaInput(e.target.value)}
                placeholder="اكتب فكرة سيرفرك بالتفصيل ليقوم الذكاء الاصطناعي ببناء الرومات وأسئلة التقديم..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-2xl p-4 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none"
              />
            </div>

            <button
              type="button"
              disabled={buildingIdea}
              onClick={handleBuildByServerIdea}
              className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-gradient-to-r from-[#7C3AED] via-[#4F46E5] to-[#10B981] hover:opacity-95 text-white text-xs sm:text-sm font-black shadow-xl flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>
                {buildingIdea
                  ? '⏳ جاري تصميم الرومات وتوليد أسئلة التقديم بالذكاء الاصطناعي...'
                  : '🚀 إنشاء الرومات وتجهيز التقديم حسب فكرة السيرفر'}
              </span>
            </button>

            {/* Generated Result Preview */}
            {ideaBuildResult && (
              <div className="p-5 rounded-2xl bg-[#0B1222] border border-emerald-500/40 space-y-4 animate-in fade-in">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div className="text-sm font-black text-emerald-300">
                    ✅ تم تجهيز سيرفرك وتحديث أسئلة التقديم تلقائياً حسب فكرة: ({ideaBuildResult.ideaTitle})
                  </div>
                  {onNavigateTab && (
                    <button
                      type="button"
                      onClick={() => onNavigateTab('staff_apps')}
                      className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>📋 معاينة الأسئلة في قسم التقديمات</span>
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
                    <div className="font-black text-purple-300">📁 الرومات والرتب التي تم تجهيزها:</div>
                    <div className="flex flex-wrap gap-1.5">
                      {ideaBuildResult.createdChannels.map((c, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded bg-purple-500/15 border border-purple-500/30 text-purple-200 font-mono"
                        >
                          #{c}
                        </span>
                      ))}
                      {ideaBuildResult.createdRoles.map((r, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-200 font-mono"
                        >
                          @{r}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
                    <div className="font-black text-emerald-300">
                      📋 أسئلة التقديم التي تم توليدها وحفظها في البوت:
                    </div>
                    <ol className="list-decimal list-inside space-y-1 text-slate-200">
                      {ideaBuildResult.generatedQuestions.map((q, idx) => (
                        <li key={idx}>{q}</li>
                      ))}
                    </ol>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= VIEW 2: INTERACTIVE SUGGESTIONS HUB (نظام الاقتراحات في الويب والديسكورد) ================= */}
      {view === 'suggestions' && (
        <div className="space-y-8">
          {/* Header */}
          <div className="rounded-3xl bg-[#060913] border border-sky-500/35 p-6 sm:p-8 shadow-2xl space-y-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-sky-500/15 border border-sky-500/35 text-sky-300 text-xs font-black">
              💡 نظام الاقتراحات التفاعلي المزدوج (الويب + الديسكورد)
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              💡 الاقتراحات وتطوير البوت والسيرفر (Interactive Suggestions Hub)
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              يمكن للأعضاء إرسال اقتراحاتهم عبر أمر <code className="text-sky-300 font-mono">/suggest</code> أو الكتابة مباشرة في روم <code className="text-sky-300 font-mono">#{sugChannelName}</code> أو من خلال هذه اللوحة، مع تصويت حي وقرار الإدارة الفوري!
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Submit an Idea Box */}
            <div className="lg:col-span-5 rounded-3xl bg-[#060913] border border-slate-800 p-6 space-y-4 h-fit">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-400" />
                <span>شاركنا فكرتك أو اقتراحك نطبقه فوراً</span>
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">اسمك أو لقبك (اختياري):</label>
                  <input
                    type="text"
                    value={sugAuthorName}
                    onChange={(e) => setSugAuthorName(e.target.value)}
                    placeholder="مثال: فيصل العتيبي"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-bold mb-1">تصنيف الفكرة:</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(['فكرة للسيرفر', 'فكرة للبوت', 'لعبة جديدة', 'أمر جديد'] as const).map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setSugCategory(cat)}
                        className={`py-2 px-3 rounded-xl font-black text-xs border cursor-pointer transition-all ${
                          sugCategory === cat
                            ? 'bg-purple-600/30 border-purple-500 text-white'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 font-bold mb-1">تفاصيل الفكرة أو الاقتراح:</label>
                  <textarea
                    rows={4}
                    value={sugContent}
                    onChange={(e) => setSugContent(e.target.value)}
                    placeholder="اكتب فكرتك هنا بوضوح ليصوت عليها الأعضاء وتعتمدها الإدارة..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">روم الاقتراحات في ديسكورد:</label>
                    <input
                      type="text"
                      value={sugChannelName}
                      onChange={(e) => setSugChannelName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                    />
                  </div>
                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 cursor-pointer self-end">
                    <input
                      type="checkbox"
                      checked={sugSendToDiscord}
                      onChange={(e) => setSugSendToDiscord(e.target.checked)}
                      className="accent-purple-600 w-4 h-4"
                    />
                    <span className="font-bold text-slate-200">نشر في ديسكورد تلقائياً</span>
                  </label>
                </div>

                <button
                  type="button"
                  disabled={submittingSug}
                  onClick={handleSubmitSuggestion}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#7C3AED] to-[#2563EB] hover:opacity-95 text-white font-black text-xs sm:text-sm shadow-lg flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{submittingSug ? '⏳ جاري نشر الفكرة...' : '🚀 إرسال الفكرة للتصويت الآن'}</span>
                </button>
              </div>
            </div>

            {/* Live Community Suggestions Board */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-white">
                  📊 لوحة أفكار واقتراحات المجتمع الحية ({suggestions.length})
                </h3>
              </div>

              <div className="space-y-3.5">
                {suggestions.map((sug) => {
                  const totalVotes = Math.max(1, sug.upvotes + sug.downvotes);
                  const approvalPct = Math.round((sug.upvotes / totalVotes) * 100);
                  const filledBars = Math.round(approvalPct / 10);
                  const barStr = '▓'.repeat(filledBars) + '░'.repeat(10 - filledBars);

                  const statusStyle =
                    sug.status === 'implemented'
                      ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                      : sug.status === 'featured'
                      ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                      : sug.status === 'rejected'
                      ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                      : 'bg-sky-500/20 border-sky-500/40 text-sky-300';

                  return (
                    <div
                      key={sug.id}
                      className="rounded-2xl bg-[#060913]/95 border border-slate-800 hover:border-purple-500/40 p-5 space-y-3.5 shadow-xl transition-all"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-9 rounded-xl bg-purple-600/25 border border-purple-500/40 flex items-center justify-center text-xs font-black text-purple-200">
                            {sug.authorName.slice(0, 2)}
                          </div>
                          <div>
                            <div className="text-xs font-black text-white flex items-center gap-2">
                              <span>{sug.authorName}</span>
                              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-[10px] text-purple-300">
                                {sug.category}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400">{sug.createdAt}</div>
                          </div>
                        </div>

                        <span className={`px-2.5 py-1 rounded-lg border text-[11px] font-black ${statusStyle}`}>
                          {sug.statusLabel}
                        </span>
                      </div>

                      <p className="text-xs sm:text-sm text-slate-200 leading-relaxed bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80">
                        {sug.content}
                      </p>

                      {/* Live Approval Bar */}
                      <div className="flex items-center justify-between text-xs font-mono bg-slate-950 px-3.5 py-2 rounded-xl border border-slate-800">
                        <span className="text-sky-400">
                          {barStr} {approvalPct}%
                        </span>
                        <span className="text-slate-400 text-[11px]">
                          👍 {sug.upvotes} | 👎 {sug.downvotes}
                        </span>
                      </div>

                      {/* Vote & Admin Action Buttons */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleVoteSuggestion(sug.id, 'up')}
                            className="px-3.5 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/35 border border-emerald-500/40 text-emerald-300 text-xs font-black flex items-center gap-1.5 cursor-pointer"
                          >
                            <ThumbsUp className="w-3.5 h-3.5" />
                            <span>🔥 صوّت للفكرة (+1) ({sug.upvotes})</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleVoteSuggestion(sug.id, 'down')}
                            className="px-3 py-1.5 rounded-xl bg-rose-600/15 hover:bg-rose-600/30 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <ThumbsDown className="w-3.5 h-3.5" />
                            <span>({sug.downvotes})</span>
                          </button>
                        </div>

                        <div className="flex flex-wrap items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleSuggestionDecision(sug.id, 'implemented')}
                            className="px-2.5 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/30 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold cursor-pointer"
                          >
                            🟢 تم التنفيذ
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSuggestionDecision(sug.id, 'featured')}
                            className="px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/30 border border-amber-500/30 text-amber-300 text-[11px] font-bold cursor-pointer"
                          >
                            ⭐ فكرة مميزة
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSuggestionDecision(sug.id, 'rejected')}
                            className="px-2.5 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 border border-rose-500/30 text-rose-300 text-[11px] font-bold cursor-pointer"
                          >
                            ❌ رفض
                          </button>
                          <button
                            type="button"
                            onClick={() => handlePushSuggestionToDiscord(sug.id)}
                            className="px-2.5 py-1 rounded-lg bg-purple-600/25 hover:bg-purple-600/40 border border-purple-500/40 text-purple-200 text-[11px] font-bold cursor-pointer"
                          >
                            📢 إرسال للديسكورد
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
