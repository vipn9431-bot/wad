import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Flame,
  Link2,
  Lock,
  Save,
  Check,
  Plus,
  Trash2,
  Radio,
  Send,
  Skull,
  UserCheck,
  ShieldCheck,
  Zap,
  Eye,
  BellRing,
  BellOff,
  Clock,
  Sliders,
  KeyRound,
  RefreshCw,
  Sparkles,
  DollarSign,
  Smartphone,
  MessageSquare
} from 'lucide-react';
import {
  AntiNukeConfig,
  AntiSpamConfig,
  AntiInviteConfig,
  HoneypotTrapConfig,
  ThreatLog,
  AdminImportanceTier,
  AdminRoleRateLimitPolicy,
  AdminCommandRateLimitConfig
} from '../types';
import { ChannelSelector } from './ChannelSelector';
import { getAuthHeaders } from './TokenAuthGate';
import { sound } from '../utils/sound';
import {
  BrowserPushPermissionState,
  getBrowserPushPermission,
  isAntiNukePushEnabled,
  requestAntiNukePushPermission,
  setAntiNukePushEnabled,
  subscribePushStateChange
} from '../utils/browserNotifications';

interface AntiNukeTabProps {
  lang: 'ar' | 'en';
  antiNuke: AntiNukeConfig;
  setAntiNuke: React.Dispatch<React.SetStateAction<AntiNukeConfig>>;
  antiSpam: AntiSpamConfig;
  setAntiSpam: React.Dispatch<React.SetStateAction<AntiSpamConfig>>;
  antiInvite: AntiInviteConfig;
  setAntiInvite: React.Dispatch<React.SetStateAction<AntiInviteConfig>>;
  honeypotTrap: HoneypotTrapConfig;
  setHoneypotTrap: React.Dispatch<React.SetStateAction<HoneypotTrapConfig>>;
  onSaveSettings: () => void;
  guildRoles?: { id: string; name: string; color?: string }[];
  onTestThreatSimulated?: (log: ThreatLog) => void;
}

interface ProtectionRuleCardState {
  id: number;
  title: string;
  description: string;
  enabled: boolean;
  punishment: 'ban' | 'kick' | 'strip_roles' | 'timeout_24h';
  hasLimit?: boolean;
  limitValue?: number;
}

const INITIAL_10_GUARD_CARDS: ProtectionRuleCardState[] = [
  {
    id: 1,
    title: '1. حماية حذف القنوات والرتب السريع',
    description: 'رصد من يحذف الرومات أو الأقسام بشكل متكرر ومعاقبته واسترجاع ما حذفه',
    enabled: true,
    punishment: 'ban',
    hasLimit: true,
    limitValue: 1
  },
  {
    id: 2,
    title: '2. حماية إنشاء الرومات بكثافة',
    description: 'منع إغراق السيرفر برومات جديدة؛ يتم حذف الرومات المزعجة ومعاقبة المنفذ',
    enabled: true,
    punishment: 'ban',
    hasLimit: true,
    limitValue: 3
  },
  {
    id: 3,
    title: '3. حماية حذف وتعديل الرتب',
    description: 'رصد من يحذف الرتب ومعاقبته وإعادة الرتب بنفس الصلاحيات والأعضاء',
    enabled: true,
    punishment: 'ban',
    hasLimit: true,
    limitValue: 1
  },
  {
    id: 4,
    title: '4. حماية إنشاء الرتب بكثافة',
    description: 'منع إغراق السيرفر برتب جديدة؛ يتم حذف الرتب المزعجة ومعاقبة المنفذ',
    enabled: true,
    punishment: 'ban',
    hasLimit: true,
    limitValue: 3
  },
  {
    id: 5,
    title: '5. حماية الصلاحيات الخطيرة',
    description: 'منع منح صلاحيات مثل Administrator أو Ban أو Manage Roles لرتبة أو لعضو؛ يتم سحبها فوراً ومعاقبة المنفذ',
    enabled: true,
    punishment: 'ban',
    hasLimit: false
  },
  {
    id: 6,
    title: '6. حماية دخول البوتات العشوائية',
    description: 'أي بوت يضيفه شخص غير موثوق يُطرد فوراً. أضف البوتات المسموح بها إلى القائمة البيضاء للسماح بها مسبقاً',
    enabled: true,
    punishment: 'ban',
    hasLimit: false
  },
  {
    id: 7,
    title: '7. حماية طرد البوتات الموثوقة',
    description: 'معاقبة من يطرد أو يحظر أي بوت من السيرفر (مع فك الحظر عند تفعيل الاسترجاع)',
    enabled: true,
    punishment: 'ban',
    hasLimit: false
  },
  {
    id: 8,
    title: '8. حماية الطرد والحظر الجماعي للأعضاء (Anti-Nuke)',
    description: 'يشمل الطرد والحظر معاً؛ عند التجاوز يُعاقب المنفذ ويُفك حظر من حظرهم',
    enabled: true,
    punishment: 'ban',
    hasLimit: true,
    limitValue: 2
  },
  {
    id: 9,
    title: '9. حماية الـ Webhooks',
    description: 'الـ Webhooks تُستخدم كثيراً في هجمات السبام؛ أي Webhook ينشئه شخص غير موثوق يتجاوز الحد يُحذف فوراً',
    enabled: true,
    punishment: 'ban',
    hasLimit: true,
    limitValue: 1
  },
  {
    id: 10,
    title: '10. حماية تعديل إعدادات وهوية السيرفر',
    description: 'منع تغيير اسم وصورة وإعدادات السيرفر؛ يتم إرجاع التعديل ومعاقبة المنفذ',
    enabled: true,
    punishment: 'ban',
    hasLimit: false
  }
];

const INITIAL_BANNED_WORDS_SAMPLE: string[] = [
  'سبام_روابط',
  'تهكير_حسابات',
  'نيترو_مزيف',
  'free_nitro_scam',
  'discord.gg/raid',
  'شتيمة_1',
  'شتيمة_2',
  'سب_الإدارة',
  'تخريب_السيرفر',
  'سيلف_بوت',
  'token_grabber',
  'hack_tool',
  'قذف_وتشهير',
  'إعلان_مخالف',
  'نشر_سيرفرات',
  'باند_جماعي'
];

export const AntiNukeTab: React.FC<AntiNukeTabProps> = ({
  lang,
  antiNuke,
  setAntiNuke,
  antiSpam,
  setAntiSpam,
  antiInvite,
  setAntiInvite,
  honeypotTrap,
  setHoneypotTrap,
  onSaveSettings,
  guildRoles = [],
  onTestThreatSimulated
}) => {
  const isAr = lang === 'ar';
  const [pushPermission, setPushPermission] = useState<BrowserPushPermissionState>(() =>
    getBrowserPushPermission()
  );
  const [pushEnabled, setPushEnabled] = useState<boolean>(() => isAntiNukePushEnabled());
  const [testingPushAlert, setTestingPushAlert] = useState(false);
  const [pushFeedback, setPushFeedback] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'suite16' | 'trap'>('suite16');
  const [newWhitelistId, setNewWhitelistId] = useState('');
  const [newTrapWhitelistUser, setNewTrapWhitelistUser] = useState('');
  const [newTrapWhitelistRole, setNewTrapWhitelistRole] = useState('');
  const [serverRolesList, setServerRolesList] = useState<{ id: string; name: string }[]>(guildRoles);

  // 16-Card Suite State
  const [guardCards, setGuardCards] = useState<ProtectionRuleCardState[]>(INITIAL_10_GUARD_CARDS);
  const [exemptRoleIds, setExemptRoleIds] = useState<string[]>(
    antiNuke.exemptRoleId ? [antiNuke.exemptRoleId] : []
  );
  const [muteRoleName, setMuteRoleName] = useState('كتم (تلقائي)');
  const [prisonRoleName, setPrisonRoleName] = useState('سجن (تلقائي)');

  // Card 13: Banned Words Filter (558 words)
  const [bannedWordsEnabled, setBannedWordsEnabled] = useState(true);
  const [bannedWordsPunishment, setBannedWordsPunishment] = useState<'ban' | 'mute' | 'delete'>('ban');
  const [bannedWordsBanDurationSec, setBannedWordsBanDurationSec] = useState(2592000);
  const [bannedWordsTotalCount, setBannedWordsTotalCount] = useState(558);
  const [bannedWordsTags, setBannedWordsTags] = useState<string[]>(INITIAL_BANNED_WORDS_SAMPLE);
  const [newBannedWordInput, setNewBannedWordInput] = useState('');
  const [revealedWordIndex, setRevealedWordIndex] = useState<number | null>(null);

  // Card 14: Anti-Spam & Fast Messaging
  const [spamCardEnabled, setSpamCardEnabled] = useState(true);
  const [spamMaxMsgs, setSpamMaxMsgs] = useState(antiSpam.maxMessages || 5);
  const [spamWindowSec, setSpamWindowSec] = useState(antiSpam.windowSeconds || 5);
  const [spamPunishmentType, setSpamPunishmentType] = useState<'mute' | 'kick' | 'ban'>('mute');
  const [spamMuteDurationSec, setSpamMuteDurationSec] = useState(60);

  // Card 15: External Links Blocker + 2 Sub-Cards
  const [linksFilterEnabled, setLinksFilterEnabled] = useState(true);
  const [discordInvitesOnly, setDiscordInvitesOnly] = useState(antiInvite.blockDiscordInvites !== false);
  const [skipGifLinks, setSkipGifLinks] = useState(true);
  const [linksPunishment, setLinksPunishment] = useState<'mute' | 'delete' | 'ban'>('mute');
  const [linksMuteDurationSec, setLinksMuteDurationSec] = useState(300);

  // Card 16: Mention & Emoji Flood
  const [mentionProtectionEnabled, setMentionProtectionEnabled] = useState(true);
  const [maxMentionsAllowed, setMaxMentionsAllowed] = useState(antiSpam.maxMentions || 5);
  const [mentionPunishment, setMentionPunishment] = useState<'delete' | 'mute'>('mute');
  const [emojiProtectionEnabled, setEmojiProtectionEnabled] = useState(antiSpam.blockEmojiFlood !== false);
  const [maxEmojisAllowed, setMaxEmojisAllowed] = useState(10);
  const [emojiPunishment, setEmojiPunishment] = useState<'delete' | 'mute'>('delete');

  // Deploy & Test Trap state
  const [deployingTrap, setDeployingTrap] = useState(false);
  const [deployTrapResult, setDeployTrapResult] = useState<string | null>(null);
  const [testingTrap, setTestingTrap] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Per-Role Admin Command Rate Limiting State
  const defaultRoleRateLimits: AdminCommandRateLimitConfig = {
    enabled: true,
    defaultCommandsPerMinute: 12,
    notifyUserOnLimit: true,
    logChannelAlert: true,
    policies: [
      {
        id: 'rl-tier-deputy',
        roleId: '',
        roleName: 'Co-Owner / نائب الأونر',
        importanceTier: 'owner_deputy',
        commandsPerMinute: 45,
        actionOnExceed: 'block_warn',
        enabled: true
      },
      {
        id: 'rl-tier-head',
        roleId: '',
        roleName: 'Head Admin / الإدارة العليا',
        importanceTier: 'head_admin',
        commandsPerMinute: 25,
        actionOnExceed: 'block_warn',
        enabled: true
      },
      {
        id: 'rl-tier-mod',
        roleId: '',
        roleName: 'Moderator / المشرفون',
        importanceTier: 'moderator',
        commandsPerMinute: 12,
        actionOnExceed: 'timeout_5m',
        enabled: true
      },
      {
        id: 'rl-tier-helper',
        roleId: '',
        roleName: 'Helper / الدعم والمساعدون',
        importanceTier: 'helper',
        commandsPerMinute: 6,
        actionOnExceed: 'timeout_5m',
        enabled: true
      }
    ]
  };

  const roleRateLimits: AdminCommandRateLimitConfig = antiNuke.adminRoleRateLimits || defaultRoleRateLimits;
  const [rateLimitEvents, setRateLimitEvents] = useState<
    {
      id: string;
      userId: string;
      username: string;
      roleName: string;
      commandName: string;
      countInMinute: number;
      limitPerMinute: number;
      actionTaken: string;
      timestamp: string;
    }[]
  >([]);
  const [savingRoleLimits, setSavingRoleLimits] = useState(false);
  const [roleLimitsFeedback, setRoleLimitsFeedback] = useState<string | null>(null);

  // 20-Point Security Audit, Admin 2FA (TOTP + Discord DM) & AI Spending Cap State
  const [auditReport, setAuditReport] = useState<any>(null);
  const [runningAudit, setRunningAudit] = useState(false);
  const [twoFaStatus, setTwoFaStatus] = useState<any>(null);
  const [totpEnrollData, setTotpEnrollData] = useState<{ secret?: string; otpauthUrl?: string } | null>(null);
  const [twoFaCodeInput, setTwoFaCodeInput] = useState('');
  const [twoFaFeedback, setTwoFaFeedback] = useState<string | null>(null);
  const [spendingCap, setSpendingCap] = useState<{
    enabled: boolean;
    dailySpendCapUsd: number;
    monthlySpendCapUsd: number;
    dailyRequestLimit: number;
    dailySpendUsd: number;
    dailyRequestsUsed: number;
    blockedByCapCount: number;
  }>({
    enabled: true,
    dailySpendCapUsd: 2.0,
    monthlySpendCapUsd: 25.0,
    dailyRequestLimit: 250,
    dailySpendUsd: 0,
    dailyRequestsUsed: 0,
    blockedByCapCount: 0
  });
  const [savingCap, setSavingCap] = useState(false);
  const [capFeedback, setCapFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (Array.isArray(guildRoles) && guildRoles.length > 0) {
      setServerRolesList(guildRoles);
    }
  }, [guildRoles]);

  useEffect(() => {
    const loadRoles = async () => {
      try {
        let selectedGuildId = 'default';
        const rawG = localStorage.getItem('m7r_selected_guild');
        if (rawG) {
          const parsed = JSON.parse(rawG);
          if (parsed?.id) selectedGuildId = parsed.id;
        }
        const res = await fetch(`/api/guilds/${encodeURIComponent(selectedGuildId)}/details`, {
          headers: getAuthHeaders()
        });
        const data = await res.json();
        if (Array.isArray(data?.roles) && data.roles.length > 0) {
          setServerRolesList(data.roles);
        }
      } catch {
        // ignore
      }
    };
    loadRoles();

    const loadSecurityAndRateLimits = async () => {
      try {
        const [rlRes, auditRes, twoFaRes, capRes] = await Promise.all([
          fetch('/api/protection/role-rate-limits', { headers: getAuthHeaders() }).catch(() => null),
          fetch('/api/security/audit', { headers: getAuthHeaders() }).catch(() => null),
          fetch('/api/security/2fa/status', { headers: getAuthHeaders() }).catch(() => null),
          fetch('/api/security/spending-cap', { headers: getAuthHeaders() }).catch(() => null)
        ]);
        if (rlRes && rlRes.ok) {
          const rlData = await rlRes.json();
          if (rlData?.config) {
            setAntiNuke((prev) => ({ ...prev, adminRoleRateLimits: rlData.config }));
          }
          if (Array.isArray(rlData?.recentEvents)) {
            setRateLimitEvents(rlData.recentEvents);
          }
        }
        if (auditRes && auditRes.ok) {
          const aData = await auditRes.json();
          if (aData?.items) setAuditReport(aData);
        }
        if (twoFaRes && twoFaRes.ok) {
          const tData = await twoFaRes.json();
          if (tData?.twoFactor) setTwoFaStatus(tData.twoFactor);
        }
        if (capRes && capRes.ok) {
          const cData = await capRes.json();
          if (cData?.spendingCap) setSpendingCap(cData.spendingCap);
        }
      } catch {
        // ignore
      }
    };
    loadSecurityAndRateLimits();
  }, []);

  useEffect(() => {
    const syncPushState = () => {
      setPushPermission(getBrowserPushPermission());
      setPushEnabled(isAntiNukePushEnabled());
    };
    syncPushState();
    const unsub = subscribePushStateChange(syncPushState);
    window.addEventListener('focus', syncPushState);
    return () => {
      unsub();
      window.removeEventListener('focus', syncPushState);
    };
  }, []);

  const handleToggleBrowserPush = async () => {
    sound.playClick();
    if (pushEnabled) {
      setAntiNukePushEnabled(false);
      setPushEnabled(false);
      setPushFeedback(
        isAr
          ? 'تم إيقاف إشعارات المتصفح مؤقتاً — يمكنك إعادة تفعيلها في أي وقت.'
          : 'Browser push alerts paused.'
      );
      setTimeout(() => setPushFeedback(null), 4000);
      return;
    }

    const result = await requestAntiNukePushPermission();
    setPushPermission(result.permission);
    setPushEnabled(result.enabled);
    if (result.enabled) {
      sound.playShieldActivate();
      setPushFeedback(
        isAr
          ? 'تم تفعيل إشعارات المتصفح الفورية لنظام Anti-Nuke! سيصلك تنبيه فور رصد أي تهديد.'
          : 'Anti-Nuke browser push notifications enabled.'
      );
    } else if (result.permission === 'denied') {
      setPushFeedback(
        isAr
          ? 'المتصفح يحظر الإشعارات حالياً — افتح أيقونة القفل بجانب رابط الموقع واسمح بالإشعارات (Allow).'
          : 'Notifications are blocked in your browser site settings.'
      );
    } else if (result.permission === 'unsupported') {
      setPushFeedback(
        isAr ? 'هذا المتصفح لا يدعم إشعارات الويب.' : 'Browser notifications are not supported here.'
      );
    }
    setTimeout(() => setPushFeedback(null), 5000);
  };

  const handleSendTestThreatPush = async () => {
    setTestingPushAlert(true);
    sound.playAlarm();
    try {
      if (!pushEnabled) {
        const perm = await requestAntiNukePushPermission();
        setPushPermission(perm.permission);
        setPushEnabled(perm.enabled);
      }
      const res = await fetch('/api/threats/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ type: 'nuke', sendToDiscord: false })
      });
      const data = await res.json().catch(() => null);
      if (data?.log && onTestThreatSimulated) {
        onTestThreatSimulated(data.log);
      }
      setPushFeedback(
        isAr
          ? 'تم إرسال تهديد تجريبي في نظام Anti-Nuke وتحديث السجل الفوري.'
          : 'Simulated Anti-Nuke threat dispatched.'
      );
      setTimeout(() => setPushFeedback(null), 4500);
    } catch {
      setPushFeedback(
        isAr ? 'تعذر إرسال التنبيه التجريبي حالياً.' : 'Failed to trigger simulated threat.'
      );
      setTimeout(() => setPushFeedback(null), 4000);
    } finally {
      setTestingPushAlert(false);
    }
  };

  const handleSave = async () => {
    sound.playShieldActivate();
    onSaveSettings();
    try {
      await fetch('/api/protection/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          exemptRoleId: exemptRoleIds[0] || antiNuke.exemptRoleId || '',
          exemptRoleIds,
          punishmentAction: antiNuke.punishmentAction || antiNuke.massBanAction || 'ban',
          massMessageDeleteLimit: antiNuke.massMessageDeleteLimit || 5,
          liveMessageDeleteMonitor: antiNuke.liveMessageDeleteMonitor !== false,
          antiDeleteChatNotice: Boolean(antiNuke.antiDeleteChatNotice),
          guardCards,
          muteRoleName,
          prisonRoleName,
          bannedWordsConfig: {
            enabled: bannedWordsEnabled,
            punishment: bannedWordsPunishment,
            banDurationSec: bannedWordsBanDurationSec,
            words: bannedWordsTags
          },
          antiNuke
        })
      });
    } catch {}
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  // Per-Role Rate Limit Handlers
  const updateRoleRateLimits = (updater: (prev: AdminCommandRateLimitConfig) => AdminCommandRateLimitConfig) => {
    setAntiNuke((prev) => ({
      ...prev,
      adminRoleRateLimits: updater(prev.adminRoleRateLimits || defaultRoleRateLimits)
    }));
  };

  const getImportanceDefaults = (tier: AdminImportanceTier): { commandsPerMinute: number; actionOnExceed: AdminRoleRateLimitPolicy['actionOnExceed'] } => {
    if (tier === 'owner_deputy') return { commandsPerMinute: 45, actionOnExceed: 'block_warn' };
    if (tier === 'head_admin') return { commandsPerMinute: 25, actionOnExceed: 'block_warn' };
    if (tier === 'moderator') return { commandsPerMinute: 12, actionOnExceed: 'timeout_5m' };
    if (tier === 'helper') return { commandsPerMinute: 6, actionOnExceed: 'timeout_5m' };
    return { commandsPerMinute: 15, actionOnExceed: 'block_warn' };
  };

  const handleAddRoleRatePolicy = () => {
    sound.playClick();
    const newPolicy: AdminRoleRateLimitPolicy = {
      id: `rl-policy-${Date.now()}`,
      roleId: '',
      roleName: 'رتبة إدارية جديدة',
      importanceTier: 'moderator',
      commandsPerMinute: 12,
      actionOnExceed: 'block_warn',
      enabled: true
    };
    updateRoleRateLimits((prev) => ({
      ...prev,
      policies: [...prev.policies, newPolicy]
    }));
  };

  const handleAutoPopulateRolePolicies = () => {
    sound.playShieldActivate();
    if (!serverRolesList.length) {
      setRoleLimitsFeedback('لم يتم العثور على رتب من السيرفر حالياً — يمكنك إضافة السياسات يدوياً.');
      setTimeout(() => setRoleLimitsFeedback(null), 4000);
      return;
    }
    const adminCandidateRoles = serverRolesList.filter((r) => r.name !== '@everyone').slice(0, 6);
    const total = adminCandidateRoles.length;
    const generated: AdminRoleRateLimitPolicy[] = adminCandidateRoles.map((role, index) => {
      const ratio = total > 1 ? index / (total - 1) : 0;
      let tier: AdminImportanceTier = 'moderator';
      if (ratio <= 0.2) tier = 'owner_deputy';
      else if (ratio <= 0.45) tier = 'head_admin';
      else if (ratio <= 0.75) tier = 'moderator';
      else tier = 'helper';
      const preset = getImportanceDefaults(tier);
      return {
        id: `rl-auto-${role.id}`,
        roleId: role.id,
        roleName: role.name,
        importanceTier: tier,
        commandsPerMinute: preset.commandsPerMinute,
        actionOnExceed: preset.actionOnExceed,
        enabled: true
      };
    });
    updateRoleRateLimits((prev) => ({ ...prev, enabled: true, policies: generated }));
    setRoleLimitsFeedback(`تم استيراد وتوزيع ${generated.length} رتب من السيرفر تلقائياً حسب الترتيب والرتبة!`);
    setTimeout(() => setRoleLimitsFeedback(null), 4500);
  };

  const handleSaveRoleRateLimits = async () => {
    setSavingRoleLimits(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/protection/role-rate-limits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ adminRoleRateLimits: roleRateLimits })
      });
      const data = await res.json();
      if (data?.config) {
        setAntiNuke((prev) => ({ ...prev, adminRoleRateLimits: data.config }));
      }
      if (Array.isArray(data?.recentEvents)) {
        setRateLimitEvents(data.recentEvents);
      }
      setRoleLimitsFeedback(data?.message || 'تم حفظ وتفعيل سياسات Rate Limiting للرتب الإدارية!');
    } catch {
      setRoleLimitsFeedback('تعذر حفظ السياسات، تحقق من اتصال الخادم.');
    } finally {
      setSavingRoleLimits(false);
      setTimeout(() => setRoleLimitsFeedback(null), 4500);
    }
  };

  const handleRunSecurityAudit = async () => {
    setRunningAudit(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/security/audit/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() }
      });
      const data = await res.json();
      if (data?.items) setAuditReport(data);
    } catch {
      // ignore
    } finally {
      setRunningAudit(false);
    }
  };

  const handleEnrollTotp = async () => {
    sound.playClick();
    try {
      const res = await fetch('/api/security/2fa/enroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() }
      });
      const data = await res.json();
      setTotpEnrollData({ secret: data.secret, otpauthUrl: data.otpauthUrl });
      if (data.twoFactor) setTwoFaStatus(data.twoFactor);
      setTwoFaFeedback('تم توليد مفتاح Google Authenticator — أضفه في تطبيق المصادقة ثم أدخل الرمز للتحقق.');
    } catch {
      setTwoFaFeedback('تعذر توليد مفتاح Google Authenticator.');
    }
  };

  const handleSendDiscordDmOtp = async () => {
    sound.playClick();
    try {
      const res = await fetch('/api/security/2fa/send-dm-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() }
      });
      const data = await res.json();
      setTwoFaFeedback(data.message || 'تم إرسال رمز التحقق إلى خاصك في ديسكورد.');
    } catch {
      setTwoFaFeedback('تعذر إرسال رمز التحقق لخاص الديسكورد.');
    }
  };

  const handleVerify2faCode = async () => {
    if (!twoFaCodeInput.trim()) return;
    sound.playClick();
    try {
      const res = await fetch('/api/security/2fa/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ code: twoFaCodeInput.trim() })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        sound.playShieldActivate();
        if (data.twoFactor) setTwoFaStatus(data.twoFactor);
        setTwoFaCodeInput('');
        setTwoFaFeedback(data.message || 'تم تفعيل والتحقق من 2FA بنجاح!');
      } else {
        setTwoFaFeedback(data.error || 'الرمز غير صحيح، تأكد من تطبيق المصادقة أو رسالة الديسكورد.');
      }
    } catch {
      setTwoFaFeedback('تعذر التحقق من الرمز.');
    }
  };

  const handleSaveSpendingCap = async () => {
    setSavingCap(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/security/spending-cap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          enabled: spendingCap.enabled,
          dailySpendCapUsd: Number(spendingCap.dailySpendCapUsd) || 2,
          monthlySpendCapUsd: Number(spendingCap.monthlySpendCapUsd) || 25,
          dailyRequestLimit: Number(spendingCap.dailyRequestLimit) || 250
        })
      });
      const data = await res.json();
      if (data?.spendingCap) setSpendingCap(data.spendingCap);
      setCapFeedback(data?.message || 'تم حفظ سقف الإنفاق اليومي بنجاح!');
    } catch {
      setCapFeedback('تعذر حفظ إعدادات سقف الإنفاق.');
    } finally {
      setSavingCap(false);
      setTimeout(() => setCapFeedback(null), 4000);
    }
  };

  const addWhitelistUser = () => {
    if (!newWhitelistId.trim()) return;
    if (!antiNuke.whitelistUserIds.includes(newWhitelistId.trim())) {
      setAntiNuke((prev) => ({
        ...prev,
        whitelistUserIds: [...prev.whitelistUserIds, newWhitelistId.trim()]
      }));
    }
    setNewWhitelistId('');
    sound.playClick();
  };

  const removeWhitelistUser = (id: string) => {
    setAntiNuke((prev) => ({
      ...prev,
      whitelistUserIds: prev.whitelistUserIds.filter((item) => item !== id)
    }));
    sound.playClick();
  };

  const handleAddBannedWord = () => {
    const clean = newBannedWordInput.trim();
    if (!clean) return;
    sound.playClick();
    if (!bannedWordsTags.includes(clean)) {
      setBannedWordsTags((prev) => [clean, ...prev]);
      setBannedWordsTotalCount((c) => c + 1);
    }
    setNewBannedWordInput('');
  };

  const handleRemoveBannedWord = (word: string) => {
    sound.playClick();
    setBannedWordsTags((prev) => prev.filter((w) => w !== word));
    setBannedWordsTotalCount((c) => Math.max(0, c - 1));
  };

  const handleDeployTrapChannel = async () => {
    setDeployingTrap(true);
    setDeployTrapResult(null);
    sound.playShieldActivate();

    try {
      const res = await fetch('/api/trap/deploy-channel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          channelName: honeypotTrap.channelName,
          warningMessage: honeypotTrap.customWarningMessage
        })
      });
      const data = await res.json();
      setDeployTrapResult(data.message || 'تم إنشاء ونشر روم المصيدة في ديسكورد!');
      setTimeout(() => setDeployTrapResult(null), 6000);
    } catch {
      setDeployTrapResult('تعذر النشر، تأكد من اتصال البوت.');
      setTimeout(() => setDeployTrapResult(null), 5000);
    } finally {
      setDeployingTrap(false);
    }
  };

  const handleTestTrap = async () => {
    setTestingTrap(true);
    sound.playAlarm();

    try {
      const res = await fetch('/api/trap/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (data.totalTrapped !== undefined) {
        setHoneypotTrap((prev) => ({ ...prev, totalTrapped: data.totalTrapped }));
      }
      setDeployTrapResult('🚨 تم اختبار المصيدة وإرسال إنذار فوري إلى #log-server!');
      setTimeout(() => setDeployTrapResult(null), 5000);
    } catch {
      // ignore
    } finally {
      setTestingTrap(false);
    }
  };

  const addTrapUser = () => {
    if (!newTrapWhitelistUser.trim()) return;
    if (!honeypotTrap.whitelistUserIds.includes(newTrapWhitelistUser.trim())) {
      setHoneypotTrap((prev) => ({
        ...prev,
        whitelistUserIds: [...prev.whitelistUserIds, newTrapWhitelistUser.trim()]
      }));
    }
    setNewTrapWhitelistUser('');
    sound.playClick();
  };

  const removeTrapUser = (id: string) => {
    setHoneypotTrap((prev) => ({
      ...prev,
      whitelistUserIds: prev.whitelistUserIds.filter((u) => u !== id)
    }));
    sound.playClick();
  };

  const addTrapRole = () => {
    if (!newTrapWhitelistRole.trim()) return;
    if (!honeypotTrap.whitelistRoleNames.includes(newTrapWhitelistRole.trim())) {
      setHoneypotTrap((prev) => ({
        ...prev,
        whitelistRoleNames: [...prev.whitelistRoleNames, newTrapWhitelistRole.trim()]
      }));
    }
    setNewTrapWhitelistRole('');
    sound.playClick();
  };

  const removeTrapRole = (role: string) => {
    setHoneypotTrap((prev) => ({
      ...prev,
      whitelistRoleNames: prev.whitelistRoleNames.filter((r) => r !== role)
    }));
    sound.playClick();
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Save Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <ShieldAlert className="w-6 h-6 text-rose-500" />
            <h2 className="text-xl sm:text-2xl font-black text-white">
              🛡️ درع الحماية الشامل ومكافحة التخريب والسبام (M7R Shield — 16 بطاقة حماية)
            </h2>
            <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs font-black">
              مجاني 100% بالكامل 🔓
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            جميع أنظمة الحماية الـ 16 ضد التخريب والنوك والسبام و558 كلمة محظورة واسترجاع المحذوفات تعمل على مدار الساعة المستمر.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setActiveSubTab(activeSubTab === 'suite16' ? 'trap' : 'suite16');
            }}
            className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-amber-300 text-xs font-black cursor-pointer transition-all"
          >
            {activeSubTab === 'suite16' ? '🪤 فتح مصيدة السيلف بوت (Honeypot)' : '🛡️ العودة لبطاقات الحماية الـ 16'}
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] hover:opacity-95 text-white text-xs font-black rounded-xl flex items-center gap-2 transition-all shadow-lg shadow-purple-950/50 cursor-pointer"
          >
            {savedSuccess ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
            <span>{savedSuccess ? 'تم الحفظ بنجاح! ✓' : 'حفظ جميع إعدادات الحماية'}</span>
          </button>
        </div>
      </div>

      {deployTrapResult && (
        <div className="p-3.5 rounded-xl bg-slate-900 border border-rose-500/50 text-white text-xs font-bold flex items-center gap-2 shadow-lg">
          <Zap className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{deployTrapResult}</span>
        </div>
      )}

      {/* Browser Push Notifications Control Card (Anti-Nuke Instant Alerts) */}
      <div className="p-5 rounded-2xl bg-[#0B1021] border border-slate-800 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div
              className={`w-11 h-11 rounded-xl border flex items-center justify-center shrink-0 ${
                pushEnabled
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400'
                  : pushPermission === 'denied'
                  ? 'bg-rose-500/15 border-rose-500/40 text-rose-400'
                  : 'bg-amber-500/15 border-amber-500/40 text-amber-400'
              }`}
            >
              {pushEnabled ? <BellRing className="w-5 h-5" /> : <BellOff className="w-5 h-5" />}
            </div>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-3">
                <h3 className="text-sm sm:text-base font-black text-white">
                  {isAr
                    ? 'إشعارات المتصفح الفورية لتهديدات Anti-Nuke (Browser Push Notifications)'
                    : 'Anti-Nuke Instant Browser Push Notifications'}
                </h3>
                <span
                  className={`text-xs font-black ${
                    pushEnabled
                      ? 'text-emerald-400'
                      : pushPermission === 'denied'
                      ? 'text-rose-400'
                      : pushPermission === 'unsupported'
                      ? 'text-slate-400'
                      : 'text-amber-400'
                  }`}
                >
                  {pushEnabled
                    ? isAr
                      ? '• مفعّلة الآن'
                      : '• Granted & Active'
                    : pushPermission === 'denied'
                    ? isAr
                      ? '• محظورة من المتصفح'
                      : '• Blocked by Browser'
                    : pushPermission === 'unsupported'
                    ? isAr
                      ? '• غير مدعومة'
                      : '• Unsupported'
                    : isAr
                    ? '• بانتظار التفعيل'
                    : '• Prompt Needed'}
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isAr
                  ? 'احصل على إشعار متصفح وجهاز فوري عند رصد أو صد أي تهديد (حذف رومات، باند جماعي، سبام، مصيدة، أو رابط خبيث) حتى أثناء وجودك في تبويب آخر.'
                  : 'Receive instant desktop/mobile notifications whenever M7R Shield blocks an Anti-Nuke, Anti-Raid, Honeypot, or Anti-Spam threat.'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleToggleBrowserPush}
              disabled={pushPermission === 'unsupported'}
              className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer transition-all border ${
                pushEnabled
                  ? 'bg-emerald-600/20 hover:bg-emerald-600/30 border-emerald-500/45 text-emerald-300'
                  : 'bg-[#5865F2] hover:bg-[#4752C4] border-white/15 text-white shadow-lg shadow-[#5865F2]/25'
              }`}
            >
              {pushEnabled ? <BellOff className="w-4 h-4 shrink-0" /> : <BellRing className="w-4 h-4 shrink-0" />}
              <span>
                {pushEnabled
                  ? isAr
                    ? 'إيقاف إشعارات المتصفح'
                    : 'Disable Push Alerts'
                  : isAr
                  ? 'تفعيل إشعارات المتصفح الفورية'
                  : 'Enable Browser Push Alerts'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleSendTestThreatPush}
              disabled={testingPushAlert}
              className="px-4 py-2.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/45 text-rose-200 text-xs font-black flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer transition-all"
            >
              <Zap className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                {testingPushAlert
                  ? isAr
                    ? 'جاري إرسال التنبيه...'
                    : 'Sending Alert...'
                  : isAr
                  ? 'تجربة إشعار تهديد الآن'
                  : 'Test Threat Push Alert'}
              </span>
            </button>
          </div>
        </div>

        {pushFeedback && (
          <div className="px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-bold text-slate-200">
            {pushFeedback}
          </div>
        )}
      </div>

      {activeSubTab === 'suite16' ? (
        <div className="space-y-8">
          {/* ==============================================================
              أولاً: بطاقات الحماية ضد التخريب والنوك (Anti-Nuke & Server Guard Cards 1–11)
             ============================================================== */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/90 pb-2.5">
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                <span>أولاً: بطاقات الحماية ضد التخريب والنوك (Anti-Nuke & Server Guard — 1 إلى 11)</span>
              </h3>
              <span className="text-xs font-mono text-rose-300 font-bold">M7R Shield Active</span>
            </div>

            {/* Cards 1 to 10 Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {guardCards.map((card) => (
                <div
                  key={card.id}
                  className={`p-5 rounded-2xl border transition-all space-y-4 ${
                    card.enabled
                      ? 'bg-[#0b1021]/95 border-purple-500/40 shadow-lg shadow-purple-950/20'
                      : 'bg-[#080b14]/80 border-slate-800/80 opacity-75'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <h4 className="text-sm font-black text-white">{card.title}</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">{card.description}</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-0.5">
                      <input
                        type="checkbox"
                        checked={card.enabled}
                        onChange={(e) => {
                          sound.playClick();
                          setGuardCards((prev) =>
                            prev.map((c) => (c.id === card.id ? { ...c, enabled: e.target.checked } : c))
                          );
                        }}
                        className="w-5 h-5 accent-purple-500 rounded cursor-pointer"
                      />
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
                    <div>
                      <label className="text-[11px] font-bold text-slate-300 block mb-1">نوع العقوبة:</label>
                      <select
                        value={card.punishment}
                        onChange={(e) => {
                          sound.playClick();
                          const val = e.target.value as ProtectionRuleCardState['punishment'];
                          setGuardCards((prev) =>
                            prev.map((c) => (c.id === card.id ? { ...c, punishment: val } : c))
                          );
                        }}
                        className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-purple-500"
                      >
                        <option value="ban">حظر نهائي (Ban)</option>
                        <option value="kick">طرد من السيرفر (Kick)</option>
                        <option value="strip_roles">سحب الرتب فوراً (Strip Roles)</option>
                        <option value="timeout_24h">عزل يوم كامل (Timeout)</option>
                      </select>
                    </div>

                    {card.hasLimit && (
                      <div>
                        <label className="text-[11px] font-bold text-slate-300 block mb-1">
                          الحد الأقصى للتكرار (1-10):
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={10}
                          value={card.limitValue || 1}
                          onChange={(e) => {
                            const val = Math.max(1, Math.min(10, Number(e.target.value) || 1));
                            setGuardCards((prev) =>
                              prev.map((c) => (c.id === card.id ? { ...c, limitValue: val } : c))
                            );
                          }}
                          className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-black text-purple-300 focus:outline-none focus:border-purple-500"
                        />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Card 11: الرتب والمستخدمون المستثنون من الحماية (Whitelist) + راصد حذف الرسائل الفوري */}
            <div className="p-6 rounded-3xl border-2 border-rose-500/45 bg-gradient-to-br from-rose-950/30 via-[#0b1021] to-purple-950/25 space-y-5 shadow-2xl">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-white">
                      11. الرتب والمستخدمون المستثنون من الحماية (Whitelist) + راصد حذف الرسائل الفوري
                    </h4>
                    <p className="text-xs text-rose-200/90 mt-0.5 font-bold">
                      ⚠️ القاعدة الصارمة: إذا لم يتم تحديد أي رتبة أو عضو هنا، فسيقوم البوت بمعاقبة أي شخص يخالف القواعد (حتى لو كان يمتلك Administrator) باستثناء مالك السيرفر الأساسي (Server Owner) فقط!
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs font-black">
                  ⚡ استرجاع تلقائي للمحذوفات
                </span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                {/* Exempt Roles Multi-Selector */}
                <div className="p-4 rounded-2xl bg-[#060913]/90 border border-slate-800 space-y-3">
                  <label className="text-xs font-black text-white block">
                    🎭 الرتب المستثناة من الحماية (Exempt Roles):
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={antiNuke.exemptRoleId || ''}
                      onChange={(e) => {
                        sound.playClick();
                        const rId = e.target.value;
                        setAntiNuke({ ...antiNuke, exemptRoleId: rId });
                        if (rId && !exemptRoleIds.includes(rId)) {
                          setExemptRoleIds((prev) => [...prev, rId]);
                        }
                      }}
                      className="flex-1 px-3 py-2.5 rounded-xl bg-slate-900 border border-purple-500/40 text-xs font-bold text-white focus:outline-none"
                    >
                      <option value="">🚫 بدون رتبة مستثناة (محاسبة الجميع ما عدا Owner)</option>
                      {serverRolesList.map((role) => (
                        <option key={role.id} value={role.id}>
                          @{role.name} ({role.id})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {exemptRoleIds.map((rid) => {
                      const rObj = serverRolesList.find((r) => r.id === rid);
                      return (
                        <span
                          key={rid}
                          className="px-2.5 py-1 rounded-lg bg-purple-500/20 border border-purple-500/40 text-purple-200 text-xs font-bold flex items-center gap-1.5"
                        >
                          <span>@{rObj?.name || rid}</span>
                          <button
                            type="button"
                            onClick={() => {
                              setExemptRoleIds((prev) => prev.filter((x) => x !== rid));
                              if (antiNuke.exemptRoleId === rid) {
                                setAntiNuke({ ...antiNuke, exemptRoleId: '' });
                              }
                            }}
                            className="text-purple-300 hover:text-rose-400 cursor-pointer"
                          >
                            ×
                          </button>
                        </span>
                      );
                    })}
                  </div>
                </div>

                {/* Exempt Users Multi-Selector */}
                <div className="p-4 rounded-2xl bg-[#060913]/90 border border-slate-800 space-y-3">
                  <label className="text-xs font-black text-white block">
                    👤 المستخدمون المستثنون من الحماية (Exempt User IDs):
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="أدخل Discord User ID..."
                      value={newWhitelistId}
                      onChange={(e) => setNewWhitelistId(e.target.value)}
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-purple-500"
                    />
                    <button
                      type="button"
                      onClick={addWhitelistUser}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>إضافة</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {antiNuke.whitelistUserIds.map((uid) => (
                      <span
                        key={uid}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 text-xs font-mono flex items-center gap-1.5"
                      >
                        <span>{uid}</span>
                        <button
                          type="button"
                          onClick={() => removeWhitelistUser(uid)}
                          className="text-slate-400 hover:text-rose-400 cursor-pointer"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Real-Time Message Delete Tracker inside Card 11 */}
              <div className="p-4 rounded-2xl bg-[#060913]/95 border border-purple-500/40 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2.5">
                  <Eye className="w-5 h-5 text-purple-400 shrink-0" />
                  <div>
                    <h5 className="text-xs sm:text-sm font-black text-white">
                      🕵️‍♂️ راصد حذف الرسائل الفوري (Real-Time Message Delete Tracker)
                    </h5>
                    <p className="text-[11px] text-slate-400">
                      يرصد عبر AuditLogEvent.MessageDelete الكاتب الأصلي + الإداري الحاذف + النص المحذوف ويعاقب من يمسح الشات!
                    </p>
                  </div>
                </div>
                <label className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-500/15 border border-purple-500/40 cursor-pointer">
                  <span className="text-xs font-black text-purple-200">مفعل المستمر</span>
                  <input
                    type="checkbox"
                    checked={antiNuke.liveMessageDeleteMonitor !== false}
                    onChange={(e) => {
                      sound.playClick();
                      setAntiNuke({ ...antiNuke, liveMessageDeleteMonitor: e.target.checked });
                    }}
                    className="w-4 h-4 accent-purple-500 rounded cursor-pointer"
                  />
                </label>
              </div>
            </div>

            {/* ==============================================================
                لوحة سياسات تقييد معدل الأوامر لكل رتبة إدارية حسب أهميتها (Per-Role Rate Limiting)
               ============================================================== */}
            <div className="p-6 rounded-3xl border-2 border-indigo-500/45 bg-gradient-to-br from-indigo-950/35 via-[#0b1021] to-slate-950 space-y-5 shadow-2xl">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-300 shrink-0">
                    <Sliders className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2.5">
                      <h4 className="text-base font-black text-white">
                        {isAr
                          ? '⚖️ سياسات تقييد معدل الأوامر للرتب الإدارية (Per-Role Command Rate Limiting)'
                          : 'Per-Role Admin Command Rate Limiting'}
                      </h4>
                      <span
                        className={`px-2.5 py-0.5 rounded-lg text-[11px] font-black border ${
                          roleRateLimits.enabled
                            ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                            : 'bg-slate-800 border-slate-700 text-slate-400'
                        }`}
                      >
                        {roleRateLimits.enabled ? 'مفعّل على أوامر Slash & Prefix' : 'متوقف مؤقتاً'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      تحكم في الحد الأقصى لعدد الأوامر المسموح بتنفيذها في الدقيقة لكل رتبة إدارية بناءً على أهميتها (الأونر الأساسي ومالك البوت مستثنون دائماً، وعند امتلاك الإداري لأكثر من رتبة يُطبّق حد الرتبة الأعلى أهمية).
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <label className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-black text-white cursor-pointer">
                    <input
                      type="checkbox"
                      checked={roleRateLimits.enabled}
                      onChange={(e) => {
                        sound.playClick();
                        updateRoleRateLimits((prev) => ({ ...prev, enabled: e.target.checked }));
                      }}
                      className="w-4 h-4 accent-indigo-500 rounded cursor-pointer"
                    />
                    <span>تفعيل التقييد</span>
                  </label>

                  <button
                    type="button"
                    onClick={handleAutoPopulateRolePolicies}
                    className="px-3.5 py-2 rounded-xl bg-purple-600/25 hover:bg-purple-600/40 border border-purple-500/40 text-purple-200 text-xs font-black flex items-center gap-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>توزيع تلقائي من رتب السيرفر</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleAddRoleRatePolicy}
                    className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-emerald-300 text-xs font-black flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة رتبة</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveRoleRateLimits}
                    disabled={savingRoleLimits}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-950/60"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{savingRoleLimits ? 'جاري الحفظ...' : 'حفظ سياسات الرتب'}</span>
                  </button>
                </div>
              </div>

              {roleLimitsFeedback && (
                <div className="px-4 py-2.5 rounded-xl bg-indigo-950/60 border border-indigo-500/40 text-indigo-100 text-xs font-bold">
                  {roleLimitsFeedback}
                </div>
              )}

              {/* Global Defaults Row */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-2xl bg-[#060913] border border-slate-800 space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 block">
                    الحد الافتراضي للرتب الإدارية غير المحددة (أمر/دقيقة):
                  </label>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-indigo-400 shrink-0" />
                    <input
                      type="number"
                      min={1}
                      max={180}
                      value={roleRateLimits.defaultCommandsPerMinute}
                      onChange={(e) => {
                        const val = Math.max(1, Math.min(180, Number(e.target.value) || 12));
                        updateRoleRateLimits((prev) => ({ ...prev, defaultCommandsPerMinute: val }));
                      }}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs font-mono font-black text-indigo-300"
                    />
                  </div>
                </div>

                <label className="p-3.5 rounded-2xl bg-[#060913] border border-slate-800 flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <span className="text-xs font-black text-white block">تنبيه الإداري عند تجاوز الحد</span>
                    <span className="text-[11px] text-slate-400">إرسال رسالة تحذير موضحة الحد المتاح للرتبة ووقت الانتظار</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={roleRateLimits.notifyUserOnLimit !== false}
                    onChange={(e) =>
                      updateRoleRateLimits((prev) => ({ ...prev, notifyUserOnLimit: e.target.checked }))
                    }
                    className="w-4 h-4 accent-indigo-500 rounded shrink-0"
                  />
                </label>

                <label className="p-3.5 rounded-2xl bg-[#060913] border border-slate-800 flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <span className="text-xs font-black text-white block">تسجيل التجاوز في #log-server</span>
                    <span className="text-[11px] text-slate-400">إرسال تنبيه فوري لروم اللوق وسجل التهديدات عند التكرار</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={roleRateLimits.logChannelAlert !== false}
                    onChange={(e) =>
                      updateRoleRateLimits((prev) => ({ ...prev, logChannelAlert: e.target.checked }))
                    }
                    className="w-4 h-4 accent-indigo-500 rounded shrink-0"
                  />
                </label>
              </div>

              {/* Per-Role Policy Cards */}
              <div className="space-y-3">
                {roleRateLimits.policies.map((policy) => {
                  const tierAccent =
                    policy.importanceTier === 'owner_deputy'
                      ? 'border-amber-500/45 bg-amber-950/15'
                      : policy.importanceTier === 'head_admin'
                      ? 'border-purple-500/45 bg-purple-950/15'
                      : policy.importanceTier === 'moderator'
                      ? 'border-sky-500/40 bg-sky-950/10'
                      : policy.importanceTier === 'helper'
                      ? 'border-emerald-500/40 bg-emerald-950/10'
                      : 'border-slate-700 bg-[#060913]';

                  return (
                    <div
                      key={policy.id}
                      className={`p-4 rounded-2xl border ${tierAccent} ${
                        policy.enabled ? '' : 'opacity-60'
                      } grid grid-cols-1 lg:grid-cols-12 gap-3 items-center`}
                    >
                      {/* Role Selector & Custom Name */}
                      <div className="lg:col-span-4 space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-300 block">
                          الرتبة الإدارية (من السيرفر أو بالاسم):
                        </label>
                        <div className="flex gap-2">
                          <select
                            value={policy.roleId}
                            onChange={(e) => {
                              sound.playClick();
                              const selectedId = e.target.value;
                              const foundRole = serverRolesList.find((r) => r.id === selectedId);
                              updateRoleRateLimits((prev) => ({
                                ...prev,
                                policies: prev.policies.map((p) =>
                                  p.id === policy.id
                                    ? {
                                        ...p,
                                        roleId: selectedId,
                                        roleName: foundRole ? foundRole.name : p.roleName
                                      }
                                    : p
                                )
                              }));
                            }}
                            className="w-1/2 bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-2 text-xs font-bold text-white"
                          >
                            <option value="">حسب الاسم...</option>
                            {serverRolesList.map((r) => (
                              <option key={r.id} value={r.id}>
                                @{r.name}
                              </option>
                            ))}
                          </select>
                          <input
                            type="text"
                            value={policy.roleName}
                            onChange={(e) => {
                              const val = e.target.value;
                              updateRoleRateLimits((prev) => ({
                                ...prev,
                                policies: prev.policies.map((p) =>
                                  p.id === policy.id ? { ...p, roleName: val } : p
                                )
                              }));
                            }}
                            placeholder="اسم الرتبة..."
                            className="w-1/2 bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-2 text-xs font-bold text-white"
                          />
                        </div>
                      </div>

                      {/* Importance Tier */}
                      <div className="lg:col-span-3 space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-300 block">مستوى أهمية الرتبة:</label>
                        <select
                          value={policy.importanceTier}
                          onChange={(e) => {
                            sound.playClick();
                            const tier = e.target.value as AdminImportanceTier;
                            const preset = getImportanceDefaults(tier);
                            updateRoleRateLimits((prev) => ({
                              ...prev,
                              policies: prev.policies.map((p) =>
                                p.id === policy.id
                                  ? {
                                      ...p,
                                      importanceTier: tier,
                                      commandsPerMinute: preset.commandsPerMinute,
                                      actionOnExceed: preset.actionOnExceed
                                    }
                                  : p
                              )
                            }));
                          }}
                          className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white"
                        >
                          <option value="owner_deputy">👑 نائب الأونر / أعلى أهمية (45/دقيقة)</option>
                          <option value="head_admin">🛡️ الإدارة العليا (25/دقيقة)</option>
                          <option value="moderator">⚔️ مشرف / Moderator (12/دقيقة)</option>
                          <option value="helper">🛟 مساعد إداري / Helper (6/دقيقة)</option>
                          <option value="custom">⚙️ تخصيص يدوي</option>
                        </select>
                      </div>

                      {/* Commands Per Minute Slider & Number */}
                      <div className="lg:col-span-2 space-y-1.5">
                        <div className="flex items-center justify-between text-[11px] font-bold">
                          <span className="text-slate-300">الحد / دقيقة:</span>
                          <span className="font-mono font-black text-indigo-300">{policy.commandsPerMinute} أمر</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="range"
                            min={1}
                            max={90}
                            value={Math.min(90, policy.commandsPerMinute)}
                            onChange={(e) => {
                              const val = Math.max(1, Math.min(180, Number(e.target.value) || 1));
                              updateRoleRateLimits((prev) => ({
                                ...prev,
                                policies: prev.policies.map((p) =>
                                  p.id === policy.id ? { ...p, commandsPerMinute: val } : p
                                )
                              }));
                            }}
                            className="flex-1 accent-indigo-500 cursor-pointer"
                          />
                          <input
                            type="number"
                            min={1}
                            max={180}
                            value={policy.commandsPerMinute}
                            onChange={(e) => {
                              const val = Math.max(1, Math.min(180, Number(e.target.value) || 1));
                              updateRoleRateLimits((prev) => ({
                                ...prev,
                                policies: prev.policies.map((p) =>
                                  p.id === policy.id ? { ...p, commandsPerMinute: val } : p
                                )
                              }));
                            }}
                            className="w-14 bg-slate-950 border border-slate-700 rounded-lg px-1.5 py-1 text-xs font-mono font-black text-center text-white"
                          />
                        </div>
                      </div>

                      {/* Exceed Action + Controls */}
                      <div className="lg:col-span-3 flex items-end gap-2">
                        <div className="flex-1 space-y-1.5">
                          <label className="text-[11px] font-bold text-slate-300 block">الإجراء عند التجاوز:</label>
                          <select
                            value={policy.actionOnExceed}
                            onChange={(e) => {
                              const act = e.target.value as AdminRoleRateLimitPolicy['actionOnExceed'];
                              updateRoleRateLimits((prev) => ({
                                ...prev,
                                policies: prev.policies.map((p) =>
                                  p.id === policy.id ? { ...p, actionOnExceed: act } : p
                                )
                              }));
                            }}
                            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-2 text-xs font-bold text-white"
                          >
                            <option value="block_warn">🚫 حظر الأمر + تحذير</option>
                            <option value="timeout_5m">⏳ تايم أوت 5 دقائق</option>
                            <option value="strip_roles">⚠️ سحب الرتب الإدارية</option>
                            <option value="log_only">📝 تسجيل في اللوق فقط</option>
                          </select>
                        </div>

                        <label
                          title="تفعيل أو تعطيل سياسة هذه الرتبة"
                          className="p-2 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer flex items-center justify-center"
                        >
                          <input
                            type="checkbox"
                            checked={policy.enabled}
                            onChange={(e) =>
                              updateRoleRateLimits((prev) => ({
                                ...prev,
                                policies: prev.policies.map((p) =>
                                  p.id === policy.id ? { ...p, enabled: e.target.checked } : p
                                )
                              }))
                            }
                            className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                          />
                        </label>

                        <button
                          type="button"
                          onClick={() => {
                            sound.playClick();
                            updateRoleRateLimits((prev) => ({
                              ...prev,
                              policies: prev.policies.filter((p) => p.id !== policy.id)
                            }));
                          }}
                          title="حذف السياسة"
                          className="p-2 rounded-xl bg-rose-950/60 hover:bg-rose-600 border border-rose-500/40 text-rose-300 hover:text-white cursor-pointer transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {rateLimitEvents.length > 0 && (
                <div className="p-4 rounded-2xl bg-[#060913] border border-slate-800 space-y-2.5">
                  <div className="text-xs font-black text-amber-300">
                    ⚡ أحدث محاولات تجاوز حد الأوامر المرصودة ({rateLimitEvents.length}):
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {rateLimitEvents.slice(0, 4).map((ev) => (
                      <div
                        key={ev.id}
                        className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-[11px] flex items-center justify-between gap-2"
                      >
                        <div>
                          <span className="font-black text-white">@{ev.username}</span>{' '}
                          <span className="text-indigo-300 font-bold">({ev.roleName})</span>
                          <div className="text-slate-400 font-mono">
                            أمر: {ev.commandName} • {ev.countInMinute}/{ev.limitPerMinute} بالدقيقة
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded bg-rose-500/15 border border-rose-500/30 text-rose-300 font-bold shrink-0">
                          {ev.actionTaken}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ==============================================================
              ثانياً: بطاقات الفلترة ومكافحة السبام والكلمات المحظورة (AutoMod & Chat Filter Cards 12–16)
             ============================================================== */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/90 pb-2.5">
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500 animate-ping" />
                <span>ثانياً: بطاقات الفلترة ومكافحة السبام والكلمات المحظورة (AutoMod & Chat Filter — 12 إلى 16)</span>
              </h3>
              <span className="text-xs font-mono text-purple-300 font-bold">GUARD المستمر</span>
            </div>

            {/* Card 12: تخصيص رتب العقوبات (الكتم والسجن) */}
            <div className="p-5 rounded-2xl bg-[#0b1021]/95 border border-slate-800/90 space-y-4">
              <div>
                <h4 className="text-sm sm:text-base font-black text-white">
                  12. تخصيص رتب العقوبات (الكتم والسجن)
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  حدد اسم رتبة الكتم واسم رتبة السجن ليقوم البوت بإنشائها وضبط صلاحياتها في جميع الرومات تلقائياً:
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">اسم رتبة الكتم:</label>
                  <input
                    type="text"
                    value={muteRoleName}
                    onChange={(e) => setMuteRoleName(e.target.value)}
                    placeholder="كتم (تلقائي)"
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">اسم رتبة السجن:</label>
                  <input
                    type="text"
                    value={prisonRoleName}
                    onChange={(e) => setPrisonRoleName(e.target.value)}
                    placeholder="سجن (تلقائي)"
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>
            </div>

            {/* Card 13: إعدادات فلتر الكلمات المحظورة + 🚫 الكلمات المحظورة (558) */}
            <div className="p-5 sm:p-6 rounded-2xl bg-[#0b1021]/95 border border-rose-500/40 space-y-5 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm sm:text-base font-black text-white">
                      13. إعدادات فلتر الكلمات المحظورة
                    </h4>
                    <span className="px-2.5 py-0.5 rounded-lg bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-black font-mono">
                      🚫 الكلمات المحظورة ({bannedWordsTotalCount})
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    حذف فوري لأي كلمة بذيئة أو مسيئة أو سبام مع تطبيق العقوبة المحددة تلقائياً (الكلمات مموهة افتراضياً، مرر الماوس أو اضغط لإظهارها):
                  </p>
                </div>

                <input
                  type="checkbox"
                  checked={bannedWordsEnabled}
                  onChange={(e) => {
                    sound.playClick();
                    setBannedWordsEnabled(e.target.checked);
                  }}
                  className="w-5 h-5 accent-rose-500 rounded cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    العقوبة عند استخدام كلمة محظورة:
                  </label>
                  <select
                    value={bannedWordsPunishment}
                    onChange={(e) => setBannedWordsPunishment(e.target.value as any)}
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white focus:outline-none focus:border-rose-500"
                  >
                    <option value="ban">حظر الجاني (Ban)</option>
                    <option value="mute">كتم الجاني (Mute)</option>
                    <option value="delete">حذف الرسالة فقط (Delete Only)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    مدة الحظر (ثانية):
                  </label>
                  <input
                    type="number"
                    value={bannedWordsBanDurationSec}
                    onChange={(e) => setBannedWordsBanDurationSec(Math.max(60, Number(e.target.value) || 2592000))}
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono font-black text-rose-300 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Add Banned Word Input + Green "+ إضافة" Button */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newBannedWordInput}
                  onChange={(e) => setNewBannedWordInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddBannedWord();
                    }
                  }}
                  placeholder="أدخل كلمة محظورة..."
                  className="flex-1 bg-[#060913] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="button"
                  onClick={handleAddBannedWord}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ إضافة</span>
                </button>
              </div>

              {/* Interactive Blurred Red Pill Tags with × delete buttons */}
              <div className="p-3.5 rounded-2xl bg-[#060913]/90 border border-slate-800/90 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>قائمة الكلمات المحظورة النشطة ({bannedWordsTotalCount} كلمة محمية):</span>
                  <span>مرر الماوس على الكلمة لكشف التمويه</span>
                </div>
                <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto pt-1">
                  {bannedWordsTags.map((word, idx) => {
                    const isRevealed = revealedWordIndex === idx;
                    return (
                      <span
                        key={word + idx}
                        onClick={() => setRevealedWordIndex(isRevealed ? null : idx)}
                        className="group px-3 py-1 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs font-bold flex items-center gap-2 cursor-pointer transition-all"
                      >
                        <span
                          className={`transition-all select-none ${
                            isRevealed ? 'blur-none' : 'blur-[4px] group-hover:blur-none'
                          }`}
                        >
                          {word}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemoveBannedWord(word);
                          }}
                          className="text-rose-400 hover:text-white font-black cursor-pointer"
                          title="حذف الكلمة"
                        >
                          ×
                        </button>
                      </span>
                    );
                  })}
                  <span className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 text-xs font-mono">
                    + {Math.max(0, bannedWordsTotalCount - bannedWordsTags.length)} كلمة محظورة إضافية مفعلة في القاعدة
                  </span>
                </div>
              </div>
            </div>

            {/* Card 14: مكافحة السبام والإرسال السريع */}
            <div className="p-5 rounded-2xl bg-[#0b1021]/95 border border-slate-800/90 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm sm:text-base font-black text-white">
                    14. مكافحة السبام والإرسال السريع
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    إيقاف من يرسل رسائل متتالية بسرعة لإغراق الشات (Anti-Flood & Velocity Guard):
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={spamCardEnabled}
                  onChange={(e) => {
                    sound.playClick();
                    setSpamCardEnabled(e.target.checked);
                  }}
                  className="w-5 h-5 accent-purple-500 rounded cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">الحد الأقصى للرسائل:</label>
                  <input
                    type="number"
                    min={2}
                    max={20}
                    value={spamMaxMsgs}
                    onChange={(e) => {
                      const val = Number(e.target.value) || 5;
                      setSpamMaxMsgs(val);
                      setAntiSpam({ ...antiSpam, maxMessages: val });
                    }}
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-black text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">الفترة الزمنية (ثانية):</label>
                  <input
                    type="number"
                    min={1}
                    max={60}
                    value={spamWindowSec}
                    onChange={(e) => {
                      const val = Number(e.target.value) || 5;
                      setSpamWindowSec(val);
                      setAntiSpam({ ...antiSpam, windowSeconds: val });
                    }}
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-black text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">العقوبة:</label>
                  <select
                    value={spamPunishmentType}
                    onChange={(e) => setSpamPunishmentType(e.target.value as any)}
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white"
                  >
                    <option value="mute">كتم العضو (Mute)</option>
                    <option value="kick">طرد العضو (Kick)</option>
                    <option value="ban">حظر العضو (Ban)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">مدة الكتم (ثانية):</label>
                  <input
                    type="number"
                    min={10}
                    value={spamMuteDurationSec}
                    onChange={(e) => setSpamMuteDurationSec(Number(e.target.value) || 60)}
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-black text-purple-300"
                  />
                </div>
              </div>
            </div>

            {/* Card 15: منع نشر الروابط الخارجية (مع البطاقتين الفرعيتين) */}
            <div className="p-5 rounded-2xl bg-[#0b1021]/95 border border-slate-800/90 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm sm:text-base font-black text-white">
                    15. منع نشر الروابط الخارجية
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    فلترة الروابط الخارجية وروابط دعوات ديسكورد مع خيار استثناء الصور المتحركة GIF:
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={linksFilterEnabled}
                  onChange={(e) => {
                    sound.playClick();
                    setLinksFilterEnabled(e.target.checked);
                  }}
                  className="w-5 h-5 accent-purple-500 rounded cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Sub-card 1: حظر روابط ديسكورد فقط */}
                <label className="p-4 rounded-xl bg-[#060913] border border-slate-800 flex items-start justify-between gap-3 cursor-pointer">
                  <div>
                    <span className="text-xs font-black text-white block">حظر روابط ديسكورد فقط</span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      روابط الدعوة مثل discord.gg و discord.com/invite — دون حظر باقي الروابط الخارجية
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={discordInvitesOnly}
                    onChange={(e) => {
                      sound.playClick();
                      setDiscordInvitesOnly(e.target.checked);
                      setAntiInvite({ ...antiInvite, blockDiscordInvites: e.target.checked });
                    }}
                    className="w-4 h-4 accent-purple-500 rounded mt-1"
                  />
                </label>

                {/* Sub-card 2: تخطي روابط GIF والصور المتحركة */}
                <label className="p-4 rounded-xl bg-[#060913] border border-slate-800 flex items-start justify-between gap-3 cursor-pointer">
                  <div>
                    <span className="text-xs font-black text-white block">تخطي روابط GIF والصور المتحركة</span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      عدم حظر روابط الصور المتحركة من Tenor و Giphy والروابط المنتهية بـ .gif
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={skipGifLinks}
                    onChange={(e) => {
                      sound.playClick();
                      setSkipGifLinks(e.target.checked);
                    }}
                    className="w-4 h-4 accent-emerald-500 rounded mt-1"
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">العقوبة:</label>
                  <select
                    value={linksPunishment}
                    onChange={(e) => setLinksPunishment(e.target.value as any)}
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white"
                  >
                    <option value="mute">كتم العضو (Mute)</option>
                    <option value="delete">حذف الرابط فقط (Delete Only)</option>
                    <option value="ban">حظر العضو (Ban)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">مدة الكتم (ثانية):</label>
                  <input
                    type="number"
                    min={30}
                    value={linksMuteDurationSec}
                    onChange={(e) => setLinksMuteDurationSec(Number(e.target.value) || 300)}
                    className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-black text-purple-300"
                  />
                </div>
              </div>
            </div>

            {/* Card 16: منع تكرار المنشن والإشارة & منع تكرار/إغراق الإيموجيات */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 16-A: منع تكرار المنشن والإشارة */}
              <div className="p-5 rounded-2xl bg-[#0b1021]/95 border border-slate-800/90 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-black text-white">16. منع تكرار المنشن والإشارة</h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      منع إزعاج الأعضاء بمنشن متكرر في الرسالة الواحدة:
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={mentionProtectionEnabled}
                    onChange={(e) => setMentionProtectionEnabled(e.target.checked)}
                    className="w-5 h-5 accent-purple-500 rounded cursor-pointer"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">الحد الأقصى للمنشن:</label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={maxMentionsAllowed}
                      onChange={(e) => {
                        const val = Number(e.target.value) || 5;
                        setMaxMentionsAllowed(val);
                        setAntiSpam({ ...antiSpam, maxMentions: val });
                      }}
                      className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-black text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">العقوبة:</label>
                    <select
                      value={mentionPunishment}
                      onChange={(e) => setMentionPunishment(e.target.value as any)}
                      className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white"
                    >
                      <option value="delete">حذف الرسالة فقط</option>
                      <option value="mute">كتم العضو (Mute)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* 16-B: منع تكرار/إغراق الإيموجيات */}
              <div className="p-5 rounded-2xl bg-[#0b1021]/95 border border-slate-800/90 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-black text-white">منع تكرار/إغراق الإيموجيات</h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      منع إغراق الشات بعدد كبير من الإيموجيات في الرسالة الواحدة:
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={emojiProtectionEnabled}
                    onChange={(e) => {
                      setEmojiProtectionEnabled(e.target.checked);
                      setAntiSpam({ ...antiSpam, blockEmojiFlood: e.target.checked });
                    }}
                    className="w-5 h-5 accent-purple-500 rounded cursor-pointer"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">الحد الأقصى للإيموجي:</label>
                    <input
                      type="number"
                      min={3}
                      max={30}
                      value={maxEmojisAllowed}
                      onChange={(e) => setMaxEmojisAllowed(Number(e.target.value) || 10)}
                      className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-black text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">العقوبة:</label>
                    <select
                      value={emojiPunishment}
                      onChange={(e) => setEmojiPunishment(e.target.value as any)}
                      className="w-full bg-[#060913] border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white"
                    >
                      <option value="delete">حذف الرسالة فقط</option>
                      <option value="mute">كتم العضو (Mute)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* ==============================================================
                ثالثاً: حزمة التحصين الأمني الشاملة (20-Point Security Audit + Admin 2FA + AI Spending Cap)
               ============================================================== */}
            <div className="p-6 rounded-3xl border-2 border-emerald-500/40 bg-gradient-to-br from-emerald-950/25 via-[#0b1021] to-slate-950 space-y-6 shadow-2xl">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-300 shrink-0">
                    <Lock className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2.5">
                      <h4 className="text-base font-black text-white">
                        🔐 درع التحصين الشامل: فحص الـ 20 نقطة أمنية + التحقق الثنائي (2FA) + سقف إنفاق AI
                      </h4>
                      {auditReport && (
                        <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-black">
                          {auditReport.passedCount}/{auditReport.totalCount} ({auditReport.score}%)
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300 mt-1">
                      تشفير AES-256-GCM لملفات السيرفر المحلية، عزل صلاحيات RLS على الـ 10 جداول، تعقيم المدخلات، توقيع HMAC-SHA256، والتحقق الثنائي للإدارة.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleRunSecurityAudit}
                  disabled={runningAudit}
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center gap-2 cursor-pointer shrink-0 shadow-lg shadow-emerald-950/50"
                >
                  <RefreshCw className={`w-4 h-4 ${runningAudit ? 'animate-spin' : ''}`} />
                  <span>{runningAudit ? 'جاري الفحص الشامل...' : 'تشغيل الفحص الأمني الشامل (20/20)'}</span>
                </button>
              </div>

              {/* Admin 2FA + AI Spending Cap Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                {/* Admin 2FA Panel (Google Authenticator TOTP + Discord DM) */}
                <div className="p-5 rounded-2xl bg-[#060913] border border-purple-500/35 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h5 className="text-sm font-black text-white flex items-center gap-2">
                      <KeyRound className="w-4 h-4 text-purple-400" />
                      <span>التحقق الثنائي للإدارة (Admin 2FA)</span>
                    </h5>
                    <span className="text-[11px] font-black text-purple-300">
                      {twoFaStatus?.isSessionVerified || twoFaStatus?.sessionVerified
                        ? '✓ جلسة موثقة'
                        : twoFaStatus?.enabled
                        ? 'مفعّل'
                        : 'اختياري'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    فعّل الحماية الثنائية باستخدام تطبيق Google Authenticator أو استلم رمز التحقق (6 أرقام) مباشرة في خاص الديسكورد.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={handleEnrollTotp}
                      className="px-3.5 py-2 rounded-xl bg-purple-600/25 hover:bg-purple-600/40 border border-purple-500/40 text-purple-200 text-xs font-black flex items-center gap-1.5 cursor-pointer"
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>ربط Google Authenticator</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleSendDiscordDmOtp}
                      className="px-3.5 py-2 rounded-xl bg-[#5865F2]/25 hover:bg-[#5865F2]/40 border border-[#5865F2]/50 text-indigo-200 text-xs font-black flex items-center gap-1.5 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>إرسال رمز لخاص الديسكورد (DM)</span>
                    </button>
                  </div>

                  {totpEnrollData?.secret && (
                    <div className="p-3 rounded-xl bg-slate-900 border border-purple-500/30 space-y-1.5 text-xs">
                      <div className="text-slate-300 font-bold">مفتاح الإعداد اليدوي لـ Google Authenticator:</div>
                      <code className="block p-2 rounded-lg bg-slate-950 text-emerald-300 font-mono select-all break-all">
                        {totpEnrollData.secret}
                      </code>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={12}
                      value={twoFaCodeInput}
                      onChange={(e) => setTwoFaCodeInput(e.target.value)}
                      placeholder="أدخل رمز 2FA المكون من 6 أرقام..."
                      className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white"
                    />
                    <button
                      type="button"
                      onClick={handleVerify2faCode}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black cursor-pointer"
                    >
                      تحقق الآن
                    </button>
                  </div>

                  {twoFaFeedback && (
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-[11px] font-bold text-emerald-200">
                      {twoFaFeedback}
                    </div>
                  )}
                </div>

                {/* AI Daily & Monthly Spending Cap Panel */}
                <div className="p-5 rounded-2xl bg-[#060913] border border-amber-500/35 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h5 className="text-sm font-black text-white flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-amber-400" />
                      <span>سقف الإنفاق اليومي للذكاء الاصطناعي (AI Spending Cap)</span>
                    </h5>
                    <input
                      type="checkbox"
                      checked={spendingCap.enabled}
                      onChange={(e) => setSpendingCap((prev) => ({ ...prev, enabled: e.target.checked }))}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    عند بلوغ الحد اليومي أو الشهري ينتقل البوت تلقائياً للبديل المجاني دون أي تكلفة إضافية. الاستهلاك اليومي الحالي:{' '}
                    <span className="font-mono font-black text-amber-300">
                      ${Number(spendingCap.dailySpendUsd || 0).toFixed(3)} ({spendingCap.dailyRequestsUsed || 0} طلب)
                    </span>
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="text-slate-300 font-bold block mb-1">السقف اليومي ($):</label>
                      <input
                        type="number"
                        step="0.5"
                        min={0.5}
                        value={spendingCap.dailySpendCapUsd}
                        onChange={(e) =>
                          setSpendingCap((prev) => ({
                            ...prev,
                            dailySpendCapUsd: Number(e.target.value) || 2
                          }))
                        }
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 font-mono font-black text-amber-300"
                      />
                    </div>
                    <div>
                      <label className="text-slate-300 font-bold block mb-1">السقف الشهري ($):</label>
                      <input
                        type="number"
                        step="1"
                        min={1}
                        value={spendingCap.monthlySpendCapUsd}
                        onChange={(e) =>
                          setSpendingCap((prev) => ({
                            ...prev,
                            monthlySpendCapUsd: Number(e.target.value) || 25
                          }))
                        }
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 font-mono font-black text-amber-300"
                      />
                    </div>
                    <div>
                      <label className="text-slate-300 font-bold block mb-1">حد الطلبات/يوم:</label>
                      <input
                        type="number"
                        min={10}
                        value={spendingCap.dailyRequestLimit}
                        onChange={(e) =>
                          setSpendingCap((prev) => ({
                            ...prev,
                            dailyRequestLimit: Number(e.target.value) || 250
                          }))
                        }
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 font-mono font-black text-white"
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-2 pt-1">
                    {capFeedback ? (
                      <span className="text-[11px] font-bold text-emerald-300">{capFeedback}</span>
                    ) : (
                      <span className="text-[11px] text-slate-400">الطلبات المحجوبة بالسقف: {spendingCap.blockedByCapCount || 0}</span>
                    )}
                    <button
                      type="button"
                      onClick={handleSaveSpendingCap}
                      disabled={savingCap}
                      className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-black cursor-pointer"
                    >
                      {savingCap ? 'جاري الحفظ...' : 'حفظ السقف اليومي'}
                    </button>
                  </div>
                </div>
              </div>

              {/* 20-Point Security Audit Checklist Grid */}
              {Array.isArray(auditReport?.items) && (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
                  {auditReport.items.map((item: any) => (
                    <div
                      key={item.id}
                      className={`p-3.5 rounded-2xl border space-y-1.5 ${
                        item.status === 'passed'
                          ? 'bg-[#060913] border-emerald-500/35'
                          : 'bg-amber-950/20 border-amber-500/45'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-black text-white">{item.titleAr}</span>
                        <span
                          className={`text-[10px] font-mono font-black px-2 py-0.5 rounded ${
                            item.status === 'passed'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-amber-500/20 text-amber-300'
                          }`}
                        >
                          {item.status === 'passed' ? 'PASS' : 'WARN'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">{item.detailAr}</p>
                      <div className="text-[10px] font-mono text-indigo-300 pt-0.5">{item.metric}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* TAB: HONEYPOT TRAP (مصيدة الحماية) */
        <div className="space-y-6">
          <div className="rounded-xl border border-red-500/40 bg-gradient-to-r from-red-950/40 via-[#0d1017] to-red-950/20 p-5 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🪤</span>
                  <h3 className="text-base font-black text-white">
                    روم مصيدة الحماية (M7R Honeypot Trap):
                  </h3>
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-red-900/60 text-red-300 border border-red-500/40">
                    {honeypotTrap.enabled ? 'نشطة 🟢' : 'معطلة 🔴'}
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  روم وهمي مخصص لصيد حسابات السيلف بوت والمخربين تلقائياً. أي رسالة تكتب فيه يُحظر صاحبها فوراً ويُرسل إشعار تحذيري إلى #log-server!
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleDeployTrapChannel}
                  disabled={deployingTrap}
                  className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-lg flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{deployingTrap ? 'جارِ النشر...' : 'إنشاء ونشر روم المصيدة في ديسكورد الآن 🚀'}</span>
                </button>

                <button
                  onClick={handleTestTrap}
                  disabled={testingTrap}
                  className="px-3 py-2 bg-slate-800 hover:bg-amber-900/60 border border-amber-500/30 text-amber-300 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Skull className="w-3.5 h-3.5 text-amber-400" />
                  <span>اختبار المصيدة 🧪</span>
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Flame className="w-4 h-4 text-rose-500" />
                <span>إعدادات روم المصيدة والعقوبة</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <ChannelSelector
                  lang={lang}
                  label="تحديد روم المصيدة في ديسكورد"
                  value={honeypotTrap.channelName}
                  onChange={(ch) => setHoneypotTrap({ ...honeypotTrap, channelName: ch })}
                  placeholder="🚫-ممنوع-الدخول"
                />
                <ChannelSelector
                  lang={lang}
                  label="تحديد روم إشعارات المصيدة (Log)"
                  value={honeypotTrap.alertLogChannel}
                  onChange={(ch) => setHoneypotTrap({ ...honeypotTrap, alertLogChannel: ch })}
                  placeholder="log-server"
                />
              </div>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-emerald-400" />
                <span>المعفيون من المصيدة (Whitelist)</span>
              </h3>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newTrapWhitelistUser}
                  onChange={(e) => setNewTrapWhitelistUser(e.target.value)}
                  placeholder="Discord User ID..."
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                />
                <button
                  onClick={addTrapUser}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-lg cursor-pointer"
                >
                  إضافة
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {honeypotTrap.whitelistUserIds.map((id) => (
                  <span
                    key={id}
                    className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300 font-mono flex items-center gap-1"
                  >
                    <span>{id}</span>
                    <button onClick={() => removeTrapUser(id)} className="text-slate-500 hover:text-red-400">
                      ✕
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
