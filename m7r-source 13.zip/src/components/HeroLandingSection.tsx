import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Zap,
  Sparkles,
  CheckCircle2,
  Terminal,
  Copy,
  Check,
  Search,
  Server,
  Lock,
  Ticket,
  Mic,
  Gamepad2,
  Bot,
  Sliders,
  LayoutGrid,
  Users,
  Activity,
  Award,
  Layers,
  Send,
  Star,
  AlertTriangle,
  RefreshCw,
  Hash,
  ExternalLink
} from 'lucide-react';
import { sound } from '../utils/sound';
import { launchOfficialDiscordOAuthWindow } from './TokenAuthGate';

export type Language = 'ar' | 'en';

interface HeroLandingSectionProps {
  onOpenLoginPrompt?: () => void;
  onEnterLiveDashboard?: () => void;
  onOpenServerSelectorHub?: () => void;
  onOpenDashboardTab?: (tabId: string) => void;
  onOpenSidebarMenu?: () => void;
  onInstallAppClick?: () => void;
  ping?: number;
  lang?: Language;
  isStandaloneLanding?: boolean;
  isAuthenticated?: boolean;
  selectedGuild?: {
    id: string;
    name: string;
    icon?: string;
    memberCount?: number;
    channelsCount?: number;
  } | null;
}

interface SlashCommandItem {
  cmd: string;
  category: 'protection' | 'tickets' | 'admin' | 'voice' | 'games';
  categoryLabel: string;
  desc: string;
  usage: string;
  badge: string;
}

const SLASH_COMMANDS_CATALOG: SlashCommandItem[] = [
  {
    cmd: '/antiraid',
    category: 'protection',
    categoryLabel: 'الحماية المتقدمة',
    desc: 'تفعيل درع الحماية الفوري ضد الهجمات الجماعية والروابط المشبوهة وتصفير الرتب الخطر.',
    usage: '/antiraid mode:strict action:quarantine',
    badge: 'حماية فورية'
  },
  {
    cmd: '/lockdown',
    category: 'protection',
    categoryLabel: 'الحماية المتقدمة',
    desc: 'إغلاق طوارئ شامل لجميع رومات السيرفر بضغطة زر واحدة مع إشعار أمني للإدارة.',
    usage: '/lockdown reason:Emergency Security Shield',
    badge: 'طوارئ'
  },
  {
    cmd: '/ticket-panel',
    category: 'tickets',
    categoryLabel: 'التذاكر الذكية',
    desc: 'نشر لوحة تذاكر تفاعلية بأقسام متعددة وأزرار استلام التذكرة وتقييم الإداري من 1 إلى 5 نجوم.',
    usage: '/ticket-panel channel:#support style:royal',
    badge: 'تفاعلي'
  },
  {
    cmd: '/transcript',
    category: 'tickets',
    categoryLabel: 'التذاكر الذكية',
    desc: 'توليد أرشيف محادثة كامل للتذكرة مع إحصائيات سرعة الاستجابة وتقييم العضو.',
    usage: '/transcript ticket:#ticket-1042',
    badge: 'أرشفة'
  },
  {
    cmd: '/tempvoice-setup',
    category: 'voice',
    categoryLabel: 'الرومات الصوتية',
    desc: 'إنشاء روم صوتي ذكي يولّد رومات خاصة مؤقتة للأعضاء مع لوحة تحكم كاملة بالصلاحيات.',
    usage: '/tempvoice-setup hub:#إنشاء-روم',
    badge: 'صوتي ذكي'
  },
  {
    cmd: '/autoreply',
    category: 'admin',
    categoryLabel: 'الإدارة والأتمتة',
    desc: 'إضافة رد تلقائي ذكي يدعم الكلمات المفتاحية والإيمبدات المخصصة والرتب التلقائية.',
    usage: '/autoreply trigger:السلام عليكم response:وعليكم السلام ورحمة الله',
    badge: 'أتمتة'
  },
  {
    cmd: '/audit-scan',
    category: 'admin',
    categoryLabel: 'الإدارة والأتمتة',
    desc: 'فحص شامل لصلاحيات الرتب والبوتات المشبوهة وكشف الثغرات الأمنية في السيرفر.',
    usage: '/audit-scan deep:true',
    badge: 'فحص أمني'
  },
  {
    cmd: '/arena',
    category: 'games',
    categoryLabel: 'الفعاليات والألعاب',
    desc: 'تشغيل ساحة التحديات التفاعلية والألعاب الجماعية مع نظام نقاط الصدارة والجوائز.',
    usage: '/arena game:roulette prize:5000',
    badge: 'ترفيه'
  }
];

const BENTO_FEATURES = [
  {
    id: 'protection',
    tabTarget: 'antinuke',
    title: 'درع الحماية الذكي المضاد للتخريب',
    subtitle: 'Anti-Nuke & Anti-Raid',
    desc: 'رصد لحظي لسجل التدقيق (Audit Log) مع سحب فوري لصلاحيات المخربين، ومنع البوتات غير الموثقة، وحماية الرومات والرتب من الحذف العشوائي.',
    metrics: '0.02 ثانية زمن الرصد والعزل',
    accent: '#38bdf8',
    icon: ShieldCheck,
    colSpan: 'lg:col-span-7'
  },
  {
    id: 'tickets',
    tabTarget: 'tickets',
    title: 'منظومة التذاكر وتقييم الإدارة بالنجوم',
    subtitle: 'Smart Tickets & 5-Star Rating',
    desc: 'لوحات تذاكر متعددة الأقسام مع زر استلام التذكرة (Claim)، إغلاق التذكرة، وتقييم تلقائي للإداري من 1 إلى 5 نجوم مع منشن مباشر في روم التقييمات.',
    metrics: 'تقييم من 1 إلى 5 نجوم + منشن الإداري',
    accent: '#818cf8',
    icon: Ticket,
    colSpan: 'lg:col-span-5'
  },
  {
    id: 'welcome',
    tabTarget: 'welcome',
    title: 'الترحيب الملكي والبطاقات البصرية',
    subtitle: 'Royal Welcome & Visual Cards',
    desc: 'تصميم بطاقات ترحيب مرسومة عالية الدقة مع إيمبدات مخصصة وأزرار اختصار فورية لقوانين السيرفر ورتب التفاعل.',
    metrics: 'إرسال فوري وتجربة حية من الموقع',
    accent: '#10b981',
    icon: Sparkles,
    colSpan: 'lg:col-span-4'
  },
  {
    id: 'automation',
    tabTarget: 'autoreply',
    title: 'الأتمتة والردود التلقائية والرتب',
    subtitle: 'Auto-Responder & Self Roles',
    desc: 'محرك ردود ذكي يتفاعل مع رسائل الأعضاء، مع قوائم اختيار الرتب التفاعلية ونظام الأذكار والرسائل المجدولة.',
    metrics: 'تخصيص مرن بدون كتابة كود',
    accent: '#f59e0b',
    icon: Sliders,
    colSpan: 'lg:col-span-4'
  },
  {
    id: 'games',
    tabTarget: 'games',
    title: 'ساحة الألعاب والفعاليات التفاعلية',
    subtitle: 'Interactive Games & Leaderboards',
    desc: 'مجموعة متكاملة من الألعاب الجماعية والتحديات المباشرة داخل الديسكورد لرفع تفاعل الأعضاء على مدار اليوم.',
    metrics: '+15 فعالية وتحدي تفاعلي',
    accent: '#38bdf8',
    icon: Gamepad2,
    colSpan: 'lg:col-span-4'
  }
];

const COMPARISON_ROWS = [
  {
    feature: 'درع الحماية ضد التخريب وسحب الرتب الفوري (Anti-Nuke)',
    m7r: 'مشمول مجاناً بالكامل',
    others: 'باقات مدفوعة أو بوتات منفصلة'
  },
  {
    feature: 'نظام التذاكر مع استلام التذكرة وتقييم الإداري (1–5 نجوم) ومنشن بروم التقييمات',
    m7r: 'مدمج بالكامل مع الإرسال المباشر من الموقع',
    others: 'محدود ويتطلب اشتراك شهري'
  },
  {
    feature: 'بطاقات وإيمبدات الترحيب الملكية القابلة للتجربة الحية من الموقع',
    m7r: 'مدمج بالكامل مع معاينة وإرسال فوري',
    others: 'تصاميم تقليدية ثابتة'
  },
  {
    feature: 'فحص وتشخيص حالة النظام والتوكن و Redirect URI قبل التشغيل',
    m7r: 'لوحة فحص ذاتي حية ودقيقة',
    others: 'غير متوفر'
  },
  {
    feature: 'واجهة تحكم عربية فائقة السرعة ومزامنة لحظية مع السيرفر',
    m7r: 'مصممة خصيصاً للمجتمعات العربية',
    others: 'واجهات معقدة أو غير معربة'
  }
];

export const HeroLandingSection: React.FC<HeroLandingSectionProps> = ({
  onOpenLoginPrompt,
  onEnterLiveDashboard,
  onOpenServerSelectorHub,
  onOpenDashboardTab,
  ping = 14,
  isAuthenticated = false,
  selectedGuild = null
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [copiedUri, setCopiedUri] = useState<string | null>(null);

  // Live System Health & Isolated Selected Guild State
  const [healthChecking, setHealthChecking] = useState<boolean>(false);
  const [healthData, setHealthData] = useState<any>(null);

  const activeGuildId = isAuthenticated && selectedGuild?.id ? String(selectedGuild.id) : '';
  const activeGuildName = isAuthenticated && selectedGuild?.name ? String(selectedGuild.name) : '';

  const [guildChannels, setGuildChannels] = useState<{ id: string; name: string; type: string }[]>([]);
  const [targetChannelInput, setTargetChannelInput] = useState<string>('');
  const [ratingChannelInput, setRatingChannelInput] = useState<string>('');
  const [staffIdInput, setStaffIdInput] = useState<string>('1219299588402577532');
  const [staffNameInput, setStaffNameInput] = useState<string>('مشرف الدعم الفني');
  const [selectedStars, setSelectedStars] = useState<number>(5);
  const [executingAction, setExecutingAction] = useState<string | null>(null);
  const [executionResult, setExecutionResult] = useState<{
    ok: boolean;
    title: string;
    details: string;
    channelName?: string;
    guildName?: string;
    messageId?: string;
    timestamp: string;
  } | null>(null);

  const runLiveHealthDiagnostic = async () => {
    if (!isAuthenticated) return;
    setHealthChecking(true);
    try {
      const originParam = encodeURIComponent(window.location.origin);
      const guildParam = activeGuildId ? `&guildId=${encodeURIComponent(activeGuildId)}` : '';
      const res = await fetch(`/api/system-health?origin=${originParam}${guildParam}`, {
        credentials: 'include'
      });
      const data = await res.json();
      setHealthData(data);
    } catch (err: any) {
      setHealthData({
        ok: false,
        status: 'degraded',
        error: err?.message || 'تعذر الاتصال بمسار فحص النظام'
      });
    } finally {
      setHealthChecking(false);
    }
  };

  const fetchChannelsForSelectedGuild = async (gId: string) => {
    if (!isAuthenticated || !gId) {
      setGuildChannels([]);
      setTargetChannelInput('');
      setRatingChannelInput('');
      return;
    }
    try {
      const res = await fetch(`/api/guild/channels?guildId=${encodeURIComponent(gId)}`, {
        credentials: 'include'
      });
      if (res.ok) {
        const data = await res.json();
        const textChs = Array.isArray(data.textChannels)
          ? data.textChannels
          : Array.isArray(data.channels)
          ? data.channels.filter((c: any) => c.type === 'text')
          : [];
        setGuildChannels(textChs);
        if (textChs.length > 0) {
          const ticketOrGeneral =
            textChs.find(
              (c: any) =>
                c.name.includes('تذاكر') ||
                c.name.includes('ticket') ||
                c.name.includes('عام') ||
                c.name.includes('chat')
            ) || textChs[0];
          setTargetChannelInput(ticketOrGeneral.id);

          const ratingOrLog =
            textChs.find(
              (c: any) =>
                c.name.includes('تقييم') ||
                c.name.includes('rating') ||
                c.name.includes('اراء') ||
                c.name.includes('لوق') ||
                c.name.includes('log')
            ) || textChs[0];
          setRatingChannelInput(ratingOrLog.id);
        } else {
          setTargetChannelInput('');
          setRatingChannelInput('');
        }
      } else {
        setGuildChannels([]);
      }
    } catch {
      setGuildChannels([]);
    }
  };

  useEffect(() => {
    if (!isAuthenticated) return;
    runLiveHealthDiagnostic();
    const timer = setInterval(runLiveHealthDiagnostic, 20000);
    return () => clearInterval(timer);
  }, [isAuthenticated, activeGuildId]);

  useEffect(() => {
    setGuildChannels([]);
    setTargetChannelInput('');
    setRatingChannelInput('');
    setExecutionResult(null);
    if (isAuthenticated && activeGuildId) {
      fetchChannelsForSelectedGuild(activeGuildId);
    }
  }, [isAuthenticated, activeGuildId]);

  const handleCopyCommand = (usage: string) => {
    sound.playClick();
    navigator.clipboard.writeText(usage).catch(() => {});
    setCopiedCmd(usage);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const handleCopyUri = (uri: string) => {
    sound.playClick();
    navigator.clipboard.writeText(uri).catch(() => {});
    setCopiedUri(uri);
    setTimeout(() => setCopiedUri(null), 2000);
  };

  // REAL Action 1: Deploy Ticket Panel to Live Discord Channel (Strict Single Guild Isolation)
  const handleDeployRealTicketPanel = async () => {
    if (!isAuthenticated || !activeGuildId) return;
    sound.playClick();
    setExecutingAction('deploy_panel');
    setExecutionResult(null);
    try {
      const res = await fetch('/api/tickets/deploy-panel', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guildId: activeGuildId,
          channelId: targetChannelInput.trim(),
          channelName: targetChannelInput.trim(),
          ratingChannelId: ratingChannelInput.trim() || targetChannelInput.trim(),
          ratingChannelName: ratingChannelInput.trim() || targetChannelInput.trim()
        })
      });
      const data = await res.json();
      if (res.ok && data.ok !== false && data.success !== false) {
        sound.playSuccess();
        setExecutionResult({
          ok: true,
          title: 'تم إرسال لوحة التذاكر فعلياً إلى ديسكورد!',
          details: data.message,
          channelName: data.channelName,
          guildName: data.guildName,
          messageId: data.messageId,
          timestamp: new Date().toLocaleTimeString('ar-SA')
        });
      } else {
        setExecutionResult({
          ok: false,
          title: 'فشل إرسال لوحة التذاكر إلى ديسكورد',
          details: data.message || data.error || 'تحقق من صلاحيات البوت أو معرف الروم.',
          timestamp: new Date().toLocaleTimeString('ar-SA')
        });
      }
    } catch (err: any) {
      setExecutionResult({
        ok: false,
        title: 'خطأ في الاتصال بالسيرفر',
        details: err?.message || 'تعذر الاتصال بمسار /api/tickets/deploy-panel',
        timestamp: new Date().toLocaleTimeString('ar-SA')
      });
    } finally {
      setExecutingAction(null);
    }
  };

  // REAL Action 2: Send 5-Star Staff Rating & Bind Rating Channel in Discord
  const handleSendRealStaffRating = async (mode: 'both' | 'prompt' | 'result' = 'both') => {
    if (!isAuthenticated || !activeGuildId) return;
    sound.playClick();
    setExecutingAction('send_rating');
    setExecutionResult(null);
    try {
      const res = await fetch('/api/tickets/test-rating', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guildId: activeGuildId,
          ratingChannelId: (ratingChannelInput || targetChannelInput).trim(),
          ratingChannelName: (ratingChannelInput || targetChannelInput).trim(),
          staffId: staffIdInput.trim() || '1219299588402577532',
          staffUsername: staffNameInput.trim() || 'إداري الدعم الفني',
          stars: selectedStars,
          mode
        })
      });
      const data = await res.json();
      if (res.ok && data.ok !== false && data.success !== false) {
        sound.playSuccess();
        setExecutionResult({
          ok: true,
          title: `تم اعتماد روم التقييمات وإرسال التقييم (${selectedStars} نجوم) فعلياً!`,
          details: data.message,
          channelName: data.channelName,
          guildName: data.guildName,
          messageId: data.messageId,
          timestamp: new Date().toLocaleTimeString('ar-SA')
        });
      } else {
        setExecutionResult({
          ok: false,
          title: 'فشل إرسال التقييم إلى ديسكورد',
          details: data.message || data.error || 'تأكد من صحة معرف روم التقييمات.',
          timestamp: new Date().toLocaleTimeString('ar-SA')
        });
      }
    } catch (err: any) {
      setExecutionResult({
        ok: false,
        title: 'خطأ في الاتصال بالسيرفر',
        details: err?.message || 'تعذر الاتصال بمسار /api/tickets/test-rating',
        timestamp: new Date().toLocaleTimeString('ar-SA')
      });
    } finally {
      setExecutingAction(null);
    }
  };

  // REAL Action 3: Send Royal Welcome Card & Embed to Live Discord Channel
  const handleSendRealWelcome = async () => {
    if (!isAuthenticated || !activeGuildId) return;
    sound.playClick();
    setExecutingAction('send_welcome');
    setExecutionResult(null);
    try {
      const res = await fetch('/api/welcome/test', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guildId: activeGuildId,
          channelId: targetChannelInput.trim(),
          channelName: targetChannelInput.trim()
        })
      });
      const data = await res.json();
      if (res.ok && data.ok !== false && data.success !== false) {
        sound.playSuccess();
        setExecutionResult({
          ok: true,
          title: 'تم إرسال بطاقة وإيمبد الترحيب الملكي فعلياً إلى ديسكورد!',
          details: data.message,
          channelName: data.channelName,
          guildName: data.guildName,
          messageId: data.messageId,
          timestamp: new Date().toLocaleTimeString('ar-SA')
        });
      } else {
        setExecutionResult({
          ok: false,
          title: 'فشل إرسال رسالة الترحيب إلى ديسكورد',
          details: data.message || data.error || 'تأكد من اختيار الروم الصحيح.',
          timestamp: new Date().toLocaleTimeString('ar-SA')
        });
      }
    } catch (err: any) {
      setExecutionResult({
        ok: false,
        title: 'خطأ في الاتصال بالسيرفر',
        details: err?.message || 'تعذر الاتصال بمسار /api/welcome/test',
        timestamp: new Date().toLocaleTimeString('ar-SA')
      });
    } finally {
      setExecutingAction(null);
    }
  };

  const filteredCommands = SLASH_COMMANDS_CATALOG.filter((item) => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch =
      !searchQuery.trim() ||
      item.cmd.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.desc.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const devCallbackUri =
    healthData?.oauth2Readiness?.devRedirectUri ||
    'https://ais-dev-3d6x76wht4gxuksotfbupe-804593892274.europe-west2.run.app/auth/discord/callback';
  const preCallbackUri =
    healthData?.oauth2Readiness?.preRedirectUri ||
    'https://ais-pre-3d6x76wht4gxuksotfbupe-804593892274.europe-west2.run.app/auth/discord/callback';

  const triggerDiscordLogin = () => {
    sound.playClick();
    if (onOpenLoginPrompt) {
      onOpenLoginPrompt();
    } else {
      launchOfficialDiscordOAuthWindow();
    }
  };

  // ============================================================================
  // RULE 1: GUEST VISITOR VIEW BEFORE LOGIN (عرض تسجيل الدخول والمزايا فقط)
  // ============================================================================
  if (!isAuthenticated) {
    return (
      <div dir="rtl" className="w-full text-white space-y-16 pb-16 select-none">
        {/* Centered Hero with "تسجيل الدخول عبر Discord" CTA ONLY */}
        <section className="relative pt-6 sm:pt-12 text-center max-w-4xl mx-auto space-y-7">
          <div className="inline-flex flex-wrap items-center justify-center gap-2.5 px-4 py-1.5 rounded-xl bg-[#0b101b] border border-[#38bdf8]/35 mx-auto">
            <span className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse" />
            <span className="text-xs font-bold text-[#38bdf8] tracking-wide">
              M7R • البوت العربي المتكامل لإدارة وحماية مجتمعات Discord
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black leading-[1.18] tracking-tight text-white">
            حماية فورية، تذاكر ذكية،{' '}
            <span className="bg-gradient-to-l from-[#38bdf8] via-[#60a5fa] to-[#818cf8] bg-clip-text text-transparent">
              وتحكم كامل بسيرفرك
            </span>
          </h1>

          <p className="text-sm sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
            سجّل الدخول عبر حسابك الرسمي في Discord لفحص السيرفرات التي تملك فيها صلاحية الإدارة،
            إضافة البوت لأي سيرفر جديد بضغطة زر، وفتح لوحة التحكم والأوامر المعزولة لكل سيرفر على حدة.
          </p>

          <div className="flex flex-col items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={triggerDiscordLogin}
              className="px-8 py-4 rounded-2xl bg-[#5865F2] hover:bg-[#4752C4] text-white font-black text-base sm:text-lg flex items-center justify-center gap-3 shadow-[0_14px_40px_rgba(88,101,242,0.45)] transition-all cursor-pointer hover:scale-[1.02]"
            >
              <ExternalLink className="w-5 h-5" />
              <span>تسجيل الدخول عبر Discord</span>
            </button>

            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#0b101b]/90 border border-white/10 text-xs text-slate-400">
              <Lock className="w-3.5 h-3.5 text-[#38bdf8]" />
              <span>تظهر قوائم السيرفرات والرومات والأوامر وأدوات الإرسال فقط بعد إتمام تسجيل الدخول الرسمي</span>
            </div>
          </div>
        </section>

        {/* M7R Feature Bento Grid Showcase */}
        <section id="m7r-modules-showcase" className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-2 text-xs font-bold text-[#38bdf8]">
                <Layers className="w-4 h-4" />
                <span>مزايا وإمكانيات بوت M7R</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white">
                منظومة قيادة متكاملة تغنيك عن عشرات البوتات
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 max-w-md">
              سجّل الدخول عبر Discord لاختيار سيرفرك وتفعيل هذه المزايا فوراً.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {BENTO_FEATURES.map((feat) => {
              const IconComponent = feat.icon;
              return (
                <div
                  key={feat.id}
                  onClick={triggerDiscordLogin}
                  className={`${feat.colSpan} group relative rounded-2xl bg-[#0b101b]/90 hover:bg-[#0f172a] border border-white/[0.08] hover:border-[#5865F2]/60 p-6 transition-all duration-200 cursor-pointer flex flex-col justify-between overflow-hidden`}
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between gap-3">
                      <div className="w-11 h-11 rounded-xl bg-[#05070c] border border-white/10 flex items-center justify-center text-[#38bdf8]">
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <span className="text-[11px] font-mono text-slate-400 bg-white/[0.03] px-2.5 py-1 rounded-md border border-white/[0.06]">
                        {feat.subtitle}
                      </span>
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-lg sm:text-xl font-bold text-white group-hover:text-[#38bdf8] transition-colors">
                        {feat.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{feat.desc}</p>
                    </div>
                  </div>

                  <div className="pt-5 mt-5 border-t border-white/[0.06] flex items-center justify-between text-xs">
                    <span className="font-mono text-[#10b981] font-semibold">{feat.metrics}</span>
                    <span className="text-[#818cf8] group-hover:text-white font-bold flex items-center gap-1">
                      <span>سجّل الدخول للتفعيل</span>
                      <span>&larr;</span>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Feature Comparison Table */}
        <section id="m7r-comparison-section" className="space-y-6">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#10b981]">
              <Award className="w-4 h-4" />
              <span>لماذا يختار القادة منظومة M7R؟</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              مقارنة الأداء والمزايا القياسية
            </h2>
          </div>

          <div className="rounded-2xl bg-[#0b101b]/95 border border-white/10 overflow-hidden">
            <div className="grid grid-cols-12 bg-[#070a12] border-b border-white/10 px-5 py-3.5 text-xs font-black text-slate-300">
              <div className="col-span-6">الميزة التنافسية</div>
              <div className="col-span-3 text-center text-[#38bdf8]">منظومة M7R</div>
              <div className="col-span-3 text-center text-slate-500">البوتات التقليدية</div>
            </div>

            <div className="divide-y divide-white/[0.06]">
              {COMPARISON_ROWS.map((row, index) => (
                <div
                  key={index}
                  className="grid grid-cols-12 items-center px-5 py-4 text-xs sm:text-sm hover:bg-white/[0.02] transition-colors"
                >
                  <div className="col-span-6 font-bold text-slate-200 pr-2">{row.feature}</div>
                  <div className="col-span-3 text-center">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#10b981]/15 border border-[#10b981]/30 text-[#10b981] text-xs font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      <span>{row.m7r}</span>
                    </span>
                  </div>
                  <div className="col-span-3 text-center text-xs text-slate-500">{row.others}</div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div dir="rtl" className="w-full text-white space-y-16 pb-16 select-none">
      {/* ============================================================================
          1. HERO SECTION + LIVE DISCORD EXECUTION CONSOLE (LOCKED TO SELECTED GUILD)
      ============================================================================ */}
      <section className="relative pt-4 lg:pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
          {/* Right Column in RTL (Hero Copy & Primary Actions) */}
          <div className="lg:col-span-6 space-y-6 text-right">
            <div className="inline-flex flex-wrap items-center gap-2.5 px-3.5 py-1.5 rounded-lg bg-[#0b101b] border border-[#38bdf8]/30">
              <span className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse" />
              <span className="text-xs font-bold text-[#38bdf8] tracking-wide">
                M7R • تحكم معزول لسيرفر ({activeGuildName || 'السيرفر المختار'})
              </span>
              <span className="text-[11px] font-mono text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded tabular-nums">
                {healthData?.botGateway?.connected
                  ? `متصل فعلياً (${healthData.botGateway.wsPing || ping}ms)`
                  : `Ping ${ping}ms`}
              </span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black leading-[1.18] tracking-tight text-white">
              إدارة سيرفر{' '}
              <span className="bg-gradient-to-l from-[#38bdf8] via-[#60a5fa] to-[#818cf8] bg-clip-text text-transparent">
                {activeGuildName || 'M7R'}
              </span>{' '}
              بأقصى قوة وأمان
            </h1>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl font-normal">
              جميع الرومات والأوامر والتذاكر والتقييمات في هذه الصفحة مخصصة ومعزولة بالكامل لسيرفر{' '}
              <span className="text-white font-bold">{activeGuildName}</span> فقط، مع ربط حي ومباشر ببوت{' '}
              <span className="text-white font-bold font-mono">M7R</span>.
            </p>

            {/* Primary CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-1">
              {onOpenDashboardTab && (
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    onOpenDashboardTab('tickets');
                  }}
                  className="px-6 py-3.5 rounded-xl bg-gradient-to-l from-[#38bdf8] to-[#818cf8] hover:opacity-95 text-[#05070c] font-black text-sm flex items-center gap-2.5 shadow-[0_10px_30px_rgba(56,189,248,0.25)] transition-all cursor-pointer"
                >
                  <Ticket className="w-4 h-4" />
                  <span>فتح استوديو التذاكر والتقييمات</span>
                </button>
              )}

              {onOpenDashboardTab && (
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    onOpenDashboardTab('commands');
                  }}
                  className="px-5 py-3.5 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg"
                >
                  <Terminal className="w-4 h-4" />
                  <span>إدارة جميع الأوامر</span>
                </button>
              )}

              {onOpenServerSelectorHub && (
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    onOpenServerSelectorHub();
                  }}
                  className="px-5 py-3.5 rounded-xl bg-[#0b101b] hover:bg-[#11192b] text-slate-100 border border-[#38bdf8]/35 font-bold text-sm flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Server className="w-4 h-4 text-[#38bdf8]" />
                  <span>تبديل السيرفر</span>
                </button>
              )}
            </div>

            {/* Key Performance Metrics Strip */}
            <div className="grid grid-cols-3 gap-3 pt-2 border-t border-white/10">
              <div className="p-3.5 rounded-xl bg-[#0b101b]/90 border border-white/[0.07]">
                <div className="text-xs text-slate-400 font-semibold">حالة البوت الحية</div>
                <div className="text-lg sm:text-xl font-black text-[#10b981] font-mono mt-0.5 tabular-nums">
                  {healthData?.botGateway?.botTag || 'M7R#1624'}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">متصل بسيرفرك مباشرة</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#0b101b]/90 border border-white/[0.07]">
                <div className="text-xs text-slate-400 font-semibold">رومات السيرفر الحية</div>
                <div className="text-lg sm:text-xl font-black text-[#38bdf8] font-mono mt-0.5 tabular-nums">
                  {guildChannels.length} روم نصي
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">معزولة لهذا السيرفر فقط</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#0b101b]/90 border border-white/[0.07]">
                <div className="text-xs text-slate-400 font-semibold">زمن الاستجابة</div>
                <div className="text-lg sm:text-xl font-black text-[#818cf8] font-mono mt-0.5 tabular-nums">
                  {healthData?.botGateway?.wsPing || ping}ms
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">بنية سحابية مستقرة</div>
              </div>
            </div>
          </div>

          {/* Left Column in RTL: REAL LIVE DISCORD COMMAND & EMBED EXECUTION CONSOLE (LOCKED TO SELECTED GUILD) */}
          <div className="lg:col-span-6">
            <div className="rounded-2xl bg-[#0b101b]/95 border border-[#38bdf8]/30 shadow-[0_24px_60px_rgba(0,0,0,0.65)] overflow-hidden backdrop-blur-xl">
              {/* Top Console Bar */}
              <div className="px-4 py-3.5 bg-[#070a12] border-b border-white/10 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-[#38bdf8]" />
                  <span className="text-xs font-black text-white">
                    وحدة الإرسال والتنفيذ المباشر • {activeGuildName || 'السيرفر'}
                  </span>
                </div>
                <span className="px-2.5 py-1 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-black">
                  ● تنفيذ حقيقي 100% معزول
                </span>
              </div>

              <div className="p-5 space-y-4">
                {/* Step 1: Locked Selected Server Badge + Target Channel Dropdown (ONLY THIS SERVER'S CHANNELS!) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-black text-slate-300 mb-1.5">
                      1. السيرفر النشط حالياً (معزول):
                    </label>
                    <div className="w-full bg-[#060911] border border-emerald-500/35 rounded-xl px-3 py-2.5 text-xs font-bold text-white flex items-center justify-between gap-2">
                      <span className="truncate">{activeGuildName || 'غير محدد'}</span>
                      <span className="text-[10px] font-mono text-emerald-400 shrink-0 tabular-nums">
                        {activeGuildId}
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-black text-slate-300 mb-1.5">
                      2. رومات هذا السيرفر فقط ({guildChannels.length}):
                    </label>
                    <select
                      value={
                        guildChannels.some((c) => c.id === targetChannelInput)
                          ? targetChannelInput
                          : ''
                      }
                      onChange={(e) => {
                        if (e.target.value) setTargetChannelInput(e.target.value);
                      }}
                      className="w-full bg-[#060911] border border-white/15 rounded-xl px-3 py-2.5 text-xs font-bold text-white focus:outline-none focus:border-[#38bdf8]"
                    >
                      <option value="">-- اختر روماً نصياً من {activeGuildName} ({guildChannels.length}) --</option>
                      {guildChannels.map((ch) => (
                        <option key={ch.id} value={ch.id}>
                          #{ch.name} (ID: {ch.id})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Direct Channel ID or Name Input */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-black text-sky-300 mb-1.5">
                      معرف أو اسم روم الإرسال (التذاكر / الترحيب):
                    </label>
                    <div className="flex items-center bg-[#060911] border border-sky-500/30 rounded-xl px-3 py-2">
                      <Hash className="w-4 h-4 text-sky-400 ml-1.5 shrink-0" />
                      <input
                        type="text"
                        value={targetChannelInput}
                        onChange={(e) => setTargetChannelInput(e.target.value)}
                        placeholder="الصق Channel ID من هذا السيرفر..."
                        className="w-full bg-transparent text-xs font-mono font-bold text-white focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-black text-amber-300 mb-1.5">
                      معرف أو اسم روم التقييمات (لتقييم الإدارة 1–5 نجوم):
                    </label>
                    <div className="flex items-center bg-[#060911] border border-amber-500/30 rounded-xl px-3 py-2">
                      <Star className="w-4 h-4 text-amber-400 ml-1.5 shrink-0" />
                      <input
                        type="text"
                        value={ratingChannelInput}
                        onChange={(e) => setRatingChannelInput(e.target.value)}
                        placeholder="Channel ID روم التقييمات في هذا السيرفر..."
                        className="w-full bg-transparent text-xs font-mono font-bold text-white focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Staff Rating Configuration Row */}
                <div className="p-3.5 rounded-xl bg-[#070a12] border border-white/10 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                      <Award className="w-4 h-4 text-amber-400" />
                      إعداد تقييم الإداري بالنجوم (مع منشن مباشر في روم التقييمات)
                    </span>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((starNum) => (
                        <button
                          key={starNum}
                          type="button"
                          onClick={() => setSelectedStars(starNum)}
                          className={`px-2 py-1 rounded-lg text-xs font-black transition-all cursor-pointer ${
                            selectedStars >= starNum
                              ? 'bg-amber-500/20 border border-amber-400/50 text-amber-300'
                              : 'bg-white/5 border border-white/10 text-slate-500'
                          }`}
                        >
                          ★ {starNum}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <input
                      type="text"
                      value={staffIdInput}
                      onChange={(e) => setStaffIdInput(e.target.value)}
                      placeholder="معرف الإداري (Discord User ID) للمنشن..."
                      className="bg-[#0b101b] border border-white/10 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                    />
                    <input
                      type="text"
                      value={staffNameInput}
                      onChange={(e) => setStaffNameInput(e.target.value)}
                      placeholder="اسم الإداري المستلم للتذكرة..."
                      className="bg-[#0b101b] border border-white/10 rounded-lg px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* Real Execution Action Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <button
                    type="button"
                    onClick={handleDeployRealTicketPanel}
                    disabled={executingAction !== null || !activeGuildId}
                    className="py-3 px-3 rounded-xl bg-gradient-to-l from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
                  >
                    {executingAction === 'deploy_panel' ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Ticket className="w-4 h-4" />
                    )}
                    <span>إرسال لوحة التذاكر للديسكورد</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSendRealStaffRating('both')}
                    disabled={executingAction !== null || !activeGuildId}
                    className="py-3 px-3 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-[#05070c] font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
                  >
                    {executingAction === 'send_rating' ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Star className="w-4 h-4" />
                    )}
                    <span>إرسال التقييم ({selectedStars}★) لروم التقييمات</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSendRealWelcome}
                    disabled={executingAction !== null || !activeGuildId}
                    className="py-3 px-3 rounded-xl bg-gradient-to-l from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#05070c] font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
                  >
                    {executingAction === 'send_welcome' ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                    <span>إرسال الترحيب الملكي للديسكورد</span>
                  </button>
                </div>

                {/* Real Execution Result / Error Output Box */}
                {executionResult && (
                  <div
                    className={`p-4 rounded-xl border text-right space-y-1.5 ${
                      executionResult.ok
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-200'
                        : 'bg-rose-500/10 border-rose-500/40 text-rose-200'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-black flex items-center gap-1.5">
                        {executionResult.ok ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        ) : (
                          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                        )}
                        {executionResult.title}
                      </span>
                      <span className="text-[10px] font-mono opacity-75 tabular-nums">
                        {executionResult.timestamp}
                      </span>
                    </div>
                    <p className="text-xs leading-relaxed font-semibold">{executionResult.details}</p>
                    {executionResult.ok && (
                      <div className="flex flex-wrap items-center gap-2 pt-1 text-[11px] font-mono">
                        {executionResult.guildName && (
                          <span className="px-2 py-0.5 rounded bg-black/30 border border-white/10">
                            السيرفر: {executionResult.guildName}
                          </span>
                        )}
                        {executionResult.channelName && (
                          <span className="px-2 py-0.5 rounded bg-black/30 border border-white/10">
                            الروم: #{executionResult.channelName}
                          </span>
                        )}
                        {executionResult.messageId && (
                          <span className="px-2 py-0.5 rounded bg-black/30 border border-white/10 tabular-nums">
                            Message ID: {executionResult.messageId}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================================================
          2. PRE-FLIGHT SYSTEM HEALTH & DIAGNOSTIC SECTION (فحص وتشخيص النظام قبل التشغيل)
      ============================================================================ */}
      <section
        id="m7r-system-diagnostics"
        className="rounded-2xl bg-[#0b101b]/95 border border-[#38bdf8]/25 p-6 sm:p-7 space-y-5 shadow-xl"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#38bdf8]">
              <Activity className="w-4 h-4 text-[#10b981]" />
              <span>قسم فحص وتشخيص النظام قبل التشغيل (Pre-Flight System Diagnostics)</span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white">
              فحص اتصال البوت والتوكن وإعدادات Discord OAuth2 و Redirect URI
            </h2>
          </div>

          <button
            type="button"
            onClick={() => {
              sound.playClick();
              runLiveHealthDiagnostic();
            }}
            disabled={healthChecking}
            className="px-4 py-2.5 rounded-xl bg-[#05070c] hover:bg-white/5 border border-[#38bdf8]/40 text-xs font-black text-[#38bdf8] flex items-center gap-2 cursor-pointer self-start sm:self-auto"
          >
            <RefreshCw className={`w-4 h-4 ${healthChecking ? 'animate-spin' : ''}`} />
            <span>{healthChecking ? 'جاري الفحص الشامل...' : 'إعادة فحص النظام الآن'}</span>
          </button>
        </div>

        {/* 4 Diagnostic Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-[#060911] border border-white/10 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400">1. اتصال بوابة البوت</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-black ${
                  healthData?.botGateway?.connected
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                }`}
              >
                {healthData?.botGateway?.connected ? 'متصل بنجاح' : 'غير متصل'}
              </span>
            </div>
            <div className="text-sm font-black text-white font-mono">
              {healthData?.botGateway?.botTag || 'M7R#1624'}
            </div>
            <div className="text-[11px] text-slate-400">
              {healthData?.botGateway?.statusText || 'جاري التحقق من اتصال البوت...'}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#060911] border border-white/10 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400">2. حالة توكن البوت</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-black ${
                  healthData?.envCheck?.DISCORD_TOKEN
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                }`}
              >
                {healthData?.envCheck?.DISCORD_TOKEN ? 'صالح ومفعل' : 'غير مضبوط'}
              </span>
            </div>
            <div className="text-sm font-black text-white font-mono tabular-nums">
              App ID: {healthData?.botGateway?.botId || '1564565916216336494'}
            </div>
            <div className="text-[11px] text-slate-400">
              السيرفر النشط: {activeGuildName}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#060911] border border-white/10 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400">3. مصادقة Discord OAuth2</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-black ${
                  healthData?.oauth2Readiness?.ok
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                }`}
              >
                {healthData?.oauth2Readiness?.ok ? 'جاهز للعمل' : 'يحتاج ضبط'}
              </span>
            </div>
            <div className="text-sm font-black text-white font-mono tabular-nums">
              Client ID:{' '}
              {healthData?.oauth2Readiness?.envClientId ||
                healthData?.oauth2Readiness?.activeBotClientId ||
                '1564565916216336494'}
            </div>
            <div className="text-[11px] text-slate-400">
              {healthData?.oauth2Readiness?.clientSecretConfigured
                ? 'CLIENT_SECRET مفعّل (Code Exchange)'
                : 'يعمل عبر Token Grant المباشر'}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#060911] border border-white/10 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400">4. قاعدة البيانات والأوامر</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                معزولة لهذا السيرفر 100%
              </span>
            </div>
            <div className="text-sm font-black text-white font-mono tabular-nums">
              {healthData?.databaseSync?.transcriptsCount ?? 0} أرشيف تذاكر •{' '}
              {healthData?.databaseSync?.ratedStaffCount ?? 0} إداري مقيم
            </div>
            <div className="text-[11px] text-slate-400">حفظ تلقائي معزول للإعدادات وروم التقييمات</div>
          </div>
        </div>

        {/* Redirect URI Copy Helper & Diagnostic Warnings */}
        <div className="p-4 rounded-xl bg-[#060911] border border-indigo-500/30 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-black text-indigo-300">
              روابط Redirect URI الرسمية التي يجب إضافتها في Discord Developer Portal &rarr; OAuth2 &rarr; Redirects:
            </span>
            <span className="text-[11px] text-slate-400">اضغط لنسخ الرابط مباشرة</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {[devCallbackUri, preCallbackUri].map((uri) => (
              <div
                key={uri}
                className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-[#0b101b] border border-white/10"
              >
                <code className="text-[11px] font-mono text-sky-300 truncate" dir="ltr">
                  {uri}
                </code>
                <button
                  type="button"
                  onClick={() => handleCopyUri(uri)}
                  className="px-2.5 py-1 rounded bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-200 text-[11px] font-bold flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  {copiedUri === uri ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ الرابط</span>
                    </>
                  )}
                </button>
              </div>
            ))}
          </div>

          {Array.isArray(healthData?.warnings) && healthData.warnings.length > 0 && (
            <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-1">
              {healthData.warnings.map((w: string, i: number) => (
                <div key={i} className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{w}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ============================================================================
          3. CYBER-COMMAND BENTO GRID SHOWCASE (شبكة المزايا المتكاملة)
      ============================================================================ */}
      <section id="m7r-modules-showcase" className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#38bdf8]">
              <Layers className="w-4 h-4" />
              <span>هندسة الأنظمة المتكاملة</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              منظومة قيادة متكاملة تغنيك عن عشرات البوتات
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md">
            اضغط على أي نظام لفتحه مباشرة في لوحة التحكم وتخصيصه لسيرفرك.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {BENTO_FEATURES.map((feat) => {
            const IconComponent = feat.icon;
            return (
              <div
                key={feat.id}
                onClick={() => {
                  sound.playClick();
                  if (onOpenDashboardTab) {
                    onOpenDashboardTab(feat.tabTarget);
                  } else if (onEnterLiveDashboard) {
                    onEnterLiveDashboard();
                  }
                }}
                className={`${feat.colSpan} group relative rounded-2xl bg-[#0b101b]/90 hover:bg-[#0f172a] border border-white/[0.08] hover:border-[#38bdf8]/40 p-6 transition-all duration-200 cursor-pointer flex flex-col justify-between overflow-hidden`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="w-11 h-11 rounded-xl bg-[#05070c] border border-white/10 flex items-center justify-center text-[#38bdf8]">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-mono text-slate-400 bg-white/[0.03] px-2.5 py-1 rounded-md border border-white/[0.06]">
                      {feat.subtitle}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-lg sm:text-xl font-bold text-white group-hover:text-[#38bdf8] transition-colors">
                      {feat.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{feat.desc}</p>
                  </div>
                </div>

                <div className="pt-5 mt-5 border-t border-white/[0.06] flex items-center justify-between text-xs">
                  <span className="font-mono text-[#10b981] font-semibold">{feat.metrics}</span>
                  <span className="text-slate-300 group-hover:text-white font-bold flex items-center gap-1">
                    <span>ضبط النظام</span>
                    <span>&larr;</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ============================================================================
          4. INTERACTIVE SLASH COMMANDS EXPLORER (دليل أوامر السلاش التفاعلي)
      ============================================================================ */}
      <section id="m7r-commands-explorer" className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#818cf8]">
              <Terminal className="w-4 h-4" />
              <span>دليل الأوامر السريعة (Slash Commands)</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              أوامر ديسكورد جاهزة للنسخ والتنفيذ الفوري
            </h2>
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن أمر مثل /ticket-panel..."
              className="w-full bg-[#0b101b] border border-white/10 focus:border-[#38bdf8]/50 rounded-xl pr-10 pl-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'all', label: 'جميع الأوامر' },
            { id: 'protection', label: 'الحماية المتقدمة' },
            { id: 'tickets', label: 'التذاكر الذكية' },
            { id: 'admin', label: 'الإدارة والأتمتة' },
            { id: 'voice', label: 'الرومات الصوتية' },
            { id: 'games', label: 'الفعاليات والألعاب' }
          ].map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => {
                sound.playClick();
                setSelectedCategory(cat.id);
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer border ${
                selectedCategory === cat.id
                  ? 'bg-[#38bdf8] text-[#05070c] border-[#38bdf8]'
                  : 'bg-[#0b101b] text-slate-300 border-white/10 hover:border-white/25'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCommands.map((item) => (
            <div
              key={item.cmd}
              className="p-5 rounded-xl bg-[#0b101b]/90 border border-white/[0.08] hover:border-[#38bdf8]/35 transition-all flex flex-col justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-black text-[#38bdf8] bg-[#38bdf8]/10 px-2.5 py-1 rounded-md border border-[#38bdf8]/25">
                      {item.cmd}
                    </span>
                    <span className="text-[11px] text-slate-400 font-semibold">
                      {item.categoryLabel}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-[#10b981] bg-[#10b981]/10 px-2 py-0.5 rounded border border-[#10b981]/25">
                    {item.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{item.desc}</p>
              </div>

              <div className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-[#05070c] border border-white/[0.06]">
                <code className="text-[11px] font-mono text-slate-300 truncate" dir="ltr">
                  {item.usage}
                </code>
                <button
                  type="button"
                  onClick={() => handleCopyCommand(item.usage)}
                  className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-xs font-bold text-slate-200 flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  {copiedCmd === item.usage ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#10b981]" />
                      <span className="text-[#10b981]">تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                      <span>نسخ</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ============================================================================
          5. COMPARISON TABLE (جدول المقارنة)
      ============================================================================ */}
      <section id="m7r-comparison-section" className="space-y-6">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-[#10b981]">
            <Award className="w-4 h-4" />
            <span>لماذا يختار القادة منظومة M7R؟</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            مقارنة الأداء والمزايا القياسية
          </h2>
        </div>

        <div className="rounded-2xl bg-[#0b101b]/95 border border-white/10 overflow-hidden">
          <div className="grid grid-cols-12 bg-[#070a12] border-b border-white/10 px-5 py-3.5 text-xs font-black text-slate-300">
            <div className="col-span-6">الميزة التنافسية</div>
            <div className="col-span-3 text-center text-[#38bdf8]">منظومة M7R</div>
            <div className="col-span-3 text-center text-slate-500">البوتات التقليدية</div>
          </div>

          <div className="divide-y divide-white/[0.06]">
            {COMPARISON_ROWS.map((row, index) => (
              <div
                key={index}
                className="grid grid-cols-12 items-center px-5 py-4 text-xs sm:text-sm hover:bg-white/[0.02] transition-colors"
              >
                <div className="col-span-6 font-bold text-slate-200 pr-2">{row.feature}</div>
                <div className="col-span-3 text-center">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#10b981]/15 border border-[#10b981]/30 text-[#10b981] text-xs font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span>{row.m7r}</span>
                  </span>
                </div>
                <div className="col-span-3 text-center text-xs text-slate-500">{row.others}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
