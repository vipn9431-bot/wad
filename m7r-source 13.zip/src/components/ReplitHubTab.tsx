import React, { useState } from 'react';
import {
  Terminal,
  Copy,
  Check,
  Download,
  KeyRound
} from 'lucide-react';
import { sound } from '../utils/sound';

interface ReplitHubTabProps {
  lang: 'ar' | 'en';
}

export const ReplitHubTab: React.FC<ReplitHubTabProps> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [copiedFile, setCopiedFile] = useState<string | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'server' | 'package' | 'env' | 'replit'>('server');

  const serverJsCode = `/**
 * ========================================================
 * M7R Discord Bot + Web Dashboard + Discord OAuth2 + Server Selector
 * Ready for Replit المستمر + UptimeRobot
 * ========================================================
 */

import express from 'express';
import {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
  AuditLogEvent,
  SlashCommandBuilder,
  ChannelType
} from 'discord.js';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.set('trust proxy', 1);
app.use(express.json());
const PORT = process.env.PORT || 3000;
const WEB_DASHBOARD_URL = process.env.WEB_DASHBOARD_URL || 'https://bot-m7r.netlify.app/';
const PREFIX = process.env.PREFIX || '!';
const sessionsMap = new Map();

// ================= STATE & ACTIVE SERVER CONFIG =================
let loggedInUser = {
  id: '1219299588402577532',
  username: 'u5r9',
  avatar: 'https://cdn.discordapp.com/embed/avatars/0.png',
  isLoggedIn: false
};

let selectedGuildId = '1486763846151438456';

let aiRoomConfig = {
  enabled: true,
  allowedChannel: 'all',
  autoReplyWithoutPrefix: true
};

let honeypotTrapConfig = {
  enabled: true,
  channelName: '🚫-ممنوع-الدخول',
  punishment: 'ban', // 'ban' | 'kick' | 'timeout'
  timeoutDurationMinutes: 60,
  deleteMessage: true
};

const FALLBACK_GUILDS = [
  {
    id: '1486763846151438456',
    name: 'M7R Empire ⚜️',
    icon: 'https://cdn.discordapp.com/icons/1486763846151438456/bcd0ce5bcbf335a201189354919525c2.webp',
    memberCount: 146,
    channelsCount: 36,
    owner: true
  },
  {
    id: '1493178407188693112',
    name: 'm7r',
    icon: 'https://cdn.discordapp.com/icons/1493178407188693112/f61be6472a2e8801cab912a46a0165f9.webp',
    memberCount: 72,
    channelsCount: 22,
    owner: true
  },
  {
    id: '1525374225425367171',
    name: '𝐀𝐩𝐞𝐱 ⚜️ / صيد الضبان 🦎',
    icon: 'https://cdn.discordapp.com/icons/1525374225425367171/f62646a01b911a76d02c672d1c97985e.webp',
    memberCount: 306,
    channelsCount: 43,
    owner: false
  },
  {
    id: '1564569257755410523',
    name: "𝓜7𝓡's server",
    icon: '',
    memberCount: 6,
    channelsCount: 7,
    owner: true
  }
];

function getGuildsList() {
  if (botClient && botClient.isReady() && botClient.guilds.cache.size > 0) {
    return Array.from(botClient.guilds.cache.values()).map((g) => ({
      id: g.id,
      name: g.name,
      icon: g.iconURL() || '',
      memberCount: g.memberCount || 0,
      channelsCount: g.channels.cache.size,
      owner: true
    }));
  }
  return FALLBACK_GUILDS;
}

const SENSITIVE_PATTERNS = [
  /توكن|token|باسورد|كلمه سر|كلمة سر|password|secret key|api key|مفتاح سري/i,
  /اختراق|تهكير|هكر|هاكر|hack|exploit|ddos|dox|سحب ايبي|ip grabber/i,
  /تفجير سيرفر|تخريب سيرفر|نوك|nuke bot|raid bot|سبام بوت|كيف اخرب|كيف اهكر/i
];

function isSensitiveQuestion(q) {
  return SENSITIVE_PATTERNS.some((rx) => rx.test(q || ''));
}

const M7R_SYSTEM_INSTRUCTION =
  'أنت الذكاء الاصطناعي الرسمي لبوت M7R، الذي طوره وصنعه u5r9. شخصيتك سعودية ظريفة، مرحة، ذكية جداً، وودودة مع الأعضاء. يجب أن تجيب على أي سؤال يُطرح عليك بدقة وذكاء ومباشرة (سواء كان رياضيات، برمجة، ألعاب، معلومات عامة، أو دردشة) بأسلوب لطيف ومختصر ومرتب مع إيموجيات جميلة.';

function solveArabicMath(input) {
  const eastern = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  let s = String(input || '');
  for (let i = 0; i < 10; i++) s = s.replace(new RegExp(eastern[i], 'g'), String(i));
  s = s
    .replace(/مضروب\\s+في|ضرب|في|[×xX⋅]/gi, ' * ')
    .replace(/مقسوم\\s+على|قسمة|قسمه|تقسيم|على|[÷]/gi, ' / ')
    .replace(/زائد|زايد|جمع|مع/gi, ' + ')
    .replace(/ناقص|طرح/gi, ' - ');
  const m = s.match(/(\\(?\\s*-?\\d+(?:\\.\\d+)?\\s*\\)?(?:\\s*[\\+\\-\\*\\/]\\s*\\(?\\s*-?\\d+(?:\\.\\d+)?\\s*\\)?)+)/);
  if (!m) return null;
  const expr = m[1].trim();
  if (!/^[\\d\\s\\.\\+\\-\\*\\/\\(\\)]+$/.test(expr)) return null;
  try {
    const val = Function('"use strict"; return (' + expr + ');')();
    if (typeof val === 'number' && !Number.isNaN(val)) {
      return { expr: expr.replace(/\\*/g, '×').replace(/\\//g, '÷'), result: Number.isInteger(val) ? val : Number(val.toFixed(4)) };
    }
  } catch {}
  return null;
}

async function askFriendlyM7RAi(question, askerName = 'يا غالي') {
  const cleanQ = (question || '').trim();
  if (!cleanQ) {
    return {
      blocked: false,
      answer: \`اكتب سؤالك وخلنا نسولف! مثال: \\\`/ask\\\` أو اكتب سؤالك مباشرة في #m7r-ai 🤖🤍\`
    };
  }

  if (isSensitiveQuestion(cleanQ)) {
    return {
      blocked: true,
      answer: \`عذراً يا غالي (**\${askerName}**)، لا أستطيع الإجابة على هذا السؤال الحساس حفاظاً على أمان السيرفر 🤍✨\`
    };
  }

  const mathSolved = solveArabicMath(cleanQ);
  const promptForAi = mathSolved
    ? \`\${cleanQ}\\n[معلومة رياضية مؤكدة: ناتج (\${mathSolved.expr}) هو بالضبط (\${mathSolved.result}). أجب بالنتيجة الصحيحة بأسلوبك السعودي الظريف.]\`
    : cleanQ;

  // 1. Primary: Official Google Gemini API (@google/genai)
  if (process.env.GEMINI_API_KEY) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: promptForAi,
        config: {
          systemInstruction: M7R_SYSTEM_INSTRUCTION
        }
      });
      if (response.text) {
        return { blocked: false, answer: response.text.trim() };
      }
    } catch (err) {
      console.log('[M7R AI Gemini Notice]:', err.message);
    }
  }

  // 2. Secondary: Live Free OpenAI-compatible AI Fallback
  try {
    const resp = await fetch('https://text.pollinations.ai/openai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'openai',
        messages: [
          { role: 'system', content: M7R_SYSTEM_INSTRUCTION },
          { role: 'user', content: promptForAi }
        ]
      })
    });
    if (resp.ok) {
      const data = await resp.json();
      const reply = data?.choices?.[0]?.message?.content?.trim();
      if (reply) return { blocked: false, answer: reply };
    }
  } catch (err) {
    console.log('[M7R AI Secondary Fallback Notice]:', err.message);
  }

  if (mathSolved) {
    return {
      blocked: false,
      answer: \`🧮 **الجواب هو: \\\`\${mathSolved.result}\\\`** ✨\\n(\\\`\${mathSolved.expr} = \${mathSolved.result}\\\`) 😎👌\`
    };
  }

  return {
    blocked: false,
    answer: \`أبشر بعزك يا **\${askerName}**! 😎✨ أنا **M7R AI** اللي طوره **u5r9** 👑 — اسألني أي سؤال في الرياضيات أو البرمجة أو الألعاب وأبشر بالجواب الصافي فوراً! 🤖🔥\`
  };
}

function buildM7RAiEmbed(user, answerText, blocked = false) {
  const cleanAns = String(answerText || '').replace(/^يا\\s*هلا\\s*ومليون\\s*غلا[^\\n!！]*[!！]?\\s*/i, '').trim();
  const embed = new EmbedBuilder()
    .setColor(blocked ? '#f59e0b' : '#5865F2')
    .setTitle('M7R AI ✨')
    .setDescription(\`<@\${user.id}>\\nيا هلا ومليون غلا بك يا \${user.username}! 🌸😊\\n\\n\${cleanAns}\`)
    .setFooter({ text: 'Powered by M7R AI • Created by u5r9 👑' });
  return { embeds: [embed] };
}

// ================= 1. EXPRESS المستمر + OAUTH2 + SERVER SELECTION ROUTES =================
app.get(['/ping', '/uptime', '/health'], (req, res) => {
  res.status(200).json({
    status: 'ONLINE_24_7',
    bot: botClient?.user?.tag || 'M7R',
    uptime: process.uptime(),
    ping: botClient?.ws?.ping || 17,
    selectedGuildId
  });
});

// STRICT SERVER FILTERING (MUTUAL GUILDS ONLY): Cross-reference OAuth2 guilds with botClient.guilds.cache
app.get(['/api/guilds', '/api/bot/guilds'], (req, res) => {
  res.json({ success: true, guilds: getGuildsList(), selectedGuildId });
});

app.post('/api/guilds', (req, res) => {
  const oauthGuilds = Array.isArray(req.body?.guilds) ? req.body.guilds : [];
  if (botClient && botClient.isReady()) {
    const mutualGuilds = oauthGuilds
      .filter((g) => botClient.guilds.cache.has(String(g.id)))
      .map((g) => {
        const liveGuild = botClient.guilds.cache.get(String(g.id));
        return {
          id: liveGuild.id,
          name: liveGuild.name,
          icon: liveGuild.iconURL() || '',
          memberCount: liveGuild.memberCount,
          channelsCount: liveGuild.channels.cache.size,
          rolesCount: liveGuild.roles.cache.size,
          owner: Boolean(g.owner),
          hasBot: true,
          botPresent: true
        };
      });
    return res.json({ success: true, guilds: mutualGuilds, selectedGuildId });
  }
  return res.json({ success: true, guilds: getGuildsList(), selectedGuildId });
});

// DYNAMIC CHANNEL & ROLE FETCHING PER SERVER: GET /api/guilds/:guildId/details
app.get('/api/guilds/:guildId/details', (req, res) => {
  const guildId = String(req.params.guildId || '').trim();
  if (!botClient || !botClient.isReady()) {
    return res.status(503).json({ success: false, error: 'Bot client is not ready yet' });
  }
  const guild = botClient.guilds.cache.get(guildId);
  if (!guild) {
    return res.status(404).json({ success: false, error: 'Bot is not a member of this server' });
  }

  selectedGuildId = guild.id;

  const textChannels = guild.channels.cache
    .filter((c) => c.type === ChannelType.GuildText)
    .map((c) => ({ id: c.id, name: c.name, type: 'text', position: c.position || 0 }));

  const voiceChannels = guild.channels.cache
    .filter((c) => c.type === ChannelType.GuildVoice)
    .map((c) => ({ id: c.id, name: c.name, type: 'voice', position: c.position || 0 }));

  const roles = guild.roles.cache
    .filter((r) => r.name !== '@everyone')
    .sort((a, b) => b.position - a.position)
    .map((r) => ({ id: r.id, name: r.name, color: r.hexColor, position: r.position }));

  return res.json({
    success: true,
    live: true,
    guild: {
      id: guild.id,
      name: guild.name,
      icon: guild.iconURL() || '',
      memberCount: guild.memberCount,
      channelsCount: textChannels.length + voiceChannels.length,
      rolesCount: roles.length,
      ownerId: guild.ownerId,
      hasBot: true,
      botPresent: true
    },
    textChannels,
    voiceChannels,
    channels: [...textChannels, ...voiceChannels],
    roles
  });
});

app.post(['/api/guild/select', '/api/bot/select-guild'], (req, res) => {
  const { guildId } = req.body;
  if (!guildId) return res.status(400).json({ error: 'guildId is required' });
  selectedGuildId = String(guildId);
  const guilds = getGuildsList();
  const selectedGuild = guilds.find((g) => g.id === selectedGuildId) || guilds[0];
  res.json({
    success: true,
    selectedGuild,
    redirectUrl: \`/dashboard/\${selectedGuild.id}\`,
    message: \`Switched active server to \${selectedGuild.name}\`
  });
});

// Start Discord OAuth2 Login
app.get(['/auth/discord', '/api/auth/discord'], (req, res) => {
  const clientId = process.env.DISCORD_CLIENT_ID || process.env.CLIENT_ID || botClient?.user?.id || '1564565916216336494';
  const baseUrl = (process.env.APP_URL || \`\${req.protocol}://\${req.get('host')}\`).replace(/\\/$/, '');
  const redirectUri = process.env.DISCORD_REDIRECT_URI || \`\${baseUrl}/auth/discord/callback\`;

  if (process.env.DISCORD_CLIENT_SECRET || process.env.CLIENT_SECRET) {
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: 'identify guilds'
    });
    return res.redirect(\`https://discord.com/oauth2/authorize?\${params.toString()}\`);
  }

  return res.redirect(
    \`https://discord.com/oauth2/authorize?client_id=\${clientId}&permissions=8&scope=bot%20applications.commands\`
  );
});

// Discord OAuth2 Callback -> Hybrid Token + Cross-Origin Cookie + postMessage / ?auth_token= Redirect
app.get(['/auth/callback', '/auth/discord/callback', '/api/auth/discord/callback'], async (req, res) => {
  const { code, guild_id } = req.query;
  const clientId = process.env.DISCORD_CLIENT_ID || process.env.CLIENT_ID || botClient?.user?.id || '1564565916216336494';
  const clientSecret = process.env.DISCORD_CLIENT_SECRET || process.env.CLIENT_SECRET || '';
  const baseUrl = (process.env.APP_URL || \`\${req.protocol}://\${req.get('host')}\`).replace(/\\/$/, '');
  const redirectUri = process.env.DISCORD_REDIRECT_URI || \`\${baseUrl}\${req.path}\`;
  let mutualGuilds = getGuildsList();

  if (code && clientSecret) {
    try {
      const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          grant_type: 'authorization_code',
          code: String(code),
          redirect_uri: redirectUri
        })
      });

      if (tokenRes.ok) {
        const tokenData = await tokenRes.json();
        const [userRes, guildsRes] = await Promise.all([
          fetch('https://discord.com/api/users/@me', {
            headers: { Authorization: \`Bearer \${tokenData.access_token}\` }
          }),
          fetch('https://discord.com/api/users/@me/guilds', {
            headers: { Authorization: \`Bearer \${tokenData.access_token}\` }
          })
        ]);
        if (userRes.ok) {
          const dUser = await userRes.json();
          loggedInUser = {
            id: String(dUser.id),
            username: dUser.global_name || dUser.username,
            avatar: dUser.avatar
              ? \`https://cdn.discordapp.com/avatars/\${dUser.id}/\${dUser.avatar}.png\`
              : 'https://cdn.discordapp.com/embed/avatars/0.png',
            isLoggedIn: true,
            isOwner: String(dUser.id) === '1219299588402577532'
          };
        }
        if (guildsRes.ok && botClient && botClient.isReady()) {
          const rawGuilds = await guildsRes.json();
          mutualGuilds = rawGuilds
            .filter((g) => botClient.guilds.cache.has(String(g.id)))
            .map((g) => {
              const liveG = botClient.guilds.cache.get(String(g.id));
              return {
                id: liveG.id,
                name: liveG.name,
                icon: liveG.iconURL() || '',
                memberCount: liveG.memberCount,
                channelsCount: liveG.channels.cache.size,
                owner: Boolean(g.owner),
                hasBot: true,
                botPresent: true
              };
            });
        }
      }
    } catch (err) {
      console.log('[M7R OAuth2 Notice]:', err.message);
    }
  } else {
    loggedInUser.isLoggedIn = true;
  }

  if (guild_id) {
    selectedGuildId = String(guild_id);
  }

  const generatedToken = \`m7r_auth.\${Buffer.from(JSON.stringify({ ...loggedInUser, ts: Date.now() })).toString('base64url')}\`;
  sessionsMap.set(generatedToken, { user: loggedInUser, guilds: mutualGuilds });

  res.cookie('m7r_session', generatedToken, {
    secure: true,
    sameSite: 'none',
    httpOnly: false,
    maxAge: 7 * 24 * 60 * 60 * 1000
  });

  const targetUrl = \`/?auth_token=\${encodeURIComponent(generatedToken)}\`;

  return res.send(\`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
      <meta charset="UTF-8" />
      <title>جاري التحويل إلى لوحة التحكم...</title>
    </head>
    <body style="background:#07090e;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;">
      <script>
        var authToken = \${JSON.stringify(generatedToken)};
        var authUser = \${JSON.stringify(loggedInUser)};
        var authGuilds = \${JSON.stringify(mutualGuilds)};
        try {
          localStorage.setItem('m7r_auth_token', authToken);
          localStorage.setItem('m7r_session_token', authToken);
          localStorage.setItem('m7r_discord_user', JSON.stringify(authUser));
          localStorage.setItem('m7r_logged_in', 'true');
        } catch (e) {}
        if (window.opener && !window.opener.closed && window.opener !== window) {
          window.opener.postMessage({ type: 'DISCORD_AUTH_SUCCESS', token: authToken, user: authUser, guilds: authGuilds }, '*');
          window.close();
        } else {
          window.location.replace('\${targetUrl}');
        }
      </script>
      <p>✅ تم تسجيل الدخول بنجاح! جاري نقلك إلى لوحة التحكم...</p>
    </body>
    </html>
  \`);
});

// Backend Auth Middleware Route: Checks Authorization: Bearer <token> FIRST, cookies SECOND
app.get(['/api/me', '/api/auth/discord/user'], (req, res) => {
  const authHeader = req.headers.authorization || '';
  const bearerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  const session = sessionsMap.get(bearerToken);
  const activeUser = session?.user || (loggedInUser.isLoggedIn ? loggedInUser : null);
  if (!activeUser) {
    return res.json({ isLoggedIn: false, user: null, guilds: [] });
  }
  const isOwner = String(activeUser.id) === '1219299588402577532';
  return res.json({
    ok: true,
    isLoggedIn: true,
    isOwner,
    accessMode: isOwner ? 'bot_owner' : 'server_admin',
    user: { ...activeUser, isOwner },
    guilds: session?.guilds || getGuildsList()
  });
});

// Interactive Web Dashboard & Server Selector UI
app.get(['/', '/dashboard', '/dashboard/:guildId'], (req, res) => {
  if (req.params.guildId) {
    selectedGuildId = req.params.guildId;
    loggedInUser.isLoggedIn = true;
  }
  const guilds = getGuildsList();
  const currentGuild = guilds.find((g) => g.id === selectedGuildId) || guilds[0];

  res.send(\`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>M7R PRO | لوحة تحكم السيرفرات</title>
      <style>
        * { box-sizing: border-box; }
        body { background: #07090e; color: #f8fafc; font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 24px; }
        .container { max-width: 980px; margin: 0 auto; }
        .header { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 16px; background: #0d111a; border: 1px solid #1e293b; padding: 20px 24px; border-radius: 20px; margin-bottom: 24px; }
        .badge { background: rgba(16,185,129,0.15); color: #34d399; border: 1px solid rgba(16,185,129,0.3); padding: 6px 14px; border-radius: 999px; font-size: 12px; font-weight: bold; }
        .btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 11px 20px; border-radius: 12px; font-weight: bold; font-size: 13px; text-decoration: none; cursor: pointer; border: none; transition: 0.2s; color: #fff; }
        .btn-discord { background: #5865F2; }
        .btn-discord:hover { background: #4752C4; }
        .btn-web { background: #e11d48; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; margin-top: 16px; }
        .server-card { background: #0d111a; border: 1px solid #1e293b; border-radius: 18px; padding: 18px; display: flex; flex-direction: column; justify-content: space-between; gap: 14px; cursor: pointer; transition: 0.2s; }
        .server-card:hover, .server-card.active { border-color: #5865F2; box-shadow: 0 10px 30px rgba(88,101,242,0.18); transform: translateY(-2px); }
        .active-panel { background: linear-gradient(135deg, #131826, #0d111a); border: 1px solid #5865F2; border-radius: 20px; padding: 24px; margin-bottom: 24px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div>
            <span class="badge">🟢 البوت شغال المستمر | Ping: \${botClient?.ws?.ping || 17}ms</span>
            <h1 style="margin: 10px 0 4px; font-size: 22px;">🛡️ مركز تحكم بوت M7R PRO</h1>
            <p style="margin: 0; color: #94a3b8; font-size: 13px;">اختر أي سيرفر بالأسفل للتحكم المباشر أو سجل دخولك عبر ديسكورد</p>
          </div>
          <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a class="btn btn-discord" href="/auth/discord">تسجيل الدخول عبر ديسكورد (OAuth2)</a>
            <a class="btn btn-web" href="\${WEB_DASHBOARD_URL}?guild_id=\${currentGuild.id}" target="_blank">فتح لوحة الويب الكاملة 🌐</a>
          </div>
        </div>

        <div class="active-panel" id="activeServerBox">
          <h2 style="margin:0 0 8px; color:#38bdf8;">⚡ السيرفر المتحكم به حالياً: <span id="activeServerName">\${currentGuild.name}</span></h2>
          <p style="margin:0; color:#cbd5e1; font-size:14px;">
            عدد الأعضاء: <b id="activeServerMembers">\${currentGuild.memberCount}</b> عضو • عدد الرومات: <b id="activeServerChannels">\${currentGuild.channelsCount}</b> روم • المصيدة: <b>\${honeypotTrapConfig.punishment.toUpperCase()}</b>
          </p>
        </div>

        <h3 style="margin: 0 0 10px;">📋 اختر السيرفر لإدارته:</h3>
        <div class="grid">
          \${guilds.map((g) => \`
            <div class="server-card \${g.id === currentGuild.id ? 'active' : ''}" onclick="selectServer('\${g.id}')">
              <div style="display:flex; align-items:center; gap:12px;">
                \${g.icon
                  ? \`<img src="\${g.icon}" style="width:48px;height:48px;border-radius:14px;object-fit:cover;" />\`
                  : \`<div style="width:48px;height:48px;border-radius:14px;background:#1e1b4b;display:flex;align-items:center;justify-content:center;font-weight:bold;">\${g.name.slice(0,2)}</div>\`
                }
                <div>
                  <div style="font-weight:bold; font-size:15px;">\${g.name}</div>
                  <div style="color:#94a3b8; font-size:12px; margin-top:4px;">👥 \${g.memberCount} عضو • 🟢 البوت متواجد</div>
                </div>
              </div>
              <button type="button" class="btn btn-discord" style="width:100%;" onclick="event.stopPropagation(); selectServer('\${g.id}')">
                \${g.id === currentGuild.id ? '✅ السيرفر المختار حالياً' : '⚙️ إدارة السيرفر (Manage)'}
              </button>
            </div>
          \`).join('')}
        </div>
      </div>

      <script>
        async function selectServer(guildId) {
          try {
            const res = await fetch('/api/guild/select', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ guildId })
            });
            const data = await res.json();
            if (data && data.selectedGuild) {
              window.location.href = '/dashboard/' + encodeURIComponent(guildId);
            }
          } catch (err) {
            window.location.href = '/dashboard/' + encodeURIComponent(guildId);
          }
        }
      </script>
    </body>
    </html>
  \`);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(\`[M7R المستمر] Express & OAuth2 Dashboard listening on port \${PORT}\`);
});

// ================= 2. DISCORD BOT CLIENT & EVENTS =================
const botClient = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildModeration
  ],
  partials: [Partials.Message, Partials.Channel, Partials.User]
});

const spamMap = new Map();

botClient.once('ready', async () => {
  console.log(\`[M7R] Logged in as \${botClient.user.tag}!\`);
  botClient.user.setPresence({
    activities: [{ name: 'M7R Security & AI 🛡️' }],
    status: 'dnd'
  });
});

const activeTicketsMap = new Map(); // channelId -> { ownerId, claimedBy, staffRoleId }

// ================= 3. MESSAGES: CLAIM LOCK INTERCEPTOR + HONEYPOT TRAP (DM FIRST) + AI ASK =================
botClient.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild) return;
  const content = message.content.trim();
  const chName = (message.channel.name || '').toLowerCase();

  // A0. Strict Single-Admin Claim Lock Interceptor (blocks other admins even with Administrator flag)
  const ticketState = activeTicketsMap.get(message.channel.id);
  if (ticketState && ticketState.claimedBy) {
    if (message.author.id !== ticketState.ownerId && message.author.id !== ticketState.claimedBy) {
      await message.delete().catch(() => {});
      const warn = await message.channel.send({
        content: \`⚠️ <@\${message.author.id}> هذه التذكرة مستلمة حالياً من قبل <@\${ticketState.claimedBy}> ولا يمكنك التداخل!\`
      }).catch(() => null);
      if (warn) setTimeout(() => warn.delete().catch(() => {}), 6000);
      return;
    }
  }

  // A. Honeypot Trap: 1) Delete msg, 2) Send DM Embed (#FF2A54) FIRST, 3) Execute Kick/Ban
  const trapCh = (honeypotTrapConfig.channelName || '').replace('#', '').trim().toLowerCase();
  if (honeypotTrapConfig.enabled && trapCh && chName === trapCh) {
    if (!message.member?.permissions.has(PermissionFlagsBits.Administrator)) {
      if (honeypotTrapConfig.deleteMessage) {
        await message.delete().catch(() => {});
      }
      const dmEmbed = new EmbedBuilder()
        .setColor('#FF2A54')
        .setTitle('🚨 إشعار حظر/طرد تلقائي | حماية M7R 🛡️')
        .setDescription(
          [
            '╭───────────────────────────╮',
            '⚠️ **لقد تم طردك/حظرك من السيرفر تلقائياً!**',
            '📌 **السبب:** الكتابة في روم مصيدة السبام (Honeypot Trap).',
            \`🏢 **السيرفر:** \${message.guild.name}\`,
            \`⏰ **الوقت:** <t:\${Math.floor(Date.now() / 1000)}:R>\`,
            '╰───────────────────────────╯'
          ].join('\\n')
        )
        .setFooter({ text: 'M7R Security Shield • Honeypot Protection' })
        .setTimestamp();

      // CRITICAL ORDER: Send DM BEFORE kicking or banning
      await message.member?.send({ embeds: [dmEmbed] }).catch(() => {});

      if (honeypotTrapConfig.punishment === 'ban') {
        await message.member?.ban({ reason: 'M7R Honeypot Trap Triggered' }).catch(() => {});
      } else if (honeypotTrapConfig.punishment === 'kick') {
        await message.member?.kick('M7R Honeypot Trap Triggered').catch(() => {});
      } else {
        const ms = (honeypotTrapConfig.timeoutDurationMinutes || 60) * 60 * 1000;
        await message.member?.timeout(ms, 'M7R Honeypot Trap Triggered').catch(() => {});
      }
      return;
    }
  }

  // B. Friendly Gemini-Style AI Ask ("ai ask ...", "!ask ...", "اسال ...") + #m7r-ai Auto-Reply
  const lower = content.toLowerCase();
  const isAiRoom =
    chName.includes('m7r-ai') ||
    chName.includes('m7r•ai') ||
    (aiRoomConfig.allowedChannel !== 'all' && chName === aiRoomConfig.allowedChannel.toLowerCase());
  const isDirectAsk = lower.startsWith('ai ask') || lower.startsWith(\`\${PREFIX}ask\`) || lower.startsWith('اسال ');

  if (isDirectAsk) {
    const questionText = content.replace(/^(!?ai\\s+ask|!ask|اسال)\\s*/i, '').trim();
    await message.channel.sendTyping().catch(() => {});
    const aiRes = await askFriendlyM7RAi(questionText, message.author.username);
    return message.reply(buildM7RAiEmbed(message.author, aiRes.answer, aiRes.blocked)).catch(() => {});
  }

  if (aiRoomConfig.enabled && aiRoomConfig.autoReplyWithoutPrefix && isAiRoom && !content.startsWith(PREFIX)) {
    await message.channel.sendTyping().catch(() => {});
    const aiRes = await askFriendlyM7RAi(content, message.author.username);
    return message.reply(buildM7RAiEmbed(message.author, aiRes.answer, aiRes.blocked)).catch(() => {});
  }
  // C. Enhanced Smart Auto-Responder (Exact / Contains / Starts With / Regex + Smart Variables)
  for (const rule of autoResponseRules) {
    if (!rule.enabled) continue;
    const text = message.content;
    const trig = rule.trigger || '';
    let matched = false;
    if (rule.matchType === 'exact') matched = text.toLowerCase() === trig.toLowerCase();
    else if (rule.matchType === 'starts_with') matched = text.toLowerCase().startsWith(trig.toLowerCase());
    else if (rule.matchType === 'regex') {
      try { matched = new RegExp(trig, 'i').test(text); } catch {}
    } else matched = text.toLowerCase().includes(trig.toLowerCase());

    if (matched) {
      const formatted = (rule.response || '')
        .replace(/\\{user\\}/gi, \`<@\${message.author.id}>\`)
        .replace(/\\{username\\}/gi, message.author.username)
        .replace(/\\{server\\}/gi, message.guild.name)
        .replace(/\\{memberCount\\}/gi, String(message.guild.memberCount))
        .replace(/\\{channel\\}/gi, \`<#\${message.channel.id}>\`);
      if (rule.deleteTriggerMessage) await message.delete().catch(() => {});
      if (rule.responseMode === 'embed') {
        const emb = new EmbedBuilder().setColor(rule.embedColor || '#8A2BE2').setDescription(formatted);
        if (rule.embedTitle) emb.setTitle(rule.embedTitle);
        if (rule.embedImageUrl) emb.setImage(rule.embedImageUrl);
        await (rule.replyMode === 'send' ? message.channel.send({ embeds: [emb] }) : message.reply({ embeds: [emb] })).catch(() => {});
      } else {
        await (rule.replyMode === 'send' ? message.channel.send({ content: formatted }) : message.reply({ content: formatted })).catch(() => {});
      }
      break;
    }
  }
});

// ================= 4. TEMPVOICE PRO: JOIN-TO-CREATE & AUTO-DELETE WHEN EMPTY =================
const activeTempRooms = new Map(); // channelId -> { ownerId, guildId }
const savedTempVoicePrefs = new Map(); // userId -> { roomName, userLimit, locked, hidden }

function buildTempVoicePanelPayload() {
  const embed = new EmbedBuilder()
    .setColor('#8A2BE2')
    .setAuthor({ name: 'منظومة الرومات الصوتية المؤقتة 🎙️' })
    .setTitle('إنشاء وإدارة الرومات الصوتية')
    .setDescription(
      [
        'تمتع بإنشاء غرفتك الصوتية المؤقتة والتحكم بكامل خصوصيتها وإعداداتها.',
        '',
        '🚀 **طريقة الإنشاء السريع:**',
        '1️⃣ انضم إلى الروم الصوتي **أنشئ رومك** ليتم إنشاء رومك الخاص فوراً.',
        '2️⃣ أو اضغط على زر **إنشاء روم صوتي** بالأسفل.',
        '',
        '🛠️ **لوحة التحكم (لصاحب الروم فقط):**',
        '• 🔒 \`قفل الروم\` • 🔓 \`فتح الروم\` • 🙈 \`إخفاء\` • 👁️ \`إظهار\`',
        '• ✏️ \`تعديل الاسم\` • 👢 \`طرد الأعضاء\` • 👥 \`تحديد السعة\`',
        '• 💾 **حفظ واسترداد الإعدادات (PRO):** \`حفظ الإعدادات\` • \`استرداد الإعدادات\`',
        '',
        '💡 ملاحظة: يُحذف الروم تلقائياً فور خروج كافة المتواجدين منه.'
      ].join('\\n')
    )
    .setFooter({ text: 'M7R Empire ⚜️' });

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tempvc_create').setLabel('إنشاء روم صوتي 🎙️').setStyle(ButtonStyle.Success)
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tempvc_lock').setLabel('إغلاق 🔒').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('tempvc_unlock').setLabel('فتح 🔓').setStyle(ButtonStyle.Success)
  );
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tempvc_hide').setLabel('إخفاء 🙈').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tempvc_unhide').setLabel('إظهار 👁️').setStyle(ButtonStyle.Secondary)
  );
  const row4 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tempvc_rename').setLabel('تغيير الاسم ✏️').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('tempvc_kick').setLabel('طرد عضو 👢').setStyle(ButtonStyle.Danger)
  );
  const row5 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tempvc_save').setLabel('حفظ الإعدادات 💾').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('tempvc_load').setLabel('استرداد الإعدادات 📥').setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row1, row2, row3, row4, row5] };
}

botClient.on('voiceStateUpdate', async (oldState, newState) => {
  // Auto-delete empty temporary voice channel
  if (oldState.channelId && activeTempRooms.has(oldState.channelId)) {
    const oldCh = oldState.channel;
    if (oldCh && oldCh.members.size === 0) {
      activeTempRooms.delete(oldState.channelId);
      await oldCh.delete('M7R TempVoice Pro: Room empty').catch(() => {});
    }
  }
  // Join-to-Create when joining "أنشئ رومك"
  if (newState.channel && newState.member && !newState.member.user.bot) {
    if (newState.channel.name.includes('أنشئ رومك') || newState.channel.name.includes('انشئ رومك')) {
      const room = await newState.guild.channels.create({
        name: \`🔊・\${newState.member.user.username}\`,
        type: ChannelType.GuildVoice,
        parent: newState.channel.parentId || undefined,
        permissionOverwrites: [
          { id: newState.guild.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
          { id: newState.member.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers] }
        ]
      }).catch(() => null);
      if (room) {
        activeTempRooms.set(room.id, { ownerId: newState.member.id, guildId: newState.guild.id });
        await newState.member.voice.setChannel(room).catch(() => {});
      }
    }
  }
});

botClient.on('interactionCreate', async (interaction) => {
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === 'ask') {
      const question = interaction.options.getString('question', true);
      await interaction.deferReply();
      const aiRes = await askFriendlyM7RAi(question, interaction.user.username);
      await interaction.editReply(buildM7RAiEmbed(interaction.user, aiRes.answer, aiRes.blocked));
    }
    return;
  }

  // Single-Admin Ticket Claim Lock & TempVoice Pro Buttons
  if (interaction.isButton()) {
    if (interaction.customId.startsWith('tempvc_')) {
      const member = interaction.member;
      if (interaction.customId === 'tempvc_create') {
        const room = await interaction.guild.channels.create({
          name: \`🔊・\${interaction.user.username}\`,
          type: ChannelType.GuildVoice
        });
        activeTempRooms.set(room.id, { ownerId: interaction.user.id, guildId: interaction.guild.id });
        if (member?.voice?.channelId) await member.voice.setChannel(room).catch(() => {});
        return interaction.reply({ content: \`✅ تم إنشاء رومك الصوتي المؤقت: <#\${room.id}> 🎙️\`, ephemeral: true });
      }
      const vcId = member?.voice?.channelId;
      const roomMeta = vcId ? activeTempRooms.get(vcId) : null;
      if (!vcId || !roomMeta || roomMeta.ownerId !== interaction.user.id) {
        return interaction.reply({ content: '⚠️ هذه اللوحة مخصصة لصاحب الروم الصوتي فقط!', ephemeral: true });
      }
      const vc = interaction.guild.channels.cache.get(vcId);
      if (interaction.customId === 'tempvc_lock') {
        await vc.permissionOverwrites.edit(interaction.guild.id, { Connect: false });
        return interaction.reply({ content: '🔒 تم قفل الروم الصوتي بنجاح.', ephemeral: true });
      }
      if (interaction.customId === 'tempvc_unlock') {
        await vc.permissionOverwrites.edit(interaction.guild.id, { Connect: true });
        return interaction.reply({ content: '🔓 تم فتح الروم الصوتي للجميع.', ephemeral: true });
      }
      if (interaction.customId === 'tempvc_hide') {
        await vc.permissionOverwrites.edit(interaction.guild.id, { ViewChannel: false });
        return interaction.reply({ content: '🙈 تم إخفاء الروم الصوتي.', ephemeral: true });
      }
      if (interaction.customId === 'tempvc_unhide') {
        await vc.permissionOverwrites.edit(interaction.guild.id, { ViewChannel: true });
        return interaction.reply({ content: '👁️ تم إظهار الروم الصوتي.', ephemeral: true });
      }
      return;
    }

    const state = activeTicketsMap.get(interaction.channelId) || { ownerId: interaction.user.id, claimedBy: null, staffRoleId: null };
    if (interaction.customId === 'claim_ticket') {
      state.claimedBy = interaction.user.id;
      activeTicketsMap.set(interaction.channelId, state);
      await interaction.channel.permissionOverwrites.edit(interaction.user.id, {
        ViewChannel: true,
        SendMessages: true,
        AttachFiles: true
      }).catch(() => {});
      if (state.staffRoleId) {
        await interaction.channel.permissionOverwrites.edit(state.staffRoleId, {
          ViewChannel: true,
          SendMessages: false
        }).catch(() => {});
      }
      const claimEmbed = new EmbedBuilder()
        .setColor('#10b981')
        .setDescription(\`✨ **تم استلام التذكرة بنجاح!** 🙋‍♂️\\nمرحباً، قام الإداري <@\${interaction.user.id}> باستلام تذكرتك الآن. تم قفل الشات عن بقية الإدارة لمنع التداخل وضمان أفضل خدمة لك! 🌸\`);
      await interaction.reply({ embeds: [claimEmbed] });
    } else if (interaction.customId === 'unclaim_ticket') {
      state.claimedBy = null;
      activeTicketsMap.set(interaction.channelId, state);
      if (state.staffRoleId) {
        await interaction.channel.permissionOverwrites.edit(state.staffRoleId, {
          ViewChannel: true,
          SendMessages: true
        }).catch(() => {});
      }
      await interaction.reply({ content: \`🔓 تم فك استلام التذكرة بواسطة <@\${interaction.user.id}> وإعادة فتح الشات للإدارة.\` });
    } else if (interaction.customId === 'close_ticket') {
      const fetched = await interaction.channel.messages.fetch({ limit: 100 }).catch(() => null);
      const rows = fetched
        ? Array.from(fetched.values()).reverse().map(m => \`<div style="margin:8px 0;padding:10px;background:#160D29;border-left:4px solid #8A2BE2;border-radius:8px;"><b>\${m.author.username}</b> <small>(\${m.createdAt.toLocaleTimeString('ar-SA')})</small><p>\${m.content}</p></div>\`).join('')
        : '';
      const htmlDoc = \`<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>Transcript #\${interaction.channel.name}</title></head><body style="background:#0B0614;color:#fff;font-family:sans-serif;padding:24px;"><h2>📄 أرشيف التذكرة #\${interaction.channel.name}</h2>\${rows}</body></html>\`;
      await interaction.reply({
        content: \`🔒 تم إغلاق التذكرة وتوليد ملف الأرشيف (\`transcript-\${interaction.channel.name}.html\`).\`,
        files: [{ attachment: Buffer.from(htmlDoc, 'utf-8'), name: \`transcript-\${interaction.channel.name}.html\` }]
      });
    }
  }
});

if (process.env.DISCORD_BOT_TOKEN) {
  botClient.login(process.env.DISCORD_BOT_TOKEN);
} else {
  console.log('[M7R] Add DISCORD_BOT_TOKEN in Replit Secrets to start the bot.');
}`;

  const packageJsonCode = `{
  "name": "m7r-discord-bot-24-7",
  "version": "3.0.0",
  "description": "M7R Discord Bot + OAuth2 Login + Honeypot DM + Single-Admin Ticket Claim + المستمر Quran",
  "main": "server.js",
  "type": "module",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "@discordjs/voice": "^0.19.1",
    "@google/genai": "^1.0.0",
    "discord.js": "^14.16.3",
    "dotenv": "^16.4.5",
    "express": "^4.21.2",
    "ffmpeg-static": "^5.3.0",
    "prism-media": "^1.3.5"
  }
}`;

  const envCode = `# ===========================================
# M7R DISCORD BOT & OAUTH2 ENVIRONMENT VARIABLES (Replit Secrets)
# ملاحظة: لا ترفع ملف .env إلى Git — أضف هذه القيم داخل Replit -> Secrets 🔒
# ===========================================

# 1. توكن البوت من Discord Developer Portal
DISCORD_BOT_TOKEN="YOUR_BOT_TOKEN_HERE"

# 2. بيانات OAuth2 لتسجيل الدخول عبر ديسكورد والتحويل التلقائي للوحة التحكم
DISCORD_CLIENT_ID="1564565916216336494"
DISCORD_CLIENT_SECRET="YOUR_DISCORD_CLIENT_SECRET"
DISCORD_REDIRECT_URI="https://YOUR-REPL-URL.replit.app/auth/discord/callback"

# 3. مفتاح Gemini API لتفعيل الردود الذكية الظريفة (AI Ask)
GEMINI_API_KEY="YOUR_GEMINI_API_KEY"

# 4. مفاتيح التشفير وتوقيع الجلسات (AES-256-GCM + HMAC-SHA256)
SESSION_SECRET="GENERATE_RANDOM_64_HEX_STRING"
ENCRYPTION_KEY="GENERATE_RANDOM_64_HEX_STRING"

# 5. سقف الإنفاق والحد اليومي للذكاء الاصطناعي + التحقق الثنائي 2FA
AI_DAILY_SPEND_CAP_USD="2.00"
AI_MONTHLY_SPEND_CAP_USD="25.00"
AI_DAILY_REQUEST_LIMIT="250"
ADMIN_2FA_TOTP_SECRET="OPTIONAL_BASE32_TOTP_SECRET"

# 6. رابط لوحة التحكم الرسمية والمنفذ
APP_URL="https://YOUR-REPL-URL.replit.app"
PORT=3000
`;

  const replitConfigCode = `run = "npm run build && npm run start"
entrypoint = "server.ts"
modules = ["nodejs-20", "web"]

[nix]
channel = "stable-24_05"

[env]
PORT = "3000"
NODE_ENV = "production"

[deployment]
run = ["sh", "-c", "npm run build && npm run start"]
deploymentTarget = "vm"

[[ports]]
localPort = 3000
externalPort = 80
`;

  const copyToClipboard = (text: string, label: string) => {
    sound.playClick();
    navigator.clipboard.writeText(text);
    setCopiedFile(label);
    setTimeout(() => setCopiedFile(null), 2500);
  };

  const handleDownload = (content: string, filename: string) => {
    sound.playClick();
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Terminal className="w-6 h-6 text-rose-500" />
            {isAr ? 'مركز أكواد Replit المستمر المحدثة (OAuth2 + اختيار السيرفرات + AI Ask)' : 'Replit المستمر Updated Code Hub'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {isAr
              ? 'الكود الكامل والنظيف لملف server.js مع إصلاح أزرار اختيار السيرفرات، تسجيل الدخول عبر ديسكورد OAuth2، والذكاء الاصطناعي'
              : 'Complete clean server.js with fixed server selection cards, Discord OAuth2 callback redirect, and AI Ask'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleDownload(serverJsCode, 'server.js')}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Download className="w-4 h-4 text-rose-400" />
            <span>{isAr ? 'تحميل server.js' : 'Download server.js'}</span>
          </button>
          <button
            onClick={() =>
              copyToClipboard(
                activeCodeTab === 'server'
                  ? serverJsCode
                  : activeCodeTab === 'package'
                  ? packageJsonCode
                  : activeCodeTab === 'replit'
                  ? replitConfigCode
                  : envCode,
                activeCodeTab
              )
            }
            className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            {copiedFile ? <Check className="w-4 h-4 text-emerald-200" /> : <Copy className="w-4 h-4" />}
            <span>{copiedFile ? (isAr ? 'تم النسخ بنجاح!' : 'Copied!') : isAr ? 'نسخ الكود الكامل' : 'Copy Code'}</span>
          </button>
        </div>
      </div>

      {/* Step-by-Step المستمر Replit Deployment Guide */}
      <div className="rounded-2xl border border-emerald-500/35 bg-gradient-to-br from-emerald-950/20 via-[#0b1021] to-slate-950 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <h3 className="text-base font-black text-white">
            🚀 طريقة نشر موقعك وبوتك المستمر على Replit خطوة بخطوة
          </h3>
          <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs font-black">
            جاهز عبر ملف .replit
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-[#060913] border border-slate-800 space-y-1.5">
            <div className="font-black text-purple-300">1️⃣ رفع المشروع إلى Replit</div>
            <p className="text-slate-300 leading-relaxed">
              من Replit اختر <strong>Create Repl → Import from GitHub</strong> أو ارفع ملفات المشروع مباشرة — ملف <code className="text-emerald-300 font-mono">.replit</code> مهيأ مسبقاً للعمل على المنفذ 3000.
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-[#060913] border border-slate-800 space-y-1.5">
            <div className="font-black text-amber-300">2️⃣ إضافة الأسرار في Replit Secrets 🔒</div>
            <p className="text-slate-300 leading-relaxed">
              من قائمة <strong>Tools → Secrets</strong> أضف: <code className="font-mono text-white">DISCORD_BOT_TOKEN</code>، <code className="font-mono text-white">DISCORD_CLIENT_SECRET</code>، <code className="font-mono text-white">GEMINI_API_KEY</code>، <code className="font-mono text-white">SESSION_SECRET</code>، <code className="font-mono text-white">ENCRYPTION_KEY</code>، و<code className="font-mono text-white">APP_URL</code>.
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-[#060913] border border-slate-800 space-y-1.5">
            <div className="font-black text-sky-300">3️⃣ ضبط OAuth2 في Discord Developer Portal</div>
            <p className="text-slate-300 leading-relaxed">
              داخل تطبيقك في Discord Developer Portal → <strong>OAuth2 → Redirects</strong> أضف رابط موقعك المتبوع بـ <code className="font-mono text-emerald-300">/auth/discord/callback</code> ثم اضغط <strong>Deploy → Reserved VM</strong> للتشغيل المستمر بدون توقف.
            </p>
          </div>
        </div>
      </div>

      {/* Code Viewer Container */}
      <div className="rounded-xl border border-slate-800 bg-[#0a0d13] overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#0e121a] border-b border-slate-800">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => {
                setActiveCodeTab('server');
                sound.playClick();
              }}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded cursor-pointer transition-colors ${
                activeCodeTab === 'server'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              server.js (OAuth2 + Server Selection + المستمر)
            </button>
            <button
              onClick={() => {
                setActiveCodeTab('package');
                sound.playClick();
              }}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded cursor-pointer transition-colors ${
                activeCodeTab === 'package'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              package.json
            </button>
            <button
              onClick={() => {
                setActiveCodeTab('replit');
                sound.playClick();
              }}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded cursor-pointer transition-colors ${
                activeCodeTab === 'replit'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              .replit (المستمر VM)
            </button>
            <button
              onClick={() => {
                setActiveCodeTab('env');
                sound.playClick();
              }}
              className={`px-3 py-1 text-xs font-mono font-semibold rounded cursor-pointer transition-colors ${
                activeCodeTab === 'env'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              .env (Secrets)
            </button>
          </div>

          <span className="text-[11px] text-slate-500 font-mono hidden sm:inline">UTF-8 • Node.js ES Module</span>
        </div>

        <div className="p-4 overflow-x-auto max-h-[500px]">
          <pre className="text-xs font-mono text-slate-300 leading-relaxed">
            <code>
              {activeCodeTab === 'server' && serverJsCode}
              {activeCodeTab === 'package' && packageJsonCode}
              {activeCodeTab === 'replit' && replitConfigCode}
              {activeCodeTab === 'env' && envCode}
            </code>
          </pre>
        </div>
      </div>

      {/* Developer Portal Notes */}
      <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-amber-400" />
          {isAr ? 'إعدادات Discord Developer Portal المطلوبة:' : 'Required Discord Developer Portal Setup:'}
        </h3>
        <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
          <li>
            <b>OAuth2 Redirects:</b>{' '}
            {isAr
              ? 'أضف رابط الـ Callback في قسم OAuth2 -> Redirects ليتم تحويل المستخدم تلقائياً للوحة التحكم بعد تسجيل الدخول.'
              : 'Add your callback URL under OAuth2 -> Redirects.'}
          </li>
          <li>
            <b>Privileged Gateway Intents:</b>{' '}
            {isAr
              ? 'فعّل الخيارات الثلاثة (Presence Intent، Server Members Intent، و Message Content Intent).'
              : 'Enable Presence, Server Members, and Message Content Intents.'}
          </li>
        </ul>
      </div>
    </div>
  );
};
