import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Sparkles, ArrowLeft, Bot, Globe, Terminal } from 'lucide-react';
import { sound } from '../utils/sound';

interface FloatingWebAiAssistantProps {
  lang: 'ar' | 'en';
  onNavigateTab: (tabId: string) => void;
}

interface ChatMessageItem {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  targetTab?: string;
  targetTabLabel?: string;
  timestamp: string;
}

const READY_QUESTIONS_WEB_AND_DISCORD = [
  {
    category: 'web',
    label: '🏗️ كيف أنشئ الرومات الجاهزة والتقديم حسب فكرة سيرفري؟',
    tab: 'ready_rooms',
    tabLabel: '🏗️ الرومات الجاهزة ومنشئ السيرفر',
    instantReply:
      '🏗️ **إنشاء الرومات الجاهزة والتقديم حسب فكرة سيرفرك:**\n1. افتح قسم **الرومات الجاهزة ومنشئ السيرفر**.\n2. اختر قالب جاهز بنقرة زر (`تقديم الإدارة الجاهز`، `حزمة التذاكر`، `المتجر`، `الألعاب`) أو اكتب فكرة سيرفرك في خانة الذكاء الاصطناعي.\n3. اضغط **نشر في السيرفر الآن** ليقوم البوت بإنشاء الكاتيجوري والرومات وإرسال اللوحات التفاعلية تلقائياً!'
  },
  {
    category: 'web',
    label: '🛡️ اشرح لي إعدادات درع الحماية والرتب المستثناة (Whitelist)',
    tab: 'antinuke',
    tabLabel: '🛡️ الحماية',
    instantReply:
      '🛡️ **درع الحماية الشامل (16 بطاقة حماية + Whitelist):**\n• يتضمن 11 بطاقة حماية ضد التخريب (حذف وإنشاء الرومات والرتب، الصلاحيات الخطيرة، البوتات، الطرد الجماعي، الـ Webhooks، وهوية السيرفر) + 5 بطاقات فلترة شات و558 كلمة محظورة.\n• **قاعدة القائمة البيضاء الصارمة (Whitelist):** إذا لم تقم بتحديد أي رتبة أو عضو في قائمة الاستثناء، فإن البوت يعاقب **أي شخص كائناً من كان** (حتى لو معه Administrator) باستثناء مالك السيرفر الأساسي فقط!'
  },
  {
    category: 'web',
    label: '🎫 كيف أضيف أزرار التذاكر وأفعل طلب سبب الفتح والإغلاق؟',
    tab: 'tickets',
    tabLabel: '🎫 التذاكر',
    instantReply:
      '🎫 **إدارة نظام التذاكر والأزرار غير المحدودة:**\n1. من قسم **التذاكر**، اضغط **`+ إضافة زر تذكرة جديد`** لإضافة عدد غير محدود من الأزرار المخصصة مع الإيموجي واللون والرتبة المسؤولة.\n2. من بطاقة **إعدادات التذاكر والدعم الفني**، فعّل خيار **`طلب سبب عند فتح التذكرة`** وخيار **`طلب سبب عند إغلاق التذكرة`**.\n3. اضغط **`📤 نشر اللوحة`** لإرسالها مباشرة في ديسكورد!'
  },
  {
    category: 'web',
    label: '📋 كيف أضبط التقديمات الخاصة بسيرفري ورسالة القبول والرفض؟',
    tab: 'staff_apps',
    tabLabel: '📋 التقديمات',
    instantReply:
      '📋 **نظام التقديمات المعزول لكل سيرفر:**\n1. افتح قسم **التقديمات** (كل سيرفر له إعداداته وعنوانه المستقل تماماً باسم سيرفرك الحقيقي).\n2. حدد العنوان، الشروط والضوابط، عمر الحساب الأدنى، وعدد الأسئلة (من 1 إلى 5 أسئلة نظيفة بدون نصوص قديمة).\n3. خصص **نص رسالة القبول** و**نص رسالة الرفض** والرتبة الاختيارية عند القبول ثم اضغط **حفظ ونشر اللوحة**!'
  },
  {
    category: 'discord',
    label: '⌨️ كيف أتحكم بالأوامر الـ 34 واختصاراتها؟',
    tab: 'commands',
    tabLabel: '⌨️ إعدادات الأوامر',
    instantReply:
      '⌨️ **لوحة التحكم بالأوامر الـ 34 واختصاراتها المخصصة:**\n1. انتقل إلى قسم **إعدادات الأوامر (34 أمر)** المقسمة حسب الفئات (الإشراف والعقوبات 15، الرومات الصوتية 6، الرتب 3، السحوبات 4، العملات 2، المستويات 2، العامة 2).\n2. يمكنك تفعيل أو إلغاء تفعيل جميع الأوامر بضغطة زر، أو إضافة **اختصار عربي مخصص** لكل أمر (مثل: `نداء`، `مسح`، `قفل`، `ضريبة`، `سنايب`، `وين`، `مشغول`) وتحديد الرتب والرومات المسموح لها!'
  }
];

export const FloatingWebAiAssistant: React.FC<FloatingWebAiAssistantProps> = ({
  lang,
  onNavigateTab
}) => {
  const isAr = lang === 'ar';
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [filterMode, setFilterMode] = useState<'all' | 'web' | 'discord'>('all');
  const [messages, setMessages] = useState<ChatMessageItem[]>([
    {
      id: 'welcome-msg',
      sender: 'assistant',
      text: isAr
        ? 'أهلاً بك في **🤖 مساعد M7R الذكي**!\nجميع مميزات الموقع والبوت **مجانية 100% بالكامل**.\nاختر أحد الأسئلة الجاهزة بالأسفل أو اكتب سؤالك وسأشرح لك الطريقة بالتفصيل مع زر **`🚀 انتقل للقسم الآن`**!'
        : 'Welcome to M7R Smart Assistant! Choose a ready question below or type your question.',
      targetTab: 'ready_rooms',
      targetTabLabel: '🏗️ الرومات الجاهزة ومنشئ السيرفر',
      timestamp: 'الآن'
    }
  ]);

  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSendQuestion = async (questionText?: string) => {
    const prompt = (questionText ?? input).trim();
    if (!prompt || loading) return;

    sound.playClick();
    if (!questionText) setInput('');

    const userMsg: ChatMessageItem = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: prompt,
      timestamp: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
    };
    setMessages((prev) => [...prev, userMsg]);

    // Check if it matches one of the ready questions for instant 0ms response
    const matchedReady = READY_QUESTIONS_WEB_AND_DISCORD.find((q) => q.label === prompt);
    if (matchedReady && matchedReady.instantReply) {
      const instantBotMsg: ChatMessageItem = {
        id: `a-${Date.now()}`,
        sender: 'assistant',
        text: matchedReady.instantReply,
        targetTab: matchedReady.tab,
        targetTabLabel: matchedReady.tabLabel,
        timestamp: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, instantBotMsg]);
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/web-ai-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      const data = await res.json();
      const botMsg: ChatMessageItem = {
        id: `a-${Date.now()}`,
        sender: 'assistant',
        text:
          data?.reply ||
          'يمكنك التحكم في هذا النظام مباشرة من القائمة الجانبية في لوحة تحكم M7R ثم الضغط على حفظ التغييرات.',
        targetTab: data?.targetTab || 'ready_rooms',
        targetTabLabel: data?.targetTabLabel || '🏗️ الرومات الجاهزة ومنشئ السيرفر',
        timestamp: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch {
      const fallbackMsg: ChatMessageItem = {
        id: `a-${Date.now()}`,
        sender: 'assistant',
        text: 'افتح القائمة الجانبية (☰) في أعلى اليسار للوصول السريع إلى جميع أقسام الموقع وتفعيلها بضغطة زر.',
        targetTab: 'ready_rooms',
        targetTabLabel: '🏗️ الرومات الجاهزة ومنشئ السيرفر',
        timestamp: 'الآن'
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const filteredQuestions =
    filterMode === 'all'
      ? READY_QUESTIONS_WEB_AND_DISCORD
      : READY_QUESTIONS_WEB_AND_DISCORD.filter((q) => q.category === filterMode);

  return (
    <div className="fixed bottom-6 left-6 z-[9999] select-none" dir="rtl">
      {/* Floating Chat Window */}
      {isOpen && (
        <div className="mb-4 w-[350px] sm:w-[420px] rounded-3xl bg-[#060913]/95 backdrop-blur-2xl border border-indigo-500/45 shadow-[0_20px_70px_rgba(0,0,0,0.9)] overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200 flex flex-col max-h-[600px]">
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-[#7C3AED]/35 via-[#4F46E5]/30 to-[#2563EB]/35 border-b border-slate-800/90 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#7C3AED] to-[#2563EB] flex items-center justify-center shadow-lg shadow-purple-900/50 border border-white/20">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-black text-white flex items-center gap-1.5">
                  <span>🤖 مساعد M7R الذكي (الويب والديسكورد)</span>
                </h4>
                <p className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span>أسئلة جاهزة للويب وأوامر الديسكورد • مجاني 100%</span>
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setIsOpen(false);
              }}
              className="w-8 h-8 rounded-xl bg-slate-900/80 hover:bg-rose-950/60 border border-slate-700/80 text-slate-300 hover:text-rose-300 flex items-center justify-center cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Ready Questions Filter + Scrollable Chips */}
          <div className="px-3.5 py-2.5 bg-[#090D1A] border-b border-slate-800/80 space-y-2">
            <div className="flex items-center justify-between gap-1.5">
              <div className="text-[10px] font-black text-indigo-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-purple-400" />
                <span>أسئلة جاهزة سريعة (اضغط للإجابة الفورية):</span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setFilterMode('all')}
                  className={`px-2 py-0.5 rounded text-[10px] font-black cursor-pointer ${
                    filterMode === 'all'
                      ? 'bg-purple-600 text-white'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  الكل (8)
                </button>
                <button
                  type="button"
                  onClick={() => setFilterMode('web')}
                  className={`px-2 py-0.5 rounded text-[10px] font-black flex items-center gap-1 cursor-pointer ${
                    filterMode === 'web'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  <Globe className="w-2.5 h-2.5" />
                  <span>الويب</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFilterMode('discord')}
                  className={`px-2 py-0.5 rounded text-[10px] font-black flex items-center gap-1 cursor-pointer ${
                    filterMode === 'discord'
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  <Terminal className="w-2.5 h-2.5" />
                  <span>الديسكورد</span>
                </button>
              </div>
            </div>

            <div className="max-h-28 overflow-y-auto space-y-1 pr-0.5">
              {filteredQuestions.map((q, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSendQuestion(q.label)}
                  className="w-full text-right px-2.5 py-1.5 rounded-xl bg-slate-900/95 hover:bg-purple-600/25 border border-slate-700/80 hover:border-purple-500/50 text-[11px] font-bold text-slate-200 hover:text-white transition-all cursor-pointer flex items-center justify-between gap-2"
                >
                  <span className="truncate">{q.label}</span>
                  <ArrowLeft className="w-3 h-3 text-purple-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 space-y-3 overflow-y-auto max-h-[260px] scrollbar-thin">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.sender === 'user' ? 'items-start' : 'items-end'}`}
              >
                <div
                  className={`max-w-[92%] rounded-2xl p-3 text-xs leading-relaxed whitespace-pre-line ${
                    m.sender === 'user'
                      ? 'bg-gradient-to-r from-[#7C3AED] to-[#2563EB] text-white font-bold shadow-md'
                      : 'bg-[#0E1424] border border-slate-800/90 text-slate-200'
                  }`}
                >
                  <div>{m.text}</div>

                  {m.sender === 'assistant' && m.targetTab && (
                    <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          sound.playShieldActivate();
                          onNavigateTab(m.targetTab!);
                          setIsOpen(false);
                        }}
                        className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#2563EB] hover:from-[#6D28D9] hover:to-[#1D4ED8] border border-white/20 text-white text-[11px] font-black flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-md"
                      >
                        <span>🚀 انتقل للقسم الآن: {m.targetTabLabel || m.targetTab}</span>
                        <ArrowLeft className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
                <span className="text-[9px] text-slate-500 mt-1 px-1">{m.timestamp}</span>
              </div>
            ))}

            {loading && (
              <div className="p-3 rounded-2xl bg-[#0E1424] border border-slate-800 text-xs text-purple-300 font-bold flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
                <span>جاري تجهيز الشرح والخطوات من مساعد M7R...</span>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input Box */}
          <div className="p-3 bg-[#090D18] border-t border-slate-800/90 flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSendQuestion();
              }}
              placeholder="اسأل عن أي ميزة في الموقع أو أمر في الديسكورد..."
              className="flex-1 bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => handleSendQuestion()}
              disabled={loading || !input.trim()}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#2563EB] hover:from-[#6D28D9] hover:to-[#1D4ED8] text-white text-xs font-black flex items-center gap-1 cursor-pointer disabled:opacity-50 transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>إرسال</span>
            </button>
          </div>
        </div>
      )}

      {/* Floating Circular Purple-to-Blue Gradient Button (Bottom-Left) */}
      <button
        type="button"
        onClick={() => {
          sound.playClick();
          setIsOpen(!isOpen);
        }}
        title="مساعد M7R الذكي (الويب والديسكورد)"
        className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#7C3AED] to-[#2563EB] hover:scale-105 active:scale-95 text-white shadow-[0_8px_30px_rgba(124,58,237,0.55)] border border-white/25 flex items-center justify-center cursor-pointer transition-all relative group"
      >
        <span className="absolute -inset-1 rounded-full bg-gradient-to-tr from-[#7C3AED] to-[#2563EB] opacity-40 blur-md group-hover:opacity-70 transition-opacity" />
        <div className="relative z-10 flex items-center justify-center">
          {isOpen ? (
            <X className="w-6 h-6 text-white" />
          ) : (
            <MessageCircle className="w-7 h-7 text-white fill-white" />
          )}
        </div>
      </button>
    </div>
  );
};
