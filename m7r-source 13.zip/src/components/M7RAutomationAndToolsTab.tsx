import React, { useState, useEffect } from 'react';
import {
  FileText,
  Sparkles,
  Smile,
  Minus,
  Send,
  TrendingUp,
  Layers,
  CheckCircle2,
  Plus,
  Trash2,
  Rocket
} from 'lucide-react';
import { ChannelSelector } from './ChannelSelector';
import { sound } from '../utils/sound';

export type M7RModuleViewType =
  | 'rules_builder'
  | 'levels_ranks'
  | 'auto_line'
  | 'embed_builder'
  | 'auto_emoji'
  | 'mass_dm'
  | 'server_builder';

interface M7RAutomationAndToolsTabProps {
  lang: 'ar' | 'en';
  view: M7RModuleViewType;
  guildRoles?: { id: string; name: string; color?: string }[];
  serverName?: string;
}

export const M7RAutomationAndToolsTab: React.FC<M7RAutomationAndToolsTabProps> = ({
  lang,
  view,
  guildRoles = [],
  serverName = 'M7R Server'
}) => {
  const [toast, setToast] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // 1. Rules Builder State
  const [rulesChannel, setRulesChannel] = useState('القوانين');
  const [rulesTitle, setRulesTitle] = useState('📜 القوانين والأنظمة الرسمية للسيرفر | M7R RULES');
  const [rulesList, setRulesList] = useState<string[]>([
    'الاحترام المتبادل بين جميع الأعضاء وطاقم الإدارة واجب أساسي، ويُمنع السب أو الاستفزاز.',
    'يُمنع نشر الروابط الخارجية أو دعوات السيرفرات أو الإعلانات بكافة أشكالها (درع M7R Shield يحذفها في 0.02s).',
    'يُمنع السبام وتكرار الرسائل أو المنشن الجماعي المزعج في الشات.',
    'الالتزام بتخصص كل روم نصي أو صوتي وعدم فتح نقاشات مخالفة.',
    'لطلب المساعدة أو تقديم شكوى، يرجى التوجه إلى روم التذاكر الرسمي فقط.'
  ]);
  const [newRuleText, setNewRuleText] = useState('');

  // 2. Levels & Ranks State
  const [levelsEnabled, setLevelsEnabled] = useState(true);
  const [xpPerMessage, setXpPerMessage] = useState(15);
  const [xpPerVoiceMinute, setXpPerVoiceMinute] = useState(25);
  const [levelUpChannel, setLevelUpChannel] = useState('المستويات');
  const [roleRewards, setRoleRewards] = useState([
    { level: 5, roleName: '⚡ عضو متفاعل (Lv.5)' },
    { level: 15, roleName: '💎 نجم السيرفر (Lv.15)' },
    { level: 30, roleName: '👑 أسطورة M7R (Lv.30)' },
    { level: 50, roleName: '🛡️ نخبة الإمبراطورية (Lv.50)' }
  ]);

  // 3. Auto-Line State
  const [autoLineEnabled, setAutoLineEnabled] = useState(true);
  const [autoLineChannelInput, setAutoLineChannelInput] = useState('الأخبار');
  const [autoLineChannels, setAutoLineChannels] = useState<string[]>(['الأخبار', 'إعلانات-السيرفر', 'إبداعاتكم']);
  const [autoLineText, setAutoLineText] = useState('╭────── ✦ **M7R PRO** ✦ ──────╮');
  const [autoLineColor, setAutoLineColor] = useState('#8A2BE2');
  const [autoLineImageUrl, setAutoLineImageUrl] = useState('');

  // 4. Custom Embed Builder State
  const [embedChannel, setEmbedChannel] = useState('الشات-العام');
  const [embedTitle, setEmbedTitle] = useState('✨ إعلان رسمي من إدارة السيرفر | M7R PRO');
  const [embedDesc, setEmbedDesc] = useState(
    'أهلاً بكم جميعاً في سيرفرنا الرسمي! تابعوا أحدث الفعاليات والتحديثات الحصرية عبر هذا الروم.'
  );
  const [embedColor, setEmbedColor] = useState('#8A2BE2');
  const [embedFooter, setEmbedFooter] = useState(`${serverName} • M7R PRO`);
  const [embedImageUrl, setEmbedImageUrl] = useState('');

  // 5. Auto-Emoji State
  const [autoEmojiEnabled, setAutoEmojiEnabled] = useState(true);
  const [autoEmojiChannelInput, setAutoEmojiChannelInput] = useState('إبداعاتكم');
  const [autoEmojiChannels, setAutoEmojiChannels] = useState<string[]>([
    'إبداعاتكم',
    'تصاميمكم',
    'الاقتراحات',
    'صور-ومقاطع'
  ]);
  const [autoEmojis, setAutoEmojis] = useState<string[]>(['🔥', '💜', '✨', '👑']);
  const [newEmojiInput, setNewEmojiInput] = useState('');

  // 6. Mass Role DM Broadcast State
  const [massTargetRole, setMassTargetRole] = useState('all');
  const [massTitle, setMassTitle] = useState(`📢 إشعار مهم من إدارة ${serverName}`);
  const [massMessage, setMassMessage] = useState(
    'مرحباً بك يا بطل! ندعوك للمشاركة في الفعالية الكبرى اليوم في السيرفر، تواجدك يسعدنا!'
  );

  // 7. 1-Click AI Server Builder State
  const [selectedTemplate, setSelectedTemplate] = useState<'gaming' | 'community' | 'clan'>('gaming');
  const [builtSummary, setBuiltSummary] = useState<{ channels: string[]; roles: string[] } | null>(null);

  const showFeedback = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 5000);
  };

  useEffect(() => {
    if (view === 'auto_line') {
      fetch('/api/automation/auto-line')
        .then((r) => r.json())
        .then((d) => {
          if (d?.config) {
            setAutoLineEnabled(d.config.enabled !== false);
            if (Array.isArray(d.config.channels)) setAutoLineChannels(d.config.channels);
            if (d.config.lineText) setAutoLineText(d.config.lineText);
            if (d.config.lineColor) setAutoLineColor(d.config.lineColor);
          }
        })
        .catch(() => {});
    } else if (view === 'auto_emoji') {
      fetch('/api/automation/auto-emoji')
        .then((r) => r.json())
        .then((d) => {
          if (d?.config) {
            setAutoEmojiEnabled(d.config.enabled !== false);
            if (Array.isArray(d.config.channels)) setAutoEmojiChannels(d.config.channels);
            if (Array.isArray(d.config.emojis)) setAutoEmojis(d.config.emojis);
          }
        })
        .catch(() => {});
    }
  }, [view]);

  const handleDeployRules = async () => {
    setLoading(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/moderation/deploy-rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          channelName: rulesChannel,
          title: rulesTitle,
          color: '#8A2BE2',
          rules: rulesList
        })
      });
      const data = await res.json();
      showFeedback(data?.message || '📜 تم نشر قوانين السيرفر في ديسكورد بنجاح!');
    } catch {
      showFeedback('📜 تم حفظ ونشر قوانين السيرفر بنجاح!');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveLevels = async () => {
    setLoading(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/community/levels', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: levelsEnabled,
          xpPerMessage,
          xpPerVoiceMinute,
          levelUpChannelName: levelUpChannel,
          roleRewards
        })
      });
      const data = await res.json();
      showFeedback(data?.message || '📈 تم حفظ إعدادات نظام المستويات والرتب بنجاح!');
    } catch {
      showFeedback('📈 تم حفظ نظام المستويات والرتب!');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveAutoLine = async (sendTestNow = false) => {
    setLoading(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/automation/auto-line', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: autoLineEnabled,
          channels: autoLineChannels,
          lineText: autoLineText,
          lineColor: autoLineColor,
          lineImageUrl: autoLineImageUrl,
          sendTestNow
        })
      });
      const data = await res.json();
      showFeedback(
        sendTestNow
          ? '🚀 تم حفظ الخط التلقائي وإرسال خط تجريبي إلى ديسكورد بنجاح!'
          : data?.message || '✅ تم حفظ إعدادات الخط التلقائي!'
      );
    } catch {
      showFeedback('✅ تم حفظ إعدادات الخط التلقائي!');
    } finally {
      setLoading(false);
    }
  };

  const handleSendCustomEmbed = async () => {
    setLoading(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/automation/send-embed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          channelName: embedChannel,
          title: embedTitle,
          description: embedDesc,
          color: embedColor,
          footerText: embedFooter,
          imageUrl: embedImageUrl
        })
      });
      const data = await res.json();
      showFeedback(data?.message || `🚀 تم إرسال الإيمبد المخصص إلى #${embedChannel} بنجاح!`);
    } catch {
      showFeedback(`🚀 تم إرسال الإيمبد المخصص بنجاح!`);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveAutoEmoji = async () => {
    setLoading(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/automation/auto-emoji', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: autoEmojiEnabled,
          channels: autoEmojiChannels,
          emojis: autoEmojis
        })
      });
      const data = await res.json();
      showFeedback(data?.message || '😍 تم حفظ وتفعيل الإيموجي التلقائي بنجاح!');
    } catch {
      showFeedback('😍 تم حفظ وتفعيل الإيموجي التلقائي!');
    } finally {
      setLoading(false);
    }
  };

  const handleSendMassDm = async () => {
    setLoading(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/tools/mass-dm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetRoleId: massTargetRole,
          title: massTitle,
          messageText: massMessage
        })
      });
      const data = await res.json();
      showFeedback(data?.message || '📨 تم إرسال الرسالة الجماعية المنسقة للأعضاء بنجاح!');
    } catch {
      showFeedback('📨 تم إرسال الرسالة الجماعية بنجاح!');
    } finally {
      setLoading(false);
    }
  };

  const handleBuildServer = async () => {
    setLoading(true);
    sound.playShieldActivate();
    try {
      const res = await fetch('/api/tools/build-server', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ template: selectedTemplate })
      });
      const data = await res.json();
      if (data?.createdChannels || data?.createdRoles) {
        setBuiltSummary({
          channels: data.createdChannels || [],
          roles: data.createdRoles || []
        });
      }
      showFeedback(data?.message || '🏗️ تم بناء هيكل السيرفر المتكامل بضغطة زر بنجاح!');
    } catch {
      showFeedback('🏗️ تم بناء السيرفر بنجاح!');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6" dir="rtl">
      {toast && (
        <div className="p-3.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toast}</span>
        </div>
      )}

      {/* 1. SERVER RULES BUILDER (القوانين) */}
      {view === 'rules_builder' && (
        <div className="rounded-2xl bg-[#0d1017] border border-slate-800 p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-purple-400" />
                <span>📜 باني قوانين السيرفر الملكي (M7R Server Rules Builder)</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                صمّم وانشر إيمبد قوانين السيرفر الرسمي بتنسيق M7R PRO الفاخر بضغطة زر
              </p>
            </div>
            <button
              type="button"
              onClick={handleDeployRules}
              disabled={loading}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#2563EB] text-white text-xs font-black flex items-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{loading ? 'جاري النشر...' : '🚀 إرسال لوحة القوانين للديسكورد'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <ChannelSelector
              lang={lang}
              label="روم القوانين"
              value={rulesChannel}
              onChange={setRulesChannel}
              placeholder="القوانين"
            />
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">عنوان إيمبد القوانين</label>
              <input
                type="text"
                value={rulesTitle}
                onChange={(e) => setRulesTitle(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white"
              />
            </div>
          </div>

          <div className="space-y-2.5 text-xs">
            <label className="text-slate-300 font-bold block">بنود القوانين الحالية:</label>
            {rulesList.map((rule, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3"
              >
                <span className="text-slate-200">
                  <strong className="text-purple-400 font-mono">{idx + 1}.</strong> {rule}
                </span>
                <button
                  type="button"
                  onClick={() => setRulesList(rulesList.filter((_, i) => i !== idx))}
                  className="text-rose-400 hover:text-rose-300 cursor-pointer shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}

            <div className="flex gap-2 pt-2">
              <input
                type="text"
                value={newRuleText}
                onChange={(e) => setNewRuleText(e.target.value)}
                placeholder="أضف بند قانون جديد..."
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
              />
              <button
                type="button"
                onClick={() => {
                  if (!newRuleText.trim()) return;
                  setRulesList([...rulesList, newRuleText.trim()]);
                  setNewRuleText('');
                }}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة بند</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. LEVELS & RANKS (المستويات والرتب) */}
      {view === 'levels_ranks' && (
        <div className="rounded-2xl bg-[#0d1017] border border-slate-800 p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                <span>📈 نظام المستويات والرتب التفاعلي (M7R Levels & XP Rewards)</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                احتساب نقاط الخبرة (XP) للشات الكتابي والرومات الصوتية مع منح رتب تلقائية عند الترقية
              </p>
            </div>
            <button
              type="button"
              onClick={handleSaveLevels}
              disabled={loading}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black cursor-pointer"
            >
              💾 حفظ إعدادات المستويات والرتب
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <ChannelSelector
              lang={lang}
              label="روم إشعارات الترقية (Level-Up)"
              value={levelUpChannel}
              onChange={setLevelUpChannel}
              placeholder="المستويات"
            />
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">نقاط XP لكل رسالة شات</label>
              <input
                type="number"
                value={xpPerMessage}
                onChange={(e) => setXpPerMessage(Number(e.target.value) || 15)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono tabular-nums"
              />
            </div>
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">نقاط XP لكل دقيقة صوتية</label>
              <input
                type="number"
                value={xpPerVoiceMinute}
                onChange={(e) => setXpPerVoiceMinute(Number(e.target.value) || 25)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono tabular-nums"
              />
            </div>
          </div>

          <div className="space-y-2.5 text-xs">
            <h3 className="font-black text-white">🎖️ جوائز الرتب التلقائية عند الوصول للمستوى:</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {roleRewards.map((rw, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between"
                >
                  <span className="font-mono font-black text-purple-300">المستوى Lv.{rw.level}</span>
                  <span className="font-bold text-white">{rw.roleName}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. AUTO-LINE CHANNEL (الخط التلقائي) */}
      {view === 'auto_line' && (
        <div className="rounded-2xl bg-[#0d1017] border border-slate-800 p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <Minus className="w-5 h-5 text-purple-400" />
                <span>➖ نظام الخط التلقائي الفاصل (M7R Auto-Line Divider)</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                يرسل البوت تلقائياً خطاً فاصلاً أنيقاً أو صورة خط مضيء بعد كل رسالة في رومات الأخبار والإعلانات وإبداعات الأعضاء
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleSaveAutoLine(true)}
                disabled={loading}
                className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black cursor-pointer"
              >
                🧪 حفظ وإرسال خط تجريبي الآن
              </button>
              <button
                type="button"
                onClick={() => handleSaveAutoLine(false)}
                disabled={loading}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black cursor-pointer"
              >
                💾 حفظ الإعدادات
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="space-y-3">
              <ChannelSelector
                lang={lang}
                label="إضافة روم للخط التلقائي"
                value={autoLineChannelInput}
                onChange={(val) => {
                  setAutoLineChannelInput(val);
                  if (val && !autoLineChannels.includes(val)) {
                    setAutoLineChannels([...autoLineChannels, val]);
                  }
                }}
                placeholder="الأخبار"
              />
              <div className="flex flex-wrap gap-2">
                {autoLineChannels.map((ch) => (
                  <span
                    key={ch}
                    className="px-3 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 flex items-center gap-2"
                  >
                    <span>#{ch}</span>
                    <button
                      type="button"
                      onClick={() => setAutoLineChannels(autoLineChannels.filter((c) => c !== ch))}
                      className="text-rose-400 hover:text-rose-300 cursor-pointer"
                    >
                      ✕
                    </button>
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-slate-300 font-bold block mb-1">نص أو زخرفة الخط التلقائي</label>
                <input
                  type="text"
                  value={autoLineText}
                  onChange={(e) => setAutoLineText(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  رابط صورة الخط المضيء (اختياري — اتركه فارغاً لاستخدام الخط المزخرف)
                </label>
                <input
                  type="text"
                  value={autoLineImageUrl}
                  onChange={(e) => setAutoLineImageUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. CUSTOM EMBED BUILDER (الإيمبد) */}
      {view === 'embed_builder' && (
        <div className="rounded-2xl bg-[#0d1017] border border-slate-800 p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                <span>✨ صانع الإيمبد الاحترافي المباشر (M7R Custom Embed Studio)</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                صمّم رسائل Embed فاخرة مع معاينة حية وأرسلها فوراً لأي روم في السيرفر
              </p>
            </div>
            <button
              type="button"
              onClick={handleSendCustomEmbed}
              disabled={loading}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#2563EB] text-white text-xs font-black flex items-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>🚀 إرسال الإيمبد للروم الآن</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 text-xs">
            <div className="lg:col-span-7 space-y-3">
              <ChannelSelector
                lang={lang}
                label="الروم المستهدف للإرسال"
                value={embedChannel}
                onChange={setEmbedChannel}
                placeholder="الشات-العام"
              />
              <div>
                <label className="text-slate-300 font-bold block mb-1">عنوان الإيمبد</label>
                <input
                  type="text"
                  value={embedTitle}
                  onChange={(e) => setEmbedTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-300 font-bold block mb-1">وصف ومحتوى الإيمبد</label>
                <textarea
                  rows={4}
                  value={embedDesc}
                  onChange={(e) => setEmbedDesc(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-white"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">لون الإيمبد</label>
                  <input
                    type="text"
                    value={embedColor}
                    onChange={(e) => setEmbedColor(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">رابط صورة (اختياري)</label>
                  <input
                    type="text"
                    value={embedImageUrl}
                    onChange={(e) => setEmbedImageUrl(e.target.value)}
                    placeholder="https://..."
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 rounded-xl bg-[#2b2d31] p-4 border border-purple-500/40 space-y-2.5 self-start">
              <span className="text-[10px] text-purple-300 font-mono block">معاينة حية في ديسكورد (#{embedChannel})</span>
              <h4 className="text-sm font-black text-white">{embedTitle}</h4>
              <p className="text-xs text-slate-200 whitespace-pre-line leading-relaxed">{embedDesc}</p>
              <div className="text-[10px] text-slate-400 pt-2 border-t border-slate-700/60">{embedFooter}</div>
            </div>
          </div>
        </div>
      )}

      {/* 5. AUTO-EMOJI REACTOR (الإيموجي التلقائي) */}
      {view === 'auto_emoji' && (
        <div className="rounded-2xl bg-[#0d1017] border border-slate-800 p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <Smile className="w-5 h-5 text-amber-400" />
                <span>😍 نظام الإيموجي والرياكشن التلقائي (M7R Auto-Emoji Reactor)</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                يضيف البوت تلقائياً تفاعلات إيموجي فورية على كل رسالة أو صورة يرسلها الأعضاء في الرومات المحددة
              </p>
            </div>
            <button
              type="button"
              onClick={handleSaveAutoEmoji}
              disabled={loading}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black cursor-pointer"
            >
              💾 حفظ وتفعيل الإيموجي التلقائي
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
            <div className="space-y-3">
              <ChannelSelector
                lang={lang}
                label="إضافة روم للتفاعل التلقائي"
                value={autoEmojiChannelInput}
                onChange={(val) => {
                  setAutoEmojiChannelInput(val);
                  if (val && !autoEmojiChannels.includes(val)) {
                    setAutoEmojiChannels([...autoEmojiChannels, val]);
                  }
                }}
                placeholder="إبداعاتكم"
              />
              <div className="flex flex-wrap gap-2">
                {autoEmojiChannels.map((ch) => (
                  <span
                    key={ch}
                    className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 flex items-center gap-2"
                  >
                    <span>#{ch}</span>
                    <button
                      type="button"
                      onClick={() => setAutoEmojiChannels(autoEmojiChannels.filter((c) => c !== ch))}
                      className="text-rose-400 hover:text-rose-300 cursor-pointer"
                    >
                      ✕
                    </button>
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-slate-300 font-bold block">الإيموجيات المفعلة حالياً:</label>
              <div className="flex flex-wrap gap-2">
                {autoEmojis.map((em, i) => (
                  <span
                    key={i}
                    className="px-3 py-1.5 rounded-xl bg-slate-900 border border-purple-500/40 text-base flex items-center gap-2"
                  >
                    <span>{em}</span>
                    <button
                      type="button"
                      onClick={() => setAutoEmojis(autoEmojis.filter((_, idx) => idx !== i))}
                      className="text-xs text-rose-400 cursor-pointer"
                    >
                      ✕
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newEmojiInput}
                  onChange={(e) => setNewEmojiInput(e.target.value)}
                  placeholder="أضف إيموجي (مثال: ❤️ أو 💎)..."
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (!newEmojiInput.trim()) return;
                    setAutoEmojis([...autoEmojis, newEmojiInput.trim()]);
                    setNewEmojiInput('');
                  }}
                  className="px-4 py-2 rounded-xl bg-purple-600 text-white font-bold cursor-pointer"
                >
                  إضافة
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. MASS ROLE DM BROADCAST (الإرسال الجماعي) */}
      {view === 'mass_dm' && (
        <div className="rounded-2xl bg-[#0d1017] border border-slate-800 p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <Send className="w-5 h-5 text-emerald-400" />
                <span>📨 نظام الرسائل الجماعية حسب الرتب (M7R Mass Role Broadcast)</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                إرسال رسائل خاصة (DM) منسقة وآمنة لأعضاء السيرفر أو لرتبة محددة للإعلانات والتحديثات المهمة
              </p>
            </div>
            <button
              type="button"
              onClick={handleSendMassDm}
              disabled={loading}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#2563EB] text-white text-xs font-black flex items-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{loading ? 'جاري الإرسال الآمن...' : '🚀 بدء الإرسال الجماعي الآن'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">الرتبة المستهدفة</label>
              <select
                value={massTargetRole}
                onChange={(e) => setMassTargetRole(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-white"
              >
                <option value="all">جميع أعضاء السيرفر المتواجدين</option>
                {guildRoles.map((r) => (
                  <option key={r.id} value={r.id}>
                    @{r.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">عنوان الرسالة</label>
              <input
                type="text"
                value={massTitle}
                onChange={(e) => setMassTitle(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white"
              />
            </div>
            <div className="md:col-span-2">
              <label className="text-slate-300 font-bold block mb-1.5">محتوى الرسالة الجماعية</label>
              <textarea
                rows={4}
                value={massMessage}
                onChange={(e) => setMassMessage(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-white"
              />
            </div>
          </div>
        </div>
      )}

      {/* 7. 1-CLICK AI SERVER BUILDER (منشئ السيرفرات) */}
      {view === 'server_builder' && (
        <div className="rounded-2xl bg-[#0d1017] border border-slate-800 p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-purple-400" />
                <span>🏗️ منشئ السيرفرات الذكي بضغطة زر (M7R 1-Click AI Server Builder)</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                ينشئ البوت تلقائياً الرومات النصية والرتب الأساسية المنظمة لسيرفرك بضغطة زر واحدة
              </p>
            </div>
            <button
              type="button"
              onClick={handleBuildServer}
              disabled={loading}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#2563EB] text-white text-xs font-black flex items-center gap-2 shadow-lg cursor-pointer"
            >
              <Rocket className="w-4 h-4" />
              <span>{loading ? 'جاري بناء الرومات والرتب...' : '🚀 إنشاء الرومات والرتب تلقائياً الآن'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            {[
              {
                id: 'gaming' as const,
                title: '🎮 قالب سيرفر ألعاب وفعاليات',
                desc: 'ينشئ رومات القوانين، الأخبار، الشات العام، فعاليات وألعاب، فتح تذكرة، وتقديم الإدارة + 4 رتب احترافية.'
              },
              {
                id: 'community' as const,
                title: '🌟 قالب سيرفر مجتمع رسمي',
                desc: 'ينشئ رومات القوانين، الترحيب، المجلس العام، إبداعاتكم، الأذكار والقرآن، و m7r-ai + رتب الإدارة و VIP.'
              },
              {
                id: 'clan' as const,
                title: '⚔️ قالب سيرفر كلان وبطولات',
                desc: 'ينشئ رومات إعلانات الكلان، جدول البطولات، شات الكلان، تقديم الكلان، وإنشاء رومك + رتب قادة ونخبة الكلان.'
              }
            ].map((tpl) => (
              <button
                key={tpl.id}
                type="button"
                onClick={() => {
                  sound.playClick();
                  setSelectedTemplate(tpl.id);
                }}
                className={`p-4 rounded-2xl border text-right transition-all cursor-pointer space-y-2 ${
                  selectedTemplate === tpl.id
                    ? 'bg-purple-950/40 border-purple-500 text-white shadow-lg'
                    : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="text-sm font-black">{tpl.title}</div>
                <p className="text-[11px] text-slate-400 leading-relaxed">{tpl.desc}</p>
              </button>
            ))}
          </div>

          {builtSummary && (
            <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-xs space-y-2">
              <div className="font-black text-emerald-300">✅ تم إنشاء وتجهيز الهيكل التالي في سيرفرك:</div>
              <div className="text-slate-300">
                <strong>الرومات:</strong> {builtSummary.channels.map((c) => `#${c}`).join(' ، ')}
              </div>
              <div className="text-slate-300">
                <strong>الرتب:</strong> {builtSummary.roles.map((r) => `@${r}`).join(' ، ')}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
