import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Send,
  Zap,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Save,
  HelpCircle,
  Users,
  Award,
  Sparkles,
  RefreshCw,
  FileText,
  Eye
} from 'lucide-react';
import { StaffApplicationsConfig, StaffApplicationSubmission } from '../types';
import { ChannelSelector } from './ChannelSelector';
import { getAuthHeaders } from './TokenAuthGate';
import { sound } from '../utils/sound';

interface StaffApplicationsTabProps {
  lang: 'ar' | 'en';
  guildRoles?: { id: string; name: string; color?: string }[];
  serverName?: string;
  guildId?: string;
}

const OFFICIAL_PRESET_QUESTIONS = [
  'اسمك وعمرك؟',
  'كم لفلك وكم ساعة تتفاعل يومياً؟',
  'هل لديك خبرة إدارية سابقة؟',
  'هل تتعهد باحترام الجميع وأعضاء الإدارة؟',
  'ما الذي يميزك وماذا ستقدم لتطوير سيرفر M7R؟'
];

const GAMING_PRESET_QUESTIONS = [
  'لفلك في السيرفر؟',
  'عمرك؟',
  'كم معك فلوس / نقاط؟',
  'هل تحترم الجميع وأعضاء الإدارة؟',
  'كم ساعة تتواجد يومياً في الرومات والفعاليات؟'
];

const DEFAULT_STAFF_CONFIG: StaffApplicationsConfig = {
  isOpen: true,
  panelChannelName: 'تقديم-الإدارة',
  reviewChannelName: 'مراجعة-التقديمات',
  resultsChannelName: 'نتائج-التقديم',
  acceptedRoleName: '',
  staffRoleId: '',
  minAccountAgeDays: 7,
  minServerLevel: 1,
  embedTitle: '🛡️ بوابة التقديم على إدارة السيرفر | M7R STAFF PRO',
  embedDescription:
    'أهلاً بك في بوابة الانضمام لطاقم الإدارة الرسمي!\nيرجى قراءة الشروط جيداً ثم الضغط على زر **📝 التقديم على الإدارة الآن** بالأسفل وتعبئة الاستمارة بدقة:',
  embedColor: '#8A2BE2',
  bannerUrl: '/assets/aistudio/IMG_3117_2cec6847.jpeg',
  buttonLabel: '📝 التقديم على الإدارة الآن (Apply Now)',
  customAcceptMessage:
    '🎉 مبروك يا {user}! تم قبول تقديمك بنجاح في {server}، أهلاً بك معنا ونتمنى لك التوفيق!',
  customRejectMessage:
    'نشكرك يا {user} على تقديمك في {server}، نعتذر منك لم يتم قبول طلبك هذه المرة. السبب: {reason}، وحظاً أوفر في المرات القادمة!',
  questionCount: 4,
  questions: OFFICIAL_PRESET_QUESTIONS.slice(0, 4)
};

export const StaffApplicationsTab: React.FC<StaffApplicationsTabProps> = ({
  lang,
  guildRoles = [],
  serverName = 'M7R Server',
  guildId = 'default'
}) => {
  const isAr = lang === 'ar';
  const [config, setConfig] = useState<StaffApplicationsConfig>(DEFAULT_STAFF_CONFIG);
  const [submissions, setSubmissions] = useState<StaffApplicationSubmission[]>([]);
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'accepted' | 'rejected'>('all');
  const [selectedSubmission, setSelectedSubmission] = useState<StaffApplicationSubmission | null>(null);
  const [rejectModalTarget, setRejectModalTarget] = useState<StaffApplicationSubmission | null>(null);
  const [rejectReasonInput, setRejectReasonInput] = useState('عدم استيفاء شروط الخبرة المطلوبة حالياً');
  const [isSaving, setIsSaving] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [isQuickSettingUp, setIsQuickSettingUp] = useState(false);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [ideaPrompt, setIdeaPrompt] = useState<string>('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const targetGuildId = guildId || 'default';

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setFeedback({ type, text });
    setTimeout(() => setFeedback(null), 5500);
  };

  // Load config on tab open; background poll ONLY refreshes submissions so user input is never overwritten!
  const fetchStaffAppsData = async (loadConfig = false) => {
    try {
      const res = await fetch(`/api/guilds/${targetGuildId}/applications`, {
        credentials: 'include',
        headers: getAuthHeaders()
      });
      const data = await res.json();
      if (loadConfig && data?.config) {
        const rawQuestions = Array.isArray(data.config.questions)
          ? data.config.questions
              .map((q: any) => String(q || '').trim())
              .filter((q: string) => q.length > 0 && q !== '.')
          : [];
        const loadedCount = Math.min(
          5,
          Math.max(
            1,
            Number(data.config.questionCount) || (rawQuestions.length > 0 ? rawQuestions.length : 4)
          )
        );
        const mergedQuestions: string[] = [
          String(rawQuestions[0] || OFFICIAL_PRESET_QUESTIONS[0]),
          String(rawQuestions[1] || OFFICIAL_PRESET_QUESTIONS[1]),
          String(rawQuestions[2] || OFFICIAL_PRESET_QUESTIONS[2]),
          String(rawQuestions[3] || OFFICIAL_PRESET_QUESTIONS[3]),
          String(rawQuestions[4] || OFFICIAL_PRESET_QUESTIONS[4])
        ].slice(0, loadedCount);
        const sanitizedRoleId = String(data.config.staffRoleId || '').replace(/[^0-9]/g, '');

        setConfig({
          ...DEFAULT_STAFF_CONFIG,
          ...data.config,
          acceptedRoleName: String(data.config.acceptedRoleName || ''),
          staffRoleId: sanitizedRoleId,
          questionCount: loadedCount,
          questions: mergedQuestions
        });
      }
      if (Array.isArray(data?.submissions)) {
        setSubmissions(data.submissions);
      } else if (Array.isArray(data?.applications)) {
        setSubmissions(data.applications);
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetchStaffAppsData(true);
    const timer = setInterval(() => fetchStaffAppsData(false), 8000);
    return () => clearInterval(timer);
  }, [targetGuildId]);

  const buildSanitizedPayload = (cfg: StaffApplicationsConfig): StaffApplicationsConfig => {
    const cleanRoleId = String(cfg.staffRoleId || '').replace(/[^0-9]/g, '');
    const count = Math.min(5, Math.max(1, Number(cfg.questionCount) || 4));
    const cleanQuestions: string[] = [];
    for (let i = 0; i < count; i++) {
      const candidate = String(cfg.questions[i] || '').trim();
      const validVal =
        candidate && candidate !== '.'
          ? candidate
          : OFFICIAL_PRESET_QUESTIONS[i] || `السؤال ${i + 1}`;
      cleanQuestions.push(validVal);
    }
    return {
      ...cfg,
      resultsChannelName: String(cfg.resultsChannelName || '').replace(/^#/, '').trim(),
      acceptedRoleName: String(cfg.acceptedRoleName || '').trim(),
      staffRoleId: cleanRoleId,
      customAcceptMessage:
        String(cfg.customAcceptMessage || '').trim() || DEFAULT_STAFF_CONFIG.customAcceptMessage,
      customRejectMessage:
        String(cfg.customRejectMessage || '').trim() || DEFAULT_STAFF_CONFIG.customRejectMessage,
      questionCount: count,
      questions: cleanQuestions
    };
  };

  const handleToggleOpenStatus = async () => {
    sound.playShieldActivate();
    const nextOpen = !config.isOpen;
    const updated = buildSanitizedPayload({ ...config, isOpen: nextOpen });
    setConfig(updated);
    try {
      const res = await fetch(`/api/guilds/${targetGuildId}/applications/config`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify(updated)
      });
      const data = await res.json();
      if (data?.config) {
        setConfig((prev) => ({ ...prev, isOpen: data.config.isOpen }));
      }
      showToast(
        nextOpen
          ? '🟢 تم فتح باب التقديم على الإدارة وتحديث الحالة في ديسكورد فوراً!'
          : '🔴 تم إغلاق التقديم على الإدارة مؤقتاً!'
      );
    } catch {
      showToast('تعذر تحديث حالة التقديم.', 'error');
    }
  };

  const handleSaveConfig = async () => {
    setIsSaving(true);
    sound.playShieldActivate();
    const payload = buildSanitizedPayload(config);
    setConfig(payload);
    try {
      const res = await fetch(`/api/guilds/${targetGuildId}/applications/config`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data?.config) {
        setConfig({
          ...payload,
          ...data.config,
          acceptedRoleName: String(data.config.acceptedRoleName ?? payload.acceptedRoleName ?? ''),
          staffRoleId: String(data.config.staffRoleId ?? payload.staffRoleId ?? '').replace(/[^0-9]/g, ''),
          questionCount: Number(data.config.questionCount) || payload.questionCount || 4,
          questions:
            Array.isArray(data.config.questions) && data.config.questions.length > 0
              ? data.config.questions
              : payload.questions
        });
      }
      showToast('✅ تم حفظ وتحديث أسئلة وإعدادات التقديم بنجاح!');
    } catch {
      showToast('حدث خطأ أثناء حفظ الإعدادات.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeployPanel = async () => {
    setIsDeploying(true);
    sound.playShieldActivate();
    const payload = buildSanitizedPayload(config);
    setConfig(payload);
    try {
      await fetch(`/api/guilds/${targetGuildId}/applications/config`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify(payload)
      });

      const res = await fetch(`/api/guilds/${targetGuildId}/applications/deploy`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          channelName: payload.panelChannelName,
          config: payload
        })
      });
      const data = await res.json();
      if (res.ok && data?.success) {
        showToast(data.message || `🚀 تم نشر لوحة التقديم في #${payload.panelChannelName} بنجاح!`);
      } else {
        showToast(data?.error || 'تعذر نشر لوحة التقديم في ديسكورد.', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء نشر اللوحة.', 'error');
    } finally {
      setIsDeploying(false);
    }
  };

  const handleQuickSetup = async () => {
    setIsQuickSettingUp(true);
    sound.playShieldActivate();
    const payload = buildSanitizedPayload(config);
    try {
      const res = await fetch('/api/quick-setup/staff-apps', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ config: payload })
      });
      const data = await res.json();
      if (data?.config) {
        setConfig({
          ...payload,
          ...data.config,
          acceptedRoleName: String(data.config.acceptedRoleName ?? payload.acceptedRoleName ?? ''),
          staffRoleId: String(data.config.staffRoleId ?? payload.staffRoleId ?? '').replace(/[^0-9]/g, '')
        });
      }
      if (res.ok && data?.success) {
        showToast(
          data.message ||
            '⚡ تم الإعداد السريع لنظام التقديم! تم تجهيز روم التقديم وروم المراجعة ونشر اللوحة الفاخرة!'
        );
      } else {
        showToast(data?.error || 'تعذر تنفيذ الإعداد السريع.', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء الإعداد السريع.', 'error');
    } finally {
      setIsQuickSettingUp(false);
    }
  };

  const handleSubmissionAction = async (
    submissionId: string,
    action: 'accept' | 'reject' | 'interview',
    reason?: string
  ) => {
    setActionLoadingId(submissionId);
    sound.playShieldActivate();
    try {
      const res = await fetch(`/api/guilds/${targetGuildId}/applications/${submissionId}/action`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ submissionId, action, reason })
      });
      const data = await res.json();
      const updatedList = data?.submissions || data?.applications;
      if (Array.isArray(updatedList)) {
        setSubmissions(updatedList);
        if (selectedSubmission?.id === submissionId) {
          const updatedSub = updatedList.find((s: StaffApplicationSubmission) => s.id === submissionId);
          setSelectedSubmission(updatedSub || null);
        }
      }
      setRejectModalTarget(null);
      if (res.ok && data?.success) {
        showToast(data.message || '✅ تم تنفيذ الإجراء وتحديث حالة المتقدم في ديسكورد والخاص!');
      } else {
        showToast(data?.error || 'تعذر تنفيذ الإجراء.', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء تنفيذ الإجراء.', 'error');
    } finally {
      setActionLoadingId(null);
    }
  };

  const updateQuestion = (idx: number, val: string) => {
    const next = [...config.questions];
    while (next.length <= idx) {
      next.push(OFFICIAL_PRESET_QUESTIONS[next.length] || `السؤال ${next.length + 1}`);
    }
    next[idx] = val;
    setConfig((prev) => ({ ...prev, questions: next }));
  };

  const handleSelectQuestionCount = (count: number) => {
    sound.playClick();
    const clamped = Math.min(5, Math.max(1, count));
    const nextQuestions = [...config.questions];
    for (let i = 0; i < clamped; i++) {
      if (!nextQuestions[i] || nextQuestions[i].trim() === '' || nextQuestions[i].trim() === '.') {
        nextQuestions[i] = OFFICIAL_PRESET_QUESTIONS[i] || `السؤال ${i + 1}`;
      }
    }
    setConfig((prev) => ({
      ...prev,
      questionCount: clamped,
      questions: nextQuestions.slice(0, clamped)
    }));
  };

  const applyQuestionPreset = (presetType: 'official' | 'gaming') => {
    sound.playShieldActivate();
    const source = presetType === 'gaming' ? GAMING_PRESET_QUESTIONS : OFFICIAL_PRESET_QUESTIONS;
    setConfig((prev) => ({
      ...prev,
      questionCount: 4,
      questions: source.slice(0, 4)
    }));
    showToast(
      presetType === 'gaming'
        ? '🎮 تم تطبيق قالب سيرفر الألعاب والفعاليات (4 أسئلة نظيفة بدون نصوص مزعجة) — اضغط حفظ لتطبيقها!'
        : '✨ تم تطبيق قالب الأسئلة الرسمي الجاهز (4 أسئلة احترافية) — اضغط حفظ لتطبيقها!'
    );
  };

  const filteredSubmissions = submissions.filter((s) =>
    filterStatus === 'all' ? true : s.status === filterStatus
  );

  const pendingCount = submissions.filter((s) => s.status === 'pending').length;
  const acceptedCount = submissions.filter((s) => s.status === 'accepted').length;
  const rejectedCount = submissions.filter((s) => s.status === 'rejected').length;

  const optionalRoleId = String(config.staffRoleId || '').replace(/[^0-9]/g, '');
  const optionalRoleName = String(config.acceptedRoleName || '').trim();

  return (
    <div className="space-y-6">
      {/* Top Header & 1-Click Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2.5">
            <ShieldCheck className="w-6 h-6 text-purple-400" />
            <span>
              {isAr
                ? '🛡️ نظام التقديم على الإدارة الاحترافي (M7R Staff Applications Pro)'
                : '🛡️ M7R Staff Applications Pro'}
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isAr
              ? 'مركز متكامل لاستقبال ومراجعة طلبات الإدارة عبر نافذة Modal تفاعلية نظيفة (من 1 إلى 5 أسئلة)، بدون أي نصوص توضيحية مزعجة أو رتب إجبارية'
              : 'Complete staff recruitment system with 1-to-5 customizable Modal questions, zero clutter placeholders, and optional role assignment'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {/* 1-Click Toggle Open/Closed */}
          <button
            type="button"
            onClick={handleToggleOpenStatus}
            className={`px-4 py-2.5 rounded-xl text-xs font-black border flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
              config.isOpen
                ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/70'
                : 'bg-rose-950/70 border-rose-500/50 text-rose-300 hover:bg-rose-900/70'
            }`}
          >
            <span>{config.isOpen ? '🟢 التقديم مفتوح' : '🔴 التقديم مغلق'}</span>
          </button>

          {/* 1-Click Auto-Setup Wizard */}
          <button
            type="button"
            onClick={handleQuickSetup}
            disabled={isQuickSettingUp}
            className="px-4 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-black flex items-center gap-1.5 cursor-pointer transition-all whitespace-nowrap"
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <span>
              {isQuickSettingUp
                ? isAr
                  ? 'جاري الإعداد السريع...'
                  : 'Setting up...'
                : isAr
                ? '⚡ إعداد سريع بضغطة زر'
                : '⚡ 1-Click Quick Setup'}
            </span>
          </button>

          {/* Deploy Application Panel to Discord */}
          <button
            type="button"
            onClick={handleDeployPanel}
            disabled={isDeploying}
            className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black flex items-center gap-1.5 shadow-lg shadow-purple-950/50 cursor-pointer transition-all whitespace-nowrap"
          >
            <Send className="w-4 h-4" />
            <span>
              {isDeploying
                ? isAr
                  ? 'جاري النشر...'
                  : 'Deploying...'
                : isAr
                ? '🚀 إرسال لوحة التقديم للديسكورد'
                : '🚀 Deploy Panel to Discord'}
            </span>
          </button>

          {/* Save Settings & Questions Immediately */}
          <button
            type="button"
            onClick={handleSaveConfig}
            disabled={isSaving}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center gap-1.5 shadow-lg shadow-emerald-950/50 cursor-pointer transition-all whitespace-nowrap"
          >
            <Save className="w-4 h-4" />
            <span>
              {isSaving
                ? 'جاري الحفظ...'
                : isAr
                ? '💾 حفظ الأسئلة والإعدادات'
                : '💾 Save Questions & Config'}
            </span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl border text-xs font-bold flex items-center gap-2 ${
            feedback.type === 'success'
              ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
              : 'bg-rose-950/80 border-rose-500/50 text-rose-200'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {/* KPI Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl bg-[#0d1017] border border-slate-800 p-4">
          <span className="text-[11px] text-slate-400 block">إجمالي طلبات التقديم</span>
          <span className="text-2xl font-black text-white font-mono tabular-nums mt-1 block">
            {submissions.length}
          </span>
        </div>
        <div className="rounded-xl bg-[#0d1017] border border-slate-800 p-4">
          <span className="text-[11px] text-amber-400 block">قيد المراجعة (Pending)</span>
          <span className="text-2xl font-black text-amber-300 font-mono tabular-nums mt-1 block">
            {pendingCount}
          </span>
        </div>
        <div className="rounded-xl bg-[#0d1017] border border-slate-800 p-4">
          <span className="text-[11px] text-emerald-400 block">تم القبول (Accepted)</span>
          <span className="text-2xl font-black text-emerald-300 font-mono tabular-nums mt-1 block">
            {acceptedCount}
          </span>
        </div>
        <div className="rounded-xl bg-[#0d1017] border border-slate-800 p-4">
          <span className="text-[11px] text-rose-400 block">تم الرفض (Rejected)</span>
          <span className="text-2xl font-black text-rose-300 font-mono tabular-nums mt-1 block">
            {rejectedCount}
          </span>
        </div>
      </div>

      {/* Main Configuration & Live Discord Preview Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 7 Columns: Channels, Requirements, and 5-Question Builder */}
        <div className="lg:col-span-7 space-y-5">
          {/* 1. Channels, Optional Role & Requirements */}
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
              <Award className="w-4 h-4 text-purple-400" />
              <span>
                {isAr
                  ? '1. تحديد رومات التقديم والمراجعة والشروط'
                  : '1. Channels & Requirements'}
              </span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <ChannelSelector
                lang={lang}
                label={isAr ? 'روم لوحة التقديم (Application Panel Channel)' : 'Application Panel Channel'}
                value={config.panelChannelName}
                onChange={(ch) => setConfig({ ...config, panelChannelName: ch })}
                placeholder="تقديم-الإدارة"
                helperText={isAr ? 'الروم الذي يضغط فيه الأعضاء على زر التقديم' : 'Channel where members click Apply'}
              />

              <ChannelSelector
                lang={lang}
                label={isAr ? 'روم مراجعة الطلبات (Staff Review Logs Channel)' : 'Staff Review Channel'}
                value={config.reviewChannelName}
                onChange={(ch) => setConfig({ ...config, reviewChannelName: ch })}
                placeholder="مراجعة-التقديمات"
                helperText={
                  isAr
                    ? 'الروم الخاص بالإدارة العليا لقبول أو رفض الطلبات'
                    : 'Private staff channel for reviewing submissions'
                }
              />

              <div className="sm:col-span-2">
                <ChannelSelector
                  lang={lang}
                  label={
                    isAr
                      ? '📢 روم نتائج التقديم (Results Channel — اختياري لإعلان القبول والرفض في السيرفر)'
                      : '📢 Application Results Channel (Optional)'
                  }
                  value={config.resultsChannelName || ''}
                  onChange={(ch) => setConfig({ ...config, resultsChannelName: ch })}
                  placeholder="نتائج-التقديم"
                  helperText={
                    isAr
                      ? 'عند قبول أو رفض المتقدم يرسل البوت إيمبد النتيجة للعضو في الخاص وفي هذا الروم مع منشن العضو تلقائياً'
                      : 'Posts the accept/reject embed in this channel mentioning the applicant'
                  }
                />
              </div>

              <div className="sm:col-span-2 p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="text-slate-200 font-bold block">
                    {isAr
                      ? '🎖️ رتبة القبول (اختياري 100% — اتركه فارغاً للقبول بدون إسناد رتبة)'
                      : '🎖️ Accepted Role (100% Optional — Leave empty for no auto-role)'}
                  </label>
                  {(optionalRoleId || optionalRoleName) && (
                    <button
                      type="button"
                      onClick={() => setConfig({ ...config, staffRoleId: '', acceptedRoleName: '' })}
                      className="px-2.5 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900/70 border border-rose-500/40 text-rose-300 text-[11px] font-bold cursor-pointer"
                    >
                      🚫 إزالة الرتبة (قبول بدون رتبة)
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <span className="text-[11px] text-slate-400 block mb-1">
                      آيدي الرتبة أو اسمها (اختياري — اتركه فارغاً إذا لا تريد إعطاء رتبة)
                    </span>
                    <input
                      type="text"
                      value={config.staffRoleId || config.acceptedRoleName || ''}
                      onChange={(e) => {
                        const raw = e.target.value.trim();
                        const digits = raw.replace(/[^0-9]/g, '');
                        if (digits.length >= 15) {
                          setConfig({ ...config, staffRoleId: digits, acceptedRoleName: '' });
                        } else {
                          setConfig({ ...config, staffRoleId: '', acceptedRoleName: raw });
                        }
                      }}
                      placeholder="اختياري: اتركه فارغاً أو اختر رتبة..."
                      className="w-full bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-lg px-3 py-2 text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-400 block mb-1">
                      أو اختر من رتب السيرفر (اختياري)
                    </span>
                    <select
                      value={optionalRoleId || ''}
                      onChange={(e) => {
                        const selectedId = e.target.value;
                        if (!selectedId) {
                          setConfig({ ...config, staffRoleId: '', acceptedRoleName: '' });
                          return;
                        }
                        const found = guildRoles.find((r) => r.id === selectedId || r.name === selectedId);
                        if (found) {
                          setConfig({
                            ...config,
                            staffRoleId: found.id,
                            acceptedRoleName: found.name
                          });
                        }
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-300 text-xs"
                    >
                      <option value="">بدون رتبة تلقائية (قبول مباشر فقط)</option>
                      {guildRoles.map((r) => (
                        <option key={r.id} value={r.id}>
                          @{r.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1.5">
                  {isAr ? 'أقل عمر للحساب (بالأيام)' : 'Min Account Age (Days)'}
                </label>
                <input
                  type="number"
                  min={0}
                  max={3650}
                  value={config.minAccountAgeDays}
                  onChange={(e) =>
                    setConfig({ ...config, minAccountAgeDays: Math.max(0, Number(e.target.value) || 0) })
                  }
                  className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg px-3 py-2 text-white font-mono tabular-nums focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1.5">
                  {isAr ? 'أقل لفل في السيرفر' : 'Min Server Level'}
                </label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={config.minServerLevel}
                  onChange={(e) =>
                    setConfig({ ...config, minServerLevel: Math.max(0, Number(e.target.value) || 0) })
                  }
                  className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg px-3 py-2 text-white font-mono tabular-nums focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* 2. Custom 1-to-5 Question Modal Builder (Zero Placeholders, Question Count Selector + 1-Click Presets) */}
          <div className="rounded-xl border border-purple-500/40 bg-[#0d1017] p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-purple-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {isAr
                      ? '2. تخصيص عدد وأسئلة استمارة التقديم (1 إلى 5 أسئلة نظيفة 100%)'
                      : '2. Customize Modal Question Count & Questions (1 to 5 Clean Inputs)'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    تم إزالة جميع النصوص التوضيحية القديمة داخل المربعات (Zero Placeholders) وإخفاء أي خانة زائدة بالأسفل تلقائياً
                  </p>
                </div>
              </div>

              <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-[11px] text-emerald-300 font-bold">
                مربعات نظيفة 100% بدون Placeholders ✓
              </span>
            </div>

            {/* Question Count Selector (1 to 5) */}
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-black text-white block">
                  🔢 عدد أسئلة التقديم (Number of Questions):
                </span>
                <span className="text-[11px] text-slate-400">
                  اختر عدد الأسئلة المطلوب وسيتم إخفاء الخانات الزائدة فوراً في الموقع وفي نافذة ديسكورد
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((num) => {
                  const activeCount = Math.min(5, Math.max(1, Number(config.questionCount) || 4));
                  const isSelected = activeCount === num;
                  return (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleSelectQuestionCount(num)}
                      className={`w-10 h-9 rounded-xl font-mono text-xs font-black border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-purple-600 border-purple-400 text-white shadow-lg shadow-purple-950/60 scale-105'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-purple-500/50 hover:text-white'
                      }`}
                    >
                      {num}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 1-Click Ready Question Presets + Server Idea Generator */}
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => applyQuestionPreset('official')}
                  className="p-3 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/40 text-right transition-all cursor-pointer group"
                >
                  <div className="text-xs font-black text-purple-200 group-hover:text-white flex items-center justify-between">
                    <span>✨ قالب أسئلة رسمي جاهز (4 أسئلة احترافية)</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">بضغطة زر</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1 truncate">
                    اسمك وعمرك؟ · كم لفلك وكم ساعة تتفاعل؟ · خبرة إدارية؟ · احترام الجميع؟
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => applyQuestionPreset('gaming')}
                  className="p-3 rounded-xl bg-indigo-950/40 hover:bg-indigo-900/50 border border-indigo-500/40 text-right transition-all cursor-pointer group"
                >
                  <div className="text-xs font-black text-indigo-200 group-hover:text-white flex items-center justify-between">
                    <span>🎮 قالب سيرفر الألعاب والفعاليات (4 أسئلة)</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">بضغطة زر</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1 truncate">
                    لفلك في السيرفر؟ · عمرك؟ · كم معك فلوس / نقاط؟ · هل تحترم الجميع وأعضاء الإدارة؟
                  </p>
                </button>
              </div>

              {/* AI Idea Question Generator */}
              <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={ideaPrompt}
                  onChange={(e) => setIdeaPrompt(e.target.value)}
                  placeholder="💡 أو اكتب فكرة سيرفرك (مثال: سيرفر رول بلاي، كلان بطولات، متجر...) لتوليد أسئلة التقديم فوراً"
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                />
                <button
                  type="button"
                  onClick={() => {
                    sound.playShieldActivate();
                    const text = ideaPrompt.trim();
                    const isRp = text.includes('رول') || text.includes('شرط') || text.includes('واقع');
                    const isStore = text.includes('متجر') || text.includes('بيع') || text.includes('وسيط');
                    const generated = isRp
                      ? [
                          'اسمك وعمرك الحقيقي؟',
                          'ما هي خبرتك في قوانين الرول بلاي (RP)؟',
                          'كيف تتصرف عند رصد مخالفة داخل السيرفر؟',
                          'كم ساعة يمكنك التواجد يومياً في الرقابة؟'
                        ]
                      : isStore
                      ? [
                          'اسمك وعمرك؟',
                          'ما هي خبرتك في خدمة العملاء والتذاكر والوساطة؟',
                          'كم ساعة تتواجد يومياً للرد على التذاكر؟',
                          'هل تتعهد بالأمانة الكاملة واحترام العملاء؟'
                        ]
                      : [
                          `ما سبب رغبتك بالانضمام لإدارة (${text || serverName})؟`,
                          'كم عمرك وكم ساعة تتفاعل يومياً؟',
                          'ما هي خبرتك السابقة في إدارة السيرفرات والفعاليات؟',
                          'هل تتعهد باحترام جميع الأعضاء وقوانين الإدارة؟'
                        ];
                    setConfig((prev) => ({
                      ...prev,
                      questionCount: 4,
                      questions: generated
                    }));
                    showToast('🧠 تم توليد أسئلة التقديم المناسبة لفكرة سيرفرك! اضغط حفظ لتطبيقها.');
                  }}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#2563EB] text-white text-xs font-black cursor-pointer shrink-0"
                >
                  ⚡ توليد الأسئلة حسب الفكرة
                </button>
              </div>
            </div>

            {/* Dynamic Question Inputs (1 to questionCount ONLY) */}
            <div className="space-y-3 text-xs">
              {Array.from({ length: Math.min(5, Math.max(1, Number(config.questionCount) || 4)) }).map(
                (_, idx) => {
                  const q = config.questions[idx] ?? '';
                  const modalLabelPreview = (q.trim() || `السؤال ${idx + 1}`).slice(0, 45);
                  return (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-900/75 border border-slate-800 hover:border-purple-500/40 transition-colors space-y-2"
                    >
                      <div className="flex items-center justify-between text-[11px]">
                        <label
                          htmlFor={`staff-question-input-${idx}`}
                          className="text-purple-300 font-bold flex items-center gap-1.5"
                        >
                          <span className="w-5 h-5 rounded-md bg-purple-600/20 border border-purple-500/40 text-purple-300 font-mono font-black inline-flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <span>السؤال رقم {idx + 1} (عنوان الحقل في نافذة ديسكورد):</span>
                        </label>
                        <span className="text-[10px] text-emerald-400 font-mono">
                          {modalLabelPreview.length}/45 حرف
                        </span>
                      </div>

                      <input
                        id={`staff-question-input-${idx}`}
                        type="text"
                        maxLength={45}
                        value={q}
                        onChange={(e) => updateQuestion(idx, e.target.value)}
                        placeholder={`اكتب نص السؤال رقم ${idx + 1} هنا...`}
                        className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-lg px-3.5 py-2.5 text-white font-semibold focus:outline-none"
                      />
                    </div>
                  );
                }
              )}
            </div>

            {/* Prominent Save Questions & Config Button */}
            <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-slate-800">
              <span className="text-[11px] text-slate-400">
                ✅ يظهر في ديسكورد الآن فقط <strong className="text-purple-300">{Math.min(5, Math.max(1, Number(config.questionCount) || 4))} أسئلة</strong> نظيفة تماماً وبدون أي مربع خامس زائد أو نصوص قديمة!
              </span>
              <button
                type="button"
                onClick={handleSaveConfig}
                disabled={isSaving}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60 cursor-pointer transition-all whitespace-nowrap"
              >
                <Save className="w-4 h-4" />
                <span>
                  {isSaving
                    ? 'جاري الحفظ...'
                    : '💾 حفظ الأسئلة والإعدادات'}
                </span>
              </button>
            </div>
          </div>

          {/* 3. Panel Styling & Banner */}
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>3. تخصيص مظهر لوحة التقديم لسيرفر ({serverName})</span>
              </h3>
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setConfig({
                    ...config,
                    embedTitle: `🛡️ التقديم على إدارة ${serverName}`,
                    embedDescription: `أهلاً بك في بوابة الانضمام لطاقم إدارة ${serverName} الرسمي!\nيرجى قراءة الشروط جيداً ثم الضغط على زر **📝 التقديم على الإدارة الآن** بالأسفل وتعبئة الاستمارة بدقة:`
                  });
                }}
                className="px-2.5 py-1 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40 text-purple-200 text-[11px] font-black cursor-pointer"
              >
                🔄 ضبط باسم ({serverName}) تلقائياً
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  عنوان التقديم (مثال: التقديم على إدارة {serverName})
                </label>
                <input
                  type="text"
                  value={config.embedTitle}
                  onChange={(e) => setConfig({ ...config, embedTitle: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-300 font-semibold block mb-1">نص زر التقديم</label>
                <input
                  type="text"
                  value={config.buttonLabel}
                  onChange={(e) => setConfig({ ...config, buttonLabel: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                />
              </div>
            </div>
            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                الشروط والضوابط ووصف التقديم (خاص بسيرفر {serverName} فقط)
              </label>
              <textarea
                rows={3}
                value={config.embedDescription}
                onChange={(e) => setConfig({ ...config, embedDescription: e.target.value })}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
              />
            </div>

            {/* 4. Custom Accept & Reject Messages + Live Luxury Embed Preview */}
            <div className="pt-4 border-t border-slate-800 space-y-4">
              <h4 className="text-xs sm:text-sm font-black text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>4. تخصيص نص رسالة القبول والرفض (تُرسل في الخاص وفي روم نتائج التقديم)</span>
              </h4>
              <p className="text-[11px] text-slate-400">
                المتغيرات المتاحة: <code className="text-purple-300 font-mono">{'{user}'}</code> لمنشن العضو،{' '}
                <code className="text-purple-300 font-mono">{'{server}'}</code> لاسم السيرفر،{' '}
                <code className="text-purple-300 font-mono">{'{reason}'}</code> لسبب الرفض.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-emerald-950/25 border border-emerald-500/40 space-y-2">
                  <label className="text-emerald-300 font-black block text-xs">
                    ✅ نص رسالة القبول (Custom Accept Message):
                  </label>
                  <textarea
                    rows={3}
                    value={config.customAcceptMessage || DEFAULT_STAFF_CONFIG.customAcceptMessage}
                    onChange={(e) => setConfig({ ...config, customAcceptMessage: e.target.value })}
                    className="w-full bg-slate-950 border border-emerald-500/30 rounded-lg p-2.5 text-white text-xs"
                  />
                  <div className="p-2.5 rounded-lg bg-[#091815] border-r-4 border-r-emerald-400 text-[11px] text-slate-200">
                    <div className="font-black text-emerald-300 mb-1">معاينة إيمبد القبول (#10B981):</div>
                    {(config.customAcceptMessage || DEFAULT_STAFF_CONFIG.customAcceptMessage || '')
                      .replace(/\{user\}/g, '@Member')
                      .replace(/\{server\}/g, serverName)}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-rose-950/25 border border-rose-500/40 space-y-2">
                  <label className="text-rose-300 font-black block text-xs">
                    ❌ نص رسالة الرفض (Custom Reject Message):
                  </label>
                  <textarea
                    rows={3}
                    value={config.customRejectMessage || DEFAULT_STAFF_CONFIG.customRejectMessage}
                    onChange={(e) => setConfig({ ...config, customRejectMessage: e.target.value })}
                    className="w-full bg-slate-950 border border-rose-500/30 rounded-lg p-2.5 text-white text-xs"
                  />
                  <div className="p-2.5 rounded-lg bg-[#1A0B10] border-r-4 border-r-rose-500 text-[11px] text-slate-200">
                    <div className="font-black text-rose-300 mb-1">معاينة إيمبد الرفض (#EF4444):</div>
                    {(config.customRejectMessage || DEFAULT_STAFF_CONFIG.customRejectMessage || '')
                      .replace(/\{user\}/g, '@Member')
                      .replace(/\{server\}/g, serverName)
                      .replace(/\{reason\}/g, 'عدم استيفاء شروط التفاعل')}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right 5 Columns: Live Discord Panel & Modal Preview */}
        <div className="lg:col-span-5 space-y-4 sticky top-20">
          <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-purple-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">
                    معاينة لوحة التقديم لسيرفر ({serverName}) — ({Math.min(5, Math.max(1, Number(config.questionCount) || 4))} أسئلة)
                  </h3>
                  <p className="text-[11px] text-slate-400">الروم: #{config.panelChannelName}</p>
                </div>
              </div>
              <span className="text-[11px] text-purple-300 font-mono">
                {config.isOpen ? '🟢 مفتوح' : '🔴 مغلق'}
              </span>
            </div>

            {/* Simulated Discord Embed */}
            <div className="rounded-xl bg-[#313338] p-4 border border-slate-800 space-y-3">
              <div className="rounded-lg bg-[#2b2d31] p-4 border border-purple-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black text-white">{config.embedTitle}</h4>
                </div>
                <div className="text-xs font-mono text-purple-300 font-bold">
                  ╭─── ✦ {serverName} ✦ ───╮
                </div>
                <p className="text-xs text-slate-200 whitespace-pre-line leading-relaxed">
                  {config.embedDescription}
                </p>
                <div className="text-xs font-mono text-purple-300 font-bold">
                  ╰───────────────────────────╯
                </div>

                <div className="p-2.5 rounded-lg bg-[#1e1f22] text-[11px] space-y-1 text-slate-300">
                  <div>
                    📌 <strong>حالة التقديم:</strong>{' '}
                    <span className={config.isOpen ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {config.isOpen ? '🟢 التقديم مفتوح الآن' : '🔴 التقديم مغلق حالياً'}
                    </span>
                  </div>
                  <div>
                    ⏳ <strong>الحد الأدنى لعمر الحساب:</strong>{' '}
                    <span className="text-amber-300 font-mono">{config.minAccountAgeDays || 7} يوم</span>
                  </div>
                  {(optionalRoleId || optionalRoleName) && (
                    <div>
                      🎖️ <strong>الرتبة عند القبول:</strong>{' '}
                      <span className="text-purple-300 font-mono">
                        {optionalRoleId ? `<@&${optionalRoleId}>` : `@${optionalRoleName}`}
                      </span>
                    </div>
                  )}
                  <div className="pt-1 border-t border-slate-800/80 mt-1 space-y-0.5">
                    <strong className="text-purple-300 block">
                      📋 أسئلة النافذة المنبثقة ({Math.min(5, Math.max(1, Number(config.questionCount) || 4))} أسئلة نظيفة بدون نصوص قديمة):
                    </strong>
                    {config.questions
                      .slice(0, Math.min(5, Math.max(1, Number(config.questionCount) || 4)))
                      .map((q, idx) => (
                        <div key={idx} className="text-[10px] text-slate-300 truncate">
                          {idx + 1}. {q || `السؤال ${idx + 1}`}
                        </div>
                      ))}
                  </div>
                </div>

                {config.bannerUrl && (
                  <div className="rounded-lg overflow-hidden border border-slate-800 max-h-40 bg-black/50">
                    <img
                      src={config.bannerUrl}
                      alt="M7R Staff Banner"
                      referrerPolicy="no-referrer"
                      className="w-full h-36 object-cover"
                    />
                  </div>
                )}

                <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
                  {serverName} • M7R Staff Applications Pro 🛡️
                </div>
              </div>

              {/* Clean Single Apply Button for Members */}
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={!config.isOpen}
                  className={`px-4 py-2 rounded-lg text-xs font-bold text-white flex items-center gap-2 ${
                    config.isOpen ? 'bg-[#5865F2] hover:bg-[#4752C4]' : 'bg-slate-700 opacity-60'
                  }`}
                >
                  <span>{config.buttonLabel}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Applications Submissions Table */}
      <div className="rounded-xl border border-slate-800 bg-[#0d1017] p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-purple-400" />
            <div>
              <h3 className="text-sm font-black text-white">
                {isAr
                  ? '📋 جدول طلبات التقديم الحية (فرز وقبول/رفض مباشر من الموقع)'
                  : '📋 Live Staff Applications Table'}
              </h3>
              <p className="text-[11px] text-slate-400">
                أي قرار تتخذه هنا يُنفذ فوراً في ديسكورد (تحديث إيمبد المراجعة + إرسال رسالة خاص DM للمتقدم)
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {(
              [
                { id: 'all', label: `الكل (${submissions.length})` },
                { id: 'pending', label: `قيد المراجعة (${pendingCount})` },
                { id: 'accepted', label: `المقبولين (${acceptedCount})` },
                { id: 'rejected', label: `المرفوضين (${rejectedCount})` }
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilterStatus(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-colors whitespace-nowrap ${
                  filterStatus === tab.id
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}

            <button
              type="button"
              onClick={() => {
                sound.playClick();
                fetchStaffAppsData(true);
              }}
              className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 cursor-pointer"
              title="تحديث القائمة"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {filteredSubmissions.length === 0 ? (
          <div className="py-10 text-center space-y-2">
            <FileText className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-xs font-bold text-slate-400">
              لا توجد طلبات تقديم في هذا التصنيف حالياً. اضغط على (🚀 إرسال لوحة التقديم للديسكورد) لاستقبال طلبات الأعضاء!
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-start border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2.5 px-3 text-start">المتقدم</th>
                  <th className="py-2.5 px-3 text-start">عمر الحساب</th>
                  <th className="py-2.5 px-3 text-start">وقت التقديم</th>
                  <th className="py-2.5 px-3 text-start">الحالة</th>
                  <th className="py-2.5 px-3 text-start">الإجابات</th>
                  <th className="py-2.5 px-3 text-end">إجراءات الإدارة الفورية</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {filteredSubmissions.map((sub) => (
                  <tr key={sub.id} className="hover:bg-slate-900/50 transition-colors">
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={sub.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}
                          alt={sub.username}
                          referrerPolicy="no-referrer"
                          className="w-8 h-8 rounded-full object-cover border border-purple-500/40"
                        />
                        <div>
                          <div className="font-bold text-white">{sub.username}</div>
                          <div className="text-[10px] text-slate-400 font-mono tabular-nums">ID: {sub.userId}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-mono tabular-nums text-slate-300">
                      {sub.accountAgeDays} يوم
                    </td>
                    <td className="py-3 px-3 text-slate-400 font-mono tabular-nums">{sub.submittedAt}</td>
                    <td className="py-3 px-3">
                      {sub.status === 'pending' && (
                        <span className="text-amber-400 font-bold">⏳ قيد المراجعة</span>
                      )}
                      {sub.status === 'accepted' && (
                        <div>
                          <span className="text-emerald-400 font-bold">✅ مقبول</span>
                          {sub.reviewedBy && (
                            <span className="block text-[10px] text-slate-400">بواسطة {sub.reviewedBy}</span>
                          )}
                        </div>
                      )}
                      {sub.status === 'rejected' && (
                        <div>
                          <span className="text-rose-400 font-bold">❌ مرفوض</span>
                          {sub.rejectionReason && (
                            <span className="block text-[10px] text-slate-400 max-w-[180px] truncate">
                              السبب: {sub.rejectionReason}
                            </span>
                          )}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <button
                        type="button"
                        onClick={() => setSelectedSubmission(sub)}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-purple-300 font-bold cursor-pointer whitespace-nowrap"
                      >
                        عرض الأجوبة ({sub.answers.length}) 📄
                      </button>
                    </td>
                    <td className="py-3 px-3 text-end">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          disabled={actionLoadingId === sub.id || sub.status === 'accepted'}
                          onClick={() => handleSubmissionAction(sub.id, 'accept')}
                          className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold cursor-pointer whitespace-nowrap"
                        >
                          ✅ قبول المتقدم
                        </button>
                        <button
                          type="button"
                          disabled={actionLoadingId === sub.id || sub.status === 'rejected'}
                          onClick={() => {
                            setRejectModalTarget(sub);
                            setRejectReasonInput('عدم استيفاء شروط الخبرة المطلوبة حالياً');
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white font-bold cursor-pointer whitespace-nowrap"
                        >
                          ❌ رفض
                        </button>
                        <button
                          type="button"
                          disabled={actionLoadingId === sub.id}
                          onClick={() => handleSubmissionAction(sub.id, 'interview')}
                          className="px-2.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>مقابلة</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Selected Application Answers Modal */}
      {selectedSubmission && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xl rounded-2xl bg-[#0e111a] border border-purple-500/40 p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <img
                  src={selectedSubmission.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}
                  alt={selectedSubmission.username}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full border border-purple-500/50"
                />
                <div>
                  <h4 className="text-sm font-black text-white">
                    استمارة تقديم: {selectedSubmission.username}
                  </h4>
                  <p className="text-[11px] text-slate-400 font-mono">
                    ID: {selectedSubmission.userId} · عمر الحساب: {selectedSubmission.accountAgeDays} يوم
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedSubmission(null)}
                className="text-slate-400 hover:text-white text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {selectedSubmission.answers.map((item, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                  <div className="text-xs font-bold text-purple-300">
                    س{i + 1}: {item.question}
                  </div>
                  <div className="text-xs text-white whitespace-pre-line">{item.answer}</div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-800">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSubmissionAction(selectedSubmission.id, 'accept')}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black cursor-pointer"
                >
                  ✅ قبول المتقدم
                </button>
                <button
                  type="button"
                  onClick={() => handleSubmissionAction(selectedSubmission.id, 'interview')}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-black cursor-pointer"
                >
                  💬 فتح تذكرة مقابلة
                </button>
              </div>
              <button
                type="button"
                onClick={() => setSelectedSubmission(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Reason Mini-Modal */}
      {rejectModalTarget && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#0e111a] border border-rose-500/40 p-5 space-y-4 shadow-2xl">
            <h4 className="text-sm font-black text-white">
              ❌ رفض طلب التقديم ({rejectModalTarget.username})
            </h4>
            <p className="text-xs text-slate-400">
              اكتب سبب الرفض ليتم توثيقه في روم المراجعة وإرساله برسالة مهذبة إلى خاص المتقدم:
            </p>
            <textarea
              rows={3}
              value={rejectReasonInput}
              onChange={(e) => setRejectReasonInput(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-rose-500"
              placeholder="اكتب سبب الرفض..."
            />
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setRejectModalTarget(null)}
                className="px-3 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() =>
                  handleSubmissionAction(rejectModalTarget.id, 'reject', rejectReasonInput.trim())
                }
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black cursor-pointer"
              >
                تأكيد الرفض وإرسال السبب ❌
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
