export type ThreatSeverity = 'low' | 'medium' | 'high' | 'critical';

export interface ThreatLog {
  id: string;
  type: 'anti-nuke' | 'anti-spam' | 'anti-invite' | 'rogue-bot' | 'lockdown';
  action: string;
  target: string;
  executor: string;
  timestamp: string;
  severity: ThreatSeverity;
  details: string;
}

export type AdminImportanceTier = 'owner_deputy' | 'head_admin' | 'moderator' | 'helper' | 'custom';

export interface AdminRoleRateLimitPolicy {
  id: string;
  roleId: string;
  roleName: string;
  importanceTier: AdminImportanceTier;
  commandsPerMinute: number;
  actionOnExceed: 'block_warn' | 'timeout_5m' | 'strip_roles' | 'log_only';
  enabled: boolean;
}

export interface AdminCommandRateLimitConfig {
  enabled: boolean;
  defaultCommandsPerMinute: number;
  notifyUserOnLimit: boolean;
  logChannelAlert: boolean;
  policies: AdminRoleRateLimitPolicy[];
}

export interface AntiNukeConfig {
  enabled: boolean;
  exemptRoleId?: string;
  punishmentAction?: 'strip_roles' | 'ban' | 'kick' | 'timeout_24h';
  massBanLimit: number; // max bans in window
  massBanWindowSeconds: number;
  massBanAction: 'ban' | 'kick' | 'strip_roles' | 'timeout_24h';
  massKickLimit: number;
  massChannelDeleteLimit: number;
  massRoleDeleteLimit: number;
  massMessageDeleteLimit?: number;
  liveMessageDeleteMonitor?: boolean;
  antiDeleteChatNotice?: boolean;
  quarantineNewBots: boolean;
  blockWebhookCreation: boolean;
  whitelistUserIds: string[];
  adminRoleRateLimits?: AdminCommandRateLimitConfig;
}

export interface AntiSpamConfig {
  enabled: boolean;
  maxMessages: number;
  windowSeconds: number;
  maxMentions: number;
  blockRepetitiveMessages: boolean;
  blockEmojiFlood: boolean;
  punishment: 'timeout' | 'kick' | 'ban';
  timeoutDurationMinutes: number;
  trapChannels: string[];
}

export interface AntiInviteConfig {
  enabled: boolean;
  blockDiscordInvites: boolean;
  blockSuspiciousLinks: boolean;
  whitelistDomains: string[];
  exemptRoles: string[];
  action: 'delete_warn' | 'timeout' | 'kick';
}

export interface TicketMessage {
  id: string;
  author: string;
  avatar: string;
  isStaff: boolean;
  content: string;
  timestamp: string;
}

export interface Ticket {
  id: string;
  channelName: string;
  category: 'store' | 'support' | 'complaints' | 'partnerships';
  categoryLabel: string;
  user: {
    name: string;
    avatar: string;
    id: string;
  };
  claimedBy: string | null; // Staff name
  claimedById?: string | null;
  status: 'open' | 'claimed' | 'closed';
  createdAt: string;
  messages: TicketMessage[];
}

export type Language = 'ar' | 'en';

export interface TicketTranscriptItem {
  id: string;
  ticketId: string;
  channelName: string;
  categoryLabel: string;
  openedBy: string;
  openerName?: string;
  openedById: string;
  claimedBy: string | null;
  claimedById?: string | null;
  closedBy: string;
  closedById?: string;
  closeReason?: string;
  closedReason?: string;
  openedAt?: string;
  closedAt: string;
  durationText?: string;
  messagesCount: number;
  userMessagesCount?: number;
  staffRepliesCount?: number;
  staffRatingStars?: number;
  staffRating?: number;
  htmlContent?: string;
  messages: TicketMessage[];
}

export interface StaffRatingMember {
  userId: string;
  username: string;
  avatar?: string;
  claimedTickets: number;
  closedTickets: number;
  ticketsClaimed?: number;
  ticketsClosed?: number;
  ratingsCount: number;
  totalStars: number;
  averageStars: number;
  averageRating?: number;
  staffPoints: number;
  lastActiveAt: string;
}

export interface FileRoutingConfig {
  ticketFilesChannel: string;
  securityFilesChannel: string;
  dmTranscript: boolean;
  autoExportSecurityLogs?: boolean;
  updatedAt?: string;
}

export interface ArchiveFileItem {
  id: string;
  fileName: string;
  fileType: 'ticket_html' | 'security_log' | 'backup_json';
  typeLabel: string;
  channelRoutedTo: string;
  dmDelivered: boolean;
  createdBy: string;
  createdAt: string;
  sizeKB: number;
  content: string;
  ticketMeta?: {
    ticketId: string;
    channelName: string;
    openedBy: string;
    claimedBy: string | null;
    closedBy: string;
    messagesCount: number;
  };
}

export interface ReactionRoleItem {
  id: string;
  label: string;
  emoji: string;
  roleId?: string;
  roleName: string;
  roleColor?: string;
  colorHex?: string;
  buttonStyle?: 'Primary' | 'Secondary' | 'Success' | 'Danger';
  category: 'gaming' | 'pings' | 'special' | 'custom';
  description?: string;
}

export interface ReactionRolesConfig {
  enabled: boolean;
  channelId?: string;
  channelName?: string;
  targetChannelName?: string;
  panelTitle: string;
  panelDescription: string;
  embedColor: string;
  bannerUrl?: string;
  mode?: 'buttons' | 'select' | 'both';
  displayMode?: 'buttons' | 'select' | 'both';
  autoCreateMissingRoles: boolean;
  roles?: ReactionRoleItem[];
  items: ReactionRoleItem[];
}

export interface LiveServerStatCounter {
  id?: string;
  type: 'total_members' | 'online_members' | 'boosts_count' | 'role_members' | 'members' | 'online' | 'boosts' | 'gamers';
  enabled: boolean;
  format: string;
  formatTemplate?: string;
  channelId?: string;
  roleName?: string;
  currentValue?: number;
}

export interface LiveServerStatsConfig {
  enabled: boolean;
  categoryName: string;
  updateIntervalMinutes?: number;
  updateIntervalSec?: number;
  counters: LiveServerStatCounter[];
}

export interface AutoModConfig {
  enabled: boolean;
  antiDiscordInvite: boolean;
  antiExternalLinks: boolean;
  antiPhishing: boolean;
  antiCapsSpam: boolean;
  antiEmojiFlood: boolean;
  maxEmojis: number;
  maxMentions: number;
  punishment: 'delete_warn' | 'timeout_10m' | 'timeout_1h' | 'kick';
  logChannelName: string;
  whitelistedDomains: string[];
  exemptRoleNames: string[];
}

export interface AutoResponse {
  id: string;
  trigger: string;
  matchType: 'smart' | 'exact' | 'contains' | 'starts_with' | 'regex';
  responseMode?: 'text' | 'embed' | 'button' | 'reaction';
  reply: string;
  embedTitle?: string;
  embedColor?: string;
  embedImageUrl?: string;
  embedThumbnailUrl?: string;
  buttonLabel?: string;
  buttonUrl?: string;
  autoReaction?: string;
  deleteTriggerMessage?: boolean;
  replyMode?: 'reply' | 'send';
  autoDeleteSec?: number;
  cooldownSec?: number;
  allowedChannels?: string[];
  ignoredChannels?: string[];
  allowedRoles?: string[];
  ignoredRoles?: string[];
  enabled: boolean;
}

export interface TempVoiceConfig {
  enabled: boolean;
  panelTextChannelName: string; // e.g. 'انشاء-رومك'
  masterVoiceChannelName: string; // e.g. 'أنشئ رومك'
  categoryName: string; // e.g. '🎙️ | الرومات الصوتية المؤقتة'
  defaultRoomPrefix: string; // e.g. '🔊・'
  defaultUserLimit: number; // 0 = unlimited
  embedColor: string; // '#5865F2' or '#8A2BE2'
  autoDeleteEmpty?: boolean;
}

export interface TempVoiceRoomItem {
  channelId: string;
  channelName: string;
  guildId?: string;
  ownerId: string;
  ownerUsername: string;
  roomName?: string;
  locked: boolean;
  hidden: boolean;
  userLimit: number;
  memberCount: number;
  createdAt: string;
}

export interface QuranReciter {
  id: string;
  name: string;
  nameEn: string;
  streamUrl: string;
  description: string;
  style: 'murattal' | 'mujawwad' | 'radio';
}

export interface QuranScheduleSlot {
  id: string;
  startHour: number; // 0-23 (e.g. 6 for morning, 12 for dhuhr, 16 for asr, 20 for night)
  endHour: number;   // 0-23
  reciterId: string;
  label: string;
}

export interface Voice247Config {
  enabled: boolean;
  channelId: string;
  channelName: string;
  audioMode: 'quran' | 'radio' | 'silent';
  selectedReciter: string;
  autoReconnect: boolean;
  deafened: boolean;
  muted: boolean;
  scheduleEnabled?: boolean;
  scheduleSlots?: QuranScheduleSlot[];
}

export interface LevelUser {
  rank: number;
  name: string;
  avatar: string;
  level: number;
  xp: number;
  nextLevelXp: number;
  messagesCount: number;
}

export interface LevelConfig {
  enabled: boolean;
  xpMultiplier: number;
  levelUpChannel: string;
  cardTheme: 'crimson' | 'obsidian' | 'emerald';
}

export interface GiveawayItem {
  id: string;
  prize: string;
  winnersCount: number;
  channel: string;
  endsAt: string;
  entriesCount: number;
  status: 'active' | 'ended';
  winnerNames?: string[];
}

export interface BackupSnapshot {
  id: string;
  code: string;
  createdAt: string;
  rolesCount: number;
  channelsCount: number;
  sizeKB: number;
  note: string;
}

export interface VerificationConfig {
  enabled: boolean;
  channelName: string;
  verifiedRoleName: string;
  minAccountAgeDays: number;
  blockDefaultAvatar: boolean;
  captchaMode: 'button' | 'code_image' | 'web_shield';
}

export interface BotBasicSettings {
  botUsername: string;
  presenceStatus: 'online' | 'dnd' | 'idle' | 'invisible';
  activityType: 'PLAYING' | 'WATCHING' | 'LISTENING' | 'COMPETING' | 'STREAMING';
  activityText: string;
  streamingUrl: string;
  prefix: string;
  logChannelName: string;
  commandsChannelName?: string;
  keepAlive247: boolean;
  heartbeatIntervalSec: number;
  bioDescription?: string;
  websiteUrl?: string;
  termsUrl?: string;
  privacyUrl?: string;
  supportServerUrl?: string;
  bannerColor?: string;
}

export interface TicketPanelButton {
  id: string;
  label: string;
  emoji: string;
  style: 'Primary' | 'Secondary' | 'Success' | 'Danger';
  categoryDescription: string;
  targetCategoryName?: string;
  enabled: boolean;
}

export type ThemeMode = 'dark' | 'midnight' | 'cyber';

export interface TicketPanelConfig {
  storeName: string;
  embedTitle: string;
  embedDescription: string;
  embedColor: string;
  welcomeMessage: string;
  targetChannelName: string;
  ticketLogChannelName?: string;
  ticketCategoryName?: string;
  supportRoleName: string;
  buttons: TicketPanelButton[];
  // NEW ENHANCEMENTS:
  namingFormat?: 'number' | 'username' | 'username_number'; // النمط: رقم فقط | اسم العضو فقط | اسم العضو ورقم
  channelPrefix?: string; // e.g. 'ticket' or 'تذكرة'
  askReasonModal?: boolean; // طلب سبب فتح التذكرة في نافذة منبثقة (Modal)
  aiWaitingAssistant?: boolean; // تفعيل رسالة الانتظار الذكية وسؤال الذكاء الاصطناعي لحين وصول الإدارة
  waitingMessage?: string; // نص رسالة الانتظار المخصصة
  bannerUrl?: string; // بانر التكت الرسمي (يرفق في البانل وداخل التذكرة)
  transcriptChannelName?: string; // روم أرشيف التذاكر HTML
  ratingChannelName?: string; // روم تقييم الإداريين بالنجوم بعد إغلاق التذكرة
  ratingChannelId?: string; // معرف روم تقييم الإداريين
  autoHtmlTranscript?: boolean; // توليد وإرسال ملف HTML تلقائياً عند الإغلاق
}

export interface DiscordCommandConfig {
  id: string;
  name: string;
  aliases: string[];
  description: string;
  category: 'moderation' | 'channels' | 'voice' | 'security' | 'tickets' | 'islamic' | 'utility' | 'general';
  enabled: boolean;
  cooldownSec: number;
  customReply: string;
  allowedChannel?: string; // '' or 'all' means all channels, or specific channel name like 'cmd'
  isSensitive?: boolean; // true for dangerous/destructive commands hidden from regular server control mode
}

export type AccessRoleMode = 'bot_owner' | 'server_admin';

export interface GuildJoinNotification {
  id: string;
  guildId: string;
  guildName: string;
  guildIcon: string;
  memberCount: number;
  channelsCount: number;
  ownerId: string;
  ownerTag: string;
  joinedAt: string;
  permissionGranted: string;
  accessMode: 'server_admin';
  read: boolean;
}

export interface DiscordOAuthUser {
  id: string;
  username: string;
  globalName?: string;
  tag?: string;
  avatar?: string;
  email?: string;
  isLoggedIn?: boolean;
  isOwner?: boolean;
  isMasterOwner?: boolean;
}

export interface ConnectedGuildItem {
  id: string;
  name: string;
  icon: string;
  memberCount: number;
  channelsCount: number;
  rolesCount: number;
  ownerId?: string;
  owner?: boolean;
  hasBot?: boolean;
  botPresent?: boolean;
  permissions?: string;
  canManage?: boolean;
  hasManagePermission?: boolean;
  features?: string[];
}

export interface GuildChannelItem {
  id: string;
  name: string;
  type: 'text' | 'voice' | 'category';
  guildId?: string;
}

export interface AzkarItem {
  id: string;
  category: 'sabah' | 'masaa' | 'istighfar' | 'salawat' | 'quran' | 'general';
  categoryLabel: string;
  arabicText: string;
  virtue: string;
  source?: string;
  enabled: boolean;
}

export interface AzkarConfig {
  enabled: boolean;
  channelName: string;
  intervalMinutes: number; // e.g. 15, 30, 60, 180, 360
  embedColor: string;
  showVirtue: boolean;
  mentionRoleName?: string;
  items: AzkarItem[];
}

export interface HoneypotTrapConfig {
  enabled: boolean;
  channelName: string; // e.g. "🚫-ممنوع-الدخول" or "trap"
  punishment: 'ban' | 'kick' | 'timeout' | 'quarantine';
  timeoutDurationMinutes: number;
  deleteMessage: boolean;
  alertLogChannel: string;
  customWarningMessage: string;
  whitelistUserIds: string[];
  whitelistRoleNames: string[];
  totalTrapped: number;
}

export interface WelcomeConfig {
  enabled: boolean;
  channelName: string;
  messageMode: 'embed_and_text' | 'embed_only' | 'text_only';
  welcomeMessage: string;
  embedTitle: string;
  embedDescription: string;
  embedColor: string;
  bannerUrl: string;
  embedBannerUrl?: string;
  showAvatarThumbnail: boolean;
  showMemberCount: boolean;
  showAccountAge: boolean;
  footerText: string;
  embedFooter?: string;
  autoRoleEnabled: boolean;
  autoRoleName: string;
  botAutoRoleEnabled?: boolean;
  botAutoRoleName: string;
  sendDm: boolean;
  dmMessage: string;
  leaveEnabled: boolean;
  leaveChannelName: string;
  leaveMessage: string;
  mentionUser?: boolean;
  useEmbed?: boolean;
  vipCardEnabled?: boolean;
  vipCardTheme?: 'purple_chrome' | 'obsidian_gold' | 'cyber_emerald';
  cardTheme?: 'purple_chrome' | 'obsidian_gold' | 'cyber_emerald';
  cardHeadline?: string;
  cardSubtext?: string;
  cardAccentColor?: string;
  neonBorderColor?: string;
  rulesChannelName?: string;
  rolesChannelName?: string;
  ticketChannelName?: string;
  sayWelcomeEnabled?: boolean;
}

export interface StaffApplicationSubmission {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  accountCreatedAt: string;
  joinedAt: string;
  accountAgeDays: number;
  answers: { question: string; answer: string }[];
  status: 'pending' | 'accepted' | 'rejected';
  submittedAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  reviewChannelId?: string;
  reviewMessageId?: string;
  interviewChannelId?: string;
}

export interface StaffApplicationsConfig {
  isOpen: boolean;
  panelChannelName: string;
  reviewChannelName: string;
  resultsChannelName?: string;
  acceptedRoleName: string;
  staffRoleId?: string;
  minAccountAgeDays: number;
  minServerLevel: number;
  embedTitle: string;
  embedDescription: string;
  embedColor: string;
  bannerUrl: string;
  buttonLabel: string;
  customAcceptMessage?: string;
  customRejectMessage?: string;
  questionCount?: number;
  questions: string[];
}

export interface SuggestionItem {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  category: 'فكرة للبوت' | 'فكرة للسيرفر' | 'لعبة جديدة' | 'أمر جديد';
  content: string;
  upvotes: number;
  downvotes: number;
  status: 'implemented' | 'in_progress' | 'featured' | 'rejected' | 'pending';
  statusLabel: string;
  adminNote?: string;
  createdAt: string;
  discordMessageId?: string;
  discordChannelName?: string;
}

export type MiniGameKey =
  | 'roulette'
  | 'mafia'
  | 'out_of_loop'
  | 'bomb'
  | 'wyr'
  | 'mystery_box'
  | 'xo'
  | 'rps'
  | 'tournament'
  | 'chairs'
  | 'dice'
  | 'fastest'
  | 'fkk_rkb'
  | 'order'
  | 'reverse'
  | 'missing_letter'
  | 'emoji'
  | 'flags_capitals'
  | 'math'
  | 'riddles'
  | 'treasure';

export interface GameItemConfig {
  key: MiniGameKey;
  category?: 'party' | 'duel' | 'blitz';
  titleAr: string;
  titleEn: string;
  emoji: string;
  triggers?: string[];
  descriptionAr: string;
  enabled: boolean;
  pointsReward: number;
  xpReward: number;
}

export interface GamesShopItem {
  key: 'shield' | 'extraLife' | 'doublePoints' | 'doubleKick';
  id?: 'shield' | 'extraLife' | 'doublePoints' | 'doubleKick';
  nameAr: string;
  nameEn?: string;
  emoji: string;
  descriptionAr: string;
  price: number;
  enabled: boolean;
}

export interface GamePlayerPerks {
  shield: number;
  extraLife: number;
  doublePoints: number;
  doubleKick: number;
}

export interface GamesConfig {
  enabled: boolean;
  allowedChannel: string;
  hubChannelName: string;
  embedColor: string;
  autoTournamentEnabled?: boolean;
  autoTournamentIntervalSec?: number;
  games: GameItemConfig[];
  shopItems?: GamesShopItem[];
}

export interface GameLeaderboardPlayer {
  userId: string;
  username: string;
  avatar?: string;
  points: number;
  xp: number;
  wins: number;
  gamesPlayed: number;
  favoriteGame: string;
  lastWinAt: string;
  perks?: GamePlayerPerks;
}


